pub(crate) mod duration;
pub(crate) mod functions;
pub(crate) mod instant;
pub(crate) mod timeout;
pub use duration::PyDuration;
pub use functions::{py_duration, py_instant, sleep};
pub use instant::PyInstant;
use pyo3::prelude::*;
pub use timeout::PyTimeout;

pub fn pymod_add(m: &Bound<'_, PyModule>) -> PyResult<()> {
    std::sync::LazyLock::force(&instant::REPR_ANCHOR);
    m.add_class::<PyDuration>()?;
    m.add_class::<PyInstant>()?;
    m.add_function(wrap_pyfunction!(functions::py_instant, m)?)?;
    m.add_function(wrap_pyfunction!(functions::py_duration, m)?)?;
    m.add_function(wrap_pyfunction!(functions::sleep, m)?)?;
    Ok(())
}
