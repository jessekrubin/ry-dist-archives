#![doc = include_str!("../README.md")]
use std::io::{Read, Write};

use ::bzip2::Compression;
use ::bzip2::read::BzDecoder;
use ::bzip2::write::BzEncoder;
use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;
use ryo3_bytes::{ReadableBuffer, RyBytes};

fn rs_bzip2_encode(data: &[u8], quality: Compression) -> PyResult<RyBytes> {
    let mut bzip2_encoder = BzEncoder::new(Vec::new(), quality);
    bzip2_encoder.write_all(data.as_ref())?;
    let encoded = bzip2_encoder.finish()?;
    Ok(encoded.into())
}

fn rs_bzip2_decode(data: &[u8]) -> PyResult<RyBytes> {
    let mut decompressed = Vec::new();
    BzDecoder::new(data).read_to_end(&mut decompressed)?;
    Ok(decompressed.into())
}

// ============================================================================
// DEPRECATED ~ remove in v0.0.109 (along with this crate); use the stdlib `bz2`
// ============================================================================

#[pyfunction]
#[pyo3(
    signature = (data, quality = PyCompression::default()),
    text_signature = "(data, quality=6)",
    warn(
        message = "`bzip2_encode` is deprecated; use `bz2.compress` instead [removal: v0.0.109]",
        category = pyo3::exceptions::PyDeprecationWarning
    )
)]
#[expect(clippy::needless_pass_by_value)]
pub fn bzip2_encode(
    py: Python<'_>,
    data: ReadableBuffer,
    quality: PyCompression,
) -> PyResult<RyBytes> {
    let data: &[u8] = data.as_ref();
    py.detach(|| rs_bzip2_encode(data, quality.0))
}

#[pyfunction]
#[pyo3(
    signature = (data, quality = PyCompression::default()),
    text_signature = "(data, quality=6)",
    warn(
        message = "`bzip2` is deprecated; use `bz2.compress` instead [removal: v0.0.109]",
        category = pyo3::exceptions::PyDeprecationWarning
    )
)]
#[expect(clippy::needless_pass_by_value)]
pub fn bzip2(py: Python<'_>, data: ReadableBuffer, quality: PyCompression) -> PyResult<RyBytes> {
    let data: &[u8] = data.as_ref();
    py.detach(|| rs_bzip2_encode(data, quality.0))
}

#[pyfunction]
#[pyo3(warn(
    message = "`bzip2_decode` is deprecated; use `bz2.decompress` instead [removal: v0.0.109]",
    category = pyo3::exceptions::PyDeprecationWarning
))]
#[expect(clippy::needless_pass_by_value)]
pub fn bzip2_decode(py: Python<'_>, data: ReadableBuffer) -> PyResult<RyBytes> {
    let data: &[u8] = data.as_ref();
    py.detach(|| rs_bzip2_decode(data))
}

#[derive(Copy, Clone, PartialEq, Eq, Debug, Default)]
pub struct PyCompression(pub(crate) Compression);

impl PyCompression {
    #[must_use]
    pub const fn try_new(level: u32) -> Option<Self> {
        if let Some(c) = Compression::try_new(level) {
            Some(Self(c))
        } else {
            None
        }
    }
}

impl<'py> FromPyObject<'_, 'py> for PyCompression {
    type Error = pyo3::PyErr;
    fn extract(ob: Borrowed<'_, 'py, PyAny>) -> Result<Self, Self::Error> {
        if let Ok(level) = ob.extract::<u32>() {
            if let Some(c) = Compression::try_new(level) {
                return Ok(Self(c));
            }
        } else if let Ok(c) = ob.extract::<&str>() {
            match c {
                "fast" => return Ok(Self(Compression::fast())),
                "best" => return Ok(Self(Compression::best())),
                _ => {}
            }
        }
        Err(PyValueError::new_err(
            "Invalid compression level; valid levels are int 1..=9 or string 'fast' or 'best'",
        ))
    }
}

pub fn pymod_add(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(bzip2_decode, m)?)?;
    m.add_function(wrap_pyfunction!(bzip2_encode, m)?)?;
    m.add_function(wrap_pyfunction!(self::bzip2, m)?)?;
    Ok(())
}
