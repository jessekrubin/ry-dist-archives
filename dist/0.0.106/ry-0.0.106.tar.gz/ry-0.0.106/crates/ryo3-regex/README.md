# `ryo3-regex`

Wrapper around the `regex` crate for Python.

**NOT FULLY IMPLEMENTED:** crudely implemented (as of 2026-03-18)

- [crates.io](https://crates.io/crates/regex)
- [docs.rs](https://docs.rs/regex)

---

## TODO

- [ ] match the `regex` crate examples
- [ ] figure out how to support bytes/string maybe generics?
- [ ] Builders? - not sure if should be a part of the api at all...
  - [ ] `RegexBuilder`
  - [ ] `RegexSetBuilder`
- [x] `Regex` options/flags? kwargs or bitflags?
- [x] `RegexSet` python wrapper
