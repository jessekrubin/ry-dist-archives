# ACKNOWLEDGEMENTS

This project would not be possible without the incredible work of many others.

## THANK YOU

- pyo3 developers
- all authors of all libraries used in this project!
- burnt-sushi for the incredible set of libraries
- Kyle Barron for working on `pyo3-bytes` and letting me contribute to it
- The academy and the hollywood foreign press

---

If you want to be added to this list, please open an issue or PR! Happy to add
you if you've helped in any way!
