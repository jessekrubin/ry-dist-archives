use pyo3::BoundObject;
use pyo3::prelude::*;

use crate::RyBytes;
use crate::ryo3_bytes::RyBuffer;

/// Custom zero-copy bytes-like for extracting `&[u8]`
#[derive(Debug)]
pub enum ReadableBuffer<'a, 'py> {
    /// python `builtins.bytes`
    PyBytes(Borrowed<'a, 'py, pyo3::types::PyBytes>),
    /// Reference to a `ryo3-bytes::RyBytes` object
    RyBytes(Borrowed<'a, 'py, RyBytes>),
    /// Any object that supports the buffer protocol
    Buffer(::bytes::Bytes),
}

impl ReadableBuffer<'_, '_> {
    /// Return buffer as byte slice
    #[inline]
    pub fn as_slice(&self) -> &[u8] {
        self.as_ref()
    }

    /// Return buffer length
    #[inline]
    pub fn len(&self) -> usize {
        self.as_slice().len()
    }

    #[inline]
    /// Return `true` if buffer is empty
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Copy buffer into a new `bytes::Bytes` instance (always allocates)
    #[inline]
    pub fn copy_to_bytes(&self) -> bytes::Bytes {
        bytes::Bytes::copy_from_slice(self.as_slice())
    }

    /// Convert to `bytes::Bytes`, potentially zero-copy (cheap clone and refcount bump)
    #[inline]
    pub fn to_bytes(&self) -> bytes::Bytes {
        match self {
            ReadableBuffer::PyBytes(pb) => {
                let pbb = pyo3::pybacked::PyBackedBytes::from(pb.into_bound());
                bytes::Bytes::from_owner(pbb)
            }
            ReadableBuffer::RyBytes(rb) => {
                let rbb: &bytes::Bytes = rb.get().as_ref();
                rbb.clone()
            }
            ReadableBuffer::Buffer(b) => b.clone(),
        }
    }

    /// Consume and convert to `bytes::Bytes`; same as `to_bytes` but moves
    /// the `Buffer` variant instead of cloning/ref-bumping it
    #[inline]
    pub fn into_bytes(self) -> bytes::Bytes {
        match self {
            ReadableBuffer::PyBytes(pb) => {
                let pbb = pyo3::pybacked::PyBackedBytes::from(pb.into_bound());
                bytes::Bytes::from_owner(pbb)
            }
            ReadableBuffer::RyBytes(rb) => {
                let rbb: &bytes::Bytes = rb.get().as_ref();
                rbb.clone()
            }
            ReadableBuffer::Buffer(b) => b,
        }
    }

    /// Convert to `ryo3-bytes::RyBytes`, potentially zero-copy (cheap clone and refcount bump)
    #[inline]
    pub fn to_rybytes(&self) -> RyBytes {
        RyBytes::new(self.to_bytes())
    }

    /// Consume and convert to `ryo3-bytes::RyBytes` (see `into_bytes`)
    #[inline]
    pub fn into_rybytes(self) -> RyBytes {
        RyBytes::new(self.into_bytes())
    }
}

impl AsRef<[u8]> for ReadableBuffer<'_, '_> {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        match self {
            ReadableBuffer::PyBytes(pybytes) => pybytes.as_bytes(),
            ReadableBuffer::RyBytes(rybytes) => rybytes.get().as_slice(),
            ReadableBuffer::Buffer(buffer) => buffer.as_ref(),
        }
    }
}

impl<'a, 'py> FromPyObject<'a, 'py> for ReadableBuffer<'a, 'py> {
    type Error = PyErr;

    fn extract(ob: Borrowed<'a, 'py, PyAny>) -> Result<Self, Self::Error> {
        if ob.is_exact_instance_of::<pyo3::types::PyBytes>() {
            #[expect(unsafe_code)]
            let pybytes = unsafe {
                // SAFETY: wenodis (see line above)
                ob.cast_unchecked::<pyo3::types::PyBytes>()
            };
            Ok(Self::PyBytes(pybytes))
        } else if ob.is_exact_instance_of::<RyBytes>() {
            #[expect(unsafe_code)]
            let rybytes = unsafe {
                // SAFETY: wenodis (see line above)
                ob.cast_unchecked::<RyBytes>()
            };
            Ok(Self::RyBytes(rybytes))
        } else if let Ok(buffer) = ob.extract::<RyBuffer>() {
            Ok(Self::Buffer(::bytes::Bytes::from_owner(buffer)))
        } else {
            Err(pyo3::exceptions::PyTypeError::new_err(
                "Expected bytes, bytearray, or buffer-protocol object",
            ))
        }
    }
}

/// Exact size buffer reader
///
/// Use cases:
/// - hash functions with fixed-size keys/seeds
/// - binary protocol headers with fixed sizes
#[derive(Debug)]
pub struct ExactReadableBuffer<'a, 'py, const N: usize>(ReadableBuffer<'a, 'py>);

impl<'a, 'py, const N: usize> FromPyObject<'a, 'py> for ExactReadableBuffer<'a, 'py, N> {
    type Error = PyErr;

    fn extract(ob: Borrowed<'a, 'py, PyAny>) -> PyResult<Self> {
        let buf = ob.extract::<ReadableBuffer<'a, 'py>>()?;
        let len = buf.as_ref().len();

        if len == N {
            Ok(Self(buf))
        } else {
            Err(pyo3::exceptions::PyValueError::new_err(format!(
                "Expected buffer of exactly {N} bytes, got {len}"
            )))
        }
    }
}

impl<const N: usize> AsRef<[u8]> for ExactReadableBuffer<'_, '_, N> {
    fn as_ref(&self) -> &[u8] {
        self.0.as_ref()
    }
}

impl<const N: usize> ExactReadableBuffer<'_, '_, N> {
    /// Return buffer as fixed-size array reference
    ///
    /// # Panics
    ///
    /// Panics if the buffer length is not exactly `N` bytes, but this should
    /// never happen because the constructor checks the length, but wenodis.
    pub fn as_array(&self) -> &[u8; N] {
        self.0.as_ref().try_into().expect("wenodis: length-checked")
    }
}
