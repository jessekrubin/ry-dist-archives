# CHANGELOG

> All notable changes to this project will be documented in this file.
>
> pre-`0.1.0` releases may contain breaking changes, but imma do my best to tell
> ya; hit me up if you find a bug/breaking-change

---

## v0.0.105 [unreleased]

- cleanup
  - nuked old serialize v1 in `ryo3-json`
- `ryo3-jiff`
  - `Timestamp.from_second_f64` ~ float unix-seconds constructor; `NaN`/`inf` or
    too-damn-big raise `ValueError`
  - `Timestamp.from_second` and `SignedDuration.from_secs` take `int | float`
    (exact `int`/`float` only)
  - pydantic json-schemas dont say RFC 3339 `date-time`/`time` for types where
    it doesnt make sense (ajv errored w/rejection of ry's own output):
    - `DateTime` -> `format: "date-time-local"`
    - `Time` -> `format: "time-local"`
    - `ZonedDateTime` -> plain `string` w/ a description + example (no released
      json-schema format for RFC 9557 zoned datetimes yet)
- `ryo3-std`
  - `Duration.from_secs` takes `int | float` (exact `int`/`float` only)
- `ryo3-reqwest`
  - `list`/`tuple` request bodies (<=1024 items) are snagged right away as
    opposed to being consumed through the async/sync pumping mechanism on the
    tokio blocking pool. items are any bytes-like obj and get extracted via
    `ryo3_bytes::ReadableBuffer`
  - `Response.stream()` on known-length (not compressed) bodies takes frames
    that are already here w/o spawning the read-ahead pump which is faster for
    bodies barely over the prefetch threshold
  - SSE ~ `Response.sse()` / `BlockingResponse.sse()`
    - parser adapted from the `sse-core` crate (vendored and modified for more
      zero-copy)
    - parse only, no auto-reconnect. `last_event_id` + `retry` are on the stream
      so you can reconnect w/ `Last-Event-ID` yourself using a while loop
    - names follow the WHATWG/mdn `EventSource`/`MessageEvent` naming
      conventions
    - `max_event_size` kwarg (default 512KiB)
    - event `data` is zero-copy; `ServerSentEvent.bytes` gives it as `ry.Bytes`
    - `sse()` raises `ReqwestError` on 4xx/5xx
  - `ReqwestError` finally holds a `reqwest::Error` internally now
- **DEPRECATIONS**
  - deprecated `SignedDuration.__int__` and `Duration.__int__` [removal:
    v0.0.108]
    - for some insane reason i decided to make `__int__` return nanoseconds...
    - I probably thought it the more pure/precise thing to do, but in practice
      it is a huge pain in the ass

---

## v0.0.104 [2026-10-21]

- misc
  - clean up `pyo3::intern!()` usage
  - fix cert 4 https://emudhra.we-have-a-problem.com/ :wq
- `ryo3-jiff-core` (new crate)
  - all `Jiff*` new-types + their python conversions moved out of `ryo3-jiff`
    into `newts.rs`/`fns.rs`/`to_py.rs`/`from_py.rs`
  - `JiffPyDateTime` renamed to `JiffAnyDateTime`
  - `get_time_zone`/`bundled_tzdb` live here now
  - `ryo3-serde`'s `jiff` feature uses `ryo3-jiff-core` instead of `ryo3-jiff`
  - fix infinite recursion in `IntoPyObject for &JiffUnit`
- `ryo3-size`
  - bump `size` to v0.6.0
  - `scale: int | None` (0-255) for `fmt_size`, `Size.format`, and
    `SizeFormatter`
- `ryo3-tokio`
  - fix `AsyncFile.readline(size: int)` bug causing readline to throw away line
    part(s) beyond the buffer limit
  - the `*_async` fs fns now use `ry.Coroutine` w/ properly working cancelations
  - `AsyncReadDir.take()` defaults to `n=1` like the stub says (this was broke)
  - `AsyncFile` fixes:
    - no more process abort when an `AsyncFile` gets dropped w/ an op in flight
      (flush-on-drop called `block_on` from a tokio thread)
    - cancelled `close()` no longer loses unflushed writes
    - `await f` on an already-open file no longer re-opens it (which truncated
      `wb` files and tossed the write buffer which was dumb)
    - `seek()` w/ a bad `whence` or a negative position raises `ValueError` (not
      an `OSError`)
    - open errors are the right `OSError` subclass w/ `errno`/`filename` (same
      as builtin `open()`)
    - `closed` doesnt block the event loop if anothe file op is in flight
- `ryo3-tokio-rt`
  - `RyJoinHandle` aborts the tokio task on drop; so they dont leave their tasks
    running in the bg
  - `ry.ryo3.Coroutine`:
    - this is the core of this entire refactor and is something I have been
      percolating on since introducing usage of pyo3's `experimental-async`
      feature
    - the `ry.ryo3.Coroutine` is based on the pyo3 `PyCoroutine` implementation
      but builds it out quite a bit
    - it is specifically designed to be used w/ tokio and the primary api
      consists of:
      - `ryo3_tokio_rt::done_coro`: coroutine that is "done" and immediately
        ready
      - `ryo3_tokio_rt::pyloop_coro`: coroutine that runs on the python asyncio
        loop
      - `ryo3_tokio_rt::tokio_coro`: coroutine that runs on the Tokio runtime
- `ryo3-tokio-websockets`
  - `WebSocket` methods return `ry.Coroutine`
  - `ready_state` follows mdn
    ([readyState](https://developer.mozilla.org/en-US/docs/Web/API/WebSocket/readyState)):
    - a new (not yet awaited) ws is `0`/CONNECTING and `closed` is `False` (was
      `3`/`True`)
    - a failed connect leaves it `3`/CLOSED
    - `close()` on a never-opened ws -> `3`
  - cancelling `recv`/`send`/connect works in every build and the ws is
    ok/usable
  - `close()` always finishes (bounded by `close_timeout`), even if the
    `close()` call itself gets cancelled
- `ryo3-reqwest`
  - small bodies (known length <= 64kb) that are already there get read w/ the
    head so `bytes()`/`text()`/`json()`/`stream()` dont need another round trip;
    never waits on a slow body and body errors still raise on read
  - same small-body prefetch for the `BlockingClient` ~ ~30-40% faster blocking
    requests for bodies <= 64kb (no body-pump task per response)
  - async `Client` methods, `fetch`, `Response.bytes/text/json` and
    `ResponseStream.readall/take/collect` return `ry.Coroutine`
  - no more gil grabbing on tokio threads: async iterable request bodies get
    started/cancelled via `LoopHandle`
  - async iterable request bodies start pumping (in their own eager task on
    3.12+) as soon as a request is `await`-ed
  - requests w/ an async iterable body can be made w/o a running loop and/or
    awaited on a different loop (eg `run_coroutine_threadsafe`) ~ the body runs
    on whichever loop awaits the request
  - `http2_max_frame_size` default was upped to 64kb (was previously 16kb as
    defined by hyper); pass `None` for the old behavior
  - fewer copies: `text()` decodes straight into the python `str` (was body ->
    `String` -> `str`) and `ResponseStream.readall()` hands back a lone chunk
    w/o copying it (which is sick)

---

## v0.0.103 [2026-10-16]

- pyo3 v0.30.x
  - rm skip_from_py_object did this:
    - `rg "" -l | xargs -t -n1 sed -i 's///g'`
    - `rg "    skip_from_py_object,?$" -l | xargs -t -n1 sed -i '/    skip_from_py_object,\?$/d'`
    - `just fmt`
- python `v3.15`
- `ryo3-json-ser`
  - better reserving and org for writer
  - use weird tricks to get better micro opts for ints/floats
- `ryo3-jiff`
  - cleaned up jiff-py-conversions and adopted conversion for
    `datetime.datetime` to `jiff::Zoned` based on pyo3-v0.30.0
  - no more `pyo3/jiff-02` feature; all `datetime.*` conversions are ry
    new-types (pyo3's `Zoned` -> `datetime` sets the wrong `fold` on fall-back)
  - removed `Py_LIMITED_API` conversion branches (pyo3 v0.30 datetime `Access`
    traits work on abi3)
  - `ry.offset(hours)` raises `ValueError` for out of range hours instead of
    panicking, whoops missed that one
  - `SignedDuration.to_pytimedelta()` raises `OverflowError` (was `ValueError`)
    when too big for `datetime.timedelta` (same as python)
  - `ZonedDateTime.from_pydatetime(naive)` raises `TypeError` (was `ValueError`)
- `ryo3-bytes`
  - internal rename `PyBytes` struct to `RyBytes` to avoid confusion with
    `pyo3::types::PyBytes`
  - flip-flopped export alias so one/you can still `use ryo3_bytes::PyBytes`
  - fixed panic on negative-step slices that run to index 0 (e.g. `b[::-1]`);
    via `PySliceMethods::indices`
  - `Bytes.__mul__` & `Bytes.__rmul__`:
    - `Bytes * n` / `n * Bytes` where `n <= 0` returns `b""` (was `TypeError`)
      as opposed to erroring
    - `Bytes * n` / `n * Bytes` where `n` is too big may raise `OverflowError`
      or `MemoryError` instead of panicking/aborting
  - `b"" in Bytes(...)` returns `True` (was a panic); `__contains__` uses the
    same substring search as `find`/`index`
  - `Bytes.expandtabs` w/ a huge result raises `OverflowError`/`MemoryError`
    (was an abort)
- `ryo3-std`
  - `Duration.from_secs_f32`/`from_secs_f64` raise `ValueError` for negative
    seconds (was `TypeError`)
  - client `timeout`/`read_timeout`/`connect_timeout` that are too big raise
    `OverflowError` (was a panic)
  - `FileReadStream`/`ry.read_stream` w/ a huge `read_size`/`take(n)` no longer
    aborts; chunks are exactly `read_size` except the last
- `ryo3-tokio`
  - `ry.asleep`/`ry.sleep_async` raise `ValueError` for negative/nan seconds and
    `OverflowError` for inf/too-big seconds (was a panic on a tokio worker);
    raised before the sleep is scheduled
- `ryo3-reqwest`
  - async iterable request stream bodies are pumped by a faux py "coroutine"
    that forwards the iterator's awaitables (no task per chunk(!!!))
  - response streams are lazily read ahead by a background task (up to 8
    chunks); `anext()` skips making a future when a chunk ready!
  - `take()`, `collect()` and blocking `__next__` respect `min_read_size` which
    i forgot to do previously for everything but `__anext__`
  - `ResponseStream` does `async with` + `close()` and `BlockingResponseStream`
    does `with` + `close()` ~ closing drops the body + stops the read-ahead

---

## v0.0.102 [2026-10-09]

- `pyo3-v0.29.3`
- `ryo3-brotli`
  - update `brotli` to v9
  - update `async-compression`/`compression-codecs` transitive deps which use
    `brotli` v9
- `ryo3-jiff`
  - fix `__radd__` impls for temporal types used to add duration types that have
    an `__add__` method that is not aware of the ry-jiff-temporal types
    (`datetimes.timedelta` and `ry.Duration`)
- `ryo3-reqwest`
  - reworked streaming request bodies (sync + async iterables); python is no
    longer pulled from on the tokio workers
    - fixes problem based on benchmark here:
      https://github.com/curioswitch/pyqwest/issues/247#issuecomment-5988864560
    - sync iters are polled/pull on a sync pool
    - async iters are polled/pull on the python event loop by a done-callback
      pump (which is basically a weird rust re-write of the pyo3-async-runtimes
      into-stream-v2)
    - chunks are forwarded to reqwest via channel
    - request cancellation (or server hangup) cancels pending tasks `__anext__`
      so a generator's `finally` fires
    - no longer uses the `pyo3-async-runtimes` `unstable-streams` feature
- stubs/types
  - fix positional dunder stubs
- `ryo3-jiter`
  - added `ry.JSONDecodeError`
    - class which may or may not carry the offending JSON document
    - WHY? primarily for when `data = await response.json()` fails and ya need
      the response body
- `ryo3-json` / `ryo3-json-ser`
  - custom vector based serializer implementation inspired by `serde_json` and
    `flexon`; gives a solid 5-10% performance boost
  - use `jiter` + the new serializer for the `JSON.fmt` and `JSON.minify` funcs
  - json-string-escaping (swar aka poor-mans simd):
    - faster escaping via a SWAR method for detecting chars that need escaping
    - [REF-SWAR-JSON-ESCAPING](https://lemire.me/blog/2025/04/13/detect-control-characters-quotes-and-backslashes-efficiently-using-swar/)
    - Notes:
      - appears to be about 1.5-3x faster than the previous version adapted from
        `serde-json`
      - I (jesse) was in some sort of fugue state the other day and wrote
        several versions of the SWAR json escaping function; there were 14
        versions in total and I eventually settled on `escape_into_swar_v9`
        which (is the current `escape_into_swar`) implementation. I tried
        re-writing v9 to be more readable but for some weird reason none of the
        re-writes preserved the very slight performance edge :/.
- `ryo3-serde`
  - support sorting keys in json target
  - use dict serializer for dict-subclasses as opposed to the mapping serializer

---

## v0.0.101 [2026-09-23]

- `ryo3-core`/`ryo3-serde`
  - `BorrowedListIter` added for no rec-count-bumpage when iterating over lists
- `ryo3-zstd`
  - update `zstd` to `0.14.0`
  - update `zstd-safe` to `0.8.0`
- `ryo3-reqwest`
  - update `reqwest` to `0.13.5` && add newly exposed `http1_max_headers` to
    config/kwargs (default is 100) ~
    [reqwest-0.13.5](https://github.com/seanmonstar/reqwest/releases#release-v0.13.5)
  - faster/more-accurate kwarg ingestion (cpython only); its a wee bit faster,
    BUT it also flags invalid/extra kwargs
- `ryo3-jiter`
  - update `jiter` to `0.17.0` (which AFAICT adds simd parsing!?)
- `cargo update`
- `ryo3-bytes`
  - use `pyo3::ffi::compat::Py_HashBuffer` for `__hash__`
  - cache the hash in a `std::sync::atomic::AtomicIsize` w/ `-1` being not
    computed
  - remove `ahash` dep

---

## v0.0.100 [2026-09-04]

- `ryo3-crc32fast`
  - `crc32` class hasher implementation following the ry hasher conventions; I
    need this soon and need it to be fast. The `crc32fast` crate is already used
    by the `flate2` crate
- `ryo3-flate2`
  - switch from `miniz_oxide` to `zlib-rs`
- `ryo3-jiff`
  - `ry.TimeSpan`
    - property `is_absolute`; is the timespan composed of only positive/0 units
    - property `is_calendar`; `True` if the timespan contains any calendar units
    - property `is_exact`; `True` if the timespan contains NO calendar units
    - `friendly()` takes designator `"compact"`, `"human"`, `"human-time"`,
      `"short"`, and `"verbose"`; defaults to `"compact"`
    - `__abs__()` and `abs()` now return the same immutable instance when the
      span is already non-negative
    - `add`/`sub` now accept kwargs OR `other` positional arg; if both given
      err, if neither given, err
  - `ry.SignedDuration`
    - added property `is_absolute`; `True` when the duration is non-negative
    - `friendly()` also now accepts the designator `"compact"`, `"human"`,
      `"human-time"`, `"short"`, and `"verbose"` like `ry.TimeSpan.friendly()`;
      default `"compact"`
    - `abs()` and `abs(duration)` now return the same immutable instance when
      the duration is already non-negative
  - type annotations changed `_AbsoluteUnit` to `_ExactUnit`
- `ryo3-core`
  - handle possible UB in `ryo3_core::pystring_ascii_new` as pointed out in
    [jiter/261](https://github.com/pydantic/jiter/issues/261)
- `ryo3-serde`
  - added serialization target for future serializer specific optimizations

---

## v0.0.99 [2026-07-31]

- `ryo3-dirs`
  - added docstrings
- `ryo3-jiff`
  - update to latest jiff and fix error msg changes that occurred
- `ryo3-http`
  - update to `v1.5.x` with new `Query` http method
- `ryo3-reqwest`
  - added request client query method(s)/support
- type-annotations
  - moved all typed-dicts for jiff module in to `ry.ryo3._jiff.pyi` type
    annotation(s) file
- `cancel_handle`
  - added `CancelHandle` support for `ryo3-tokio`, `ryo3-tokio-websockets`
  - `ryo3-tokio-rt`: refactored `on_tokio_py_cancel` to spawn task w/ manual
    abort which appears faster and less memory intensive

---

## v0.0.98 [2026-07-16]

- docs/types
  - Converted (painstakingly/by-hand) all (public) docstrings from
    "google-style" to "numpydoc-style"
- `ryo3-ulid`
  - Update to ulid v2.0.1
  - Added class-attrs:
    - `ULID.MAX` => `ULID("7ZZZZZZZZZZZZZZZZZZZZZZZZZ")`
    - `ULID.NIL` => `ULID("00000000000000000000000000")`
    - `ULID.TIME_BITS` => `48`
    - `ULID.RAND_BITS` => `80`
- `ryo3-lz4rip`
  - Initial wrapper library for lz4 compression/decompression
- `ryo3-jiff`
  - updated to `v0.16.0`
- `ryo3-serde`
  - dictionary serialization
    - exact map lengths and no double `len()` calls
    - hot path for string keys (which is the primary use case)

---

## v0.0.97 [2026-06-26]

- `ryo3-globset` - redesigned from the ground up
  - **BREAKING** `ry.Glob` no longer allows negation (`!`-prefixed patterns)
  - `ry.GlobSet` and `ry.Globster` constructors take (`*args`)
  - `GlobOptions` internal refactoring
  - `__repr__` includes kwargs when non-default
  - `Globster` uses gitignore-style last match wins for negative patterns
  - split src files up
- `ryo3-bytes`
  - constructor returns same instance if input is already `ry.Bytes`
  - added `Bytes.clone()` method which clones internally returning new instance
  - `__add__` now accepts any `ReadableBuffer` (not just another `Bytes`);
    returns self/other unchanged when one operand is empty
- `ryo3-fspath`
  - `__repr__` uses `posix_display()` for correct cross-platform path rendering
  - `parents` returns internal lazy iter (`PyFsPathAncestors`)
  - `drive`, `extension`, `file_name`, `file_prefix`, `file_stem`, `name` return
    `OsString`
  - `anchor` uses `OsStr::display()` instead of `to_string_lossy()`
- `ryo3-jiter`
  - `JiterParseOptions` gains builder methods: `new()`, `with_allow_inf_nan()`,
    `with_cache_mode()`, `with_partial_mode()`, `with_catch_duplicate_keys()`
  - re-exports `FloatMode`, `PartialMode`, `PythonParse`, `StringCacheMode`,
    `map_json_error` as `pub use`
- `ryo3-jiff`
  - update jiff to 0.2.29
  - add `ry.ZonedDateTime.UNIX_EPOCH`
- `_ryo3-dev` cleaned out

---

## v0.0.96 [2026-06-12]

- pyo3-v0.29
- `ryo3-jiff`
  - **BREAKING:** removed deprecated fns slated for removal:
    - `ry.SignedDuration.from_isoformat` (use `ry.SignedDuration.fromisoformat`
      instead)
    - `ry.TimeSpan.parse_common_iso` (use `ry.TimeSpan.fromisoformat` instead)
    - `ry.TimeSpan.from_isoformat` (use `ry.TimeSpan.fromisoformat` instead)
  - refactored `__sub__`/`sub` implementations to be cleaner
  - internal refactoring
- `ryo3-walkdir`
  - **BREAKING:** removed support for `objects=False` so iterators always yield
    `ry.WalkDirEntry`
  - **BREAKING:** `ry.WalkdirGen` renamed to `ry.WalkDirIter`
- misc
  - all `__repr__` impls now use `std::fmt::Display`
- `ry.ulid` submodule removed; use `ry.ULID`
- `ry.dirs` submodule removed; use `ry.XYZ_dir()` instead (eg `ry.home_dir()`)

---

## v0.0.95 [2026-06-04]

**NOTE:**

- build
  - fix cicd git-hash embedding
- `ryo3-fnv`
  - renamed `key` to `seed` for `xxhash` parity and bc it is a better term for
    the hash
  - added clsattr `ry.fnv1a.default_seed`
  - added static-method
    `ry.fnv1a.oneshot_int(data: Buffer, *, seed: int | bytes = 0xCBF29CE484222325) -> int: ...`
  - added static-method
    `ry.fnv1a.oneshot_hex(data: Buffer, *, seed: int | bytes = 0xCBF29CE484222325) -> str: ...`
- `ryo3-twox-hash`
  - added class-level one-shot helpers to xxhash hashers (`xxh32`, `xxh64`,
    `xxh3_64`, `xxh3_128`):
    - `ry.xxh32.oneshot_int(data, *, seed=0) -> int`
    - `ry.xxh32.oneshot_hex(data, *, seed=0) -> str`
    - `ry.xxh64.oneshot_int(data, *, seed=0) -> int`
    - `ry.xxh64.oneshot_hex(data, *, seed=0) -> str`
    - `ry.xxh3_64.oneshot_int(data, *, seed=0, secret=...) -> int`
    - `ry.xxh3_64.oneshot_hex(data, *, seed=0, secret=...) -> str`
    - `ry.xxh3_128.oneshot_int(data, *, seed=0, secret=...) -> int`
    - `ry.xxh3_128.oneshot_hex(data, *, seed=0, secret=...) -> str`
- `ryo3-aws-lc`
  - added static-methods to `ry.<AWS-HASHER>.oneshot_hex(data)`
- `ryo3-dirs`
  - moved `*_dir` to ry package rooot
  - **DEPRECATED:** deprecated `ry.dirs.*` and all the non-suffixed methods
- `ryo3-ulid`
  - exposed `ry.ULID` at the `ry` root; `ry.ulid.ULID` remains as a deprecated
    compatibility export until `0.0.96`
- `ryo3-uuid`
  - added `ry.UUID.NIL` and `ry.UUID.MAX` to match python3.14
  - moved `UUID`, `uuid1`, `uuid3`, `uuid4`, `uuid5`, `uuid6`, `uuid7`, and
    `uuid8` to the `ry` package root
  - kept `ry.uuid` as a compatibility module that re-exports UUID helpers and
    constants
- types
  - reshuffled type annotation files (was a nightmare)

---

## v0.0.94 [2026-06-03]

- `ryo3-reqwest`
  - update to `0.13.4` which notably updates `hickory-resolver` to `0.26`
- `ryo3-jiff`
  - added `ry.TimeSpan.MIN` and `ry.TimeSpan.MAX` as the minimum and maximum
    representable time spans
  - made `ry.TimeSpan` mapping-like so you can spread it into a dict or
    kwargs...
  - update to `0.13.4` which notably updates `hickory-resolver` to `0.26`
  - `ry.SignedDuration.seconds` returns the total seconds instead of the seconds
    remainder (seconds % 86400) and added `ry.SignedDuration.seconds_remainder`
  - `ry.SignedDuration.__truediv__` now supports being divided by `ry.Duration`
- `ryo3-bytes`
  - `__getitem__` return via enum + `impl IntoPyObject`
- `ryo3-cookie`
  - added `ry.Cookie.to_string()` for consistency w/ other `ry` types
- `ryo3-size`

  - added constants/classattrs to `ry.Size`
    - min/max/zero
      - `ry.Size.ZERO: t.Final[Size]  # Size(0)`
      - `ry.Size.MAX: t.Final[Size]  # Size(9_223_372_036_854_775_807)`
      - `ry.Size.MIN: t.Final[Size]  # Size(-9_223_372_036_854_775_808)`
    - byte units
      - `ry.Size.B: t.Final[Size]  # Size(1)`
      - `ry.Size.BYTE: t.Final[Size]  # Size(1)`
      - `ry.Size.KB: t.Final[Size]  # Size(1_000)`
      - `ry.Size.KIB: t.Final[Size]  # Size(1_024)`
      - `ry.Size.KIBIBYTE: t.Final[Size]  # Size(1_024)`
      - `ry.Size.KILOBYTE: t.Final[Size]  # Size(1_000)`
      - `ry.Size.MB: t.Final[Size]  # Size(1_000_000)`
      - `ry.Size.MEBIBYTE: t.Final[Size]  # Size(1_048_576)`
      - `ry.Size.MEGABYTE: t.Final[Size]  # Size(1_000_000)`
      - `ry.Size.MIB: t.Final[Size]  # Size(1_048_576)`
      - `ry.Size.GB: t.Final[Size]  # Size(1_000_000_000)`
      - `ry.Size.GIB: t.Final[Size]  # Size(1_073_741_824)`
      - `ry.Size.GIBIBYTE: t.Final[Size]  # Size(1_073_741_824)`
      - `ry.Size.GIGABYTE: t.Final[Size]  # Size(1_000_000_000)`
      - `ry.Size.TB: t.Final[Size]  # Size(1_000_000_000_000)`
      - `ry.Size.TEBIBYTE: t.Final[Size]  # Size(1_099_511_627_776)`
      - `ry.Size.TERABYTE: t.Final[Size]  # Size(1_000_000_000_000)`
      - `ry.Size.TIB: t.Final[Size]  # Size(1_099_511_627_776)`
      - `ry.Size.PB: t.Final[Size]  # Size(1_000_000_000_000_000)`
      - `ry.Size.PEBIBYTE: t.Final[Size]  # Size(1_125_899_906_842_624)`
      - `ry.Size.PETABYTE: t.Final[Size]  # Size(1_000_000_000_000_000)`
      - `ry.Size.PIB: t.Final[Size]  # Size(1_125_899_906_842_624)`
      - `ry.Size.EB: t.Final[Size]  # Size(1_000_000_000_000_000_000)`
      - `ry.Size.EIB: t.Final[Size]  # Size(1_152_921_504_606_846_976)`
      - `ry.Size.EXABYTE: t.Final[Size]  # Size(1_000_000_000_000_000_000)`
      - `ry.Size.EXBIBYTE: t.Final[Size]  # Size(1_152_921_504_606_846_976)`
  - internal refactoring to preserve integer inputs as opposed to coercing them
    to floats when doing `ry.Size.from_*`

- parsing
  - `parse(...)`/`from_str(...)` are positional only now

---

## v0.0.93 [2026-05-22]

- set MSRV to 1.95
- `ryo3-reqwest`
  - refactor internals
  - don't clone header map, split via `into_parts` and use the actual owned
    headers map
  - custom copy pasta charset handling
  - still no body caching bc I think that is dumb but may add if someone asks
  - use `ryo3-tokio-rt` helpers more
- deprecations
  - new
    - deprecated `ry.SignedDuration.from_isoformat`,
      `ry.TimeSpan.parse_common_iso`, and `ry.TimeSpan.from_isoformat` in favor
      of `*.fromisoformat`; this matches python/pandas
  - removed
    - removed deprecated jiff `.intz(...)` aliases; use `.in_tz(...)` instead
    - `ryo3_tokio::fs::aiopen` (aka `ry.aiopen`); use `ry.aopen` instead (which
      has the benefit of not having the letters "ai")
    - `ryo3_url::URL.replace_*` methods in favor of `ryo3_url::URL.with_*`
      methods
    - `ry.HttpClient` (`ryo3_reqwest::RyHttpClient`) removed (finally); use
      instead `ry.Client`

---

## v0.0.92 [2026-05-15]

- errors
  - use `format_args!` instead of `format!` in
    `py_*_err!(...)`/`py_*_error!(...)` macros to avoid allocations on
    string-literal error messages
- `ryo3-bytes`
  - upgrade `strip`, `lstrip`, and `rstrip` methods; return same instance if no
    stripping
  - use `ReadableBuffer` for slightly faster access on `ry.Bytes` methods
  - custom internal iterator for bytes (bc I need it (for work) to be a weeee
    bit faster)

---

## v0.0.91 [2026-05-08]

- use readable buffer in `ryo3-flate2`, `ryo3-bzip2` and `ryo3-brotli`
- fixed context handlers to use `&Bound<'_, PyAny>` instead of `Py<PyAny>`
- `ryo3-brotli`
  - compression/decompression functions now return `ry.Bytes` instead of
    `builtins.bytes`
- `ryo3-tokio-websocket`
  - unexpected ws disconnects mark websocket closed when read/write fail

---

## v0.0.90 [2026-04-30]

- `ryo3-reqwest`
  - deprecated `ry.HttpClient` in favor of `ry.Client`; `ry.HttpClient` will be
    removed in `0.0.93`
  - consolidated `ry.HttpClient` into `ry.Client` with impls flip flopping based
    on `pyo3/experimental-async` activation
  - removed `join` kwarg from `ResponseStream.collect` and
    `BlockingResponseStream.collect` and replaced with `.readall()` method on
    the stream classes
- `ryo3-fspath`
  - pydantic integration
- `ryo3-http`
  - pydantic support for `ry.Headers` and `ry.HttpStatus`
- pydantic integration
  - changed all pydantic stuff to use `no_info_plain_validator_function` instead
    of `no_info_wrap_validator_function` for all but `ulid` as it is 25-50%
    faster in benchmarks:

```text
---------------------------------------------------------------------------------------- benchmark 'pydantic-Timestamp-validate-json': 2 tests ----------------------------------------------------------------------------------------
Name (time in ns)                                            Min                     Max                Mean              StdDev              Median                IQR            Outliers  OPS (Mops/s)            Rounds  Iterations
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
test_rydantic_bench_json[ry.Timestamp] (0001_plain)     337.9992 (1.0)       55,788.9998 (1.0)      373.8919 (1.0)      303.6747 (1.0)      363.9998 (1.0)      23.0011 (1.0)      147;2168        2.6746 (1.0)       56877           1
test_rydantic_bench_json[ry.Timestamp] (0002_wrap)      394.0004 (1.17)     143,503.9994 (2.57)     453.5600 (1.21)     699.1917 (2.30)     441.9999 (1.21)     35.0010 (1.52)      77;1176        2.2048 (0.82)      50096           1
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------- benchmark 'pydantic-Timestamp-validate-python': 2 tests ---------------------------------------------------------------------------------
Name (time in us)                                            Min                Max              Mean            StdDev            Median               IQR            Outliers  OPS (Kops/s)            Rounds  Iterations
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
test_rydantic_bench_python[ry.Timestamp] (0001_plain)     1.0610 (1.0)      51.7840 (1.44)     1.1756 (1.0)      0.4291 (1.12)     1.1460 (1.0)      0.0880 (1.54)      129;420      850.6392 (1.0)       29310           1
test_rydantic_bench_python[ry.Timestamp] (0002_wrap)      1.4080 (1.33)     35.9990 (1.0)      1.5289 (1.30)     0.3846 (1.0)      1.5130 (1.32)     0.0570 (1.0)        78;379      654.0615 (0.77)      15973           1
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
```

---

## v0.0.89 [2026-04-24]

- tests
  - tests for `ry.panic()` and `ry.unreachable()`
- repo
  - switch to `prek.toml` from `.pre-commit.yaml`
- rust-deps
  - `tokio` -> `1.52.1`
  - `mimalloc` -> `0.1.49` (changes underlying mimalloc to `v3` AFAICT)
  - `uuid` -> `1.23.1`
- `ryo3-core`
  - added `UnreachableError` and `PanicException` exception types
  - added `unreachable()` and `panic()` funks (useful for testing)
- `ryo3-fspath`
  - constructor takes `*args` now like `pathlib.Path`
  - impl joinpath with `*args`
- `ryo3-jiff`
  - pattern matching support via `__match_args__` for:
    - `ry.Date`: `(year, month, day)`
    - `ry.DateTime`:
      `(year, month, day, hour, minute, second, subsec_nanosecond)`
    - `ry.ISOWeekDate`: `(year, week, weekday)`
    - `ry.Time`: `(hour, minute, second, subsec_nanosecond)`
    - `ry.SignedDuration`: `(secs, nanos)`
    - `ry.Timestamp`: `(secs, nanos)`
    - `ry.ZonedDateTime`:
      `(year, month, day, hour, minute, second, subsec_nanosecond)`
  - remove `std::sync::Arc` wrapper around `ry.TimeZone`
  - pydantic support for `ry.TimeZone`
- `ryo3-std`
  - pattern matching support for `ry.Duration` => `(secs, nanos)`
- `ryo3-size`
  - random updates n shit (use `PyAsciiString`, make sure `repr` for formatter
    evals to same thing still dont love the size wrapper lib)
  - formatter improvements
- `ryo3-uuid`
  - use readable-buffer and small adjustments to speed up extraction
  - use `PyAsciiString` for `__repr__` and `__str__`
- `ryo3-ulid`
  - macros for errors
  - use `PyAsciiString` for `__repr__` and `__str__`

---

## v0.0.88 [2026-04-10] back-to-the-future

- repo
  - use import granularity `Module`
- `ryo3-serde`
  - python `enum` serialization support
  - fix issue with depth in `set`/`frozenset`
  - serializers no longer redundantly cast/check types
- expanding usage of `ReadableBuffer` for (every-so-slightly) perf gains when
  reading bytes
  - use in `memchr`
- `ryo3-memchr`
  - use `ReadableBuffer` for bytes extraction
- `ryo3-aws-lc`
  - Use release GIL if length of bytes to digest is `>2047` similar to how
    python's `hashlib` does it
- `ryo3-tokio-websockets`
  - `config()` function on `ry.WebSocket` to return a typed dict with the config
    values
- `ryo3-twox-hash`
  - fix secret validaion/ extraction for `xxhash3*`: was validating secret to be
    buf w/ length 192, when in reality an xxhash3-secret is valid so long as it
    is as least 132 bytes
  - reexport xxhasher pyclasses at top level of library (stupid submodules)
  - `oneshot` methods now return bytes as it is (slightly) faster
- `ryo3-fnv`
  - `oneshot` static method now returns bytes not an integer

---

## v0.0.87 [2026-04-03]

- internal
  - remove imports from `pyo3` where covered by `pyo3::prelude::*`
- `ryo3-tokio-rt`
  - moved the `ryo3-tokio` runtime tools/utils into own crate `ryo3-tokio-rt`
  - Use crate in `ryo3-reqwest`, `ryo3-tokio` and future `ryo3-tokio-websockets`
- `ryo3-tokio-websockets`
  - finally implemented (over about a week) bc I am working on a ws server at
    work and gonna use this to test it
  - work in progress websocket client using `tokio-websockets` crate
  - add `json()` fn to `ry.WsMessage` to parse message payload as JSON
- `ryo3-cookie`
  - Move `PyCookie` out from under `ryo3-reqwest` and into its own happy home

---

## v0.0.86 [2026-03-18]

- `ryo3-serde`
  - refactor py-uuid serializer
  - refactor py-float serializer
  - clean up dead code

---

## v0.0.85 [2026-03-04]

- `ryo3-fnv`
  - drop `fnv` crate dependency
  - internal refactoring and cleanup to use `ryo3-core` utils
- `ryo3-reqwest`
  - `text_with_charset` response methods
  - `text` now takes `encoding="utf-8"` kw-only-arg (looks like rnet guy copied
    this... nice)
- `ryo3-aws-lc`
  - dep updates to resolve depbot security issues

---

## v0.0.84 [2026-02-16]

- bump `jiff` version to `0.2.20`
- `ryo3-aws-lc`
  - new crate! yay
  - implemented digest wrappers!

---

## v0.0.83 [2026-02-05]

- pyo3: updated `pyo3` to `0.28.x`
- `ryo3-jiff`
  - more timestamp testing
  - pendulum/whenever/arrow style `add` and `sub` apis for jiff types
- misc
  - add clippy `derive_partial_eq_without_eq` lint
- `ryo3-glob`
  - Renamed `Pattern` to `GlobPattern` for clarity. People using
    `ry.GlobPattern` probably prefer using `ry.Glob` over `ry.GlobPattern`
    (formerly `ry.Pattern`) as it is more performant and more configurable.

---

## v0.0.82 [2026-01-27]

- `ryo3-http`
  - renamed several http types to have `Py` prefix to avoid confusion with
    `http` crate types and be clear that they are wrapper types for
    extracting/into-ing w/ `pyo3`:
    - `HttpMethod` -> `PyHttpMethod`
    - `HttpVersion` -> `PyHttpVersion`
    - `HttpHeaderName` -> `PyHttpHeaderName`
    - `HttpHeaderNameRef` -> `PyHttpHeaderNameRef`
    - `HttpHeaderValue` -> `PyHttpHeaderValue`
    - `HttpHeaderMap` -> `PyHttpHeaderMap`
- `ryo3-reqwest`
  - `connection_verbose` kwarg for `ry.HttpClient`, `ry.Client` and
    `ry.BlockingClient` for debugging
  - internal refactoring of client kwargs extraction

---

## v0.0.81 [2026-01-23]

- `ryo3-jiter`
  - restore big-int json parsing support. jiter `feature: num-bigint` was
    removed when I turned off all default features :/

---

## v0.0.80 [2026-01-22] ~ the wild 80's

- `ryo3-http`
  - remove `parking_lot` from http
  - cache status `ry.HttpStatus` code struct instances. the classattrs go
    through the same mechanism so `ry.HttpStatus.OK is ry.HttpStatus(200)` is
    `True`. Statuses are only cached for codes in the 100-599 range even tho
    `::http::StatusCode` allows `u16` from `100..=999` (which idk why they did
    that)
- `ryo3-std`
  - the internal `DirEntry` struct getters were changed to be methods instead of
    properties to match the `async` version in `ryo3-tokio`
  - `FileType` finally supporting `FileTypeExt` and internally reworked
  - removed `FileType.to_dict()` and associated `FileTypeDict` typed-dict
  - sync-file-stream kwarg `chunk_size` renamed to `read_size` to be more clear
- `ryo3-tokio`
  - async-file-stream kwarg `chunk_size` renamed to `read_size` to be more clear
  - Experiments with using tokio runtime to spawn instead of
    pyo3-async-runtimes + py-futures

---

## v0.0.79 [2026-01-15]

- `ryo3-jiff`
  - rejigger `__add__` to be commutative for span/signed_duration
- `default-features = false` everywere and manually fine-grain control feats
- `ryo3-serde`
  - internal refactoring and some unsafe-ness where it is straight-forward
  - removed `Dataclass` from pointer lookup table and put dataclass serialzation
    under the new `PyUnknownSerializer`
- `type-annotations`
  - removed generic `ry.Proxy` as it was more confusing than helpful

---

## v0.0.78 [2026-01-12]

- internal
  - use uv publishing
  - update pre-commit stuff
  - update dev/testing deps
- `ryo3-reqwest`
  - added new `tls_crls_only` kwarg
  - added `ry.CertificateRevocationList`
  - added `ry.Identity`
  - added `resolve` mapping support for clients
  - renames/deprecations:
    - `root_certificates` -> `tls_certs_merge` and `tls_certs_only`
    - `danger_accept_invalid_certs` -> `tls_danger_accept_invalid_certs`
    - `danger_accept_invalid_hostnames` -> `tls_danger_accept_invalid_hostnames`

---

## v0.0.77 [2026-01-07]

- `ryo3-reqwest`
  - Allow
    `Generator[Buffer] | AsyncGenerator[Buffer] | Iterable[Buffer] | AsyncIterable[Buffer]`
    as body input
  - Renamed tls version kwargs to match reqwest naming:
    - `tls_max_version` -> `tls_version_max`
    - `tls_min_version` -> `tls_version_min`
  - `Response.stream()` now takes a `min_read_size` kwarg; must be positive int,
    and `default=0` meaning no buffering

---

## v0.0.76 [2026-01-05]

- `ryo3-jiff`
  - Custom extractors for enums to avoid clones
  - Cleaner `SpanRelativeTo` impl that does not involve cloning
  - bump jiff version:wq
- `ryo3-reqwest`
  - Update to reqwest `v0.13.1+`
- `ryo3-serde`
  - Custom faster string extraction w/ orjson as the inspiration

---

## v0.0.75 [2025-12-22]

- `ryo3-serde`
  - Renamed all `SerializePy*` structs to `Py*Serializer` w/ this one-liner:
    - `find . -type f -name "*.rs" -print0 | xargs -0 sed -i -E 's/SerializePy([A-Z][A-Za-z0-9_]*)/Py\1Serializer/g'`
- `ryo3-jiff`
  - Consolidate `map_py_err_*` functions into `ryo3_core`
  - `ry.TimeZone.preceding` & `ry.TimeZone.following` for timezone transitions
- `ryo3-core`
  - renamed `PyMutex` to `RyMutex` to avoid confusion with `pyo3`'s `PyMutex`
- `ryo3-fspath`
  - Removed richcmp between non `FsPath` objects and `ry.FsPath` (can use
    `equiv`) to check for equality
  - Use `RyMutex` instead of `parking_lot::Mutex`
- `ryo3-glob`
  - Use `RyMutex` instead of `parking_lot::Mutex`
- `ryo3-reqwest`
  - Remove mutex wrapping global client
  - Experimental new `ry.Client` that uses `pyo3`'s `experimental-async` feat
- `ryo3-uuid`
  - made `__hash__` equiv to python's `__hash__` impl so that rich comparisons
    between `ry.UUID` and `uuid.UUID` work as expected in hashed collections
- `ryo3-url`
  - Added `equiv` method for comparing `ry.URL` with other `ry.URL` instances or
    python `str` objects
  - Removed richcmp between non `URL` objects and `ry.URL` (can use `equiv`) to
    check for equality

---

## v0.0.74 [2025-12-16]

- updating pyo3 to use `skip_from_py_object` where applicable (this will be a
  staged effort)
- `ryo3-serde`
  - move to using `borrowed` over `&bound`; benchmarks show 10-20% perf in
    serializing
- `ryo3-jiff`
  - Removed equality with `datetime.timedelta` can use `ry.SignedDuration.equiv`
    to compare to `datetime.timedelta`, `ry.SignedDuration`, or `ry.Duration`.
- `ryo3-reqwest`
  - Fix race condition when creating error from reqwest-client-wrapper

---

## v0.0.73 [2025-12-12]

- `ryo3-jiff`
  - offset
    - pydantic integration
    - Changed signature of constructor to be
      `ry.Offset(hours=0, minutes=0, seconds=0)`
  - use defaults for all round/difference objects/function calls
  - fixed f-str formatting when empty fmt string given

---

## v0.0.72 [2025-12-10]

- RENAMES:
  - `ry.URL.replace_*` -> `ry.URL.with_*`: the `replace_*` methods are
    deprecated in favor of `with_*` methods. The `ry.URL.replace` still exists
    as a way to replace multiple parts at once.
  - `ry.aiopen` -> `ry.aopen`: it was supposed to be "asyncio-open", but it
    could be easily confused with "artificial-intelligence-open"/"llm-open"
  - `ryo3-fnv`
    - `FnvHasher` -> `fnv1a`
    - `fnv1a` function removed as it was just a stupid proxy for `fnv1a` class
      constructor
- `ryo3-tokio`
  - Added `AsyncFileReadStream` pyclass for async file read streams
  - Helper function `read_str_async` for creating an `AsyncFileReadStream`
- `ryo3-jiff`
  - use `PyMutex` and get rid of `parking_lot::Mutex` for jiff series iterators

---

## v0.0.71 [2025-12-03]

- `ryo3-serde`
  - crude string subclass support
- `ryo3-jiff`
  - use `py_parse` and `py_from_str` for jiff types so that str/bytes are
    allowed `def parse(cls, s: str | bytes) -> t.Self:`
  - Fix pydantic paring problems caused by lazy copy-pasta-ing w/o using
    eyeballs to read what I had copy-pasta-ed

---

## v0.0.70 [2025-12-02] (30 is the new 70)

- type annotations
  - Fixing type annotations and starting to use `stubtest`
- `ryo3-http`
  - Bump version to 1.4.0 which adds `103 Early Hints` status code among other
    things
- `ryo3-reqwest`
  - Removed `client` kwarg from `fetch` function as it is kinda stupid
  - `BlockingClient` and `BlockingResponse` for sync/blocking reqs... This makes
    the `HttpClient` name awkward and may rename it to just `Client`... TBD
  - added `fetch_sync` function for blocking/sync http requests
- `ryo3-jiff`
  - `offset_conflict` and `disambiguation` type annotation fixes
  - `collect()` methods for jiff series

---

## v0.0.69 [2025-11-21]

- added `immutable_type` attr to pyclasses bc many of the things in this crate
  are practically primitives
- `ryo3-fnv`
  - Add `py.detach` where it makes sense
  - Return python `builtins.bytes` from digest not `ry.Bytes`
- `ryo3-url`
  - `URL.host` property returns `None | str | ry.Ipv4Addr | ry.Ipv6ddr` if
    `ryo3-std` feature enabled
- `ryo3-std`
  - pydantic support for `ry.Ipv4Addr`, `ry.Ipv6addr`, and `ry.Ipaddr`
- `ryo3-brotli`
  - Internal refactoring & type-annotation updates
- `ryo3-bzip2`
  - Internal refactoring & type-annotation updates
- `ryo3-flate2`
  - Internal refactoring & type-annotation updates

---

## v0.0.68 [2025-11-14]

- `ryo3-glob`
  - fix error on `take`
- `ryo3-core`
  - `PyMutex` that lets ya pick to throw or not via const generic (very fancy
    look at me)
- `ryo3-jiff`
  - Update jiff to `0.2.16`
  - Add `ZonedSeries`
- `ryo3-std`
  - Use jiff for duration formatting
  - `ry.Duration.seconds` now returns total seconds in duration
  - `ry.Duration.seconds_remainder` returns seconds % days (self.seconds
    % 86400)
  - Remove `datetime.timedelta` support for `ry.Duration.__richcmp__` as there
    is not a one-2-uno direct mapping between timedeltas and durations (bc
    durations are unsigned)
  - pydantic support for `ry.Duration`
- `ryo3-serde`
  - Use jiff unsigned-duration serialization for `ry.Duration`

---

## v0.0.67 [2025-11-07]

- `ryo3-std`
  - `read_str` as `read_text` alias
- fix musl builds
- `ryo3-url`
  - pydantic support

---

## v0.0.66 [2025-10-31]

- fix typos in python tests
- windows arm64 builds
- use `py.detach` where beneficial:
  - `ryo3-brotli`
  - `ryo3-fspath`
  - `ryo3-same-file`
  - `ryo3-std`
  - `ryo3-walkdir`
  - `ryo3-which`
- `ryo3-bytes`
  - optimized extraction of `builtins.bytes`, `ry.Bytes`
- `ryo3-http`
  - switch from `parking_lot::Mutex` to `parking_lot::RwLock` for `PyHeaders`:wq
- global-allocator
  - `mimalloc` feature added to use `mimalloc` over the system allocator
  - added top level `__allocator__` constant

---

## v0.0.65 [2025-10-24]

- `ryo3-reqwest`
  - Manually implement `ClientConfig::default` as global fetch was failing
- `ryo3-uuid`
  - Fixed features problems as pointed out by clippy + cargo-hack
  - Removed unused `uuid2` function as it is not implemented in the underlying
    `uuid` crate

---

## v0.0.64 [2025-10-20]

- `ryo3-reqwest`
  - Turn on hickory-dns by default
  - Use `rustls-tls-webpki-roots

---

## v0.0.63 [2025-10-20]

- pyo3
  - Upgrade pyo3 version to `0.27.x`
- `ryo3-std`
  - Missing `std::fs` function wrappers:
    - `std::fs::hard_link` ->
      `ry.hard_link(src: FsPathLike, dst: FsPathLike) -> None`
    - `std::fs::read_link` -> `ry.read_link(path: FsPathLike) -> FsPathLike`
    - `std::fs::read_to_string` -> `ry.read_to_string(path: FsPathLike) -> str`
    - `std::fs::set_permissions` ->
      `ry.set_permissions(path: FsPathLike, permissions: ry.Permissions) -> None`
    - `std::fs::soft_link` ->
      `ry.soft_link(from_path: FsPathLike, to_path: FsPathLike) -> None`
    - `std::fs::symlink_metadata` ->
      `ry.symlink_metadata(path: FsPathLike) -> ry.Metadata`
- `ryo3-glob`
  - Detach implementation of `take` and `collect` (which is cleaner and probably
    a wee bit faster)
- `_future`
  - `ryo3-ignore` wrapper placeholder
  - `ryo3-tokio-websockets` crate placeholder
- `ryo3-reqwest`
  - `ry.Certificate` for `HttpClient` added
  - `root_certificates` added to `ry.HttpClient`

---

## v0.0.62 [2025-10-15]

- python3.14 builds
- `ryo3-uuid`
  - Fixed uuid `.time` property on python 3.14+
- `ryo3-sqlformat`
  - Internal refactoring
  - Fixed type annotations
  - Starting to think that the `QueryParams` wrapper is totally stupid and
    useless and may remove/deprecate
  - Upgrade sqlformat to `0.5.0` which adds the kwarg
    `dialect: t.Literal["generic", "postgresql", "sqlserver"] = "generic"`
  - Added `SqlFormatter` object for storing a "config"/set-o-opts and for reuse
    (which I was in need of)
- `ryo3-reqwest`
  - Added `basic_auth` and `bearer_auth` kwargs to fetch functions (`get`,
    `post`, `put`, `delete`, `head`, `patch`, and of course `fetch`)
  - Internal refactoring of body/form/json/multipart parsing.
  - Added more client kwargs from `reqwest::ClientBuilder`:
    - `redirect: int | None = 10`
    - `referer: bool = True`
    - `zstd: bool = True`
    - `hickory_dns: bool = True`
    - `http1_only: bool = False`
    - `https_only: bool = False`
    - `http1_title_case_headers: bool = False`
    - `http1_allow_obsolete_multiline_headers_in_responses: bool = False`
    - `http1_allow_spaces_after_header_name_in_responses: bool = False`
    - `http1_ignore_invalid_headers_in_responses: bool = False`
    - `http2_prior_knowledge: bool = False`
    - `http2_initial_stream_window_size: int | None = None`
    - `http2_initial_connection_window_size: int | None = None`
    - `http2_adaptive_window: bool = False`
    - `http2_max_frame_size: int | None = None`
    - `http2_max_header_list_size: int | None = None`
    - `http2_keep_alive_interval: Duration | None = None`
    - `http2_keep_alive_timeout: Duration | None = None`
    - `http2_keep_alive_while_idle: bool = False`
    - `pool_idle_timeout: Duration | None = ...,  # 90 second`
    - `pool_max_idle_per_host: int | None = ...,  # usize::MA`
    - `tcp_keepalive: Duration | None = ...,  # 15 second`
    - `tcp_keepalive_interval: Duration | None = ...,  # 15 second`
    - `tcp_keepalive_retries: int | None = 3`
    - `tcp_nodelay: bool = True`
    - `tls_min_version: t.Literal["1.0", "1.1", "1.2", "1.3"] | None = None`
    - `tls_max_version: t.Literal["1.0", "1.1", "1.2", "1.3"] | None = None`
    - `tls_info: bool = False`
    - `tls_sni: bool = True`
    - `danger_accept_invalid_certs: bool = False`
    - `danger_accept_invalid_hostnames: bool = False`

---

## v0.0.61 [2025-10-08]

- `ryo3-std`
  - added `to_dict`/`from_dict` to `ry.Duration`
- use `jessekrubin/pyo3-async-runtimes` (branch 'unpaid-interns') git repo (for
  now):
  - [PyO3/pyo3-async-runtimes#60](https://github.com/PyO3/pyo3-async-runtimes/pull/60)
  - [PyO3/pyo3-async-runtimes#62](https://github.com/PyO3/pyo3-async-runtimes/pull/62)
- `ryo3-uuid`
  - supa speedy pydantic support added to `ry.uuid.UUID` (bc I need it now)
- `ryo3-reqwest`
  - `ry.Cookie` class/struct and `cookies`/`set_cookies` properties on the
    `ry.Response` class/struct
- removed deprecated `.string()` methods from several structs/classes:
  - `ry.FsPath`
  - `ry.UUID`
  - `ry.DateTime`
  - `ry.Date`
  - `ry.SignedDuration`
  - `ry.TimeSpan`
  - `ry.Time`
  - `ry.Timestamp`
  - `ry.ZonedDateTime`

---

## v0.0.60 [2025-09-26]

- deprecations
  - bump out `.string()` method deprecation removals to `0.0.61`
- `ryo3-std`
  - `ry.FileType` struct now has inner faux type/real type
- `ryo3-jiff`
  - `strftime`/`__format__` changed to use `BrokenDownTime` to not panic
- `ryo3-tokio`
  - renamed:
    - `DirEntryAsync` -> `AsyncDirEntry`
    - `ReadDirAsync` -> `AsyncReadDir`

---

## v0.0.59 [2025-09-24]

- `ryo3-request`
  - switched query/form kwargs to accept anything that can be serde-d via
    `ryo3-serde` which is basically anything that is json-serializable via
    `ry.stringify`
- `ry.protocols`
  - moved all protocols to `ry.protocols`
- deprecations
  - deprecate all `obj.string()` methods in favor of `obj.to_string()` tho I
    still dont love it in the first place
- `ryo3-jiff`
  - added `isoformat` and `from_isoformat` methods to `ry.TimeSpan` and
    `ry.SignedDuration` structs
- `ryo3-sqlformat`
  - Updated to version 0.4.0 of `sqlformat` crate
  - Added sqlformat version 0.4.0 new options:
    - `ignore_case_convert: list[str] | None = None`
    - `inline: bool = False`
    - `max_inline_block: int = 50`
    - `max_inline_arguments: int | None = None`
    - `max_inline_top_level: int | None = None`
    - `joins_as_top_level: bool = False`
  - Changed `indent` arg/kwarg to accept either:
    - `int` (positive integer for number of spaces)
    - `str` ("tabs", "\t" or "spaces")
  - Changed `uppercase` arg/kwarg to default to `False` instead of `True` to be
    more inline with the default behaviour of `sqlformat` crate

---

## v0.0.58 [2025-09-18]

- `ryo3-jiff`
  - added `.__format__()` methods to several jiff structs to allow custom
    f-string formatting
  - Fixed `SignedDuration.__truediv__` operator
- internal
  - migrated all `downcast*` usages to `cast*`
- Min python version for ry is now 3.11+

---

## v0.0.57 [2025-09-12]

- `ryo3-jiff`
  - Added `TimeRound` python struct
  - Fixed types for all `*Round` operations limiting max "smallest" arg literal
    types.
  - Round-api changes
    - builder-y functions and getter functions have been flip-flopped:
      - Switched "builder"-y apis to start with prefix for all `*Round` structs:
        - `increment(n: int) -> Self` -> `_increment(n: int) -> Self`
        - `mode(m: str) -> Self` -> `_mode(m: str) -> Self`
        - `smallest(unit: str) -> Self` -> `_smallest(unit: str) -> Self`
      - Switched all getter functions to be properties:
        - `round_obj._increment() -> int` -> `round_obj.increment -> int`
        - `round_obj._mode() -> str` -> `round_obj.mode -> str`
        - `round_obj._smallest() -> str` -> `round_obj.smallest -> str`
- `to_dict()`
  - `.asdict()` renamed to `.to_dict()` all structs
  - renames structs:
    - `ry.DateTime.asdict()` -> `ry.DateTime.to_dict()`
    - `ry.Date.asdict()` -> `ry.Date.to_dict()`
    - `ry.TimeSpan.asdict()` -> `ry.TimeSpan.to_dict()`
    - `ry.Time.asdict()` -> `ry.Time.to_dict()`
    - `ry.Headers.asdict()` -> `ry.Headers.to_dict()`
  - Added `.to_dict()` to:
- migrated from `xxhash-rust` to `twox-hash` ~ retiring `ryo3-xxhash` :( - the
  `xxhash-rust` hashers liked to sometimes crash, whereas the `twox-hash`
  py-hashers dont

---

## v0.0.56 [2025-09-05]

- `ryo3-serde`
  - refactoring and testing recursion and stitch
- `ryo3-tokio`
  - Fix: python open mode parsing for `aiopen` function
- `ryo3-reqwest`
  - Add `jiter` parsing options to `Response.json()`
- `ryo3-jiff`
  - use `#[pyo3(warn(...))]` for deprecation warnings instead of doing it
    manually
  - fixed utc methods to use `.with_time_zone(TimeZone::UTC)` instead of
    `.in_tz("UTC")`

---

## v0.0.55 [2025-09-03]

- upgrade pyo3 v0.26.x
- `ryo3-bytes`
  - Update buffer usage based on kyle barron `pyo3-bytes`
    [changes](https://github.com/developmentseed/obstore/commit/2ca22a8c3949ae51fbf750ef5a08e3a76f583819)
- `ryo3-std`
  - Make each sub-module a feature flag `std-net`, `std-fs`, `std-time`, etc...
- internal changes
  - Implemented `Display` for several types for use in their `__repr__` methods

---

## v0.0.54 [2025-08-28]

- `ryo3-std`
  - Serialization for std types
  - Speed run of socketaddr types (WIP); needs more testing and the socket types
    could be cleaner...
- `ryo3-memchr`
  - Basic functionality for `memchr` and `memrchr` operations
- `ryo3-jiff`
  - Changed `human` arg/kwarg in `ry.TimeSpan` and `ry.SignedDuration` to
    `friendly` and also make keyword only
  - Changed `strptime` and `strftime` functions to be more inline with python's
    `datetime` module by changing the order of args to be `(string, format)`
    instead of `(format, string)`; the strptime signature is
    `strptime(s: str, /, fmt: str) -> Self`
  - Added to `ry.TimeSpan` and `ry.SignedDuration` the `friendly` method for
    more natural string representations
  - Many internal refactors and cleanup
  - Converted all `__repr__` methods to use struct `Display` impls
  - Fixed rounding object repr function(s) and added pickling and tests for
    round objects
- type-annotations
  - Missing `lstrip`/`rstrip` method types for `ry.Bytes`
  - Updated types for `ry.TimeSpan` and `ry.SignedDuration` w/ correct
    `friendly` kwarg and `friendly()` methods
- Added ruff `A002` lint
- Added ruff `FBT` lints

---

## v0.0.53 [2025-08-18]

- `ry`
  - Bump min python version 3.10 -- this is a breaking change, but ry is still
    very much a WIP/in-beta, so the versioning schema is "yolo-versioning"
- `ryo3-serde`
  - internal refactoring and cleanup

---

## v0.0.52 [2025-07-30]

- `ryo3-bytes`
  - internal refactoring
  - added
    - `ry.Bytes.__rmul__`
    - `ry.Bytes.lstrip`
    - `ry.Bytes.rstrip`
- `ryo3-xxhash`
  - all xxhash-ing classes are now `frozen` pyclasses
    [#259](https://github.com/jessekrubin/ry/issues/259)

---

## v0.0.51 [2025-07-25]

- `ryo3-bytes`
  - Separated `pyo3-bytes` and `ryo3-bytes`
    - `pyo3-bytes` mirrors the official `pyo3-bytes` crate + extra methods, BUT
      it requires the `multiple-pymethods` feature to be enabled
    - `ryo3-bytes` is a crammed together version of the `pyo3-bytes`
      implementation and extra methods and does NOT require the
      `multiple-pymethods` feature to be enabled
  - Made `PythonBytesMethods` trait for the methods that are shared between
    `pyo3-bytes` and `ryo3-bytes`
- `ryo3-ulid`
  - strict + lax ulid parsing for pydantic
- `ryo3-jiff`
  - Renamed `checked_add` and `checked_sub` to `add` and `sub` where the
    checked_version can error; did not remove where the checked version returns
    an `Option` type (`ry.SignedDuration`). `.checked_add` may return later as a
    method that returns an `Option` type for all types (tbd). This is also meant
    to pave the way for `add`/`sub` functions with a more familiar api akin to
    `whenever`, `pendulum`, `arrow`, `insert-other-datetime-lib-here`
  - Added `replace` methods to `Date`, `DateTime` and `Time` structs that use
    the underlying jiff `with` functions

---

## v0.0.50 [2025-07-14]

- internal
  - clippy lint fixes `unused_self` (all but `ryo3-bytes` which needs its own
    cleanup)
- `ryo3-bytes`
  - Added (bc I need them) more python compat methods:
    - `title()`
    - `swapcase()`
    - `expandtabs()`
    - `strip()`
- `ryo3-fspath`
  - Added `open` method that forwards to `open` method of `pathlib.Path`
  - Added `mkdir` method that mimics `mkdir` method of `pathlib.Path`

---

## v0.0.49 [2025-07-04] (fourth o july)

- workspace
  - set rust edition to 2024
- `ryo3-serde`
  - Fixed recursive serialization w/ max depth of 255 (aligning with `orjson`)
  - support `PyEllipsis` for `None` values in serialization
- `ryo3-json`
  - `minify` function to remove whitespace/newlines from json-string/bytes
- `ryo3-jiff`
  - internal refactoring
  - `isoformat` methods aligned with python's `datetime` library methods
  - Freeze (make pyclass frozen) for all jiff types (changed `*Series`
    iterables)
- `ryo3-fspath`
  - `which` feature allowing `FsPath.which` and `FsPath.which_all`

---

## v0.0.48 [2025-06-24]

- `ryo3-json`
  - `pybytes` bool kwargs to return `builtins.bytes` if `True` and `ry.Bytes` if
    `False`; default is `False`
- `ryo3-serde`
  - support for types defined in `ryo3-http`
  - support for `default` kwarg that is passed to the serde serializer; like w/
    the stdlib-json and orjson serializers, this allows for serializing types
    that are not natively supported by ry/serde and if failure should occur, it
    should raise a `TypeError` or `ValueError` instead of returning `None` by
    default
- `ryo3-reqwest`
  - `json` kwarg added to request builders that auto-serializes via
    `ryo3-serde`; also because it uses the `reqwest::RequestBuilder` it auto
    sets the `Content-Type` header to `application/json`

---

## v0.0.47 [2025-06-17]

- pyo3 v0.25.1
- `ryo3-serde` (wip)
  - serializers for `PyAny` and more
  - this should theoretically allow for serializing any python object that is
    `serde` serializable with almost any `serde` serializer... that is the goal
- `ryo3-json`
  - Where json stuff + ry is going to live in the near future (may consolidate
    `ryo3-jiter` into this newer crate)
  - `ry.stringify()` uses `ryo3-serde` + `serde_json` to write json bytes/bufs
    and it is pretty fast, faster than ujson and rapidjson (not tested yyjson),
    BUT orjson is still fastest (read a bunch of their code and it is remarkably
    advanced and optimized)

---

## v0.0.46 [2025-06-06]

- version 0.0.46
- `ryo3-reqwest`
  - `ResponseStream`
    - Added `__repr__` method
    - Added `async def take(self, n: int=1): ...` method returns n chunks as a
      list
    - Added `async def collect(self: join = False) -> ...:` method that collects
      the stream into a single `ry.Bytes` object if `join=True` or a list of
      `ry.Bytes` objects if `join=False`
    - Added `async def take(self, n: int=1): ...` which returns n chunks as a
      list
- `ryo3-glob`
  - add `dtype` kwarg that takes either `dtype=str | ry.FsPath | pathlib.Path`
    as type of obj yielded by the iterable; something about this feels really
    icky, the default may be changed to `str` (from `pathlib.Path`)
- `ryo3-ulid`
  - Added mostly as a way to test how much pydantic + ry integration would be
- `ryo3-which`
  - upgrade which to version 8

---

## v0.0.45 [2025-05-30]

- added `__target__` to python package metadata in `ry.__about__` with the
  target triple of the current build
- `ryo3-std`
  - Buffering for `FileReadStream`
- `ryo3-jiter`
  - Add function `parse_jsonl` for parsing json lines
  - Add `lines` kwarg to `read_json` for parsing/reading json lines
- `ryo3-jiff`

  - `ZonedDateTime.__new__` takes more python-datetime like args/kwargs, old
    version of constructor moved to classmethod
    `ZonedDateTime.from_parts(timestamp: ry.Timestamp, tz: ry.TimeZone) -> ZonedDateTime`
  - `zoned` top level function

    - if `tz` is `None` then it uses the system timezone
    - SIGNATURE

    ```python
    def zoned(
        year: int,
        month: int,
        day: int,
        hour: int = 0,
        minute: int = 0,
        second: int = 0,
        nanosecond: int = 0,
        tz: str | None = None,
    ) -> ZonedDateTime: ...
    ```

---

## v0.0.44 [2025-05-23]

- internal:
  - renamed `ryo3-macros` to `ryo3-macro-rules`
- docs
  - Cleaned up `./README.md`
  - Removed type-annotations from `./README.md`
- pyo3-v0.25.0
- py-types
  - reqwest-request functions use `TypedDict` and `Unpack`
- `ryo3-jiff`
  - serde serialization features/support
  - `ry.ZonedDateTime.replace` method mirroring `ZonedWith` -- `with` is a
    python keyword, so used `replace` instead
  - example script based on jiff-docs examples
  - `test_jiff_examples_v2.py` test script (basis for example script)
    - Was tired/fried so I copy-pasta-ed the `ry/ryo3/_jiff.pyi` type
      annotations, the jiff-v2-docs-examples, and the jiff-v1-hand-translated
      `test_jiff_examples_v1.py` file into Chad-Gippity who was able to do most
      of the translation from `rust` to `ry`...
- `ryo3-xxhash`
  - Align with `xxhash` pypi library w/ respect to naming conventions

---

## v0.0.43 [2025-05-17]

- `ryo3-jiff`
  - panic-able functions to create new/altered (time)spans moved to use `try_*`
- fix: anyio marker flat issue in pytests for cicd
- `ryo3-uuid`
  - added `uuid` wrapper for `uuid` crate; ty to the maintainers of `uuid-utils`
    and `fastuuid` for helping figure out some of the nitty gritty bits and bobs
- `ryo3-tokio`
  - `AsyncFile` and `aiopen` experiment(s) added for async file reading/writing
    etc

---

## v0.0.42 [2025-05-12]

- panic=abort
  - panic is now (maybe will go back) `abort` for release builds
  - means smaller binaries and faster error handling (in theory)
- `ryo3-reqwest`
  - more type fixes to response
  - Got response type more inline with other python http-client libraries
  - try `parking_lot` for default `reqwest` client mutex
  - include missing kwargs for fetch functions
- `ryo3-glob`
  - freeze struct(s) to be frozen
- `ryo3-http`
  - http version python conversions to/from string/int
  - crude-ish serde implementation for `HeadersMap` for json
    encoding/decoding... was a lot of googling
  - status code reason(s) interned
  - intern all standard http header-names
- `ryo3-fnv`
  - align with hashlib style hashing
- deps-up
  - pyo3 version 0.24.2
  - brotli 8
  - jiff patch

---

## v0.0.41 [2025-04-18]

- `ryo3-jiter`
  - added `read_json` function to read from path-like obj
- `ryo3-bytes`
  - misc small improvements and tests
- `ryo3-std`
  - `ry.IpAddr` added to handle both ipv4/ipv6
  - `ry.read_dir` implemented
- `ryo3-walkdir`
  - added `objects` impl and example script
- `ryo3-tokio`
  - `ry.read_dir_async` implemented; also contains fancy async take/collect

---

## v0.0.40 [2025-04-11]

- scripts
  - `dl_versions.py` script to download all versions of ry while ry is still
    pre-1-point-oh and old version(s) are being nuked from pypi as needed
- types
  - fix types for few packages
- Updated several dependencies ~ most notably `pyo3` to `0.24.1`
- Fixed several new clippy lints that appear in CI stable rust builds
- `ryo3-std`
  - `std::net` ipv4/ipv6 wrappers speed run impl

---

## v0.0.39 [2025-03-14]

- internal
  - cleaned up several dependencies and features
- `ryo3-zstd`
  - actually changed to use py buffer protocol this time... I dont know how it
    got missed before...
  - re-factored a decent bit and made submodule with future plans to expand
    encoding/decoding dictionary support
  - submodule is `ry.zstd` and/or `ry.ryo3.zstd`

---

## v0.0.38 [2025-03-13]

- `ryo3-reqwest`
  - client configuration for pickling
  - allow buffer-protocol for `body` fetching methods (should add string maybe?)
- `ryo3-walkdir`
  - Few more options added
- `ryo3-glob`
  - new wrapper around `glob` crate
- `ryo3-jiff`
  - Switched to use conversions from `jiff` feature of `pyo3-v24` as opposed to
    hand-rolled conversions we had before

---

## v0.0.37 [2025-03-11]

- pyo3 version `0.24.0`
- `ryo3-which` functions return `pathlib.Path` now due to changes in pyo3-v24;
  this may change in the near future...

---

## v0.0.36 [2025-03-11]

- dependencies updated
- pickling support and tests for several types
- bytes/buffer-protocol support for several sub-packages/packages:
  - `ryo3-brotli`
  - `ryo3-bzip2`
  - `ryo3-flate2`
  - `ryo3-fnv`
  - `ryo3-xxhash`
  - `ryo3-zstd`

---

## v0.0.35 [2025-03-06]

- internal
  - types split up and cleaned up
- `ryo3-size`
  - `ry.Size` object
- `ryo3-jiff`
  - `series` iterators have `take` function that takes a `usize` returns a list
    of size `usize`
  - updated series types to be `JiffSeries` class

---

## v0.0.34 [2025-02-28]

- `ryo3-std`
  - `fs`:
    - `read_stream` function that returns an iterator of `ry.Bytes` objects from
      a `PathLike` object
    - Several more fs functions added
- `ryo3-tokio`
  - Several more tokio fs functions added
- internal
  - reorganized type annotations to be not a HUGE file...

---

## v0.0.33 [2025-02-26]

- update to pyo3 v0.23.5

---

## v0.0.32 [2025-02-25]

- `ryo3-jiter`
  - Allow `PyBytes` wrapper/buffer protocol to be given
  - renamed `jiter_cache_clear` to `json_cache_clear` and `jiter_cache_usage` to
    `json_cache_usage`
  - Removed `parse_json_str` just use `parse_json` with `str` input
- `ryo3-fspath`
  - Allow read/write to take `ry.Bytes` or `Bytes` objects

---

## v0.0.31 [2025-02-21]

- `ryo3-core`
  - got rid of `ryo3-types` and moved into `ryo3-core`
- `ryo3-tokio`
  - `read_async` and `write_async` async functions
- `ryo3-which`
  - `which_re` functions accepts `ry.Regex` or `str` now
- `ryo3-std`
  - `read` and `write` functions which take/return `ry.Bytes` objects
- `internal`
  - Changed many many many of the structs/classes to be pyo3 `frozen` behaviour
    should not be different

---

## v0.0.30 [2025-02-18]

- `jiff`
  - Upgraded jiff to version 2
- internal
  - Switch all lints from `#[allow(...)]`/`#![allow(...)]` to
    `#[expect(...)]`/`#![expect(...)]`
  - Removed a bunch o commented out code
- `ryo3-std`
  - added several `std::fs` structs
- `ryo3-fspath`
  - conversion to `pathlib.Path` by way of `FsPath.to_pathlib()`

---

## v0.0.29 [2025-02-03]

- internal
  - Made sure each `ryo3-*` crate has a `README.md`
- `ryo3-bytes` & `ryo3-fspath`
  - added `__hash__` dunders to both `Bytes` and `FsPath` structs

---

## v0.0.28 [2025-01-31]

- `jiff`
  - Per Mr. Sushi's thoughts changed all `until`/`since` methods to use kwargs
    instead of the rust-like tuples that impl `From`/`Into` as it does not
    translate well to python
  - Gets rid of the following inane types:

```python
IntoDateDifference = (
    DateDifference
    | Date
    | DateTime
    | ZonedDateTime
    | tuple[JIFF_UNIT_STRING, Date]
    | tuple[JIFF_UNIT_STRING, DateTime]
    | tuple[JIFF_UNIT_STRING, ZonedDateTime]
)
IntoTimeDifference = (
    TimeDifference
    | Time
    | DateTime
    | ZonedDateTime
    | tuple[JIFF_UNIT_STRING, Time]
    | tuple[JIFF_UNIT_STRING, DateTime]
    | tuple[JIFF_UNIT_STRING, ZonedDateTime]
)
IntoDateTimeDifference = (
    DateTimeDifference
    | Date
    | Time
    | DateTime
    | ZonedDateTime
    | tuple[JIFF_UNIT_STRING, Date]
    | tuple[JIFF_UNIT_STRING, Time]
    | tuple[JIFF_UNIT_STRING, DateTime]
    | tuple[JIFF_UNIT_STRING, ZonedDateTime]
)
IntoTimestampDifference = (
    TimestampDifference
    | Timestamp
    | ZonedDateTime
    | tuple[JIFF_UNIT_STRING, Timestamp]
    | tuple[JIFF_UNIT_STRING, ZonedDateTime]
)
```

---

## v0.0.27 [2025-01-23]

- `ry`
  - Warning on `debug` build
- `reqwest`
  - headers-property response returns `Headers` object instead of python dict
- `same-file`
  - wrapper module added with `is_same_file` py-fn (yet another piece of burnt
    sushi)
- `jiff`
  - jiff-version `0.1.25` ~ add `in_tz` methods and point old `intz` at new
    `in_tz` methods and raise `DeprecationWarning` for old `intz` methods
  - Continued adding implementations that previously raised
    `NotImplementedError`
    - `Date.nth_weekday_of_month`
    - `Date.nth_weekday`
    - `DateTime.nth_weekday_of_month`
    - `DateTime.nth_weekday`
    - `TimeSpan.compare`
    - `TimeSpan.total`
    - `ZonedDateTime.nth_weekday_of_month`
    - `ZonedDateTime.nth_weekday`

---

## v0.0.26 [2025-01-13]

- `reqwest`
  - `AsyncClient` renamed to `HttpClient`
- `jiff`
  - human timespan strings for `TimeSpan` and `SignedDuration` objects:
    - `ry.TimeSpan.parse("P2M10DT2H30M").string(human=True) == "2mo 10d 2h 30m"`
    - `ry.SignedDuration.parse("PT2H30M").string(human=True) == "2h 30m"`
- internal
  - workspace-ified all the deps

---

## v0.0.25 [2024-01-07] (25 for 2025)

- `jiff`
  - Updated to `0.1.21` which has span and signed duration strings with capital
    letters

---

## v0.0.24 [2024-12-24] (the night b4 xmas...)

- `http`
  - basic headers struct/obj -- WIP
- `reqwest`
  - reqwest client (currently root-export)
  - default client + root `fetch` function likely needs work...
  - response `byte_stream`!

---

## v0.0.23 [2024-12-19]

- `python -m ry.dev` repl for ipython/python repl ~ handy nifty secret tool
  makes it into repo
- internal
  - in process of renaming all python-rust `#[new]` functions to be named
    `fn py_new(...)`
- `unindent`
  - Added `unindent` module for unindenting strings will move to `ryo3-unindent`
- `FsPath`
  - creeping ever closer to being a full-fledged pathlib.Path replacement
  - Added bindings to all rust `std::path::Path(buf)` methods for `FsPath`
- sub-packaging
  - `xxhash` is own sub package now `ry.xxhash`
  - `JSON` is own subpackage right now -- named `ry.JSON` to avoid conflict with
    `json` module but maybe will change...
  - food-for-thought-ing how `ryo3` and `ry` should be organized w/ respect to
    sub-packages and where that organization should be
- type-annotations
  - required to break up the type annotations due to migration to sub-packages
  - breaking up the type annotations file into smaller files under
    `<REPO>/python/ry/ryo3/*.pyi`

---

## v0.0.22 [2024-12-16]

- `regex`
  - Super simple regex wrapper (must to do here, but was added for
    `ryo3-which::which_re`)
- `jiff`
  - `until`/`since`
    - Basic `until`/`since` implementation but I do not like them and they
      confusingly named `*Difference` structs/py-objects, so I may change how
      they work...
  - `jiff` seems to be about as performant as `whenever` ~ yay! also the
    whenever dude appears to be watching this repo (as of 2024-12-16)
- `walkdir`
  - `collect` added to `WalkdirGen` to collect the results into a list
- deps
  - `thiserror` version `2.0.7` -> `2.0.8`

---

## v0.0.21 [2024-12-13] (friday the 13th... spoogidy oogidity)

- `walkdir`
  - add `glob` kwarg that takes a `ry.Glob` or `ry.GlobSet` or `ry.Globster` obj
    to filter the walk on
- `globset`
  - Internal refactoring
  - added `globster()` method to `ry.Glob` and `ry.GlobSet` to return a
    `ry.Globster` obj
  - added `globset()` method to `ry.Glob` to return a `ry.GlobSet` obj from a
    `ry.Glob` obj
- `url`
  - python `Url` changed name `URL`; aligns with jawascript and other python
    libs
- `bzip2`
  - update to v5
- `jiff`
  - conversions for jiff-round-mode/unit/weekday
  - not-implemented placeholders and new impls
    - [x] `RyDateTime`
    - [x] `RyDate`
    - [x] `RyOffset`
    - [x] `RySignedDuration`
    - [x] `RySpan`
    - [x] `RyTimeZone`
    - [x] `RyTime`
    - [x] `RyZoned`
  - span builder functions use form `s._hours(1)` for panic-inducing building,
    and `s.try_hours(1)` for non-panic-inducing building
- type-annotations
  - fixes and updates and a hacky script I wrote to check for discrepancies

---

## v0.0.20 [2024-12-10]

- `regex`
  - Templated out regex package but nothing added
- `ry`
  - python 3.13 yay!
- `jiter`
  - Updated jiter version thanks depbot!

---

## v0.0.19 [2024-12-05]

- `jiff`
  - py-conversions
    - [x] `JiffDateTime`
      - [x] FromPyObject
      - [x] IntoPyObject
      - [x] IntoPyObject (REF)
    - [x] `JiffDate`
      - [x] FromPyObject
      - [x] IntoPyObject
      - [x] IntoPyObject (REF)
    - [x] `JiffOffset`
      - [x] FromPyObject
      - [x] IntoPyObject
      - [x] IntoPyObject (REF)
    - [x] `JiffSignedDuration`
      - [x] FromPyObject
      - [x] IntoPyObject
      - [x] IntoPyObject (REF)
    - [x] `JiffSpan`
      - [x] FromPyObject
      - [x] IntoPyObject
      - [x] IntoPyObject (REF)
    - [x] `JiffTimeZone`
      - [x] FromPyObject
      - [x] IntoPyObject
      - [x] IntoPyObject (REF)
    - [x] `JiffTime`
      - [x] FromPyObject
      - [x] IntoPyObject
      - [x] IntoPyObject (REF)
    - [x] `JiffZoned`
      - [x] FromPyObject
      - [x] IntoPyObject
      - [x] IntoPyObject (REF)

---

## v0.0.18 [2024-12-03]

- `jiff`
  - Renamed `ry.Span` to `ry.TimeSpan`
  - Renamed `ry.Zoned` to `ry.ZonedDateTime`
  - Updated type stubs to reflect renames
- docs
  - init-ed the docs
  - style guide under `DEVELOPMENT.md` file

---

## v0.0.17 [2024-12-02]

- `jiff`
  - `ry.TimeZone` testing and to/from `datetime.tzinfo` conversions
  - Using nu-types for `jiff` intermediate types bc of the classic orphans
    problem (aka batman) w/ traits
  - hypothesis tests
- `jiter`
  - Updated to `jiter` v0.8.1

---

## v0.0.16 [2024-11-29]

- Moved walkdir to `ryo3-walkdir`
- added `ryo3-types` for custom and shared types
- `heck` wrapper(s)
- jiff
  - Added operators `+`/`+=`/`-`/`-=` to date/time/datetime/etc
  - TODO: figure out how to take refs in the union enum for the operators
- fspath
  - further beefing out as well as testing

---

## v0.0.15 [2024-11-20]

- `from __future__ import annotations` added to all modules
- cicd updated to include more targets

---

## v0.0.14 [2024-11-20]

- Primitive/crude wrappers around Mr. Sushi's `jiff` library
- Updated to use pyo3 (had to use jiter git repo dep)
- `ry.FsPath` beefed out
- Added iterdir gen wrapper
- (todo undo when jiter + pyo3 23 is public)

---

## v0.0.13 [2024-11-20]

- **VERSION SKIPPED DUE TO `13` BEING SPOOKY AND ME BEING MODERATELY-STITCHOUS
  (AKA fully 'superstitchous')**

---

## v0.0.12 [2024-11-14]

- sqlformat wrapper(s) (this is the first `ryo3-*` sub-crate)

---

## v0.0.11 [2024-09-22]

- dependencies updated
- prepare for python 3.13

---

## v0.0.10 [2024-09-22]

- dependencies updated

---

## v0.0.9 [2024-08-22]

- Added `globset` wrapper(s)
- Added `__init__.py` generator

---

- Upgraded to pyo3-v0.22

## v0.0.8 [2024-06-25]

- Upgraded to pyo3-v0.22

---

## v0.0.7 [2024-06-08]

- internal refactoring

---

## v0.0.6 [2024-06-05]

- Added zstd (`zstd_encode`/`zstd` and `zstd_decode`)
- Added gzip (`gzip_encode`/`gzip` and `gzip_decode`/`gunzip`)
- Added bzip2 (`bzip2_encode`/`bzip2` and `bzip2_decode`)
- Added walkdir
- Reorg libs

---

## v0.0.5 [2024-04-19]

- Added brotli (`brotli_encode` and `brotli_decode`)
- xxhash
  - const functions
  - hasher streaming objects
