use std::fmt::Display;
use std::hash::{DefaultHasher, Hash, Hasher};
use std::ops::{Div, Mul};

use jiff::{SignedDuration, SignedDurationRound, Span};
use pyo3::prelude::*;
use pyo3::types::{PyDict, PyFloat, PyInt, PyTuple};
use pyo3::{BoundObject, IntoPyObjectExt};
use ryo3_core::{PyAsciiString, PyCastExactOpt, map_py_overflow_err, map_py_value_err};
use ryo3_jiff_core::fmt::{FRIENDLY_SPAN_PRINTER, TEMPORAL_SPAN_PARSER};
use ryo3_jiff_core::{
    JiffFriendlyDesignator, JiffRoundMode, JiffSignedDuration, JiffUnit, pydelta_to_signed_duration,
};
use ryo3_macro_rules::{
    any_repr, py_overflow_err, py_overflow_error, py_type_err, py_value_err, py_value_error,
    py_zero_division_err,
};
use ryo3_std::time::PyDuration;

use crate::constants::{MINUTES_PER_HOUR, NANOSECONDS_PER_SECOND, SECONDS_PER_MINUTE};
use crate::round::RySignedDurationRound;
use crate::ry_span::RySpan;

#[cfg_attr(feature = "serde", derive(serde::Serialize), serde(transparent))]
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, Hash, Default)]
#[pyclass(name = "SignedDuration", frozen, immutable_type, eq, ord)]
#[cfg_attr(feature = "ry", pyo3(module = "ry.ryo3"))]
pub struct RySignedDuration(pub(crate) SignedDuration);

impl RySignedDuration {
    pub(crate) fn py_try_from_secs_f32(secs: f32) -> PyResult<Self> {
        if secs.is_nan() {
            py_value_err!("invalid value: nan")
        } else if secs.is_infinite() {
            py_overflow_err!("invalid value: inf")
        } else {
            SignedDuration::try_from_secs_f32(secs)
                .map(Self::from)
                .map_err(|e| py_overflow_error!("{e}"))
        }
    }

    pub(crate) fn py_try_from_secs_f64(secs: f64) -> PyResult<Self> {
        if secs.is_nan() {
            py_value_err!("invalid value: nan")
        } else if secs.is_infinite() {
            py_overflow_err!("invalid value: inf")
        } else {
            SignedDuration::try_from_secs_f64(secs)
                .map(Self::from)
                .map_err(|e| py_overflow_error!("{e}"))
        }
    }
}

#[pymethods]
#[expect(clippy::wrong_self_convention)]
impl RySignedDuration {
    #[new]
    #[pyo3(signature = (secs = 0, nanos = 0))]
    pub fn py_new(secs: i64, nanos: i32) -> PyResult<Self> {
        #[expect(clippy::cast_lossless)]
        if !(-NANOSECONDS_PER_SECOND < nanos && nanos < NANOSECONDS_PER_SECOND) {
            let addsecs = nanos / NANOSECONDS_PER_SECOND;
            secs.checked_add(addsecs as i64).ok_or_else(|| {
                py_overflow_error!("nanoseconds overflowed seconds in PySignedDuration::new")
            })?;
        }
        Ok(Self::from(SignedDuration::new(secs, nanos)))
    }

    fn __getnewargs__<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyTuple>> {
        PyTuple::new(
            py,
            vec![
                self.0.as_secs().into_bound_py_any(py)?,
                self.0.subsec_nanos().into_bound_py_any(py)?,
            ],
        )
    }

    #[classattr]
    fn __match_args__() -> (&'static str, &'static str) {
        ("secs", "nanos")
    }

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn MIN() -> Self {
        Self(SignedDuration::MIN)
    }

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn MAX() -> Self {
        Self(SignedDuration::MAX)
    }

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn ZERO() -> Self {
        Self(SignedDuration::ZERO)
    }

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn HOUR() -> Self {
        Self(SignedDuration::from_secs(3600))
    }

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn MINUTE() -> Self {
        Self(SignedDuration::from_secs(60))
    }

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn SECOND() -> Self {
        Self(SignedDuration::from_secs(1))
    }

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn MILLISECOND() -> Self {
        Self(SignedDuration::from_millis(1))
    }

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn MICROSECOND() -> Self {
        Self(SignedDuration::from_micros(1))
    }

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn NANOSECOND() -> Self {
        Self(SignedDuration::from_nanos(1))
    }

    // ========================================================================
    // PROPERTIES
    // ========================================================================

    #[getter]
    fn is_absolute(&self) -> bool {
        !(self.0.is_negative())
    }

    #[getter]
    fn secs(&self) -> i64 {
        self.0.as_secs()
    }

    #[getter]
    fn nanos(&self) -> i32 {
        self.0.subsec_nanos()
    }

    #[getter]
    fn ns(&self) -> i32 {
        self.0.subsec_nanos()
    }

    #[getter]
    fn nanoseconds(&self) -> i32 {
        self.0.subsec_nanos()
    }

    #[getter]
    fn is_positive(&self) -> bool {
        self.0.is_positive()
    }

    #[getter]
    fn is_negative(&self) -> bool {
        self.0.is_negative()
    }

    #[getter]
    fn is_zero(&self) -> bool {
        self.0.is_zero()
    }

    #[getter]
    fn subsec_micros(&self) -> i32 {
        self.0.subsec_micros()
    }

    #[getter]
    fn subsec_millis(&self) -> i32 {
        self.0.subsec_millis()
    }

    #[getter]
    fn subsec_nanos(&self) -> i32 {
        self.0.subsec_nanos()
    }

    #[staticmethod]
    fn from_pytimedelta(delta: JiffSignedDuration) -> Self {
        Self(delta.into_inner())
    }

    fn to_py(&self) -> JiffSignedDuration {
        self.to_pytimedelta()
    }

    fn to_pytimedelta(&self) -> JiffSignedDuration {
        JiffSignedDuration::new(self.0)
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_dict<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyDict>> {
        use crate::interns;
        let dict = PyDict::new(py);
        dict.set_item(interns::secs(py), self.0.as_secs())?;
        dict.set_item(interns::nanos(py), self.0.subsec_nanos())?;
        Ok(dict)
    }

    fn to_timespan(&self) -> PyResult<RySpan> {
        Span::try_from(self.0)
            .map(RySpan::from)
            .map_err(map_py_overflow_err)
    }

    #[inline]
    fn __abs__(slf: PyRef<'_, Self>) -> PyResult<Bound<'_, Self>> {
        Self::abs(slf)
    }

    #[inline]
    fn abs(slf: PyRef<'_, Self>) -> PyResult<Bound<'_, Self>> {
        let py = slf.py();
        // SignedDuration::abs panics when the seconds component of this signed duration is equal to i64::MIN.
        if slf.0.is_negative() {
            if slf.0.as_secs() == i64::MIN {
                return py_overflow_err!("overflow; secs == i64::MIN");
            }
            Self(slf.0.abs()).into_pyobject(py)
        } else {
            slf.into_pyobject_or_pyerr(py)
        }
    }

    fn unsigned_abs(&self) -> PyDuration {
        PyDuration::from(self.0.unsigned_abs())
    }

    fn __format__(&self, fmt: &str) -> PyResult<String> {
        if fmt == "#" {
            Ok(format!("{:#}", self.0))
        } else if fmt.is_empty() {
            Ok(self.0.to_string())
        } else {
            py_type_err!("Invalid format specifier '{fmt}' for SignedDuration")
        }
    }

    #[staticmethod]
    fn fromisoformat(s: &str) -> PyResult<Self> {
        TEMPORAL_SPAN_PARSER
            .parse_duration(s)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    #[pyo3(signature = (*, friendly = false), name = "to_string")]
    fn py_to_string(&self, friendly: bool) -> String {
        if friendly {
            FRIENDLY_SPAN_PRINTER.duration_to_string(&self.0)
        } else {
            self.0.to_string()
        }
    }

    #[pyo3(
        signature = (designator = JiffFriendlyDesignator::COMPACT),
        text_signature = "(self, designator=\"compact\")"
    )]
    fn friendly(&self, designator: JiffFriendlyDesignator) -> String {
        FRIENDLY_SPAN_PRINTER
            .designator(designator.into())
            .duration_to_string(&self.0)
    }

    fn __float__(&self) -> f64 {
        self.0.as_secs_f64()
    }

    #[pyo3(
        warn(
            message = "`SignedDuration.__int__` is deprecated; use `SignedDuration.as_nanos` instead [removal: v0.0.108]",
            category = pyo3::exceptions::PyDeprecationWarning
        )
    )]
    fn __int__(&self) -> i128 {
        self.0.as_nanos()
    }

    fn __bool__(&self) -> bool {
        !self.0.is_zero()
    }

    fn __str__(&self) -> PyAsciiString {
        self.0.to_string().into()
    }

    fn __repr__(&self) -> PyAsciiString {
        format!("{self}").into()
    }

    fn __hash__(&self) -> u64 {
        let mut hasher = DefaultHasher::new();
        self.0.hash(&mut hasher);
        hasher.finish()
    }

    fn __add__(
        &self,
        other: maths::SignedDurationAddTarget<'_, '_>,
    ) -> PyResult<maths::PySignedDurationAddOutput> {
        use maths::PySignedDurationAdd;
        other.add_signed_duration(self)
    }

    #[expect(clippy::too_many_arguments, reason = "python kwargs")]
    #[pyo3(
        signature = (
            other = None,
            /, *,
            hours = None,
            minutes = None,
            seconds = None,
            milliseconds = None,
            microseconds = None,
            nanoseconds = None
        )
    )]
    fn add(
        &self,
        other: Option<maths::SignedDurationAddTarget<'_, '_>>,
        // **KWARG ONLY
        hours: Option<i64>,
        minutes: Option<i64>,
        seconds: Option<i64>,
        milliseconds: Option<i64>,
        microseconds: Option<i64>,
        nanoseconds: Option<i64>,
    ) -> PyResult<maths::PySignedDurationAddOutput> {
        use maths::PySignedDurationAdd;
        let kw = maths::SignedDurationArithmeticKwargs::new()
            .hours_opt(hours)
            .minutes_opt(minutes)
            .seconds_opt(seconds)
            .milliseconds_opt(milliseconds)
            .microseconds_opt(microseconds)
            .nanoseconds_opt(nanoseconds);
        match (other, !kw.is_empty()) {
            (Some(other), false) => other.add_signed_duration(self),
            (None, true) => {
                let duration = kw.to_signed_duration()?;
                self.0
                    .checked_add(duration)
                    .map(Self::from)
                    .map(maths::PySignedDurationAddOutput::SignedDuration)
                    .ok_or_else(|| py_overflow_error!())
            }
            (None, false) => {
                py_type_err!("add() missing required argument: 'other' or keyword units")
            }
            (Some(_), true) => {
                py_type_err!("add() accepts either a span-like object or keyword units, not both")
            }
        }
    }

    fn __radd__(
        &self,
        other: maths::SignedDurationAddTarget<'_, '_>,
    ) -> PyResult<maths::PySignedDurationAddOutput> {
        use maths::PySignedDurationAdd;
        other.add_signed_duration(self)
    }

    #[expect(clippy::too_many_arguments, reason = "python kwargs")]
    #[pyo3(
        signature = (
            other = None,
            /, *,
            hours = None,
            minutes = None,
            seconds = None,
            milliseconds = None,
            microseconds = None,
            nanoseconds = None
        )
    )]
    fn sub(
        &self,
        other: Option<maths::SignedDurationSubTarget<'_, '_>>,
        // **KWARG ONLY
        hours: Option<i64>,
        minutes: Option<i64>,
        seconds: Option<i64>,
        milliseconds: Option<i64>,
        microseconds: Option<i64>,
        nanoseconds: Option<i64>,
    ) -> PyResult<Self> {
        use maths::PySignedDurationSub;

        let kw = maths::SignedDurationArithmeticKwargs::new()
            .hours_opt(hours)
            .minutes_opt(minutes)
            .seconds_opt(seconds)
            .milliseconds_opt(milliseconds)
            .microseconds_opt(microseconds)
            .nanoseconds_opt(nanoseconds);
        match (other, !kw.is_empty()) {
            (Some(other), false) => other.sub_signed_duration(self),
            (None, true) => {
                let duration = kw.to_signed_duration()?;
                self.0
                    .checked_sub(duration)
                    .map(Self::from)
                    .ok_or_else(|| py_overflow_error!())
            }
            (None, false) => {
                py_type_err!("sub() missing required argument: 'other' or keyword units")
            }
            (Some(_), true) => {
                py_type_err!(
                    "sub() accepts either a duration-like object or keyword units, not both"
                )
            }
        }
    }

    fn __sub__(&self, other: maths::SignedDurationSubTarget<'_, '_>) -> PyResult<Self> {
        use maths::PySignedDurationSub;
        other.sub_signed_duration(self)
    }

    fn __rsub__(&self, other: maths::SignedDurationSubTarget<'_, '_>) -> PyResult<Self> {
        use maths::PySignedDurationSub;
        other.rsub_signed_duration(self)
    }

    fn __mul__(&self, other: maths::PySignedDurationMulInput) -> PyResult<Self> {
        other.multiply_signed_duration(self)
    }

    fn __rmul__(&self, other: maths::PySignedDurationMulInput) -> PyResult<Self> {
        self.__mul__(other)
    }

    fn __truediv__(
        &self,
        other: maths::PySignedDurationTrueDivInput<'_, '_>,
    ) -> PyResult<maths::PySignedDurationTrueDivOutput> {
        other.divide_signed_duration(self)
    }

    fn __neg__(&self) -> PyResult<Self> {
        self.0
            .checked_neg()
            .map(Self::from)
            .ok_or_else(|| py_value_error!("negation does not exist"))
    }

    #[getter]
    fn days(&self) -> i64 {
        self.0.as_secs() / 86400
    }

    /// Return the number of seconds in the duration counting days
    #[getter]
    fn seconds(&self) -> i64 {
        self.0.as_secs()
    }

    /// Return the seconds % days (self.seconds % 86400)
    #[getter]
    fn seconds_remainder(&self) -> i64 {
        self.0.as_secs() % 86400
    }

    #[getter]
    fn microseconds(&self) -> i32 {
        self.0.subsec_micros()
    }

    fn equiv(&self, other: &Bound<'_, PyAny>) -> PyResult<bool> {
        if let Ok(other_sd) = other.cast_exact::<Self>() {
            let sd = other_sd.get();
            Ok(self.0 == sd.0)
        } else if let Ok(other_ud) = other.cast_exact::<PyDuration>() {
            if self.0.is_negative() {
                Ok(false)
            } else {
                Ok(SignedDuration::try_from(*other_ud.get().inner())
                    .is_ok_and(|duration| self.0 == duration))
            }
        } else if let Ok(other_td) = other.cast::<pyo3::types::PyDelta>() {
            let extract_ed = pydelta_to_signed_duration(other_td)?;
            Ok(self.0 == extract_ed)
        } else {
            py_type_err!("comparison not supported between SignedDuration and given type")
        }
    }

    // =========
    // FROM NUMS
    // =========
    #[staticmethod]
    fn from_hours(hours: i64) -> PyResult<Self> {
        const MIN_HOUR: i64 = i64::MIN / (SECONDS_PER_MINUTE * MINUTES_PER_HOUR);
        // OK because (SECS_PER_MINUTE*MINS_PER_HOUR)!={-1,0}.
        const MAX_HOUR: i64 = i64::MAX / (SECONDS_PER_MINUTE * MINUTES_PER_HOUR);
        if (MIN_HOUR..=MAX_HOUR).contains(&hours) {
            Ok(Self(SignedDuration::from_hours(hours)))
        } else {
            Err(py_overflow_error!(
                "hours value {hours} out of range [{MIN_HOUR}, {MAX_HOUR}]"
            ))
        }
    }

    #[staticmethod]
    fn from_micros(micros: i64) -> Self {
        Self(SignedDuration::from_micros(micros))
    }

    #[staticmethod]
    fn from_millis(millis: i64) -> Self {
        Self(SignedDuration::from_millis(millis))
    }

    #[staticmethod]
    fn from_mins(mins: i64) -> PyResult<Self> {
        const MIN_MINUTE: i64 = i64::MIN / SECONDS_PER_MINUTE;
        const MAX_MINUTE: i64 = i64::MAX / SECONDS_PER_MINUTE;
        if (MIN_MINUTE..=MAX_MINUTE).contains(&mins) {
            Ok(Self(SignedDuration::from_mins(mins)))
        } else {
            Err(py_overflow_error!(
                "minutes value {mins} out of range [{MIN_MINUTE}, {MAX_MINUTE}]"
            ))
        }
    }

    #[staticmethod]
    fn from_nanos(nanos: i64) -> Self {
        Self(SignedDuration::from_nanos(nanos))
    }

    #[staticmethod]
    #[pyo3(name = "from_secs")]
    fn py_from_secs(secs: &Bound<'_, PyAny>) -> PyResult<Self> {
        if let Some(secs) = secs.cast_exact_opt::<PyInt>() {
            secs.extract::<i64>()
                .map(|s| Self(SignedDuration::from_secs(s)))
        } else if let Some(secs) = secs
            .cast_exact_opt::<PyFloat>()
            .and_then(|f| f.extract::<f64>().ok())
        {
            Self::py_try_from_secs_f64(secs)
        } else {
            py_type_err!("Invalid type for seconds; expected i64 or f64")
        }
    }

    #[staticmethod]
    fn from_secs_f32(secs: f32) -> PyResult<Self> {
        Self::py_try_from_secs_f32(secs)
    }

    #[staticmethod]
    fn from_secs_f64(secs: f64) -> PyResult<Self> {
        Self::py_try_from_secs_f64(secs)
    }

    /// Return 1 if positive, -1 if negative, 0 if zero
    fn signum(&self) -> i8 {
        self.0.signum()
    }

    #[pyo3(signature = (*, secs = None, nanos = None))]
    fn replace(&self, secs: Option<i64>, nanos: Option<i32>) -> PyResult<Self> {
        Self::py_new(
            secs.unwrap_or(self.0.as_secs()),
            nanos.unwrap_or(self.0.subsec_nanos()),
        )
    }

    // --RETURN SAME INST VERSION--
    // fn replace(
    //     slf: PyRef<'_, Self>,
    //     secs: Option<i64>,
    //     nanos: Option<i32>,
    // ) -> PyResult<Bound<'_, Self>> {
    //     match (secs, nanos) {
    //         (Some(secs), Some(nanos)) => {
    //             Self::py_new(secs, nanos)?.into_pyobject_or_pyerr(slf.py())
    //         }
    //         (Some(secs), None) => {
    //             Self::py_new(secs, slf.0.subsec_nanos())?.into_pyobject_or_pyerr(slf.py())
    //         }
    //         (None, Some(nanos)) => {
    //             Self::py_new(slf.0.as_secs(), nanos)?.into_pyobject_or_pyerr(slf.py())
    //         }
    //         (None, None) => {
    //             let py = slf.py();
    //             slf.into_pyobject_or_pyerr(py)
    //         }
    //     }
    // }

    // =======
    // AS NUMS
    // =======
    fn as_hours(&self) -> i64 {
        self.0.as_hours()
    }

    fn as_micros(&self) -> i128 {
        self.0.as_micros()
    }

    fn as_millis(&self) -> i128 {
        self.0.as_millis()
    }

    fn as_millis_f32(&self) -> f32 {
        self.0.as_millis_f32()
    }

    fn as_millis_f64(&self) -> f64 {
        self.0.as_millis_f64()
    }

    fn as_mins(&self) -> i64 {
        self.0.as_mins()
    }

    fn as_nanos(&self) -> i128 {
        self.0.as_nanos()
    }

    fn as_secs(&self) -> i64 {
        self.0.as_secs()
    }

    fn as_secs_f32(&self) -> f32 {
        self.0.as_secs_f32()
    }

    fn as_secs_f64(&self) -> f64 {
        self.0.as_secs_f64()
    }

    // ------------------------------------------------------------------------
    // CHECKED-ARITHMETIC
    // ------------------------------------------------------------------------
    fn checked_add(&self, other: &Self) -> Option<Self> {
        self.0.checked_add(other.0).map(Self::from)
    }

    fn checked_div(&self, other: i32) -> Option<Self> {
        self.0.checked_div(other).map(Self::from)
    }

    fn checked_mul(&self, other: i32) -> Option<Self> {
        self.0.checked_mul(other).map(Self::from)
    }

    fn checked_neg(&self) -> Option<Self> {
        self.0.checked_neg().map(Self::from)
    }

    fn checked_sub(&self, other: &Self) -> Option<Self> {
        self.0.checked_sub(other.0).map(Self::from)
    }

    fn div_duration_f32(&self, other: &Self) -> PyResult<f32> {
        if other.0.is_zero() {
            py_zero_division_err!("Cannot divide SignedDuration by zero")
        } else {
            Ok(self.0.div_duration_f32(other.0))
        }
    }

    fn div_duration_f64(&self, other: &Self) -> PyResult<f64> {
        if other.0.is_zero() {
            py_zero_division_err!("Cannot divide SignedDuration by zero")
        } else {
            Ok(self.0.div_duration_f64(other.0))
        }
    }

    fn div_f32(&self, n: f32) -> PyResult<Self> {
        if n.abs() == 0.0 {
            py_zero_division_err!()
        } else if n.is_nan() {
            py_value_err!("invalid value: nan")
        } else if n.is_infinite() {
            py_overflow_err!("invalid value: inf")
        } else if n.is_sign_negative() {
            py_type_err!("negative divisor")
        } else {
            let result = self.0.as_secs_f32().div(n);
            Self::py_try_from_secs_f32(result)
        }
    }

    fn div_f64(&self, n: f64) -> PyResult<Self> {
        if n.abs() == 0.0 {
            py_zero_division_err!()
        } else if n.is_nan() {
            py_value_err!("invalid value: nan")
        } else if n.is_infinite() {
            py_overflow_err!("invalid value: inf")
        } else if n.is_sign_negative() {
            py_type_err!("negative divisor")
        } else {
            let result = self.0.as_secs_f64().div(n);
            Self::py_try_from_secs_f64(result)
        }
    }

    fn mul_f32(&self, n: f32) -> PyResult<Self> {
        if n.abs() == 0.0 {
            Ok(Self::from(SignedDuration::ZERO))
        } else if n.is_infinite() {
            py_overflow_err!()
        } else if n.is_nan() {
            py_value_err!("invalid value: nan")
        } else {
            let result = self.0.as_secs_f32().mul(n);
            Self::py_try_from_secs_f32(result)
        }
    }

    fn mul_f64(&self, n: f64) -> PyResult<Self> {
        if n.abs() == 0.0 {
            Ok(Self::from(SignedDuration::ZERO))
        } else if n.is_infinite() {
            py_overflow_err!()
        } else if n.is_nan() {
            py_value_err!("invalid value: nan")
        } else {
            let result = self.0.as_secs_f64().mul(n);
            Self::py_try_from_secs_f64(result)
        }
    }
    // ------------------------------------------------------------------------
    // SATURATING-ARITHMETIC
    // ------------------------------------------------------------------------
    fn saturating_add(&self, other: &Self) -> Self {
        Self::from(self.0.saturating_add(other.0))
    }

    fn saturating_mul(&self, other: i32) -> Self {
        Self::from(self.0.saturating_mul(other))
    }

    fn saturating_sub(&self, other: &Self) -> Self {
        Self::from(self.0.saturating_sub(other.0))
    }

    // ========================================================================
    // ROUND
    // ========================================================================
    #[pyo3(
        signature = (
            smallest = JiffUnit::NANOSECOND,
            *,
            mode = JiffRoundMode::HALF_EXPAND,
            increment = 1,
        ),
        text_signature = "(self, smallest=\"nanosecond\", *, mode=\"half-expand\", increment=1)",
    )]
    fn round(&self, smallest: JiffUnit, mode: JiffRoundMode, increment: i64) -> PyResult<Self> {
        let dt_round = SignedDurationRound::new()
            .smallest(smallest.into())
            .mode(mode.into())
            .increment(increment);
        self.0
            .round(dt_round)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    fn _round(&self, options: &RySignedDurationRound) -> PyResult<Self> {
        self.0
            .round(options.jiff_round)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    // ========================================================================
    // EXTRACT
    // ========================================================================
    #[staticmethod]
    fn from_any<'py>(value: &Bound<'py, PyAny>) -> PyResult<Bound<'py, Self>> {
        use ryo3_core::PyCastOpt;
        let py = value.py();
        if let Some(val) = value.cast_exact_opt::<Self>() {
            Ok(val.as_borrowed().into_bound())
        } else if let Some(pystr) = value.cast_opt::<pyo3::types::PyString>() {
            let s = pystr.extract::<&str>()?;
            Self::from_str(s).map(|dt| dt.into_pyobject(py))?
        } else if let Some(pybytes) = value.cast_opt::<pyo3::types::PyBytes>() {
            let s = String::from_utf8_lossy(pybytes.as_bytes());
            Self::from_str(&s).map(|dt| dt.into_pyobject(py))?
        } else if let Some(v) = value.cast_exact_opt::<PyFloat>() {
            let f = v.extract::<f64>()?;
            if f.is_nan() || f.is_infinite() {
                return py_value_err!("Cannot convert NaN or infinite float to SignedDuration");
            }
            Self::py_try_from_secs_f64(f).and_then(|dt| dt.into_pyobject(py))
        } else if let Some(v) = value.cast_exact_opt::<PyInt>() {
            let i = v.extract::<i64>()?;
            Self::from(SignedDuration::new(i, 0)).into_pyobject(py)
        } else if let Ok(d) = value.extract::<JiffSignedDuration>() {
            Self::from(d.into_inner()).into_pyobject(py)
        } else {
            let valtype = any_repr!(value);
            py_type_err!("SignedDuration conversion error: {valtype}")
        }
    }
    // ========================================================================
    // PYDANTIC
    // ========================================================================

    #[cfg(feature = "pydantic")]
    #[staticmethod]
    fn _pydantic_validate<'py>(value: &Bound<'py, PyAny>) -> PyResult<Bound<'py, Self>> {
        Self::from_any(value).map_err(map_py_value_err)
    }

    #[cfg(feature = "pydantic")]
    #[classmethod]
    fn __get_pydantic_core_schema__<'py>(
        cls: &Bound<'py, ::pyo3::types::PyType>,
        source: &Bound<'py, PyAny>,
        handler: &Bound<'py, PyAny>,
    ) -> PyResult<Bound<'py, PyAny>> {
        use ryo3_pydantic::GetPydanticCoreSchemaCls;
        Self::get_pydantic_core_schema(cls, source, handler)
    }

    // ========================================================================
    // STANDARD METHODS
    // ========================================================================
    // <STD-METHODS>
    #[staticmethod]
    #[pyo3(signature = (s, /))]
    fn from_str(s: &str) -> PyResult<Self> {
        use ryo3_core::PyFromStr;
        Self::py_from_str(s)
    }

    #[staticmethod]
    #[pyo3(signature = (value, /))]
    fn parse(value: ryo3_core::PyParseArg<Self>) -> Self {
        value.into_inner()
    }

    fn isoformat(&self) -> PyAsciiString {
        <Self as crate::isoformat::PyIsoFormat>::isoformat(self)
    }
    // </STD-METHODS>
}

impl Display for RySignedDuration {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "SignedDuration(secs={}, nanos={})",
            self.0.as_secs(),
            self.0.subsec_nanos()
        )
    }
}

// ===========================================================================
// MATHS ~ MATHS ~ MATHS ~ MATHS ~ MATHS ~ MATHS ~ MATHS ~ MATHS ~ MATHS
// ===========================================================================
mod maths {

    use jiff::SignedDuration;
    use pyo3::IntoPyObjectExt;
    use pyo3::prelude::*;
    use ryo3_core::{PyCastExactOpt, map_py_overflow_err};
    use ryo3_jiff_core::JiffSignedDuration;
    use ryo3_macro_rules::{py_overflow_error, py_type_err, py_zero_division_err};

    use super::RySignedDuration;
    use crate::py_temporal_like::PyTemporalArg;
    use crate::{RyDate, RyDateTime, RyTime, RyTimestamp, RyZoned};

    // ========================================================================
    // ARITHMETIC KWARGS - ADD/SUB KWARGS
    // ========================================================================
    #[derive(Debug, Clone, Copy, PartialEq, Eq)]
    pub(crate) enum ExactUnit {
        Hours = 1 << 0,
        Minutes = 1 << 1,
        Seconds = 1 << 2,
        Milliseconds = 1 << 3,
        Microseconds = 1 << 4,
        Nanoseconds = 1 << 5,
    }

    #[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
    pub(crate) struct ExactUnitMask(u8);

    impl ExactUnitMask {
        #[expect(
            clippy::cast_possible_truncation,
            reason = "wenodis: cant fail bc there are only 10 span units"
        )]
        pub(crate) const fn count(self) -> u8 {
            self.0.count_ones() as u8
        }

        pub(crate) const fn with_unit(mut self, unit: ExactUnit) -> Self {
            self.0 |= unit as u8;
            self
        }
    }

    #[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
    pub(crate) struct SignedDurationArithmeticKwargs {
        mask: ExactUnitMask,
        hours: i64,
        minutes: i64,
        seconds: i64,
        milliseconds: i64,
        microseconds: i64,
        nanoseconds: i64,
    }
    macro_rules! kw_builder {
        ($field:ident, $field_opt:ident, $unit:ident, $itype:ty) => {
            #[inline]
            pub(crate) const fn $field_opt(mut self, value: Option<$itype>) -> Self {
                if let Some(value) = value {
                    self.mask = self.mask.with_unit(ExactUnit::$unit);
                    self.$field = value;
                }
                self
            }
        };
    }
    impl SignedDurationArithmeticKwargs {
        pub(crate) fn new() -> Self {
            Self::default()
        }

        #[inline]
        pub(crate) const fn is_empty(&self) -> bool {
            self.mask.count() == 0
        }

        #[inline]
        pub(crate) const fn is_zero(&self) -> bool {
            self.hours == 0
                && self.minutes == 0
                && self.seconds == 0
                && self.milliseconds == 0
                && self.microseconds == 0
                && self.nanoseconds == 0
        }

        kw_builder!(hours, hours_opt, Hours, i64);
        kw_builder!(minutes, minutes_opt, Minutes, i64);
        kw_builder!(seconds, seconds_opt, Seconds, i64);
        kw_builder!(milliseconds, milliseconds_opt, Milliseconds, i64);
        kw_builder!(microseconds, microseconds_opt, Microseconds, i64);
        kw_builder!(nanoseconds, nanoseconds_opt, Nanoseconds, i64);

        pub(super) fn to_signed_duration(self) -> PyResult<SignedDuration> {
            if self.is_zero() {
                return Ok(SignedDuration::ZERO);
            }

            SignedDuration::try_from_hours(self.hours)
                .and_then(|sd| {
                    SignedDuration::try_from_mins(self.minutes)
                        .and_then(|mins| sd.checked_add(mins))
                })
                .and_then(|sd| sd.checked_add(SignedDuration::from_secs(self.seconds)))
                .and_then(|sd| sd.checked_add(SignedDuration::from_millis(self.milliseconds)))
                .and_then(|sd| sd.checked_add(SignedDuration::from_micros(self.microseconds)))
                .and_then(|sd| sd.checked_add(SignedDuration::from_nanos(self.nanoseconds)))
                .ok_or_else(|| {
                    py_overflow_error!(
                        "overflow occurred while computing SignedDuration from kwargs"
                    )
                })
        }
    }

    // ========================================================================
    // ADD
    // ========================================================================
    #[derive(Debug, Clone)]
    pub(crate) enum SignedDurationAddTarget<'a, 'py> {
        SignedDuration(Borrowed<'a, 'py, RySignedDuration>),
        Delta(SignedDuration),
        TemporalType(PyTemporalArg<'a, 'py>),
    }

    impl<'a, 'py> FromPyObject<'a, 'py> for SignedDurationAddTarget<'a, 'py> {
        type Error = PyErr;

        fn extract(obj: Borrowed<'a, 'py, PyAny>) -> Result<Self, Self::Error> {
            if let Ok(sd) = obj.cast_exact::<RySignedDuration>() {
                Ok(Self::SignedDuration(sd))
            } else if let Ok(dur) = obj.cast_exact::<ryo3_std::time::PyDuration>() {
                RySignedDuration::try_from(dur.get()).map(|rysd| Self::Delta(rysd.into()))
            } else if let Ok(d) = obj.cast::<pyo3::types::PyDelta>() {
                let rs_dur: JiffSignedDuration = d.extract()?;
                Ok(Self::Delta(rs_dur.into_inner()))
            } else if let Ok(date_time_type) = obj.extract::<PyTemporalArg<'a, 'py>>() {
                Ok(Self::TemporalType(date_time_type))
            } else {
                py_type_err!(
                    "unsupported operand type(s); must be SignedDuration | datetime.timedelta | TemporalType( Date | DateTime | Time | Zoned | Timestamp )"
                )
            }
        }
    }

    pub(super) trait PySignedDurationAdd<'a, 'py> {
        type Output;
        fn add_signed_duration(self, sd: &RySignedDuration) -> PyResult<Self::Output>;
    }

    // this is some fugue-state-jesse shit from last week -- idk wtf I was dgoing,
    // but I was absolutely in that insane macro-flow state
    macro_rules! impl_signed_duration_add_for_borrowed_temporal {
        ($ty:ty) => {
            impl<'a, 'py> PySignedDurationAdd<'a, 'py> for Borrowed<'a, 'py, $ty> {
                type Output = $ty;
                fn add_signed_duration(self, sd: &RySignedDuration) -> PyResult<Self::Output> {
                    self.get()
                        .0
                        .checked_add(sd.0)
                        .map(Self::Output::from)
                        .map_err(map_py_overflow_err)
                }
            }
        };
    }

    pub(super) enum PySignedDurationAddOutput {
        SignedDuration(RySignedDuration),
        Zoned(RyZoned),
        Date(RyDate),
        DateTime(RyDateTime),
        Time(RyTime),
        Timestamp(RyTimestamp),
    }

    impl<'py> IntoPyObject<'py> for PySignedDurationAddOutput {
        type Target = PyAny;

        type Output = Bound<'py, PyAny>;

        type Error = PyErr;
        fn into_pyobject(self, py: Python<'py>) -> Result<Self::Output, PyErr> {
            match self {
                Self::SignedDuration(sd) => sd.into_bound_py_any(py),
                Self::Zoned(z) => z.into_bound_py_any(py),
                Self::Date(d) => d.into_bound_py_any(py),
                Self::DateTime(dt) => dt.into_bound_py_any(py),
                Self::Time(t) => t.into_bound_py_any(py),
                Self::Timestamp(ts) => ts.into_bound_py_any(py),
            }
        }
    }

    impl_signed_duration_add_for_borrowed_temporal!(RyDate);
    impl_signed_duration_add_for_borrowed_temporal!(RyDateTime);
    impl_signed_duration_add_for_borrowed_temporal!(RyTime);
    impl_signed_duration_add_for_borrowed_temporal!(RyZoned);
    impl_signed_duration_add_for_borrowed_temporal!(RyTimestamp);

    impl<'a, 'py> PySignedDurationAdd<'a, 'py> for PyTemporalArg<'a, 'py> {
        type Output = PySignedDurationAddOutput;
        fn add_signed_duration(self, sd: &RySignedDuration) -> PyResult<Self::Output> {
            match self {
                Self::Date(date) => date
                    .add_signed_duration(sd)
                    .map(PySignedDurationAddOutput::Date),
                Self::DateTime(datetime) => datetime
                    .add_signed_duration(sd)
                    .map(PySignedDurationAddOutput::DateTime),
                Self::Time(time) => time
                    .add_signed_duration(sd)
                    .map(PySignedDurationAddOutput::Time),
                Self::Zoned(zoned) => zoned
                    .add_signed_duration(sd)
                    .map(PySignedDurationAddOutput::Zoned),
                Self::Timestamp(timestamp) => timestamp
                    .add_signed_duration(sd)
                    .map(PySignedDurationAddOutput::Timestamp),
            }
        }
    }

    impl<'a, 'py> PySignedDurationAdd<'a, 'py> for SignedDurationAddTarget<'a, 'py> {
        // type Target = PyAny;
        type Output = PySignedDurationAddOutput;

        fn add_signed_duration(self, lhs: &RySignedDuration) -> PyResult<Self::Output> {
            match self {
                Self::SignedDuration(rhs) => lhs
                    .0
                    .checked_add(rhs.get().0)
                    .map(|e| {
                        let sd = RySignedDuration::from(e);
                        PySignedDurationAddOutput::SignedDuration(sd)
                    })
                    .ok_or_else(|| py_overflow_error!()),
                Self::Delta(rhs) => lhs
                    .0
                    .checked_add(rhs)
                    .map(|e| {
                        let sd = RySignedDuration::from(e);
                        PySignedDurationAddOutput::SignedDuration(sd)
                    })
                    .ok_or_else(|| py_overflow_error!()),
                Self::TemporalType(t) => t.add_signed_duration(lhs),
            }
        }
    }

    // ========================================================================
    // SUB
    // ========================================================================
    pub(super) trait PySignedDurationSub<'a, 'py> {
        type Output;
        fn sub_signed_duration(self, sd: &RySignedDuration) -> PyResult<Self::Output>;

        fn rsub_signed_duration(self, sd: &RySignedDuration) -> PyResult<Self::Output>;
    }

    #[derive(Debug, Clone)]
    pub(super) enum SignedDurationSubTarget<'a, 'py> {
        SignedDuration(Borrowed<'a, 'py, RySignedDuration>),
        Delta(SignedDuration),
    }

    impl<'a, 'py> FromPyObject<'a, 'py> for SignedDurationSubTarget<'a, 'py> {
        type Error = PyErr;

        fn extract(obj: Borrowed<'a, 'py, PyAny>) -> Result<Self, Self::Error> {
            if let Ok(sd) = obj.cast_exact::<RySignedDuration>() {
                Ok(Self::SignedDuration(sd))
            } else if let Ok(dur) = obj.cast_exact::<ryo3_std::time::PyDuration>() {
                RySignedDuration::try_from(dur.get()).map(|rysd| Self::Delta(rysd.into()))
            } else if let Ok(d) = obj.cast::<pyo3::types::PyDelta>() {
                let rs_dur: JiffSignedDuration = d.extract()?;
                Ok(Self::Delta(rs_dur.into_inner()))
            } else {
                py_type_err!(
                    "unsupported operand type(s); must be SignedDuration | datetime.timedelta"
                )
            }
        }
    }

    impl<'a, 'py> PySignedDurationSub<'a, 'py> for SignedDurationSubTarget<'a, 'py> {
        type Output = RySignedDuration;

        fn sub_signed_duration(
            self,
            lhs: &RySignedDuration, // rename
        ) -> PyResult<Self::Output> {
            match self {
                Self::SignedDuration(rhs) => lhs
                    .0
                    .checked_sub(rhs.get().0)
                    .map(RySignedDuration::from)
                    .ok_or_else(|| py_overflow_error!()),
                // .map(|e| e.into_pyobject(py))?,
                Self::Delta(rhs) => lhs
                    .0
                    .checked_sub(rhs)
                    .map(RySignedDuration::from)
                    .ok_or_else(|| py_overflow_error!()),
                // .map(|e| e.into_pyobject(py))?,
            }
        }

        fn rsub_signed_duration(self, rhs: &RySignedDuration) -> PyResult<Self::Output> {
            match self {
                // I dont think this shit is possible bc the sub-would have
                // already taken care of it?
                Self::SignedDuration(lhs) => lhs
                    .get()
                    .0
                    .checked_sub(rhs.0)
                    .map(RySignedDuration::from)
                    .ok_or_else(|| py_overflow_error!()),
                Self::Delta(lhs) => (lhs)
                    .checked_sub(rhs.0)
                    .map(RySignedDuration::from)
                    .ok_or_else(|| py_overflow_error!()),
            }
        }
    }

    // ========================================================================
    // MUL
    // ========================================================================

    pub(super) enum PySignedDurationMulInput {
        Int(i32),
        Float(f64),
    }

    impl PySignedDurationMulInput {
        pub(super) fn multiply_signed_duration(
            self,
            sd: &RySignedDuration,
        ) -> PyResult<RySignedDuration> {
            match self {
                Self::Int(n) => sd.checked_mul(n).ok_or_else(|| py_overflow_error!()),
                Self::Float(f) => sd.mul_f64(f),
            }
        }
    }

    impl<'a, 'py> FromPyObject<'a, 'py> for PySignedDurationMulInput {
        type Error = PyErr;

        fn extract(obj: Borrowed<'a, 'py, PyAny>) -> Result<Self, Self::Error> {
            if let Ok(i) = obj.extract::<i32>() {
                Ok(Self::Int(i))
            } else if let Ok(f) = obj.extract::<f64>() {
                Ok(Self::Float(f))
            } else {
                py_type_err!("unsupported operand type(s); must be int or float")
            }
        }
    }

    // ========================================================================
    // TRUEDIV
    // ========================================================================
    pub(super) enum PySignedDurationTrueDivInput<'a, 'py> {
        PySignedDuration(Borrowed<'a, 'py, RySignedDuration>),
        SignedDuration(SignedDuration),
        Int(i32),
        Float(f64),
    }

    pub(super) enum PySignedDurationTrueDivOutput {
        Float(f64),
        SignedDuration(RySignedDuration),
    }

    impl PySignedDurationTrueDivInput<'_, '_> {
        pub(super) fn divide_signed_duration(
            self,
            sd: &RySignedDuration,
        ) -> PyResult<PySignedDurationTrueDivOutput> {
            match self {
                Self::PySignedDuration(dur) => sd.div_duration_f64(dur.get()).map(Into::into),
                Self::SignedDuration(dur) => {
                    if dur.is_zero() {
                        py_zero_division_err!()
                    } else {
                        Ok(sd.0.div_duration_f64(dur).into())
                    }
                }
                Self::Int(n) => {
                    if n == 0 {
                        py_zero_division_err!("Cannot divide SignedDuration by zero")
                    } else {
                        sd.checked_div(n)
                            .ok_or_else(|| py_overflow_error!())
                            .map(Into::into)
                    }
                }
                Self::Float(n) => sd.div_f64(n).map(Into::into),
            }
        }
    }

    impl From<f64> for PySignedDurationTrueDivOutput {
        fn from(f: f64) -> Self {
            Self::Float(f)
        }
    }

    impl From<RySignedDuration> for PySignedDurationTrueDivOutput {
        fn from(sd: RySignedDuration) -> Self {
            Self::SignedDuration(sd)
        }
    }

    impl<'a, 'py> FromPyObject<'a, 'py> for PySignedDurationTrueDivInput<'a, 'py> {
        type Error = PyErr;

        fn extract(obj: Borrowed<'a, 'py, PyAny>) -> Result<Self, Self::Error> {
            if let Some(sd) = obj.cast_exact_opt::<RySignedDuration>() {
                Ok(Self::PySignedDuration(sd))
            } else if let Some(dur) = obj.cast_exact_opt::<ryo3_std::time::PyDuration>() {
                RySignedDuration::try_from(dur.get()).map(|rysd| Self::SignedDuration(rysd.into()))
            } else if let Ok(d) = obj.cast::<pyo3::types::PyDelta>() {
                let rs_dur: JiffSignedDuration = d.extract()?;
                Ok(Self::SignedDuration(rs_dur.into_inner()))
            } else if let Ok(i) = obj.extract::<i32>() {
                Ok(Self::Int(i))
            } else if let Ok(f) = obj.extract::<f64>() {
                Ok(Self::Float(f))
            } else {
                py_type_err!(
                    "unsupported operand type(s); must be SignedDuration | Duration | datetime.timedelta | int | float"
                )
            }
        }
    }

    impl<'py> IntoPyObject<'py> for PySignedDurationTrueDivOutput {
        type Target = PyAny;
        type Output = Bound<'py, Self::Target>;
        type Error = PyErr;

        fn into_pyobject(self, py: Python<'py>) -> Result<Self::Output, Self::Error> {
            match self {
                Self::Float(f) => f.into_bound_py_any(py),
                Self::SignedDuration(sd) => sd.into_bound_py_any(py),
            }
        }
    }
}
