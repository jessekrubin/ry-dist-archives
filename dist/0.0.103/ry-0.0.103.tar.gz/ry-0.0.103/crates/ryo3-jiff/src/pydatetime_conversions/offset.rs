use jiff::tz::Offset;
use pyo3::prelude::*;
use pyo3::types::{PyNone, PyTzInfo};
use ryo3_core::map_py_value_err;
use ryo3_macro_rules::py_type_err;

use crate::{JiffOffset, JiffSignedDuration, JiffTimeZone};

impl<'py> IntoPyObject<'py> for JiffOffset {
    type Target = PyTzInfo;
    type Output = Bound<'py, Self::Target>;
    type Error = PyErr;

    fn into_pyobject(self, py: Python<'py>) -> Result<Self::Output, Self::Error> {
        (&self).into_pyobject(py)
    }
}

impl<'py> IntoPyObject<'py> for &JiffOffset {
    type Target = PyTzInfo;
    type Output = Bound<'py, Self::Target>;
    type Error = PyErr;

    fn into_pyobject(self, py: Python<'py>) -> Result<Self::Output, Self::Error> {
        JiffTimeZone::new(self.inner().to_time_zone()).into_pyobject(py)
    }
}

impl<'py> FromPyObject<'_, 'py> for JiffOffset {
    type Error = PyErr;

    fn extract(obj: Borrowed<'_, 'py, PyAny>) -> PyResult<Self> {
        let ob = obj.cast::<PyTzInfo>()?;

        let py_timedelta =
            ob.call_method1(pyo3::intern!(ob.py(), "utcoffset"), (PyNone::get(ob.py()),))?;
        if py_timedelta.is_none() {
            return py_type_err!("{ob:?} is not a fixed offset timezone");
        }
        let total_seconds: JiffSignedDuration = py_timedelta.extract()?;

        let total_seconds =
            i32::try_from(total_seconds.into_inner().as_secs()).map_err(map_py_value_err)?;
        Offset::from_seconds(total_seconds)
            .map(Self::from)
            .map_err(map_py_value_err)
    }
}
