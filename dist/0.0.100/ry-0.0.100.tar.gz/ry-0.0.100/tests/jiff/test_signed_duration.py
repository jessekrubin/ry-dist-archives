from __future__ import annotations

import datetime as pydt
from math import isnan

import pytest
from hypothesis import given
from hypothesis import strategies as st

import ry

from ..strategies import st_i32, st_i64
from .strategies import st_signed_durations

_NANOS_PER_SEC: int = 1_000_000_000
_NANOS_PER_MILLI: int = 1_000_000
_NANOS_PER_MICRO: int = 1_000
_MILLIS_PER_SEC: int = 1_000
_MICROS_PER_SEC: int = 1_000_000
_SECS_PER_MINUTE: int = 60
_MINS_PER_HOUR: int = 60


def test_signed_duration_replace() -> None:
    dur = ry.SignedDuration(1, 2)
    replaced = dur.replace(secs=3, nanos=4)
    assert replaced.secs == 3
    assert replaced.nanos == 4


def test_signed_duration_min_max() -> None:
    assert ry.SignedDuration.MIN == ry.SignedDuration(-(1 << 63), -999_999_999)
    assert ry.SignedDuration.MAX == ry.SignedDuration((1 << 63) - 1, 999_999_999)


@given(st_i64, st_i32)
def test_signed_duration_new(secs: int, nanos: int) -> None:
    # WTF this is some fugue-state-jesse oneliner unreadable bullshit shit from
    # the other day
    will_overflow = (abs(nanos) >= _NANOS_PER_SEC) and not (
        ry.I64_MIN
        <= (
            secs
            + ((nanos // _NANOS_PER_SEC) if nanos > 0 else -(-nanos // _NANOS_PER_SEC))
        )
        <= ry.I64_MAX
    )
    if will_overflow:
        with pytest.raises(OverflowError):
            _ = ry.SignedDuration(secs, nanos)
    else:
        dur = ry.SignedDuration(secs, nanos)
        assert isinstance(dur, ry.SignedDuration)
        expected_float = secs + (nanos / _NANOS_PER_SEC)
        if abs(expected_float) < 2**53:
            # check close enough if stupid fucking floating point numbers
            # aren't being a totally pain in the ass (as they almost
            # always are....). Idk what is going on here... this was
            # fugue state jesse yesterday (2025-12-13) and I just want my PR
            # to go
            assert abs(float(dur) - expected_float) < 1e-9


def test_signed_duration_cmp() -> None:
    left = ry.SignedDuration(1, 2)
    right = ry.SignedDuration(3, 4)
    assert left < right
    assert right > left
    assert left <= right
    assert right >= left
    assert left != right
    assert right != left
    assert left == left
    assert right == right


@given(st_signed_durations())
def test_cast_float(dur: ry.SignedDuration) -> None:
    f = float(dur)
    assert isinstance(f, float)
    if dur.is_zero:
        assert f == 0.0
    assert f == dur.as_secs() + dur.subsec_nanos / 1_000_000_000.0


@given(st_signed_durations())
def test_cast_int(dur: ry.SignedDuration) -> None:
    i = int(dur)
    assert isinstance(i, int)
    assert i == dur.as_nanos()


@given(st_signed_durations())
def test_cast_bool(dur: ry.SignedDuration) -> None:
    b = bool(dur)
    assert isinstance(b, bool)
    assert b == (not dur.is_zero)


@pytest.mark.skip(reason="legacy behavior ~ remove this test me")
def test_signed_duration_cmp_timedelta() -> None:
    left = ry.SignedDuration(1, 2)
    right = ry.SignedDuration(3, 4).to_py()
    assert left < right
    assert right > left
    assert left <= right
    assert right >= left
    assert left != right
    assert right != left
    assert left == left
    assert right == right


def test_duration_from_pydelta() -> None:
    pydelta = pydt.timedelta(days=1, hours=2, minutes=3, seconds=4, microseconds=5)
    ryduration = ry.SignedDuration.from_pytimedelta(pydelta)

    assert pydelta.days == 1
    assert pydelta.seconds == (2 * 60 * 60) + (3 * 60) + 4
    assert pydelta.microseconds == 5
    assert ryduration.days == 1
    assert ryduration.secs == 93784
    assert ryduration.seconds_remainder == (2 * 60 * 60) + (3 * 60) + 4
    assert ryduration.microseconds == 5


def test_to_timespan() -> None:
    dur = ry.SignedDuration(10, 500_000_000)
    timespan = dur.to_timespan()
    assert isinstance(timespan, ry.TimeSpan)
    assert timespan.seconds == 10
    assert timespan.milliseconds == 500


def test_truediv() -> None:
    dur = ry.SignedDuration(10, 500_000_000)

    div_by_int = dur / 2
    assert isinstance(div_by_int, ry.SignedDuration)
    assert div_by_int == ry.SignedDuration(5, 250_000_000)

    div_by_float = dur / 2.0
    assert isinstance(div_by_float, ry.SignedDuration)
    assert div_by_float == ry.SignedDuration(5, 250_000_000)

    div_by_duration = dur / ry.SignedDuration(2, 0)
    assert isinstance(div_by_duration, float)
    assert div_by_duration == 5.25

    with pytest.raises(ZeroDivisionError):
        _ = dur / 0
    with pytest.raises(ZeroDivisionError):
        _ = dur / 0.0
    with pytest.raises(ZeroDivisionError):
        _ = dur / ry.SignedDuration(0, 0)

    with pytest.raises(TypeError):
        _ = dur / "string"  # type: ignore[operator]  # ty:ignore[unsupported-operator]


def test_duration_2_pydelta() -> None:
    pydelta = pydt.timedelta(days=1, hours=2, minutes=3, seconds=4, microseconds=5)
    ryduration = ry.SignedDuration.from_pytimedelta(pydelta)

    roundtrip = ryduration.to_pytimedelta()
    assert isinstance(roundtrip, pydt.timedelta)
    assert roundtrip == pydelta


def test_equality() -> None:
    pydelta = pydt.timedelta(days=1, hours=2, minutes=3, seconds=4, microseconds=5)
    ryduration = ry.SignedDuration.from_pytimedelta(pydelta)

    pydelta2 = pydt.timedelta(days=0, hours=2, minutes=3, seconds=4, microseconds=5)
    ryduration2 = ry.SignedDuration.from_pytimedelta(pydelta2)
    assert ryduration != ryduration2
    assert ryduration == ryduration
    assert ryduration2 == ryduration2
    assert ryduration2 != ryduration

    assert ryduration.equiv(pydelta)
    assert pydelta == ryduration.to_py()
    assert ryduration2.equiv(pydelta2)
    assert pydelta2 == ryduration2.to_py()

    assert not ryduration.equiv(pydelta2)
    assert not ryduration2.equiv(pydelta)
    assert not pydelta2 == ryduration.to_py()
    assert not ryduration2.to_py() == pydelta
    assert not pydelta == ryduration2.to_py()


@pytest.mark.parametrize(
    ("left", "right", "is_equiv"),
    [
        # equiv
        (ry.SignedDuration(1, 0), ry.SignedDuration(1, 0), True),
        (ry.SignedDuration(1, 0), pydt.timedelta(seconds=1), True),
        (ry.SignedDuration(1, 0), ry.Duration(1), True),
        # not equiv
        (ry.SignedDuration(1, 0), ry.SignedDuration(2, 0), False),
        (ry.SignedDuration(1, 0), pydt.timedelta(seconds=2), False),
        (ry.SignedDuration(1, 0), ry.Duration(2), False),
        (ry.SignedDuration(-1, 0), ry.Duration(1), False),
    ],
)
def test_equiv(
    left: ry.SignedDuration,
    right: ry.SignedDuration | pydt.timedelta | ry.Duration,
    *,
    is_equiv: bool,
) -> None:
    assert left.equiv(right) is is_equiv


@pytest.mark.parametrize(
    "obj",
    [
        complex(1, 2),
        1234,
        [1, 2, 3],
    ],
)
def test_equiv_invalid_type(obj: complex | list[int]) -> None:
    with pytest.raises(TypeError):
        _e = ry.SignedDuration(1, 0).equiv(obj)  # type: ignore[arg-type]  # ty:ignore[invalid-argument-type]


class TestSignedDurationProperties:
    def test_positive(self) -> None:
        dur = ry.SignedDuration(90061, 123456789)

        assert dur.days == 1
        assert dur.subsec_nanos == 123456789
        assert dur.subsec_micros == 123456
        assert dur.microseconds == 123456
        assert dur.is_zero is False
        assert dur.subsec_millis == 123
        assert dur.secs == 90061
        assert dur.nanos == 123456789
        assert dur.is_positive is True
        assert dur.is_negative is False

    def test_negative(self) -> None:
        dur = -ry.SignedDuration(90061, 123456789)

        assert dur.days == -1
        assert dur.subsec_nanos == -123456789
        assert dur.subsec_micros == -123456
        assert dur.microseconds == -123456
        assert dur.is_zero is False
        assert dur.subsec_millis == -123
        assert dur.secs == -90061
        assert dur.nanos == -123456789
        assert dur.is_positive is False
        assert dur.is_negative is True

    def test_zero(self) -> None:
        dur = ry.SignedDuration(0, 0)

        assert dur.days == 0
        assert dur.subsec_nanos == 0
        assert dur.subsec_micros == 0
        assert dur.microseconds == 0
        assert dur.is_zero is True
        assert dur.subsec_millis == 0
        assert dur.secs == 0
        assert dur.nanos == 0
        assert dur.is_positive is False
        assert dur.is_negative is False


class TestSignedDurationStrings:
    def test_signed_duration_string(self) -> None:
        sd = ry.SignedDuration.parse("PT2H30M")
        assert str(sd) == "PT2H30M"

    def test_signed_duration_isoformat(self) -> None:
        sd = ry.SignedDuration.parse("PT2H30M")
        assert sd.isoformat() == "PT2H30M"
        assert ry.SignedDuration.fromisoformat(sd.isoformat()) == sd

    def test_signed_duration_parse(self) -> None:
        sd = ry.SignedDuration.parse("PT2H30M")
        assert sd.to_string(friendly=True) == "2h 30m"
        assert sd.friendly() == "2h 30m"
        assert str(sd) == "PT2H30M"
        assert str(sd) == "PT2H30M"
        assert f"{sd}" == "PT2H30M"
        assert f"{sd:#}" == "2h 30m"
        with pytest.raises(TypeError):
            assert sd.to_string(True) == "2h 30m"  # type: ignore[call-arg]  # noqa: FBT003  # ty:ignore[too-many-positional-arguments]

    def test_invalid_format_specifier(self) -> None:
        sd = ry.SignedDuration.parse("PT2H30M")
        with pytest.raises(TypeError):
            assert f"{sd:invalid}" == "PT2H30M"


class TestSignedDurationAbs:
    def test_signed_duration_abs(self) -> None:
        sd = ry.SignedDuration(1, -1_999_999_999)

        assert abs(sd) == ry.SignedDuration(0, 999_999_999)
        assert sd.abs() == ry.SignedDuration(0, 999_999_999)

    def test_unsigned_abs(self) -> None:
        sd = ry.SignedDuration.MIN

        dur = sd.unsigned_abs()
        assert dur == ry.Duration(secs=9223372036854775808, nanos=999999999)


class TestSignedDurationRound:
    def test_signed_duration_round(self) -> None:
        dur = ry.SignedDuration(4 * 60 * 60 + 17 * 60 + 1, 123_456_789)

        rounded = dur.round(smallest="second", mode="expand", increment=30)
        assert rounded == ry.SignedDuration.from_secs(4 * 60 * 60 + 17 * 60 + 30)

    def test_signed_duration_round_object(self) -> None:
        dur = ry.SignedDuration(4 * 60 * 60 + 17 * 60 + 1, 123_456_789)

        rounded = dur._round(
            ry.SignedDurationRound(smallest="second", mode="expand", increment=30)
        )

        assert rounded == ry.SignedDuration.from_secs(4 * 60 * 60 + 17 * 60 + 30)


class TestDurationArithmetic:
    # =========================================================================
    # ADDITION
    # =========================================================================

    @given(st_signed_durations(), st_signed_durations())
    def test_add(self, left: ry.SignedDuration, right: ry.SignedDuration) -> None:
        if left.checked_add(right) is None:
            with pytest.raises(OverflowError):
                _ = left + right
            return

        result = left + right
        assert isinstance(result, ry.SignedDuration)

    @given(
        st_signed_durations(),
        st.timedeltas(
            min_value=pydt.timedelta(0),
        ),
    )
    def test_add_with_timedelta(
        self, left: ry.SignedDuration, right: pydt.timedelta
    ) -> None:
        if left.checked_add(ry.SignedDuration.from_pytimedelta(right)) is None:
            with pytest.raises(OverflowError):
                _ = left + right
            return

        result = left + right
        assert isinstance(result, ry.SignedDuration)
        result_right = right + left
        assert isinstance(result_right, ry.SignedDuration)
        assert result == result_right

    def test_add_with_kwargs(self) -> None:
        dur = ry.SignedDuration(1, 123)
        expected = (
            dur
            + ry.SignedDuration.from_hours(2)
            + ry.SignedDuration.from_mins(3)
            + ry.SignedDuration.from_secs(4)
            + ry.SignedDuration.from_millis(5)
            + ry.SignedDuration.from_micros(6)
            + ry.SignedDuration.from_nanos(7)
        )
        added = dur.add(
            hours=2,
            minutes=3,
            seconds=4,
            milliseconds=5,
            microseconds=6,
            nanoseconds=7,
        )
        assert added == expected

    def test_add_with_zero_kwargs(self) -> None:
        dur = ry.SignedDuration(1, 123)
        assert dur.add(hours=0) == dur

    def test_add_with_large_i64_hours_keyword_unit(self) -> None:
        hours = ry.I32_MAX + 1
        dur = ry.SignedDuration(0, 0).add(hours=hours)
        assert dur == ry.SignedDuration.from_hours(hours)

    def test_add_rejects_positional_and_kwargs(self) -> None:
        dur = ry.SignedDuration(1, 0)
        other = ry.SignedDuration(2, 0)
        with pytest.raises(
            TypeError,
            match="add\\(\\) accepts either a span-like object or keyword units, not both",
        ):
            dur.add(other, seconds=1)  # type: ignore[call-overload]  # ty: ignore[no-matching-overload]

    def test_add_requires_positional_or_keyword_units(self) -> None:
        dur = ry.SignedDuration(1, 0)
        with pytest.raises(
            TypeError,
            match="add\\(\\) missing required argument: 'other' or keyword units",
        ):
            dur.add()

    @pytest.mark.parametrize(
        ("unit", "value"),
        [
            ("hours", 2_562_047_788_015_216),
            ("hours", -2_562_047_788_015_216),
            ("minutes", 153_722_867_280_912_931),
            ("minutes", -153_722_867_280_912_931),
        ],
    )
    def test_add_with_keyword_unit_value_overflow(self, unit: str, value: int) -> None:
        dur = ry.SignedDuration(0, 0)
        with pytest.raises(OverflowError):
            dur.add(**{unit: value})

    def test_add_with_keyword_units_result_overflow(self) -> None:
        with pytest.raises(OverflowError):
            ry.SignedDuration.MAX.add(nanoseconds=1)

    # =========================================================================
    # SUBTRACTION
    # =========================================================================
    @given(st_signed_durations(), st_signed_durations())
    def test_sub(self, left: ry.SignedDuration, right: ry.SignedDuration) -> None:
        if left.checked_sub(right) is None:
            with pytest.raises(OverflowError):
                _res = left - right
            return
        result = left - right
        assert isinstance(result, ry.SignedDuration)

    @given(
        st_signed_durations(),
        st.timedeltas(),
    )
    def test_sub_with_timedelta(
        self, left: ry.SignedDuration, right: pydt.timedelta
    ) -> None:
        if left.checked_sub(ry.SignedDuration.from_pytimedelta(right)) is None:
            with pytest.raises(OverflowError):
                _res = left - right
            return
        result = left - right
        assert isinstance(result, ry.SignedDuration)

    @given(
        st_signed_durations(),
        st.timedeltas(),
    )
    def test_sub_with_timedelta_rsub(
        self, left: ry.SignedDuration, right: pydt.timedelta
    ) -> None:
        if left.checked_sub(ry.SignedDuration.from_pytimedelta(right)) is None:
            with pytest.raises(OverflowError):
                _res = right - left
            return

        result = left - right
        assert isinstance(result, ry.SignedDuration)

    def test_sub_with_keyword_units(self) -> None:
        dur = ry.SignedDuration(7_385, 5_006_130)
        assert dur.sub(
            hours=2,
            minutes=3,
            seconds=4,
            milliseconds=5,
            microseconds=6,
            nanoseconds=7,
        ) == ry.SignedDuration(1, 123)

    def test_sub_with_zero_keyword_units(self) -> None:
        dur = ry.SignedDuration(1, 123)
        assert dur.sub(hours=0) == dur

    def test_sub_with_large_i64_hours_keyword_unit(self) -> None:
        hours = ry.I32_MAX + 1
        dur = ry.SignedDuration.from_hours(hours).sub(hours=hours)
        assert dur == ry.SignedDuration(0, 0)

    def test_sub_rejects_positional_and_keyword_units(self) -> None:
        dur = ry.SignedDuration(1, 0)
        other = ry.SignedDuration(2, 0)
        with pytest.raises(
            TypeError,
            match="sub\\(\\) accepts either a duration-like object or keyword units, not both",
        ):
            dur.sub(other, seconds=1)  # type: ignore[call-overload]  # ty: ignore[no-matching-overload]

    def test_sub_requires_positional_or_keyword_units(self) -> None:
        dur = ry.SignedDuration(1, 0)
        with pytest.raises(
            TypeError,
            match="sub\\(\\) missing required argument: 'other' or keyword units",
        ):
            dur.sub()

    @pytest.mark.parametrize(
        ("unit", "value"),
        [
            ("hours", 2_562_047_788_015_216),
            ("hours", -2_562_047_788_015_216),
            ("minutes", 153_722_867_280_912_931),
            ("minutes", -153_722_867_280_912_931),
        ],
    )
    def test_sub_with_keyword_unit_value_overflow(self, unit: str, value: int) -> None:
        dur = ry.SignedDuration(0, 0)
        with pytest.raises(OverflowError):
            dur.sub(**{unit: value})

    def test_sub_with_keyword_units_result_overflow(self) -> None:
        with pytest.raises(OverflowError):
            ry.SignedDuration.MIN.sub(nanoseconds=1)

    # =========================================================================
    # DIVISION
    # =========================================================================

    def test_div_number(self) -> None:
        dur = ry.SignedDuration(16, 0)
        divided = dur / 2
        assert isinstance(divided, ry.SignedDuration)
        assert divided == ry.SignedDuration(8, 0)

        divided = dur / 2.0
        assert isinstance(divided, ry.SignedDuration)
        assert divided == ry.SignedDuration(8, 0)

    def test_div_self(self) -> None:
        dur1 = ry.SignedDuration(16, 0)
        dur2 = ry.SignedDuration(4, 0)
        divided = dur1 / dur2
        assert isinstance(divided, float)
        assert divided == 4.0

    def test_div_timedelta(self) -> None:
        dur = ry.SignedDuration(16, 0)
        pydelta = pydt.timedelta(seconds=4)
        divided = dur / pydelta
        assert isinstance(divided, float)
        assert divided == 4.0

    def test_div_duration(self) -> None:
        dur = ry.SignedDuration(16, 0)
        divided = dur / ry.Duration(4, 0)
        assert isinstance(divided, float)
        assert divided == 4.0

    def test_div_zero_raises_zero_division_error(self) -> None:
        dur = ry.SignedDuration(1, 0)
        with pytest.raises(ZeroDivisionError):
            _r = dur / 0
        with pytest.raises(ZeroDivisionError):
            _r = dur / 0.0
        with pytest.raises(ZeroDivisionError):
            _f = dur / ry.SignedDuration.ZERO
        with pytest.raises(ZeroDivisionError):
            _f = dur / ry.Duration.ZERO
        with pytest.raises(ZeroDivisionError):
            _f = dur / pydt.timedelta()
        with pytest.raises(ZeroDivisionError):
            dur.div_f32(0.0)
        with pytest.raises(ZeroDivisionError):
            dur.div_f64(0.0)

    def test_div_f32_nan_raises_value_error(self) -> None:
        dur = ry.SignedDuration(1, 0)
        with pytest.raises(ValueError, match="invalid value: nan"):
            _r = dur.div_f32(float("nan"))

    def test_div_f64_nan_raises_value_error(self) -> None:
        dur = ry.SignedDuration(1, 0)
        with pytest.raises(ValueError, match="invalid value: nan"):
            _r = dur.div_f64(float("nan"))

    def test_div_f32_inf_raises_overflow_error(self) -> None:
        dur = ry.SignedDuration(1, 0)
        with pytest.raises(OverflowError):
            _r = dur.div_f32(float("inf"))
        with pytest.raises(OverflowError):
            _r = dur.div_f32(float("-inf"))

    def test_div_f64_inf_raises_overflow_error(self) -> None:
        dur = ry.SignedDuration(1, 0)
        with pytest.raises(OverflowError):
            _r = dur.div_f64(float("inf"))
        with pytest.raises(OverflowError):
            _r = dur.div_f64(float("-inf"))

    def test_div_type_error(self) -> None:
        dur = ry.SignedDuration(1, 0)
        with pytest.raises(TypeError):
            _r = dur / "string"  # type: ignore[operator]  # ty:ignore[unsupported-operator]
        with pytest.raises(TypeError):
            _r = dur / []  # type: ignore[operator]  # ty:ignore[unsupported-operator]

    @given(st_signed_durations(), st.floats(width=32))
    def test_div_f32(
        self,
        dur: ry.SignedDuration,
        divisor: float,
    ) -> None:
        if divisor == 0:
            with pytest.raises(ZeroDivisionError):
                _dur = dur.div_f32(divisor)
            return
        if isnan(divisor):
            with pytest.raises(ValueError, match="invalid value: nan"):
                dur.div_f32(divisor)
            return
        if divisor == float("inf") or divisor == float("-inf"):
            with pytest.raises(OverflowError):
                _dur = dur.div_f32(divisor)
            return
        if divisor < 0:
            with pytest.raises((TypeError, OverflowError, ZeroDivisionError)):
                _dur = dur.div_f32(divisor)
            return

        try:
            divided = dur.div_f32(divisor)
            assert isinstance(divided, ry.SignedDuration)
        except OverflowError:
            ...
        except ZeroDivisionError:
            ...

    @given(st_signed_durations(), st.floats())
    def test_div_f64(
        self,
        dur: ry.SignedDuration,
        divisor: float,
    ) -> None:
        if divisor == 0:
            with pytest.raises(ZeroDivisionError):
                _dur = dur.div_f64(divisor)
            return
        if isnan(divisor):
            with pytest.raises(ValueError, match="invalid value: nan"):
                dur.div_f64(divisor)
            return
        if divisor == float("inf") or divisor == float("-inf"):
            with pytest.raises(OverflowError):
                _dur = dur.div_f64(divisor)
            return
        if divisor < 0:
            with pytest.raises((TypeError, ZeroDivisionError)):
                _dur = dur.div_f64(divisor)
            return
        try:
            divided = dur.div_f64(divisor)
            assert isinstance(divided, ry.SignedDuration)
        except OverflowError:
            ...
        except ZeroDivisionError:
            ...

    @given(st_signed_durations(), st_signed_durations())
    def test_div_duration_f32(
        self,
        left: ry.SignedDuration,
        right: ry.SignedDuration,
    ) -> None:
        if right.is_zero:
            with pytest.raises(ZeroDivisionError):
                _r = left.div_duration_f32(right)
            return
        try:
            result = left.div_duration_f32(right)
            assert isinstance(result, float)
        except OverflowError:
            ...

    @given(st_signed_durations(), st_signed_durations())
    def test_div_duration_f64(
        self,
        left: ry.SignedDuration,
        right: ry.SignedDuration,
    ) -> None:
        if right.is_zero:
            with pytest.raises(ZeroDivisionError):
                _r = left.div_duration_f64(right)
            return
        try:
            result = left.div_duration_f64(right)
            assert isinstance(result, float)
        except OverflowError:
            ...

    # =========================================================================
    # MULTIPLICATION
    # =========================================================================
    def test_mul_f32_nan_raises_value_error(self) -> None:
        dur = ry.SignedDuration(1, 0)
        with pytest.raises(ValueError, match="invalid value: nan"):
            _r = dur.mul_f32(float("nan"))

    def test_mul_f64_nan_raises_value_error(self) -> None:
        dur = ry.SignedDuration(1, 0)
        with pytest.raises(ValueError, match="invalid value: nan"):
            _r = dur.mul_f64(float("nan"))

    def test_mul_f32_inf_raises_overflow_error(self) -> None:
        dur = ry.SignedDuration(1, 0)
        with pytest.raises(OverflowError):
            _r = dur.mul_f32(float("inf"))
        with pytest.raises(OverflowError):
            _r = dur.mul_f32(float("-inf"))

    def test_mul_f64_inf_raises_overflow_error(self) -> None:
        dur = ry.SignedDuration(1, 0)
        with pytest.raises(OverflowError):
            _r = dur.mul_f64(float("inf"))
        with pytest.raises(OverflowError):
            _r = dur.mul_f64(float("-inf"))

    @given(st_signed_durations(), st.integers(min_value=0, max_value=ry.U32_MAX))
    def test_mul_int(
        self,
        dur: ry.SignedDuration,
        factor: int,
    ) -> None:
        try:
            multiplied = dur * factor
            assert isinstance(multiplied, ry.SignedDuration)
        except OverflowError:
            ...

    @given(st_signed_durations(), st.integers(min_value=0, max_value=ry.U32_MAX))
    def test_rmul_int(
        self,
        dur: ry.SignedDuration,
        factor: int,
    ) -> None:
        try:
            multiplied = factor * dur
            assert isinstance(multiplied, ry.SignedDuration)
        except OverflowError:
            ...

    @given(st_signed_durations(), st.floats(width=32))
    def test_duration_mul_f32(
        self,
        dur: ry.SignedDuration,
        factor: float,
    ) -> None:
        if factor == 0:
            assert dur.mul_f32(factor) == ry.SignedDuration(0, 0)
            return

        if isnan(factor):
            with pytest.raises(ValueError, match="invalid value: nan"):
                dur.mul_f32(factor)
            return
        if factor == float("inf") or factor == float("-inf"):
            with pytest.raises(OverflowError):
                _dur = dur.mul_f32(factor)
            return
        try:
            divided = dur.mul_f32(factor)
            assert isinstance(divided, ry.SignedDuration)
        except OverflowError:
            ...

    @given(st_signed_durations(), st.floats(width=64))
    def test_mul_f64(
        self,
        dur: ry.SignedDuration,
        factor: float,
    ) -> None:
        if factor == 0:
            assert dur.mul_f64(factor) == ry.SignedDuration(0, 0)
            return

        if isnan(factor):
            with pytest.raises(ValueError, match="invalid value: nan"):
                dur.mul_f64(factor)
            return
        if factor == float("inf") or factor == float("-inf"):
            with pytest.raises(OverflowError):
                _dur = dur.mul_f64(factor)
            return
        try:
            divided = dur.mul_f64(factor)
            assert isinstance(divided, ry.SignedDuration)
        except OverflowError:
            ...

    @given(
        st.timedeltas(),
        st.timedeltas(),
    )
    def test_sub_and_rsub(self, left: pydt.timedelta, right: pydt.timedelta) -> None:
        dur_left = ry.SignedDuration.from_pytimedelta(left)
        dur_right = ry.SignedDuration.from_pytimedelta(right)

        if dur_left.checked_sub(dur_right) is None:
            with pytest.raises(OverflowError):
                _res = left - right
            return

        try:
            result = left - right
        except OverflowError:
            return

        assert isinstance(result, pydt.timedelta)
        # do sub and rsub
        signed_duration = left - dur_right
        assert isinstance(signed_duration, ry.SignedDuration)
        assert signed_duration == dur_left - dur_right

    @pytest.mark.parametrize(
        ("operator", "value"),
        [
            (op, value)
            for op in [
                "__add__",
                "__radd__",
                "__sub__",
                "__rsub__",
                "__truediv__",
                "__mul__",
            ]
            for value in ["string", ["asdf"], complex(1, 2)]
        ],
    )
    def test_operators_type_errors(
        self, operator: str, value: complex | list[int] | str
    ) -> None:
        dur = ry.SignedDuration(1, 0)
        _res = getattr(dur, operator)(value)
        assert _res is NotImplemented
        if operator == "__add__":
            with pytest.raises(TypeError):
                _ = dur + value  # type: ignore[operator]  # ty:ignore[unsupported-operator]
        elif operator == "__sub__":
            with pytest.raises(TypeError):
                _ = dur - value  # type: ignore[operator]  # ty:ignore[unsupported-operator]
        elif operator == "__rsub__":
            with pytest.raises(TypeError):
                _ = value - dur  # type: ignore[operator]  # ty:ignore[unsupported-operator]
        elif operator == "__radd__":
            with pytest.raises(TypeError):
                _ = value + dur  # type: ignore[operator]  # ty:ignore[unsupported-operator]
        elif operator == "__truediv__":
            with pytest.raises(TypeError):
                _ = dur / value  # type: ignore[operator]  # ty:ignore[unsupported-operator]
        else:  # operator == "__mul__":
            with pytest.raises(TypeError):
                _ = dur * value  # type: ignore[operator]  # ty:ignore[unsupported-operator]


class TestSignedDurationCheckedArithmetic:
    @given(st_signed_durations(), st_signed_durations())
    def test_checked_add(
        self, left: ry.SignedDuration, right: ry.SignedDuration
    ) -> None:
        assert isinstance(left, ry.SignedDuration)
        assert isinstance(right, ry.SignedDuration)
        result = left.checked_add(right)
        assert result is None or isinstance(result, ry.SignedDuration)

    @given(st_signed_durations(), st_signed_durations())
    def test_checked_sub(
        self, left: ry.SignedDuration, right: ry.SignedDuration
    ) -> None:
        assert isinstance(left, ry.SignedDuration)
        assert isinstance(right, ry.SignedDuration)
        result = left.checked_sub(right)
        assert result is None or isinstance(result, ry.SignedDuration)

    @given(
        st_signed_durations(), st.integers(min_value=ry.I32_MIN, max_value=ry.I32_MAX)
    )
    def test_checked_mul(self, dur: ry.SignedDuration, factor: int) -> None:
        assert isinstance(dur, ry.SignedDuration)
        result = dur.checked_mul(factor)
        assert result is None or isinstance(result, ry.SignedDuration)

    @given(st_signed_durations())
    def test_checked_neg(self, dur: ry.SignedDuration) -> None:
        """Returns `None` if the negation does not exist.

        Occurs in precisely the cases when [`SignedDuration::as_secs`] is equal
        to `i64::MIN` (ry.I64_MIN).
        """
        assert isinstance(dur, ry.SignedDuration)
        if dur.as_secs() == ry.I64_MIN:
            assert dur.checked_neg() is None
        else:
            assert dur.checked_neg() == -dur

    @given(
        st_signed_durations(), st.integers(min_value=ry.I32_MIN, max_value=ry.I32_MAX)
    )
    def test_checked_div(self, dur: ry.SignedDuration, divisor: int) -> None:
        assert isinstance(dur, ry.SignedDuration)
        result = dur.checked_div(divisor)
        assert result is None or isinstance(result, ry.SignedDuration)


class TestSignedDurationSaturatingArithmetic:
    @given(st_signed_durations(), st_signed_durations())
    def test_signed_duration_saturating_add(
        self, left: ry.SignedDuration, right: ry.SignedDuration
    ) -> None:
        left_plus_right = left.saturating_add(right)
        right_plus_left = right.saturating_add(left)
        assert left_plus_right == right_plus_left
        assert isinstance(left_plus_right, ry.SignedDuration)
        assert isinstance(right_plus_left, ry.SignedDuration)

    @given(st_signed_durations(), st_signed_durations())
    def test_signed_duration_saturating_sub(
        self, left: ry.SignedDuration, right: ry.SignedDuration
    ) -> None:
        left_minus_right = left.saturating_sub(right)
        right_minus_left = right.saturating_sub(left)
        assert isinstance(left_minus_right, ry.SignedDuration)
        assert isinstance(right_minus_left, ry.SignedDuration)

        if left == right:
            assert left_minus_right == right_minus_left
        if left.is_zero and right.is_zero:
            assert left_minus_right == ry.SignedDuration(0, 0)
            assert right_minus_left == ry.SignedDuration(0, 0)

    @given(st_signed_durations(), st_i32)
    def test_signed_duration_saturating_mul(
        self, dur: ry.SignedDuration, factor: int
    ) -> None:
        dur_times_factor = dur.saturating_mul(factor)
        assert isinstance(dur_times_factor, ry.SignedDuration)
        if factor == 0:
            assert dur_times_factor == ry.SignedDuration(0, 0)
        elif factor == 1:
            assert dur_times_factor == dur
        elif factor == -1:
            assert dur_times_factor == -dur


class TestSignedDurationAsXYZ:
    def test_as_secs_f32(self) -> None:
        dur = ry.SignedDuration(1, 500_000_000)
        assert dur.as_secs_f32() == 1.5
        assert dur.as_secs() == 1
        assert isinstance(dur.as_secs(), int)
        ndur = -dur
        assert ndur.as_secs_f32() == -1.5
        assert ndur.as_secs() == -1
        assert isinstance(ndur.as_secs(), int)

    def test_as_secs_f64(self) -> None:
        dur = ry.SignedDuration(1, 500_000_000)
        assert dur.as_secs_f64() == 1.5
        assert dur.as_secs() == 1
        assert isinstance(dur.as_secs(), int)
        ndur = -dur
        assert ndur.as_secs_f64() == -1.5
        assert ndur.as_secs() == -1
        assert isinstance(ndur.as_secs(), int)

    def test_as_millis_f32(self) -> None:
        dur = ry.SignedDuration(1, 123_456_789)
        assert dur.as_millis_f32() - 1123.456787109375 < 1e-5
        assert dur.as_millis() == 1123
        ndur = -dur
        assert abs(dur.as_millis_f32()) - 1123.456787109375 < 1e-5
        assert ndur.as_millis() == -1123

    def test_as_millis_f64(self) -> None:
        dur = ry.SignedDuration(1, 123_456_789)

        assert dur.as_millis_f64() - 1123.456787109375 < 1e-5
        assert dur.as_millis() == 1123
        ndur = -dur
        assert abs(dur.as_millis_f64()) - 1123.456787109375 < 1e-5
        assert ndur.as_millis() == -1123

    @given(st_signed_durations())
    def test_as_hours(self, dur: ry.SignedDuration) -> None:
        hours = dur.as_hours()
        assert isinstance(hours, int)
        expected = dur.signum() * int(
            abs(dur.secs) // 3600
            + abs(dur.nanos) // (_NANOS_PER_SEC * _SECS_PER_MINUTE * _MINS_PER_HOUR)
        )
        assert hours == expected

    @given(st_signed_durations())
    def test_as_mins(self, dur: ry.SignedDuration) -> None:
        minutes = dur.as_mins()
        assert isinstance(minutes, int)
        expected = dur.signum() * int(
            abs(dur.secs) // 60 + abs(dur.nanos) // 60_000_000_000
        )
        assert minutes == expected

    @given(st_signed_durations())
    def test_as_secs(self, dur: ry.SignedDuration) -> None:
        seconds = dur.as_secs()
        assert isinstance(seconds, int)
        expected = dur.signum() * (
            abs(dur.secs) + dur.signum() * int(abs(dur.nanos) // _NANOS_PER_SEC)
        )
        assert seconds == expected

    @given(st_signed_durations())
    def test_as_millis(self, dur: ry.SignedDuration) -> None:
        millis = dur.as_millis()
        assert isinstance(millis, int)
        expected = dur.signum() * int(
            abs(dur.secs) * _MILLIS_PER_SEC + abs(dur.nanos) // _NANOS_PER_MILLI
        )
        assert millis == expected

    @given(st_signed_durations())
    def test_as_micros(self, dur: ry.SignedDuration) -> None:
        micros = dur.as_micros()
        assert isinstance(micros, int)
        expected = dur.signum() * int(
            abs(dur.secs) * _MICROS_PER_SEC + abs(dur.nanos) // _NANOS_PER_MICRO
        )
        assert micros == expected

    @given(st_signed_durations())
    def test_as_nanos(self, dur: ry.SignedDuration) -> None:
        nanos = dur.as_nanos()
        assert isinstance(nanos, int)
        expected = dur.signum() * (abs(dur.secs) * _NANOS_PER_SEC + abs(dur.nanos))
        assert nanos == expected


class TestSignedDurationFromXYZ:
    @given(st_i64)
    def test_from_hours(self, hours: int) -> None:
        if -2_562_047_788_015_215 <= hours <= 2_562_047_788_015_215:
            dur = ry.SignedDuration.from_hours(hours)
            assert isinstance(dur, ry.SignedDuration)
            expected_secs = hours * _SECS_PER_MINUTE * _MINS_PER_HOUR
            assert dur.secs == expected_secs
            assert dur.nanos == 0
        else:
            with pytest.raises(OverflowError):
                ry.SignedDuration.from_hours(hours)

    @given(st_i64)
    def test_from_mins(self, mins: int) -> None:
        if mins < -153_722_867_280_912_930 or mins > 153_722_867_280_912_930:
            with pytest.raises(OverflowError):
                ry.SignedDuration.from_mins(mins)
        else:
            dur = ry.SignedDuration.from_mins(mins)
            assert isinstance(dur, ry.SignedDuration)
            expected_secs = mins * _SECS_PER_MINUTE
            assert dur.secs == expected_secs
            assert dur.nanos == 0

    @given(st_i64)
    def test_from_secs(self, secs: int) -> None:
        dur = ry.SignedDuration.from_secs(secs)
        assert isinstance(dur, ry.SignedDuration)
        assert dur.secs == secs
        assert dur.nanos == 0

    @given(st_i64)
    def test_from_millis(self, millis: int) -> None:
        dur = ry.SignedDuration.from_millis(millis)
        if millis >= 0:
            assert isinstance(dur, ry.SignedDuration)
            expected_secs = millis // _MILLIS_PER_SEC
            expected_nanos = (millis % _MILLIS_PER_SEC) * _NANOS_PER_MILLI
            assert dur.secs == expected_secs
            assert dur.nanos == expected_nanos
        else:
            expected_secs = abs(millis) // _MILLIS_PER_SEC
            expected_nanos = (abs(millis) % _MILLIS_PER_SEC) * _NANOS_PER_MILLI
            assert dur.secs == -expected_secs
            assert dur.nanos == -expected_nanos
            assert isinstance(dur, ry.SignedDuration)

    @given(st_i64)
    def test_from_micros(self, micros: int) -> None:
        dur = ry.SignedDuration.from_micros(micros)
        if micros >= 0:
            assert isinstance(dur, ry.SignedDuration)
            expected_secs = micros // _MICROS_PER_SEC
            expected_nanos = (micros % _MICROS_PER_SEC) * _NANOS_PER_MICRO
            assert dur.secs == expected_secs
            assert dur.nanos == expected_nanos
        else:
            expected_secs = abs(micros) // _MICROS_PER_SEC
            expected_nanos = (abs(micros) % _MICROS_PER_SEC) * _NANOS_PER_MICRO
            assert dur.secs == -expected_secs
            assert dur.nanos == -expected_nanos
            assert isinstance(dur, ry.SignedDuration)


class TestSignedDurationFromIntegers:
    @given(st.integers(min_value=ry.I64_MIN, max_value=ry.I64_MAX))
    def test_from_secs(self, secs: int) -> None:
        dur = ry.SignedDuration.from_secs(secs)
        assert isinstance(dur, ry.SignedDuration)
        assert dur.secs == secs
        assert dur.nanos == 0

    @given(st.integers(min_value=ry.I64_MIN, max_value=ry.I64_MAX))
    def test_from_millis(self, millis: int) -> None:
        dur = ry.SignedDuration.from_millis(millis)
        assert isinstance(dur, ry.SignedDuration)
        assert dur.secs == abs(millis) // 1000 * (1 if millis >= 0 else -1)
        assert dur.nanos == (abs(millis) % 1000) * 1_000_000 * (
            1 if millis >= 0 else -1
        )

    @given(st.integers(min_value=ry.I64_MIN, max_value=ry.I64_MAX))
    def test_from_micros(self, micros: int) -> None:
        dur = ry.SignedDuration.from_micros(micros)
        assert isinstance(dur, ry.SignedDuration)
        assert dur.secs == abs(micros) // 1_000_000 * (1 if micros >= 0 else -1)
        assert dur.nanos == (abs(micros) % 1_000_000) * 1_000 * (
            1 if micros >= 0 else -1
        )

    @given(st.integers(min_value=ry.I64_MIN, max_value=ry.I64_MAX))
    def test_from_nanos(self, nanos: int) -> None:
        dur = ry.SignedDuration.from_nanos(nanos)
        assert isinstance(dur, ry.SignedDuration)
        assert dur.secs == abs(nanos) // 1_000_000_000 * (1 if nanos >= 0 else -1)
        assert dur.nanos == (abs(nanos) % 1_000_000_000) * (1 if nanos >= 0 else -1)

    @given(st.integers(min_value=ry.I64_MIN, max_value=ry.I64_MAX))
    def test_from_hours(self, hours: int) -> None:
        if abs(hours) > ry.I64_MAX // 3600:
            with pytest.raises(OverflowError):
                _dur = ry.SignedDuration.from_hours(hours)
        else:
            dur = ry.SignedDuration.from_hours(hours)
            assert isinstance(dur, ry.SignedDuration)

    @given(st.integers(min_value=ry.I64_MIN, max_value=ry.I64_MAX))
    def test_from_mins(self, minutes: int) -> None:
        if abs(minutes) > ry.I64_MAX // 60:
            with pytest.raises(OverflowError):
                _dur = ry.SignedDuration.from_mins(minutes)
        else:
            dur = ry.SignedDuration.from_mins(minutes)
            assert isinstance(dur, ry.SignedDuration)

    def test_from_days(self) -> None:
        with pytest.raises(AttributeError):
            _ = ry.SignedDuration.from_days(1)  # type: ignore[attr-defined]  # ty:ignore[unresolved-attribute]

    @given(st.floats(width=32))
    def test_from_secs_f32(self, secs: float) -> None:
        if isnan(secs):
            with pytest.raises(ValueError, match="invalid value: nan"):
                _dur = ry.SignedDuration.from_secs_f32(secs)
        elif secs == float("inf"):
            with pytest.raises(OverflowError):
                _dur = ry.SignedDuration.from_secs_f32(secs)
        else:
            try:
                dur = ry.SignedDuration.from_secs_f32(secs)
                assert isinstance(dur, ry.SignedDuration)
            except OverflowError:
                ...

    @given(st.floats(width=64))
    def test_from_secs_f64(self, secs: float) -> None:
        if isnan(secs):
            with pytest.raises(ValueError, match="invalid value: nan"):
                _dur = ry.SignedDuration.from_secs_f64(secs)
            with pytest.raises(ValueError, match="invalid value: nan"):
                _dur = ry.SignedDuration.from_secs(secs)
        elif secs == float("inf"):
            with pytest.raises(OverflowError):
                _dur = ry.SignedDuration.from_secs_f64(secs)
            with pytest.raises(OverflowError):
                _dur = ry.SignedDuration.from_secs(secs)
        else:
            try:
                dur = ry.SignedDuration.from_secs_f64(secs)
                dur2 = ry.SignedDuration.from_secs(secs)
                assert isinstance(dur, ry.SignedDuration)
                assert isinstance(dur2, ry.SignedDuration)
                assert dur == dur2
            except OverflowError:
                ...

    def test_from_secs_type_error(self) -> None:
        with pytest.raises(TypeError):
            _ = ry.SignedDuration.from_secs("string")  # type: ignore[arg-type]  # ty:ignore[invalid-argument-type]
