use std::hash::{DefaultHasher, Hash, Hasher};
use std::ops::{Div, Mul};
use std::time::Duration;

#[cfg(feature = "jiff")]
use jiff::fmt::friendly::Designator;
use pyo3::basic::CompareOp;
use pyo3::prelude::*;
use pyo3::types::{PyAnyMethods, PyDict, PyDictMethods, PyTuple};
use pyo3::{BoundObject, IntoPyObjectExt};
use ryo3_core::{PyAsciiString, PyFromStr};
use ryo3_macro_rules::{
    py_key_err, py_overflow_err, py_overflow_error, py_type_err, py_value_err, py_zero_division_err,
};

use crate::time::duration::arithmetic::DurationLike;

const NANOS_PER_SEC: u32 = 1_000_000_000;
const SECS_PER_MINUTE: u64 = 60;
const MINS_PER_HOUR: u64 = 60;
const HOURS_PER_DAY: u64 = 24;
const DAYS_PER_WEEK: u64 = 7;
const MAX_DAYS: u64 = u64::MAX / (SECS_PER_MINUTE * MINS_PER_HOUR * HOURS_PER_DAY);
const SECS_PER_WEEK: u64 = SECS_PER_MINUTE * MINS_PER_HOUR * HOURS_PER_DAY * DAYS_PER_WEEK;

// jiff
#[cfg(feature = "jiff")]
const TEMPORAL_SPAN_PARSER: jiff::fmt::temporal::SpanParser =
    jiff::fmt::temporal::SpanParser::new();
#[cfg(feature = "jiff")]
const TEMPORAL_SPAN_PRINTER: jiff::fmt::temporal::SpanPrinter =
    jiff::fmt::temporal::SpanPrinter::new();
#[cfg(feature = "jiff")]
const FRIENDLY_SPAN_PARSER: jiff::fmt::friendly::SpanParser =
    jiff::fmt::friendly::SpanParser::new();

// Maybe use?`HumanTime` designator for friendly parser/printer to avoid
// ambiguous `µ`:w REF: https://github.com/jessekrubin/ry/discussions/229#discussioncomment-14928815
// ```txt
// RUF001 String contains ambiguous `µ` (MICRO SIGN). Did you mean `μ` (GREEK SMALL LETTER MU)?
//   --> tests\std\test_duration_str.py:45:59
//    |
// 43 |         max_dur = ry.Duration.MAX
// 44 |         iso_str = max_dur.friendly()
// 45 |         assert iso_str == "5124095576030431h 15s 999ms 999µs 999ns"
//    |                                                           ^
// 46 |         parsed_max_dur = ry.Duration.from_str(iso_str)
// 47 |         assert parsed_max_dur == max_dur
//    |
//
// Found 1 error.
// ```
#[cfg(feature = "jiff")]
const FRIENDLY_SPAN_PRINTER: jiff::fmt::friendly::SpanPrinter =
    jiff::fmt::friendly::SpanPrinter::new();

#[derive(Copy, Clone, PartialEq, Eq)]
#[pyclass(name = "Duration", frozen, immutable_type, skip_from_py_object)]
#[cfg_attr(feature = "ry", pyo3(module = "ry.ryo3"))]
pub struct PyDuration(pub(crate) Duration);

impl PyDuration {
    #[inline]
    #[must_use]
    pub const fn from_secs(secs: u64) -> Self {
        Self(Duration::from_secs(secs))
    }

    #[must_use]
    pub fn inner(&self) -> &Duration {
        &self.0
    }

    fn new(secs: u64, nanos: u32) -> PyResult<Self> {
        if nanos < NANOS_PER_SEC {
            Ok(Self(Duration::new(secs, nanos)))
        } else {
            let secs = secs
                .checked_add(u64::from(nanos / NANOS_PER_SEC))
                .ok_or_else(|| {
                    py_overflow_error!("overflow; seconds part of Duration::new too large")
                })?;
            let nanos = nanos % NANOS_PER_SEC;
            Ok(Self(Duration::new(secs, nanos)))
        }
    }

    pub(crate) fn try_from_secs_f32(secs: f32) -> PyResult<Self> {
        if secs.is_nan() {
            py_value_err!("invalid value: nan")
        } else if secs.is_infinite() {
            if secs.is_sign_negative() {
                py_type_err!("negative duration")
            } else {
                py_overflow_err!("invalid value: inf")
            }
        } else if secs < 0.0 {
            py_type_err!("negative duration")
        } else {
            Duration::try_from_secs_f32(secs)
                .map(Self::from)
                .map_err(|e| py_overflow_error!("{e}"))
        }
    }

    pub(crate) fn try_from_secs_f64(secs: f64) -> PyResult<Self> {
        if secs.is_nan() {
            py_value_err!("invalid value: nan")
        } else if secs.is_infinite() {
            if secs.is_sign_negative() {
                py_type_err!("negative duration")
            } else {
                py_overflow_err!("invalid value: inf")
            }
        } else if secs < 0.0 {
            py_type_err!("negative duration")
        } else {
            Duration::try_from_secs_f64(secs)
                .map(Self::from)
                .map_err(|e| py_overflow_error!("{e}"))
        }
    }
}

#[pymethods]
#[expect(clippy::needless_pass_by_value)]
impl PyDuration {
    #[new]
    #[pyo3(signature = (secs = 0, nanos = 0))]
    fn py_new(secs: u64, nanos: u32) -> PyResult<Self> {
        Self::new(secs, nanos)
    }

    fn __getnewargs__<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyTuple>> {
        PyTuple::new(
            py,
            vec![
                self.0.as_secs().into_bound_py_any(py)?,
                self.0.subsec_nanos().into_bound_py_any(py)?,
            ],
        )
    }

    #[classattr]
    const fn __match_args__() -> (&'static str, &'static str) {
        ("secs", "nanos")
    }

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn ZERO() -> Self {
        Self(Duration::ZERO)
    }

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn MIN() -> Self {
        Self(Duration::ZERO)
    }

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn MAX() -> Self {
        Self(Duration::MAX)
    }

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn HOUR() -> Self {
        Self(Duration::from_hours(1))
    }

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn MINUTE() -> Self {
        Self(Duration::from_mins(1))
    }

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn SECOND() -> Self {
        Self(Duration::from_secs(1))
    }

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn MILLISECOND() -> Self {
        Self(Duration::from_millis(1))
    }

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn MICROSECOND() -> Self {
        Self(Duration::from_micros(1))
    }

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn NANOSECOND() -> Self {
        Self(Duration::from_nanos(1))
    }

    fn __repr__(&self) -> PyAsciiString {
        format!("{self}").into()
    }

    fn __hash__(&self) -> u64 {
        let mut hasher = DefaultHasher::new();
        self.0.hash(&mut hasher);
        hasher.finish()
    }

    fn __bool__(&self) -> bool {
        !self.0.is_zero()
    }

    fn __float__(&self) -> f64 {
        self.0.as_secs_f64()
    }

    fn __int__(&self) -> u128 {
        self.0.as_nanos()
    }

    // ========================================================================
    // MATHS/OPERATORS
    // ========================================================================
    // OLD VERSION ALLOWING FOR DURATION/DELTA COMPARISONS
    // fn __richcmp__(&self, other: PyDurationComparable, op: CompareOp) -> bool {
    //     match other {
    //         PyDurationComparable::PyDuration(other) => match op {
    //             CompareOp::Eq => self.0 == other.0,
    //             CompareOp::Ne => self.0 != other.0,
    //             CompareOp::Lt => self.0 < other.0,
    //             CompareOp::Le => self.0 <= other.0,
    //             CompareOp::Gt => self.0 > other.0,
    //             CompareOp::Ge => self.0 >= other.0,
    //         },
    //         PyDurationComparable::Duration(other) => match op {
    //             CompareOp::Eq => self.0 == other,
    //             CompareOp::Ne => self.0 != other,
    //             CompareOp::Lt => self.0 < other,
    //             CompareOp::Le => self.0 <= other,
    //             CompareOp::Gt => self.0 > other,
    //             CompareOp::Ge => self.0 >= other,
    //         },
    //     }
    // }
    fn __richcmp__(&self, other: &Self, op: CompareOp) -> bool {
        match op {
            CompareOp::Eq => self.0 == other.0,
            CompareOp::Ne => self.0 != other.0,
            CompareOp::Lt => self.0 < other.0,
            CompareOp::Le => self.0 <= other.0,
            CompareOp::Gt => self.0 > other.0,
            CompareOp::Ge => self.0 >= other.0,
        }
    }

    fn __add__(&self, other: DurationLike) -> PyResult<Self> {
        self.0
            .checked_add(other.into())
            .map(Self::from)
            .ok_or_else(|| py_overflow_error!("overflow in Duration addition"))
    }

    fn __radd__(&self, other: DurationLike) -> PyResult<Self> {
        self.__add__(other)
    }

    fn __sub__(&self, other: DurationLike) -> PyResult<Self> {
        self.0
            .checked_sub(other.into())
            .map(Self::from)
            .ok_or_else(|| py_overflow_error!("overflow in Duration subtraction"))
    }

    fn __rsub__(&self, other: DurationLike) -> PyResult<Self> {
        let other: Duration = other.into();
        other
            .checked_sub(self.0)
            .map(Self::from)
            .ok_or_else(|| py_overflow_error!("overflow in Duration subtraction"))
    }

    fn __truediv__(
        &self,
        other: arithmetic::DurationTrueDivInput,
    ) -> PyResult<arithmetic::DurationTrueDivOutput> {
        match other {
            arithmetic::DurationTrueDivInput::Int(i) => {
                if i == 0 {
                    py_zero_division_err!("division by zero")
                } else {
                    self.checked_div(i)
                        .ok_or_else(|| py_overflow_error!("overflow in Duration division"))
                        .map(Into::into)
                }
            }
            arithmetic::DurationTrueDivInput::Float(f) => self.div_f64(f).map(Into::into),
            arithmetic::DurationTrueDivInput::Duration(d) => {
                self.div_duration_f64(d.get()).map(Into::into)
            }
            arithmetic::DurationTrueDivInput::PyDelta(d) => {
                if d.is_zero() {
                    py_zero_division_err!()
                } else {
                    Ok(self.0.div_duration_f64(d).into())
                }
            }
        }
    }

    fn __mul__(&self, other: arithmetic::DurationMulInput) -> PyResult<Self> {
        match other {
            arithmetic::DurationMulInput::Int(i) => self
                .checked_mul(i)
                .ok_or_else(|| py_overflow_error!("overflow in Duration multiplication")),
            arithmetic::DurationMulInput::Float(f) => self.mul_f64(f),
        }
    }

    fn __rmul__(&self, other: arithmetic::DurationMulInput) -> PyResult<Self> {
        self.__mul__(other)
    }

    // ========================================================================
    // PROPERTIES/GETTERS
    // ========================================================================
    #[getter]
    fn is_zero(&self) -> bool {
        self.0.is_zero()
    }

    #[getter]
    fn secs(&self) -> u64 {
        self.0.as_secs()
    }

    #[getter]
    fn nanos(&self) -> u32 {
        self.0.subsec_nanos()
    }

    #[getter]
    fn nanoseconds(&self) -> u32 {
        self.0.subsec_nanos()
    }

    #[getter]
    fn ns(&self) -> u32 {
        self.0.subsec_nanos()
    }

    #[getter]
    fn days(&self) -> u64 {
        self.0.as_secs() / 86400
    }

    /// Return the number of seconds in the duration counting days
    #[getter]
    fn seconds(&self) -> u64 {
        self.0.as_secs()
    }

    /// Return the seconds % days (self.seconds % 86400)
    #[getter]
    fn seconds_remainder(&self) -> u64 {
        self.0.as_secs() % 86400
    }

    #[getter]
    fn microseconds(&self) -> u32 {
        self.0.subsec_micros()
    }

    #[getter]
    fn subsec_millis(&self) -> u32 {
        self.0.subsec_millis()
    }

    #[getter]
    fn subsec_micros(&self) -> u32 {
        self.0.subsec_micros()
    }

    #[getter]
    fn subsec_nanos(&self) -> u32 {
        self.0.subsec_nanos()
    }

    // ========================================================================
    // TO-CONVERSIONS
    // ========================================================================
    fn as_secs(&self) -> u64 {
        self.0.as_secs()
    }

    fn as_secs_f32(&self) -> f32 {
        self.0.as_secs_f32()
    }

    fn as_secs_f64(&self) -> f64 {
        self.0.as_secs_f64()
    }

    fn as_millis(&self) -> u128 {
        self.0.as_millis()
    }

    fn as_micros(&self) -> u128 {
        self.0.as_micros()
    }

    fn as_nanos(&self) -> u128 {
        self.0.as_nanos()
    }

    // ========================================================================
    // PYTHON CONVERSIONS
    // ========================================================================

    /// Convert to python `datetime.timedelta`
    #[expect(clippy::wrong_self_convention)]
    fn to_py(&self) -> Duration {
        self.0
    }

    /// Convert to python `datetime.timedelta`
    #[expect(clippy::wrong_self_convention)]
    fn to_pytimedelta(&self) -> Duration {
        self.0
    }

    /// Convert from python `datetime.timedelta`
    #[staticmethod]
    fn from_pytimedelta(delta: Duration) -> Self {
        Self(delta)
    }

    // ========================================================================
    // TO/FROM NUMBERS
    // ========================================================================
    #[expect(clippy::wrong_self_convention)]
    fn to_dict<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyDict>> {
        let dict = PyDict::new(py);
        dict.set_item(interns::secs(py), self.0.as_secs())?;
        dict.set_item(interns::nanos(py), self.0.subsec_nanos())?;
        Ok(dict)
    }

    #[staticmethod]
    fn from_dict(d: &Bound<'_, PyDict>) -> PyResult<Self> {
        let secs: Option<u64> = d
            .get_item(interns::secs(d.py()))?
            .map(|s| s.extract())
            .transpose()?;
        let nanos: Option<u32> = d
            .get_item(interns::nanos(d.py()))?
            .map(|s| s.extract())
            .transpose()?;
        if let (Some(secs), Some(nanos)) = (secs, nanos) {
            Self::new(secs, nanos)
        } else {
            py_key_err!("dict must contain 'secs' and 'nanos' keys")
        }
    }

    // ========================================================================
    // FROM NUMBERS
    // ========================================================================

    /// Create a new `Duration` from the specified number of seconds.
    #[pyo3(name = "from_secs")]
    #[staticmethod]
    const fn py_from_secs(secs: u64) -> Self {
        Self::from_secs(secs)
    }

    #[staticmethod]
    fn from_millis(millis: u64) -> Self {
        Self(Duration::from_millis(millis))
    }

    #[staticmethod]
    fn from_micros(micros: u64) -> Self {
        Self(Duration::from_micros(micros))
    }

    #[staticmethod]
    fn from_nanos(nanos: u64) -> Self {
        Self(Duration::from_nanos(nanos))
    }

    #[staticmethod]
    fn from_hours(hours: u64) -> PyResult<Self> {
        if hours > u64::MAX / (60 * 60) {
            py_overflow_err!("overflow in Duration::from_hours")
        } else {
            Ok(Self(Duration::from_secs(hours * 60 * 60)))
        }
    }

    #[staticmethod]
    fn from_mins(mins: u64) -> PyResult<Self> {
        if mins > u64::MAX / 60 {
            py_overflow_err!("overflow in Duration::from_mins")
        } else {
            Ok(Self(Duration::from_secs(mins * 60)))
        }
    }

    #[staticmethod]
    fn from_days(days: u64) -> PyResult<Self> {
        if days > MAX_DAYS {
            py_overflow_err!("overflow in Duration::from_days: {days} > {MAX_DAYS}")
        } else {
            Ok(Self(Duration::from_secs(days * 60 * 60 * 24)))
        }
    }

    #[staticmethod]
    fn from_weeks(weeks: u64) -> PyResult<Self> {
        weeks
            .checked_mul(SECS_PER_WEEK)
            .map(|v| Duration::from_secs(v).into())
            .ok_or_else(|| py_overflow_error!("overflow in Duration::from_weeks"))
    }

    #[staticmethod]
    fn from_secs_f32(secs: f32) -> PyResult<Self> {
        Self::try_from_secs_f32(secs)
    }

    #[staticmethod]
    fn from_secs_f64(secs: f64) -> PyResult<Self> {
        Self::try_from_secs_f64(secs)
    }

    #[cfg(feature = "jiff")]
    #[staticmethod]
    fn fromisoformat(s: &str) -> PyResult<Self> {
        use ryo3_macro_rules::py_value_error;
        TEMPORAL_SPAN_PARSER
            .parse_unsigned_duration(s)
            .map(Self)
            .map_err(|e| py_value_error!("invalid isoformat string: {e}"))
    }

    #[staticmethod]
    #[pyo3(signature = (s, /))]
    fn from_str(s: &str) -> PyResult<Self> {
        Self::py_from_str(s)
    }

    #[staticmethod]
    #[pyo3(signature = (value, /))]
    fn parse(value: ryo3_core::PyParseArg<Self>) -> Self {
        value.into_inner()
    }

    // ========================================================================
    // METHODS
    // ========================================================================
    #[cfg(feature = "jiff")]
    #[pyo3(name = "to_string")]
    fn py_to_string(&self) -> String {
        self.__str__()
    }

    #[cfg(feature = "jiff")]
    fn __str__(&self) -> String {
        self.isoformat()
    }

    #[cfg(feature = "jiff")]
    fn __format__(&self, fmt: &str) -> PyResult<String> {
        if fmt == "#" {
            Ok(FRIENDLY_SPAN_PRINTER.unsigned_duration_to_string(&self.0))
        } else if fmt.is_empty() {
            Ok(self.py_to_string())
        } else {
            py_type_err!(
                "Invalid format specifier '{fmt}' for Duration; only '' and '#' are supported"
            )
        }
    }

    #[cfg(feature = "jiff")]
    fn isoformat(&self) -> String {
        TEMPORAL_SPAN_PRINTER.unsigned_duration_to_string(&self.0)
    }

    #[cfg(feature = "jiff")]
    #[pyo3(signature = (designator = "compact"))]
    fn friendly(&self, designator: &str) -> PyResult<String> {
        match designator {
            "human-time" | "human" => Ok(FRIENDLY_SPAN_PRINTER
                .designator(Designator::HumanTime)
                .unsigned_duration_to_string(&self.0)),
            "short" => Ok(FRIENDLY_SPAN_PRINTER
                .designator(Designator::Short)
                .unsigned_duration_to_string(&self.0)),
            "compact" => Ok(FRIENDLY_SPAN_PRINTER.unsigned_duration_to_string(&self.0)),
            "verbose" => Ok(FRIENDLY_SPAN_PRINTER
                .designator(Designator::Verbose)
                .unsigned_duration_to_string(&self.0)),
            other => {
                py_value_err!(
                    "invalid designator: {other} (expected 'human'/'human-time', 'short', 'compact', or 'verbose')"
                )
            }
        }
    }

    #[pyo3(signature = (*, secs = None, nanos = None))]
    fn replace(&self, secs: Option<u64>, nanos: Option<u32>) -> PyResult<Self> {
        Self::py_new(
            secs.unwrap_or(self.0.as_secs()),
            nanos.unwrap_or(self.0.subsec_nanos()),
        )
    }

    /// Sleep for the duration
    #[pyo3(signature = (*, interval = 100))]
    pub(crate) fn sleep(&self, py: Python<'_>, interval: u64) -> PyResult<()> {
        if !(1..=1000).contains(&interval) {
            return py_value_err!("interval must be in the range 1..=1000 milliseconds");
        }
        let sleep_duration = self.0;
        let check_interval = Duration::from_millis(interval);
        let mut remaining = sleep_duration;
        while remaining > check_interval {
            py.check_signals()?; // check for ctrl-c/sigs
            py.detach(|| std::thread::sleep(check_interval));
            remaining -= check_interval;
        }
        if remaining > Duration::ZERO {
            py.check_signals()?; // final check for ctrl-c/sigs
            py.detach(|| std::thread::sleep(remaining));
        }
        Ok(())
    }

    // ========================================================================
    // SLEEP CROSSBEAM IMPL
    // ========================================================================
    // pub fn sleep<'py>(&self, py: Python<'py>) -> PyResult<()> {
    //     // channel for sleepytime to signal done
    //     let (tx, rx) = crossbeam_channel::bounded::<()>(1);
    //     let duration = self.0;
    //     std::thread::spawn(move || {
    //         std::thread::sleep(duration);
    //         let _ = tx.send(());
    //     });
    //     loop {
    //         py.check_signals()?;
    //         crossbeam_channel::select! {
    //             recv(rx) -> _ => {
    //                 break;
    //             }
    //             default(Duration::from_millis(10)) => {
    //             }
    //         }
    //     }
    //     Ok(())
    // }

    fn abs_diff(&self, other: DurationLike) -> Self {
        self.0.abs_diff(other.into()).into()
    }

    fn checked_add(&self, other: &Self) -> Option<Self> {
        self.0.checked_add(other.0).map(Self::from)
    }

    fn checked_div(&self, other: u32) -> Option<Self> {
        self.0.checked_div(other).map(Self::from)
    }

    fn checked_mul(&self, other: u32) -> Option<Self> {
        self.0.checked_mul(other).map(Self::from)
    }

    fn checked_sub(&self, other: &Self) -> Option<Self> {
        self.0.checked_sub(other.0).map(Self::from)
    }

    fn div_duration_f32(&self, other: &Self) -> PyResult<f32> {
        if other.0.is_zero() {
            py_zero_division_err!()
        } else {
            Ok(self.0.div_duration_f32(other.0))
        }
    }

    fn div_duration_f64(&self, other: &Self) -> PyResult<f64> {
        if other.0.is_zero() {
            py_zero_division_err!()
        } else {
            Ok(self.0.div_duration_f64(other.0))
        }
    }

    fn div_f32(&self, n: f32) -> PyResult<Self> {
        if n.abs() == 0.0 {
            py_zero_division_err!()
        } else if n.is_nan() {
            py_value_err!("invalid value: nan")
        } else if n.is_infinite() {
            py_overflow_err!("invalid value: inf")
        } else if n.is_sign_negative() {
            py_type_err!("negative divisor")
        } else {
            let result = self.0.as_secs_f32().div(n);
            Self::try_from_secs_f32(result)
        }
    }

    fn div_f64(&self, n: f64) -> PyResult<Self> {
        if n.abs() == 0.0 {
            py_zero_division_err!()
        } else if n.is_nan() {
            py_value_err!("invalid value: nan")
        } else if n.is_infinite() {
            py_overflow_err!("invalid value: inf")
        } else if n.is_sign_negative() {
            py_type_err!("negative divisor")
        } else {
            let result = self.0.as_secs_f64().div(n);
            Self::try_from_secs_f64(result)
        }
    }

    fn mul_f32(&self, n: f32) -> PyResult<Self> {
        if n.abs() == 0.0 {
            Ok(Self::from(Duration::ZERO))
        } else if n.is_infinite() {
            py_overflow_err!()
        } else if n.is_nan() {
            py_value_err!("invalid value: nan")
        } else if n.is_sign_negative() {
            py_type_err!("negative factor")
        } else {
            let result = self.0.as_secs_f32().mul(n);
            Self::try_from_secs_f32(result)
        }
    }

    fn mul_f64(&self, n: f64) -> PyResult<Self> {
        if n.abs() == 0.0 {
            Ok(Self::from(Duration::ZERO))
        } else if n.is_infinite() {
            py_overflow_err!()
        } else if n.is_nan() {
            py_value_err!("invalid value: nan")
        } else if n.is_sign_negative() {
            py_type_err!("negative factor")
        } else {
            let result = self.0.as_secs_f64().mul(n);
            Self::try_from_secs_f64(result)
        }
    }

    fn saturating_add(&self, other: &Self) -> Self {
        Self::from(self.0.saturating_add(other.0))
    }

    fn saturating_mul(&self, other: u32) -> Self {
        Self::from(self.0.saturating_mul(other))
    }

    fn saturating_sub(&self, other: &Self) -> Self {
        Self::from(self.0.saturating_sub(other.0))
    }

    #[staticmethod]
    fn from_any<'py>(value: &Bound<'py, PyAny>) -> PyResult<Bound<'py, Self>> {
        let py = value.py();
        if let Ok(val) = value.cast_exact::<Self>() {
            Ok(val.as_borrowed().into_bound())
        } else if let Ok(pystr) = value.cast::<pyo3::types::PyString>() {
            let s = pystr.extract::<&str>()?;
            Self::from_str(s).map(|dur| dur.into_pyobject(py))?
        } else if let Ok(pybytes) = value.cast::<pyo3::types::PyBytes>() {
            use pyo3::types::PyBytesMethods;
            let s = String::from_utf8_lossy(pybytes.as_bytes());
            Self::from_str(&s).map(|dt| dt.into_pyobject(py))?
        } else if let Ok(v) = value.cast_exact::<pyo3::types::PyFloat>() {
            let f = v.extract::<f64>()?;
            Self::try_from_secs_f64(f).map(|dt| dt.into_pyobject(py))?
        } else if let Ok(v) = value.cast_exact::<pyo3::types::PyInt>() {
            let i = v.extract::<u64>()?;
            Self::from(Duration::new(i, 0)).into_pyobject(py)
        } else if let Ok(d) = value.extract::<Duration>() {
            Self::from(d).into_pyobject(py)
        } else {
            use ryo3_macro_rules::any_repr;

            let valtype = any_repr!(value);
            py_type_err!("Duration conversion error: {valtype}")
        }
    }

    // ========================================================================
    // PYDANTIC
    // ========================================================================
    #[cfg(feature = "pydantic")]
    #[staticmethod]
    fn _pydantic_validate<'py>(value: &Bound<'py, PyAny>) -> PyResult<Bound<'py, Self>> {
        Self::from_any(value).map_err(|e| {
            use ryo3_macro_rules::py_value_error;
            py_value_error!("Duration validation error: {e}")
        })
    }

    #[cfg(feature = "pydantic")]
    #[classmethod]
    fn __get_pydantic_core_schema__<'py>(
        cls: &Bound<'py, ::pyo3::types::PyType>,
        source: &Bound<'py, PyAny>,
        handler: &Bound<'py, PyAny>,
    ) -> PyResult<Bound<'py, PyAny>> {
        use ryo3_pydantic::GetPydanticCoreSchemaCls;
        Self::get_pydantic_core_schema(cls, source, handler)
    }
}

impl std::fmt::Display for PyDuration {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "Duration(secs={}, nanos={})",
            self.0.as_secs(),
            self.0.subsec_nanos()
        )
    }
}

// TODO: fix this as it is required by the repr of reqwest client config
//       currently just forwards to display
impl std::fmt::Debug for PyDuration {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{self}")
    }
}

#[cfg(feature = "jiff")]
impl std::str::FromStr for PyDuration {
    type Err = jiff::Error;
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        TEMPORAL_SPAN_PARSER
            .parse_unsigned_duration(s)
            .map(Self::from)
            .or_else(|_| {
                FRIENDLY_SPAN_PARSER
                    .parse_unsigned_duration(s)
                    .map(Self::from)
            })
    }
}

#[cfg(not(feature = "jiff"))]
impl std::str::FromStr for PyDuration {
    type Err = pyo3::PyErr;

    fn from_str(_s: &str) -> Result<Self, Self::Err> {
        use ryo3_macro_rules::py_not_implemented_error;
        Err(py_not_implemented_error!(
            "Duration::from_str is not implemented; enable the 'jiff' feature to use this functionality"
        ))
    }
}

// ----------------------------------------------------------------------------
// py-string interns
// ----------------------------------------------------------------------------

mod interns {
    use pyo3::prelude::*;
    use ryo3_macro_rules::py_intern_fn;

    py_intern_fn!(secs);
    py_intern_fn!(nanos);
}

#[cfg(feature = "pydantic")]
mod pydantic {
    use pyo3::prelude::*;
    use pyo3::types::PyType;
    use ryo3_pydantic::{GetPydanticCoreSchemaCls, interns};

    use super::PyDuration;

    impl GetPydanticCoreSchemaCls for PyDuration {
        fn get_pydantic_core_schema<'py>(
            cls: &Bound<'py, PyType>,
            source: &Bound<'py, PyAny>,
            _handler: &Bound<'py, PyAny>,
        ) -> PyResult<Bound<'py, PyAny>> {
            let py = source.py();
            let core_schema = ryo3_pydantic::core_schema(py)?;
            let timedelta_schema =
                core_schema.call_method(interns::timedelta_schema(py), (), None)?;
            let validation_fn = cls.getattr(interns::_pydantic_validate(py))?;
            let string_serialization_schema =
                core_schema.call_method(interns::to_string_ser_schema(py), (), None)?;
            let plain_validator_kwargs = pyo3::types::PyDict::new(py);
            plain_validator_kwargs
                .set_item(interns::json_schema_input_schema(py), &timedelta_schema)?;
            plain_validator_kwargs
                .set_item(interns::serialization(py), &string_serialization_schema)?;
            core_schema.call_method(
                interns::no_info_plain_validator_function(py),
                (&validation_fn,),
                Some(&plain_validator_kwargs),
            )
        }
    }
}

impl From<Duration> for PyDuration {
    fn from(d: Duration) -> Self {
        Self(d)
    }
}

impl From<&PyDuration> for Duration {
    fn from(d: &PyDuration) -> Self {
        d.0
    }
}

impl From<PyDuration> for Duration {
    fn from(d: PyDuration) -> Self {
        d.0
    }
}

impl From<PyDuration> for Option<Duration> {
    fn from(d: PyDuration) -> Self {
        Some(d.0)
    }
}

mod arithmetic {
    use std::time::Duration;

    use pyo3::IntoPyObjectExt;
    use pyo3::prelude::*;
    use ryo3_core::PyCastExactOpt;
    use ryo3_macro_rules::py_type_err;

    use crate::time::PyDuration;

    pub(super) struct DurationLike(Duration);

    impl From<DurationLike> for Duration {
        fn from(d: DurationLike) -> Self {
            d.0
        }
    }

    impl<'py> FromPyObject<'_, 'py> for DurationLike {
        type Error = PyErr;
        fn extract(obj: Borrowed<'_, 'py, PyAny>) -> Result<Self, Self::Error> {
            if let Some(inst) = obj.cast_exact_opt::<PyDuration>() {
                let dur = inst.get();
                Ok(Self(dur.0))
            } else if let Ok(inst) = obj.cast::<pyo3::types::PyDelta>() {
                let dur: Duration = inst.extract()?;
                Ok(Self(dur))
            } else {
                py_type_err!("unsupported operand type(s) for Duration-like object")
            }
        }
    }

    pub(super) enum DurationTrueDivInput<'a, 'py> {
        Int(u32),
        Float(f64),
        Duration(Borrowed<'a, 'py, PyDuration>),
        PyDelta(Duration),
    }

    pub(super) enum DurationTrueDivOutput {
        Float(f64),
        Duration(PyDuration),
    }

    impl From<f64> for DurationTrueDivOutput {
        fn from(f: f64) -> Self {
            Self::Float(f)
        }
    }

    impl From<PyDuration> for DurationTrueDivOutput {
        fn from(d: PyDuration) -> Self {
            Self::Duration(d)
        }
    }

    impl<'a, 'py> FromPyObject<'a, 'py> for DurationTrueDivInput<'a, 'py> {
        type Error = PyErr;
        fn extract(obj: Borrowed<'a, 'py, PyAny>) -> Result<Self, Self::Error> {
            if let Ok(pi) = obj.cast_exact::<pyo3::types::PyInt>() {
                let i = pi.extract::<u32>()?;
                return Ok(Self::Int(i));
            }

            if let Ok(pf) = obj.cast_exact::<pyo3::types::PyFloat>() {
                let f = pf.extract::<f64>()?;
                return Ok(Self::Float(f));
            }

            if let Ok(inst) = obj.cast_exact::<PyDuration>() {
                return Ok(Self::Duration(inst));
            }

            if let Ok(inst) = obj.cast::<pyo3::types::PyDelta>() {
                let dur: Duration = inst.extract()?;
                return Ok(Self::PyDelta(dur));
            }

            py_type_err!(
                "unsupported operand type(s); must be int | float | Duration | datetime.timedelta"
            )
        }
    }

    impl<'py> IntoPyObject<'py> for DurationTrueDivOutput {
        type Target = PyAny;

        type Output = Bound<'py, Self::Target>;

        type Error = PyErr;

        fn into_pyobject(self, py: Python<'py>) -> Result<Self::Output, Self::Error> {
            match self {
                Self::Float(f) => f.into_bound_py_any(py),
                Self::Duration(d) => d.into_bound_py_any(py),
            }
        }
    }

    pub(super) enum DurationMulInput {
        Int(u32),
        Float(f64),
    }

    impl<'a, 'py> FromPyObject<'a, 'py> for DurationMulInput {
        type Error = PyErr;
        fn extract(obj: Borrowed<'a, 'py, PyAny>) -> Result<Self, Self::Error> {
            if let Some(pi) = obj.cast_exact_opt::<pyo3::types::PyInt>() {
                let i = pi.extract::<u32>()?;
                Ok(Self::Int(i))
            } else if let Some(pf) = obj.cast_exact_opt::<pyo3::types::PyFloat>() {
                let f = pf.extract::<f64>()?;
                Ok(Self::Float(f))
            } else {
                py_type_err!("unsupported operand type(s); must be int | float")
            }
        }
    }
}
