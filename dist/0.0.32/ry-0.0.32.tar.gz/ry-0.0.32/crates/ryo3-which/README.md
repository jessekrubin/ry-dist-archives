# `ryo3-which`

Wrapper around the `which` crate for Python.

`which`:
  - [crates.io](https://crates.io/crates/which)
  - [docs.rs](https://docs.rs/which)

___

## TODO

 - [ ] make `ryo3-regex` feature flag work
 - [ ] make iterable w/ `collect`
