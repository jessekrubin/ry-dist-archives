//! `PyHttpStatus` class
//!
//! Caches instances to avoid duplicating them when you are say scraping the
//! web and getting a ton of 200s or 404s or whatever...
use pyo3::intern;
use pyo3::prelude::*;
use pyo3::pyclass::CompareOp;
use pyo3::sync::PyOnceLock;
use pyo3::types::{PyString, PyTuple};
use ryo3_core::{PyAsciiStr, PyAsciiString, py_type_err, py_value_error};

// typos:off
// is the plural of status "stati" or "statuses"? who knows. literally nothing
// I can do to find that answer online.
// typos:on
/// cache with pyoncelocks of `PyHttpStatus` for statuses/stati(?) 100-599
static STATUS_CACHE: [PyOnceLock<Py<PyHttpStatus>>; 500] = [const { PyOnceLock::new() }; 500];

fn py_cached_http_status(py: Python<'_>, status: http::StatusCode) -> PyResult<Py<PyHttpStatus>> {
    let code = status.as_u16() as usize;
    if (100..=599).contains(&code) {
        let cell = &STATUS_CACHE[code - 100];
        cell.get_or_try_init(py, || Py::new(py, PyHttpStatus(status)))
            .map(|obj| obj.clone_ref(py))
    } else {
        // fuckit no cache
        Py::new(py, PyHttpStatus(status))
    }
}

#[pyclass(name = "HttpStatus", frozen, immutable_type, skip_from_py_object)]
#[cfg_attr(feature = "ry", pyo3(module = "ry.ryo3"))]
#[derive(Clone, Copy)]
pub struct PyHttpStatus(pub(crate) http::StatusCode);

impl PyHttpStatus {
    pub fn from_status_code_cached(py: Python<'_>, status: http::StatusCode) -> PyResult<Py<Self>> {
        py_cached_http_status(py, status)
    }
}

#[pymethods]
#[expect(clippy::trivially_copy_pass_by_ref)]
impl PyHttpStatus {
    #[new]
    #[pyo3(signature = (code))]
    fn py_new(py: Python<'_>, code: u16) -> PyResult<Py<Self>> {
        let code = http::StatusCode::from_u16(code)
            .map_err(|_| py_value_error!("Invalid HTTP status code: {code}"))?;
        py_cached_http_status(py, code)
    }

    #[expect(clippy::trivially_copy_pass_by_ref)]
    fn __getnewargs__<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyTuple>> {
        PyTuple::new(py, [self.0.as_u16()])
    }

    #[must_use]
    fn __str__(&self) -> PyAsciiStr<'_> {
        PyAsciiStr::from(self.0.as_str())
    }

    #[must_use]
    fn __repr__(&self) -> PyAsciiString {
        format!("{self:?}").into()
    }

    #[must_use]
    fn __int__(&self) -> u16 {
        self.0.as_u16()
    }

    #[must_use]
    #[expect(clippy::wrong_self_convention)]
    fn to_py(&self) -> u16 {
        self.0.as_u16()
    }

    #[must_use]
    #[getter]
    fn canonical_reason<'py>(&self, py: Python<'py>) -> Option<&Bound<'py, PyString>> {
        status_code_pystring(py, self.0.as_u16())
    }

    #[getter]
    #[must_use]
    fn reason<'py>(&self, py: Python<'py>) -> Option<&Bound<'py, PyString>> {
        status_code_pystring(py, self.0.as_u16())
    }

    #[getter]
    #[must_use]
    fn is_informational(&self) -> bool {
        self.0.is_informational()
    }

    #[getter]
    #[must_use]
    fn is_success(&self) -> bool {
        self.0.is_success()
    }

    #[getter]
    #[must_use]
    fn is_redirect(&self) -> bool {
        self.0.is_redirection()
    }

    #[getter]
    #[must_use]
    fn is_redirection(&self) -> bool {
        self.0.is_redirection()
    }

    #[getter]
    #[must_use]
    fn is_client_error(&self) -> bool {
        self.0.is_client_error()
    }

    #[getter]
    #[must_use]
    fn is_server_error(&self) -> bool {
        self.0.is_server_error()
    }

    #[getter]
    #[must_use]
    fn is_error(&self) -> bool {
        self.0.is_server_error() || self.0.is_client_error()
    }

    #[getter]
    #[must_use]
    fn is_ok(&self) -> bool {
        self.0.is_success()
    }

    #[getter]
    #[must_use]
    fn ok(&self) -> bool {
        self.0.is_success()
    }

    #[must_use]
    fn __hash__(&self) -> u64 {
        u64::from(self.0.as_u16())
    }

    #[must_use]
    fn __bool__(&self) -> bool {
        self.0.is_success()
    }

    fn __richcmp__(&self, other: &Bound<'_, PyAny>, op: CompareOp) -> PyResult<bool> {
        if let Ok(status_downcast_gucci) = other.cast_exact::<Self>() {
            let status = status_downcast_gucci.get();
            match op {
                CompareOp::Eq => Ok(self.0 == status.0),
                CompareOp::Ne => Ok(self.0 != status.0),
                CompareOp::Lt => Ok(self.0 < status.0),
                CompareOp::Le => Ok(self.0 <= status.0),
                CompareOp::Gt => Ok(self.0 > status.0),
                CompareOp::Ge => Ok(self.0 >= status.0),
            }
        } else if let Ok(status) = other.extract::<u16>() {
            match op {
                CompareOp::Eq => Ok(self.0.as_u16() == status),
                CompareOp::Ne => Ok(self.0.as_u16() != status),
                CompareOp::Lt => Ok(self.0.as_u16() < status),
                CompareOp::Le => Ok(self.0.as_u16() <= status),
                CompareOp::Gt => Ok(self.0.as_u16() > status),
                CompareOp::Ge => Ok(self.0.as_u16() >= status),
            }
        } else {
            match op {
                CompareOp::Eq => Ok(false),
                CompareOp::Ne => Ok(true),
                _ => py_type_err!("http-status-code-invalid-comparison"),
            }
        }
    }

    #[cfg(feature = "pydantic")]
    #[staticmethod]
    fn _pydantic_validate<'py>(value: &Bound<'py, PyAny>) -> PyResult<Bound<'py, PyAny>> {
        let py = value.py();
        if let Ok(status) = value.cast_exact::<Self>() {
            Ok(status.clone().into_any())
        } else if let Ok(code) = value.extract::<i64>() {
            let code = u16::try_from(code).map_err(|_| {
                py_value_error!("HTTP status validation error: invalid HTTP status code: {code}")
            })?;
            let status = http::StatusCode::from_u16(code).map_err(|_| {
                py_value_error!("HTTP status validation error: invalid HTTP status code: {code}")
            })?;
            Ok(Self::from_status_code_cached(py, status)?
                .into_bound(py)
                .into_any())
        } else {
            Err(py_value_error!(
                "HTTP status validation error: expected int or HttpStatus"
            ))
        }
    }

    #[cfg(feature = "pydantic")]
    fn _pydantic_serialize(&self) -> u16 {
        self.0.as_u16()
    }

    #[cfg(feature = "pydantic")]
    #[classmethod]
    fn __get_pydantic_core_schema__<'py>(
        cls: &Bound<'py, ::pyo3::types::PyType>,
        source: &Bound<'py, PyAny>,
        handler: &Bound<'py, PyAny>,
    ) -> PyResult<Bound<'py, PyAny>> {
        use ryo3_pydantic::GetPydanticCoreSchemaCls;
        Self::get_pydantic_core_schema(cls, source, handler)
    }

    // ========================================================================
    // CLASS ATTRS
    // ------------------------------------------------------------------------
    // The following was generated crudely and could be done with a macro but meh
    // ========================================================================

    // <CLASS-ATTRS>
    /// 100 ~ Continue
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn CONTINUE(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::CONTINUE)
    }

    /// 101 ~ Switching Protocols
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn SWITCHING_PROTOCOLS(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::SWITCHING_PROTOCOLS)
    }

    /// 102 ~ Processing
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn PROCESSING(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::PROCESSING)
    }

    /// 103 ~ Early Hints
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn EARLY_HINTS(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::EARLY_HINTS)
    }

    /// 200 ~ OK
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn OK(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::OK)
    }

    /// 201 ~ Created
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn CREATED(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::CREATED)
    }

    /// 202 ~ Accepted
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn ACCEPTED(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::ACCEPTED)
    }

    /// 203 ~ Non Authoritative Information
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn NON_AUTHORITATIVE_INFORMATION(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::NON_AUTHORITATIVE_INFORMATION)
    }

    /// 204 ~ No Content
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn NO_CONTENT(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::NO_CONTENT)
    }

    /// 205 ~ Reset Content
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn RESET_CONTENT(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::RESET_CONTENT)
    }

    /// 206 ~ Partial Content
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn PARTIAL_CONTENT(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::PARTIAL_CONTENT)
    }

    /// 207 ~ Multi-Status
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn MULTI_STATUS(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::MULTI_STATUS)
    }

    /// 208 ~ Already Reported
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn ALREADY_REPORTED(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::ALREADY_REPORTED)
    }

    /// 226 ~ IM Used
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn IM_USED(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::IM_USED)
    }

    /// 300 ~ Multiple Choices
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn MULTIPLE_CHOICES(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::MULTIPLE_CHOICES)
    }

    /// 301 ~ Moved Permanently
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn MOVED_PERMANENTLY(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::MOVED_PERMANENTLY)
    }

    /// 302 ~ Found
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn FOUND(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::FOUND)
    }

    /// 303 ~ See Other
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn SEE_OTHER(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::SEE_OTHER)
    }

    /// 304 ~ Not Modified
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn NOT_MODIFIED(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::NOT_MODIFIED)
    }

    /// 305 ~ Use Proxy
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn USE_PROXY(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::USE_PROXY)
    }

    /// 307 ~ Temporary Redirect
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn TEMPORARY_REDIRECT(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::TEMPORARY_REDIRECT)
    }

    /// 308 ~ Permanent Redirect
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn PERMANENT_REDIRECT(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::PERMANENT_REDIRECT)
    }

    /// 400 ~ Bad Request
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn BAD_REQUEST(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::BAD_REQUEST)
    }

    /// 401 ~ Unauthorized
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn UNAUTHORIZED(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::UNAUTHORIZED)
    }

    /// 402 ~ Payment Required
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn PAYMENT_REQUIRED(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::PAYMENT_REQUIRED)
    }

    /// 403 ~ Forbidden
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn FORBIDDEN(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::FORBIDDEN)
    }

    /// 404 ~ Not Found
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn NOT_FOUND(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::NOT_FOUND)
    }

    /// 405 ~ Method Not Allowed
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn METHOD_NOT_ALLOWED(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::METHOD_NOT_ALLOWED)
    }

    /// 406 ~ Not Acceptable
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn NOT_ACCEPTABLE(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::NOT_ACCEPTABLE)
    }

    /// 407 ~ Proxy Authentication Required
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn PROXY_AUTHENTICATION_REQUIRED(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::PROXY_AUTHENTICATION_REQUIRED)
    }

    /// 408 ~ Request Timeout
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn REQUEST_TIMEOUT(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::REQUEST_TIMEOUT)
    }

    /// 409 ~ Conflict
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn CONFLICT(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::CONFLICT)
    }

    /// 410 ~ Gone
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn GONE(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::GONE)
    }

    /// 411 ~ Length Required
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn LENGTH_REQUIRED(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::LENGTH_REQUIRED)
    }

    /// 412 ~ Precondition Failed
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn PRECONDITION_FAILED(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::PRECONDITION_FAILED)
    }

    /// 413 ~ Payload Too Large
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn PAYLOAD_TOO_LARGE(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::PAYLOAD_TOO_LARGE)
    }

    /// 414 ~ URI Too Long
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn URI_TOO_LONG(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::URI_TOO_LONG)
    }

    /// 415 ~ Unsupported Media Type
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn UNSUPPORTED_MEDIA_TYPE(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::UNSUPPORTED_MEDIA_TYPE)
    }

    /// 416 ~ Range Not Satisfiable
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn RANGE_NOT_SATISFIABLE(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::RANGE_NOT_SATISFIABLE)
    }

    /// 417 ~ Expectation Failed
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn EXPECTATION_FAILED(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::EXPECTATION_FAILED)
    }

    /// 418 ~ I'm a teapot
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn IM_A_TEAPOT(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::IM_A_TEAPOT)
    }

    /// 421 ~ Misdirected Request
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn MISDIRECTED_REQUEST(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::MISDIRECTED_REQUEST)
    }

    /// 422 ~ Unprocessable Entity
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn UNPROCESSABLE_ENTITY(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::UNPROCESSABLE_ENTITY)
    }

    /// 423 ~ Locked
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn LOCKED(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::LOCKED)
    }

    /// 424 ~ Failed Dependency
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn FAILED_DEPENDENCY(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::FAILED_DEPENDENCY)
    }

    /// 425 ~ Too Early
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn TOO_EARLY(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::TOO_EARLY)
    }

    /// 426 ~ Upgrade Required
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn UPGRADE_REQUIRED(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::UPGRADE_REQUIRED)
    }

    /// 428 ~ Precondition Required
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn PRECONDITION_REQUIRED(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::PRECONDITION_REQUIRED)
    }

    /// 429 ~ Too Many Requests
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn TOO_MANY_REQUESTS(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::TOO_MANY_REQUESTS)
    }

    /// 431 ~ Request Header Fields Too Large
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn REQUEST_HEADER_FIELDS_TOO_LARGE(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::REQUEST_HEADER_FIELDS_TOO_LARGE)
    }

    /// 451 ~ Unavailable For Legal Reasons
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn UNAVAILABLE_FOR_LEGAL_REASONS(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::UNAVAILABLE_FOR_LEGAL_REASONS)
    }

    /// 500 ~ Internal Server Error
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn INTERNAL_SERVER_ERROR(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::INTERNAL_SERVER_ERROR)
    }

    /// 501 ~ Not Implemented
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn NOT_IMPLEMENTED(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::NOT_IMPLEMENTED)
    }

    /// 502 ~ Bad Gateway
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn BAD_GATEWAY(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::BAD_GATEWAY)
    }

    /// 503 ~ Service Unavailable
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn SERVICE_UNAVAILABLE(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::SERVICE_UNAVAILABLE)
    }

    /// 504 ~ Gateway Timeout
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn GATEWAY_TIMEOUT(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::GATEWAY_TIMEOUT)
    }

    /// 505 ~ HTTP Version Not Supported
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn HTTP_VERSION_NOT_SUPPORTED(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::HTTP_VERSION_NOT_SUPPORTED)
    }

    /// 506 ~ Variant Also Negotiates
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn VARIANT_ALSO_NEGOTIATES(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::VARIANT_ALSO_NEGOTIATES)
    }

    /// 507 ~ Insufficient Storage
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn INSUFFICIENT_STORAGE(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::INSUFFICIENT_STORAGE)
    }

    /// 508 ~ Loop Detected
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn LOOP_DETECTED(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::LOOP_DETECTED)
    }

    /// 510 ~ Not Extended
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn NOT_EXTENDED(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::NOT_EXTENDED)
    }

    /// 511 ~ Network Authentication Required
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn NETWORK_AUTHENTICATION_REQUIRED(py: Python<'_>) -> PyResult<Py<Self>> {
        py_cached_http_status(py, ::http::StatusCode::NETWORK_AUTHENTICATION_REQUIRED)
    }
    // </CLASS-ATTRS>
}

macro_rules! status_code_match {
    ($py:expr, $code:expr, {
        $(
            ($num:literal, $msg:literal)
        ),* $(,)?
    }) => {
        match $code {
            $(
                $num => Some(intern!($py, $msg)),
            )*
            _ => None,
        }
    };
}

pub fn status_code_pystring(py: Python<'_>, status_code: u16) -> Option<&Bound<'_, PyString>> {
    status_code_match!(py, status_code, {
        // 1xx
        (100, "Continue"),
        (101, "Switching Protocols"),
        (102, "Processing"),
        (103, "Early Hints"),

        // 2xx
        (200, "OK"),
        (201, "Created"),
        (202, "Accepted"),
        (203, "Non Authoritative Information"), // should or should not be `Non-Authoritative`?
        (204, "No Content"),
        (205, "Reset Content"),
        (206, "Partial Content"),
        (207, "Multi-Status"),
        (208, "Already Reported"),
        (226, "IM Used"),

        // 3xx
        (300, "Multiple Choices"),
        (301, "Moved Permanently"),
        (302, "Found"),
        (303, "See Other"),
        (304, "Not Modified"),
        (305, "Use Proxy"),
        (307, "Temporary Redirect"),
        (308, "Permanent Redirect"),

        // 4xx
        (400, "Bad Request"),
        (401, "Unauthorized"),
        (402, "Payment Required"),
        (403, "Forbidden"),
        (404, "Not Found"),
        (405, "Method Not Allowed"),
        (406, "Not Acceptable"),
        (407, "Proxy Authentication Required"),
        (408, "Request Timeout"),
        (409, "Conflict"),
        (410, "Gone"),
        (411, "Length Required"),
        (412, "Precondition Failed"),
        (413, "Payload Too Large"),
        (414, "URI Too Long"),
        (415, "Unsupported Media Type"),
        (416, "Range Not Satisfiable"),
        (417, "Expectation Failed"),
        (418, "I'm a teapot"),
        (421, "Misdirected Request"),
        (422, "Unprocessable Entity"),
        (423, "Locked"),
        (424, "Failed Dependency"),
        (425, "Too Early"),
        (426, "Upgrade Required"),
        (428, "Precondition Required"),
        (429, "Too Many Requests"),
        (431, "Request Header Fields Too Large"),
        (451, "Unavailable For Legal Reasons"),

        // 5xx
        (500, "Internal Server Error"),
        (501, "Not Implemented"),
        (502, "Bad Gateway"),
        (503, "Service Unavailable"),
        (504, "Gateway Timeout"),
        (505, "HTTP Version Not Supported"),
        (506, "Variant Also Negotiates"),
        (507, "Insufficient Storage"),
        (508, "Loop Detected"),
        (510, "Not Extended"),
        (511, "Network Authentication Required"),
    })
}

impl std::fmt::Debug for PyHttpStatus {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "HttpStatus({})", self.0.as_str())
    }
}

#[cfg(feature = "pydantic")]
impl ryo3_pydantic::GetPydanticCoreSchemaCls for PyHttpStatus {
    fn get_pydantic_core_schema<'py>(
        cls: &Bound<'py, pyo3::types::PyType>,
        source: &Bound<'py, PyAny>,
        _handler: &Bound<'py, PyAny>,
    ) -> PyResult<Bound<'py, PyAny>> {
        use pyo3::types::PyDict;
        use ryo3_pydantic::interns;

        let py = source.py();
        let core_schema = ryo3_pydantic::core_schema(py)?;
        let int_schema = core_schema.call_method(interns::int_schema(py), (), None)?;
        let validation_fn = cls.getattr(interns::_pydantic_validate(py))?;

        let serializer_fn = cls.getattr(interns::_pydantic_serialize(py))?;
        let serializer_kwargs = PyDict::new(py);
        serializer_kwargs.set_item(interns::return_schema(py), &int_schema)?;
        serializer_kwargs.set_item(interns::when_used(py), interns::json_unless_none(py))?;
        let serializer_schema = core_schema.call_method(
            interns::plain_serializer_function_ser_schema(py),
            (&serializer_fn,),
            Some(&serializer_kwargs),
        )?;

        let plain_validator_kwargs = PyDict::new(py);
        plain_validator_kwargs.set_item("json_schema_input_schema", &int_schema)?;
        plain_validator_kwargs.set_item(interns::serialization(py), &serializer_schema)?;
        core_schema.call_method(
            interns::no_info_plain_validator_function(py),
            (&validation_fn,),
            Some(&plain_validator_kwargs),
        )
    }
}
