use std::ops::{Neg, Not};
use std::str::FromStr;

use pyo3::prelude::*;
use pyo3::pyclass::CompareOp;
use pyo3::types::PyTuple;
use ryo3_core::{PyAsciiString, py_overflow_err, py_overflow_error, py_type_err, py_type_error};

use crate::types::{PyBase, PyStyle};

#[derive(Debug, Clone, Copy)]
#[pyclass(name = "Size", frozen, immutable_type, skip_from_py_object)]
#[cfg_attr(feature = "ry", pyo3(module = "ry.ryo3"))]
pub struct PySize(size::Size);

impl From<size::Size> for PySize {
    fn from(size: size::Size) -> Self {
        Self(size)
    }
}

impl From<i64> for PySize {
    fn from(size: i64) -> Self {
        Self::from_const(size)
    }
}

impl PySize {
    const fn from_const(size: i64) -> Self {
        Self(size::Size::from_const(size))
    }
}

#[expect(clippy::trivially_copy_pass_by_ref)]
#[pymethods]
impl PySize {
    #[new]
    fn py_new(size: i64) -> Self {
        Self(size::Size::from_const(size))
    }

    fn __getnewargs__<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyTuple>> {
        PyTuple::new(py, vec![self.0.bytes()])
    }

    fn __int__(&self) -> i64 {
        self.0.bytes()
    }

    fn __str__(&self) -> PyAsciiString {
        format!("{}", self.0).into()
    }

    fn __repr__(&self) -> PyAsciiString {
        format!("{self}").into()
    }

    fn __hash__(&self) -> u64 {
        // can just use the actual number converted to u64
        u64::from_ne_bytes(self.0.bytes().to_ne_bytes())
    }

    fn __bool__(&self) -> bool {
        self.0.bytes() != 0
    }

    #[getter]
    fn bytes(&self) -> i64 {
        self.0.bytes()
    }

    #[expect(clippy::needless_pass_by_value)]
    fn __richcmp__(&self, other: SizeWrapper, op: CompareOp) -> bool {
        match op {
            CompareOp::Eq => self.0 == other.0,
            CompareOp::Ne => self.0 != other.0,
            CompareOp::Lt => self.0 < other.0,
            CompareOp::Le => self.0 <= other.0,
            CompareOp::Gt => self.0 > other.0,
            CompareOp::Ge => self.0 >= other.0,
        }
    }

    #[pyo3(
        signature = (*, base = PyBase::default(), style = PyStyle::default()),
        text_signature = "(self, *, base=2, style='default')"
    )]
    fn format(&self, base: PyBase, style: PyStyle) -> PyAsciiString {
        self.0
            .format()
            .with_base(base.into())
            .with_style(style.0)
            .to_string()
            .into()
    }

    #[staticmethod]
    #[pyo3(signature = (s, /))]
    fn from_str(s: ryo3_core::PyFromStrArg<Self>) -> Self {
        s.into_inner()
    }

    #[staticmethod]
    #[pyo3(signature = (value, /))]
    fn parse(value: ryo3_core::PyParseArg<Self>) -> Self {
        value.into_inner()
    }

    fn __abs__(&self) -> Self {
        Self(size::Size::from_const(self.0.bytes().abs()))
    }

    fn __neg__(&self) -> Self {
        Self(size::Size::from_const(self.0.bytes().neg()))
    }

    fn __pos__(&self) -> Self {
        self.__abs__()
    }

    fn __invert__(&self) -> Self {
        Self(size::Size::from_const(self.0.bytes().not()))
    }

    #[expect(clippy::needless_pass_by_value)]
    fn __add__(&self, other: SizeWrapper) -> PyResult<Self> {
        self.0
            .bytes()
            .checked_add(other.0.bytes())
            .map(Self::from)
            .ok_or_else(|| py_overflow_error!("overflow"))
    }

    #[expect(clippy::needless_pass_by_value)]
    fn __sub__(&self, other: SizeWrapper) -> PyResult<Self> {
        self.0
            .bytes()
            .checked_sub(other.0.bytes())
            .map(Self::from)
            .ok_or_else(|| py_overflow_error!("overflow"))
    }

    #[expect(clippy::cast_precision_loss, clippy::cast_possible_truncation)]
    fn __mul__(&self, other: PySizeArithmetic) -> PyResult<Self> {
        let base = self.0.bytes();

        if self.0.bytes() == 0 {
            return Ok(Self::from(0));
        }
        let result_bytes: Option<i64> = match other {
            PySizeArithmetic::Size(s) => base.checked_mul(s.0.bytes()),

            PySizeArithmetic::Int64(i) => base.checked_mul(i),
            PySizeArithmetic::UInt64(u) => {
                let lhs = i128::from(base);
                let rhs = i128::from(u);
                let product = lhs
                    .checked_mul(rhs)
                    .ok_or_else(|| py_overflow_error!("overflow (size * u64)"))?;
                if (i128::from(i64::MIN)..=i128::from(i64::MAX)).contains(&product) {
                    product.try_into().ok()
                } else {
                    None
                }
            }

            PySizeArithmetic::Float64(f) => {
                if !(f.is_finite()) {
                    return py_overflow_err!("Cannot multiply Size by NaN or infinite float");
                }
                let result_f64 = (base as f64) * f;
                if !result_f64.is_finite() {
                    return py_overflow_err!("Overflow in Size * float");
                }
                let rounded = result_f64.round();
                if rounded < i64::MIN as f64 || rounded > i64::MAX as f64 {
                    None
                } else {
                    let result = rounded as i64;
                    Some(result)
                }
            }
        };
        result_bytes
            .ok_or_else(|| py_overflow_error!("Overflow in Size multiplication"))
            .map(Self::from)
    }

    fn __rmul__(&self, other: PySizeArithmetic) -> PyResult<Self> {
        self.__mul__(other)
    }

    #[staticmethod]
    fn from_bytes(size: PySizeIntermediate) -> Self {
        size.into_bytes().into()
    }

    // ========================================================================
    // CLASS METHODS ~ generated by moi in python repl and lost into the ether
    // ========================================================================
    // size::Size::from_eb
    // size::Size::from_eib
    // size::Size::from_exabytes
    // size::Size::from_exbibytes
    // size::Size::from_gb
    // size::Size::from_gib
    // size::Size::from_gibibytes
    // size::Size::from_gigabytes
    // size::Size::from_kb
    // size::Size::from_kib
    // size::Size::from_kibibytes
    // size::Size::from_kilobytes
    // size::Size::from_mb
    // size::Size::from_mebibytes
    // size::Size::from_megabytes
    // size::Size::from_mib
    // size::Size::from_pb
    // size::Size::from_pebibytes
    // size::Size::from_petabytes
    // size::Size::from_pib
    // size::Size::from_str
    // size::Size::from_tb
    // size::Size::from_tebibytes
    // size::Size::from_terabytes
    // size::Size::from_tib
    // ========================================================================

    #[staticmethod]
    fn from_eb(size: PySizeIntermediate) -> Self {
        size.into_eb().into()
    }

    #[staticmethod]
    fn from_eib(size: PySizeIntermediate) -> Self {
        size.into_eib().into()
    }

    #[staticmethod]
    fn from_exabytes(size: PySizeIntermediate) -> Self {
        size.into_exabytes().into()
    }

    #[staticmethod]
    fn from_exbibytes(size: PySizeIntermediate) -> Self {
        size.into_exbibytes().into()
    }

    #[staticmethod]
    fn from_gb(size: PySizeIntermediate) -> Self {
        size.into_gb().into()
    }

    #[staticmethod]
    fn from_gib(size: PySizeIntermediate) -> Self {
        size.into_gib().into()
    }

    #[staticmethod]
    fn from_gibibytes(size: PySizeIntermediate) -> Self {
        size.into_gibibytes().into()
    }

    #[staticmethod]
    fn from_gigabytes(size: PySizeIntermediate) -> Self {
        size.into_gigabytes().into()
    }

    #[staticmethod]
    fn from_kb(size: PySizeIntermediate) -> Self {
        size.into_kb().into()
    }

    #[staticmethod]
    fn from_kib(size: PySizeIntermediate) -> Self {
        size.into_kib().into()
    }

    #[staticmethod]
    fn from_kibibytes(size: PySizeIntermediate) -> Self {
        size.into_kibibytes().into()
    }

    #[staticmethod]
    fn from_kilobytes(size: PySizeIntermediate) -> Self {
        size.into_kilobytes().into()
    }

    #[staticmethod]
    fn from_mb(size: PySizeIntermediate) -> Self {
        size.into_mb().into()
    }

    #[staticmethod]
    fn from_mebibytes(size: PySizeIntermediate) -> Self {
        size.into_mebibytes().into()
    }

    #[staticmethod]
    fn from_megabytes(size: PySizeIntermediate) -> Self {
        size.into_megabytes().into()
    }

    #[staticmethod]
    fn from_mib(size: PySizeIntermediate) -> Self {
        size.into_mib().into()
    }

    #[staticmethod]
    fn from_pb(size: PySizeIntermediate) -> Self {
        size.into_pb().into()
    }

    #[staticmethod]
    fn from_pebibytes(size: PySizeIntermediate) -> Self {
        size.into_pebibytes().into()
    }

    #[staticmethod]
    fn from_petabytes(size: PySizeIntermediate) -> Self {
        size.into_petabytes().into()
    }

    #[staticmethod]
    fn from_pib(size: PySizeIntermediate) -> Self {
        size.into_pib().into()
    }

    #[staticmethod]
    fn from_tb(size: PySizeIntermediate) -> Self {
        size.into_tb().into()
    }

    #[staticmethod]
    fn from_tebibytes(size: PySizeIntermediate) -> Self {
        size.into_tebibytes().into()
    }

    #[staticmethod]
    fn from_terabytes(size: PySizeIntermediate) -> Self {
        size.into_terabytes().into()
    }

    #[staticmethod]
    fn from_tib(size: PySizeIntermediate) -> Self {
        size.into_tib().into()
    }

    // ========================================================================
    // CLASS ATTRIBUTES / CONSTS
    // ========================================================================

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn MIN() -> Self {
        Self::from_const(i64::MIN)
    }

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn MAX() -> Self {
        Self::from_const(i64::MAX)
    }

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn ZERO() -> Self {
        Self::from_const(0)
    }

    /// Basic "byte" constant, used across all bases.
    #[classattr]
    #[pyo3(name = "BYTE")]
    #[expect(non_snake_case, reason = "python classattr")]
    fn CONST_BYTE() -> Self {
        Self::from_const(::size::consts::BYTE)
    }
    /// Base-10 "kilobyte" constant, equal to 1000 bytes.
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn KILOBYTE() -> Self {
        Self::from_const(::size::consts::KILOBYTE)
    }
    /// Base-10 "megabyte" constant, equal to 1000 kilobytes.
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn MEGABYTE() -> Self {
        Self::from_const(::size::consts::MEGABYTE)
    }
    /// Base-10 "gigabyte" constant, equal to 1000 megabytes.
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn GIGABYTE() -> Self {
        Self::from_const(::size::consts::GIGABYTE)
    }

    /// Base-10 "terabyte" constant, equal to 1000 gigabytes.
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn TERABYTE() -> Self {
        Self::from_const(::size::consts::TERABYTE)
    }
    /// Base-10 "petabyte" constant, equal to 1000 terabytes.
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn PETABYTE() -> Self {
        Self::from_const(::size::consts::PETABYTE)
    }
    /// Base-10 "exabyte" constant, equal to 1000 petabytes.
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn EXABYTE() -> Self {
        Self::from_const(::size::consts::EXABYTE)
    }

    /// Abbreviated "byte" constant. Identical to [`BYTE`].
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn B() -> Self {
        Self::from_const(::size::consts::BYTE)
    }
    /// Abbreviated base-10 "kilobyte" constant, equal to 1000 bytes. Identical to [`KILOBYTE`].
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn KB() -> Self {
        Self::from_const(::size::consts::KILOBYTE)
    }
    /// Abbreviated base-10 "megabyte" constant, equal to 1000 kilobytes. Identical to [`MEGABYTE`].
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn MB() -> Self {
        Self::from_const(::size::consts::MEGABYTE)
    }
    /// Abbreviated base-10 "gigabyte" constant, equal to 1000 megabytes. Identical to [`GIGABYTE`].
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn GB() -> Self {
        Self::from_const(::size::consts::GIGABYTE)
    }
    /// Abbreviated base-10 "terabyte" constant, equal to 1000 gigabytes. Identical to [`TERABYTE`].
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn TB() -> Self {
        Self::from_const(::size::consts::TERABYTE)
    }
    /// Abbreviated base-10 "petabyte" constant, equal to 1000 terabytes. Identical to [`PETABYTE`].
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn PB() -> Self {
        Self::from_const(::size::consts::PETABYTE)
    }
    /// Abbreviated base-10 "exabyte" constant, equal to 1000 petabytes. Identical to [`EXABYTE`].
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn EB() -> Self {
        Self::from_const(::size::consts::EXABYTE)
    }

    /// Base-2 "kibibyte" constant, equal to 2^10 bytes.
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn KIBIBYTE() -> Self {
        Self::from_const(::size::consts::KIBIBYTE)
    }
    /// Base-2 "mebibyte" constant, equal to 2^20 bytes.
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn MEBIBYTE() -> Self {
        Self::from_const(::size::consts::MEBIBYTE)
    }
    /// Base-2 "gibibyte" constant, equal to 2^30 bytes.
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn GIBIBYTE() -> Self {
        Self::from_const(::size::consts::GIBIBYTE)
    }
    /// Base-2 "tebibyte" constant, equal to 2^40 bytes.
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn TEBIBYTE() -> Self {
        Self::from_const(::size::consts::TEBIBYTE)
    }
    /// Base-2 "pebibyte" constant, equal to 2^50 bytes.
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn PEBIBYTE() -> Self {
        Self::from_const(::size::consts::PEBIBYTE)
    }
    /// Base-2 "exbibyte" constant, equal to 2^60 bytes.
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn EXBIBYTE() -> Self {
        Self::from_const(::size::consts::EXBIBYTE)
    }

    /// Abbreviated base-2 "kibibyte" constant, equal to 1024 bytes. Identical to [`KIBIBYTE`].
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn KIB() -> Self {
        Self::from_const(::size::consts::KIBIBYTE)
    }
    /// Abbreviated base-2 "mebibyte" constant, equal to 1024 kibibytes. Identical to [`MEBIBYTE`].
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn MIB() -> Self {
        Self::from_const(::size::consts::MEBIBYTE)
    }
    /// Abbreviated base-2 "gibibyte" constant, equal to 1024 mebibytes. Identical to [`GIBIBYTE`].
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn GIB() -> Self {
        Self::from_const(::size::consts::GIBIBYTE)
    }
    /// Abbreviated base-2 "tebibyte" constant, equal to 1024 gibibytes. Identical to [`TEBIBYTE`].
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn TIB() -> Self {
        Self::from_const(::size::consts::TEBIBYTE)
    }
    /// Abbreviated base-2 "pebibyte" constant, equal to 1024 tebibytes. Identical to [`PEBIBYTE`].
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn PIB() -> Self {
        Self::from_const(::size::consts::PEBIBYTE)
    }
    /// Abbreviated base-2 "exbibyte" constant, equal to 1024 pebibytes. Identical to [`EXBIBYTE`].
    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn EIB() -> Self {
        Self::from_const(::size::consts::EXBIBYTE)
    }
}

impl<'py> FromPyObject<'_, 'py> for PySize {
    type Error = pyo3::PyErr;

    fn extract(obj: Borrowed<'_, 'py, PyAny>) -> Result<Self, Self::Error> {
        obj.cast_exact::<Self>()
            .map(Self::from)
            .map_err(|_| py_type_error!("expected `Size`"))
    }
}

impl From<Borrowed<'_, '_, Self>> for PySize {
    fn from(value: Borrowed<'_, '_, Self>) -> Self {
        Self(value.get().0)
    }
}

#[derive(Debug, Clone)]
struct SizeWrapper(size::Size);

impl<'py> FromPyObject<'_, 'py> for SizeWrapper {
    type Error = pyo3::PyErr;

    fn extract(obj: Borrowed<'_, 'py, PyAny>) -> Result<Self, Self::Error> {
        if let Ok(s) = obj.cast_exact::<PySize>() {
            Ok(Self(s.get().0))
        } else if let Ok(i) = obj.extract::<i64>() {
            Ok(Self(size::Size::from_const(i)))
        } else if let Ok(f) = obj.extract::<f64>() {
            Ok(Self(size::Size::from_bytes(f)))
        } else {
            py_type_err!("expected `Size`, int, or float")
        }
    }
}

impl FromStr for PySize {
    type Err = size::ParseSizeError;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let size = size::Size::from_str(s)?;
        Ok(Self(size))
    }
}

#[derive(Debug, Clone, FromPyObject)]
enum PySizeIntermediate {
    Int64(i64),
    UInt64(u64),
    Float64(f64),
}

// implement intermidate `into_` functions using `from_` functions on `size::Size`
macro_rules! impl_intermediate_to_size_fn {
    ($to_fnname:ident, $from_fnname:ident ) => {
        impl PySizeIntermediate {
            fn $to_fnname(self) -> size::Size {
                match self {
                    Self::Float64(f) => size::Size::$from_fnname(f),
                    Self::Int64(i) => size::Size::$from_fnname(i),
                    Self::UInt64(u) => size::Size::$from_fnname(u),
                }
            }
        }
    };
}

// impl_intermediate_to_size_fn!(to_eb, from_eb);
impl_intermediate_to_size_fn!(into_bytes, from_bytes);
impl_intermediate_to_size_fn!(into_kb, from_kb);
impl_intermediate_to_size_fn!(into_kib, from_kib);
impl_intermediate_to_size_fn!(into_kibibytes, from_kibibytes);
impl_intermediate_to_size_fn!(into_kilobytes, from_kilobytes);
impl_intermediate_to_size_fn!(into_mb, from_mb);
impl_intermediate_to_size_fn!(into_mebibytes, from_mebibytes);
impl_intermediate_to_size_fn!(into_megabytes, from_megabytes);
impl_intermediate_to_size_fn!(into_mib, from_mib);
impl_intermediate_to_size_fn!(into_gb, from_gb);
impl_intermediate_to_size_fn!(into_gib, from_gib);
impl_intermediate_to_size_fn!(into_gibibytes, from_gibibytes);
impl_intermediate_to_size_fn!(into_gigabytes, from_gigabytes);
impl_intermediate_to_size_fn!(into_tb, from_tb);
impl_intermediate_to_size_fn!(into_tebibytes, from_tebibytes);
impl_intermediate_to_size_fn!(into_terabytes, from_terabytes);
impl_intermediate_to_size_fn!(into_tib, from_tib);
impl_intermediate_to_size_fn!(into_pb, from_pb);
impl_intermediate_to_size_fn!(into_pebibytes, from_pebibytes);
impl_intermediate_to_size_fn!(into_petabytes, from_petabytes);
impl_intermediate_to_size_fn!(into_pib, from_pib);
impl_intermediate_to_size_fn!(into_eb, from_eb);
impl_intermediate_to_size_fn!(into_eib, from_eib);
impl_intermediate_to_size_fn!(into_exabytes, from_exabytes);
impl_intermediate_to_size_fn!(into_exbibytes, from_exbibytes);

#[derive(Debug, Clone, Copy, FromPyObject)]
enum PySizeArithmetic {
    Size(PySize),
    Int64(i64),
    UInt64(u64),
    Float64(f64), // must make float last
}

impl std::fmt::Display for PySize {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "Size({})", self.0.bytes())
    }
}
