#![doc = include_str!("../README.md")]

mod pyo3_bytes;
pub use pyo3_bytes::Pyo3Bytes;
