# API

## Table of Contents

- [`ry.ryo3.__init__`](#ry.ryo3.__init__)
- [`ry.ryo3.__about__`](#ry.ryo3.__about__)
- [`ry.ryo3._aws_lc`](#ry.ryo3._aws_lc)
- [`ry.ryo3._brotli`](#ry.ryo3._brotli)
- [`ry.ryo3._burli`](#ry.ryo3._burli)
- [`ry.ryo3._bytes`](#ry.ryo3._bytes)
- [`ry.ryo3._cookie`](#ry.ryo3._cookie)
- [`ry.ryo3._crc32fast`](#ry.ryo3._crc32fast)
- [`ry.ryo3._dev`](#ry.ryo3._dev)
- [`ry.ryo3._dirs`](#ry.ryo3._dirs)
- [`ry.ryo3._encoding_rs`](#ry.ryo3._encoding_rs)
- [`ry.ryo3._errors`](#ry.ryo3._errors)
- [`ry.ryo3._flate2`](#ry.ryo3._flate2)
- [`ry.ryo3._fnv`](#ry.ryo3._fnv)
- [`ry.ryo3._fspath`](#ry.ryo3._fspath)
- [`ry.ryo3._glob`](#ry.ryo3._glob)
- [`ry.ryo3._globset`](#ry.ryo3._globset)
- [`ry.ryo3._heck`](#ry.ryo3._heck)
- [`ry.ryo3._http`](#ry.ryo3._http)
- [`ry.ryo3._jiff`](#ry.ryo3._jiff)
- [`ry.ryo3._jiff_tz`](#ry.ryo3._jiff_tz)
- [`ry.ryo3._jiter`](#ry.ryo3._jiter)
- [`ry.ryo3._json`](#ry.ryo3._json)
- [`ry.ryo3._lz4rip`](#ry.ryo3._lz4rip)
- [`ry.ryo3._memchr`](#ry.ryo3._memchr)
- [`ry.ryo3._orjson`](#ry.ryo3._orjson)
- [`ry.ryo3._quick_maths`](#ry.ryo3._quick_maths)
- [`ry.ryo3._regex`](#ry.ryo3._regex)
- [`ry.ryo3._reqwest`](#ry.ryo3._reqwest)
- [`ry.ryo3._same_file`](#ry.ryo3._same_file)
- [`ry.ryo3._sh`](#ry.ryo3._sh)
- [`ry.ryo3._shlex`](#ry.ryo3._shlex)
- [`ry.ryo3._size`](#ry.ryo3._size)
- [`ry.ryo3._sqlformat`](#ry.ryo3._sqlformat)
- [`ry.ryo3._std`](#ry.ryo3._std)
- [`ry.ryo3._tokio`](#ry.ryo3._tokio)
- [`ry.ryo3._tokio_websockets`](#ry.ryo3._tokio_websockets)
- [`ry.ryo3._twox_hash`](#ry.ryo3._twox_hash)
- [`ry.ryo3._ulid`](#ry.ryo3._ulid)
- [`ry.ryo3._unindent`](#ry.ryo3._unindent)
- [`ry.ryo3._url`](#ry.ryo3._url)
- [`ry.ryo3._uuid`](#ry.ryo3._uuid)
- [`ry.ryo3._walkdir`](#ry.ryo3._walkdir)
- [`ry.ryo3._which`](#ry.ryo3._which)
- [`ry.ryo3._zstd`](#ry.ryo3._zstd)
- [`ry._types`](#ry._types)
- [`ry.protocols`](#ry.protocols)
<h2 id="ry.ryo3.__init__"><code>ry.ryo3.__init__</code></h2>

```python
"""ry api ~ type annotations"""

from ry.ryo3.__about__ import __allocator__ as __allocator__
from ry.ryo3.__about__ import __authors__ as __authors__
from ry.ryo3.__about__ import __build_profile__ as __build_profile__
from ry.ryo3.__about__ import __build_timestamp__ as __build_timestamp__
from ry.ryo3.__about__ import __crypto_provider__ as __crypto_provider__
from ry.ryo3.__about__ import __description__ as __description__
from ry.ryo3.__about__ import __git_repo__ as __git_repo__
from ry.ryo3.__about__ import __git_sha__ as __git_sha__
from ry.ryo3.__about__ import __opt_level__ as __opt_level__
from ry.ryo3.__about__ import __pkg_name__ as __pkg_name__
from ry.ryo3.__about__ import __target__ as __target__
from ry.ryo3.__about__ import __version__ as __version__
from ry.ryo3.__about__ import _build_info as _build_info
from ry.ryo3._aws_lc import awslc_version as awslc_version
from ry.ryo3._aws_lc import sha1 as sha1
from ry.ryo3._aws_lc import sha3_256 as sha3_256
from ry.ryo3._aws_lc import sha3_384 as sha3_384
from ry.ryo3._aws_lc import sha3_512 as sha3_512
from ry.ryo3._aws_lc import sha224 as sha224
from ry.ryo3._aws_lc import sha256 as sha256
from ry.ryo3._aws_lc import sha384 as sha384
from ry.ryo3._aws_lc import sha512 as sha512
from ry.ryo3._aws_lc import sha512_256 as sha512_256
from ry.ryo3._brotli import brotli_decompress as brotli_decompress
from ry.ryo3._burli import brotli_compress as brotli_compress
from ry.ryo3._bytes import Bytes as Bytes
from ry.ryo3._cookie import Cookie as Cookie
from ry.ryo3._crc32fast import crc32 as crc32
from ry.ryo3._dirs import audio_dir as audio_dir
from ry.ryo3._dirs import cache_dir as cache_dir
from ry.ryo3._dirs import config_dir as config_dir
from ry.ryo3._dirs import config_local_dir as config_local_dir
from ry.ryo3._dirs import data_dir as data_dir
from ry.ryo3._dirs import data_local_dir as data_local_dir
from ry.ryo3._dirs import desktop_dir as desktop_dir
from ry.ryo3._dirs import document_dir as document_dir
from ry.ryo3._dirs import download_dir as download_dir
from ry.ryo3._dirs import executable_dir as executable_dir
from ry.ryo3._dirs import font_dir as font_dir
from ry.ryo3._dirs import home_dir as home_dir
from ry.ryo3._dirs import picture_dir as picture_dir
from ry.ryo3._dirs import preference_dir as preference_dir
from ry.ryo3._dirs import public_dir as public_dir
from ry.ryo3._dirs import runtime_dir as runtime_dir
from ry.ryo3._dirs import state_dir as state_dir
from ry.ryo3._dirs import template_dir as template_dir
from ry.ryo3._dirs import video_dir as video_dir
from ry.ryo3._errors import FeatureNotEnabledError as FeatureNotEnabledError
from ry.ryo3._errors import PanicError as PanicError
from ry.ryo3._errors import UnreachableError as UnreachableError
from ry.ryo3._errors import panic as panic
from ry.ryo3._errors import unreachable as unreachable
from ry.ryo3._flate2 import gzip_compress as gzip_compress
from ry.ryo3._flate2 import gzip_decompress as gzip_decompress
from ry.ryo3._flate2 import is_gzip as is_gzip
from ry.ryo3._fnv import fnv1a as fnv1a
from ry.ryo3._fspath import FsPath as FsPath
from ry.ryo3._glob import GlobPattern as GlobPattern
from ry.ryo3._glob import glob as glob
from ry.ryo3._globset import Glob as Glob
from ry.ryo3._globset import GlobSet as GlobSet
from ry.ryo3._globset import Globster as Globster
from ry.ryo3._globset import globster as globster
from ry.ryo3._heck import camel_case as camel_case
from ry.ryo3._heck import kebab_case as kebab_case
from ry.ryo3._heck import pascal_case as pascal_case
from ry.ryo3._heck import shouty_kebab_case as shouty_kebab_case
from ry.ryo3._heck import shouty_snake_case as shouty_snake_case
from ry.ryo3._heck import snake_case as snake_case
from ry.ryo3._heck import snek_case as snek_case
from ry.ryo3._heck import title_case as title_case
from ry.ryo3._heck import train_case as train_case
from ry.ryo3._http import Headers as Headers
from ry.ryo3._http import HttpStatus as HttpStatus
from ry.ryo3._jiff import Date as Date
from ry.ryo3._jiff import DateDifference as DateDifference
from ry.ryo3._jiff import DateTime as DateTime
from ry.ryo3._jiff import DateTimeDifference as DateTimeDifference
from ry.ryo3._jiff import DateTimeRound as DateTimeRound
from ry.ryo3._jiff import ISOWeekDate as ISOWeekDate
from ry.ryo3._jiff import Offset as Offset
from ry.ryo3._jiff import OffsetRound as OffsetRound
from ry.ryo3._jiff import SignedDuration as SignedDuration
from ry.ryo3._jiff import SignedDurationRound as SignedDurationRound
from ry.ryo3._jiff import Time as Time
from ry.ryo3._jiff import TimeDifference as TimeDifference
from ry.ryo3._jiff import TimeRound as TimeRound
from ry.ryo3._jiff import TimeSpan as TimeSpan
from ry.ryo3._jiff import Timestamp as Timestamp
from ry.ryo3._jiff import TimestampDifference as TimestampDifference
from ry.ryo3._jiff import TimestampRound as TimestampRound
from ry.ryo3._jiff import TimeZone as TimeZone
from ry.ryo3._jiff import TimeZoneDatabase as TimeZoneDatabase
from ry.ryo3._jiff import ZonedDateTime as ZonedDateTime
from ry.ryo3._jiff import ZonedDateTimeDifference as ZonedDateTimeDifference
from ry.ryo3._jiff import ZonedDateTimeRound as ZonedDateTimeRound
from ry.ryo3._jiff import date as date
from ry.ryo3._jiff import datetime as datetime
from ry.ryo3._jiff import now as now
from ry.ryo3._jiff import offset as offset
from ry.ryo3._jiff import time as time
from ry.ryo3._jiff import timespan as timespan
from ry.ryo3._jiff import utcnow as utcnow
from ry.ryo3._jiff import zoned as zoned
from ry.ryo3._jiter import JSONDecodeError as JSONDecodeError
from ry.ryo3._jiter import _JsonPrimitive as _JsonPrimitive
from ry.ryo3._jiter import _JsonValue as _JsonValue
from ry.ryo3._jiter import json_cache_clear as json_cache_clear
from ry.ryo3._jiter import json_cache_usage as json_cache_usage
from ry.ryo3._jiter import parse_json as parse_json
from ry.ryo3._jiter import parse_jsonl as parse_jsonl
from ry.ryo3._jiter import read_json as read_json
from ry.ryo3._json import JSON as JSON
from ry.ryo3._json import stringify as stringify
from ry.ryo3._lz4rip import Lz4BlockCompressor as Lz4BlockCompressor
from ry.ryo3._lz4rip import Lz4BlockDecompressor as Lz4BlockDecompressor
from ry.ryo3._lz4rip import Lz4FrameCompressor as Lz4FrameCompressor
from ry.ryo3._lz4rip import Lz4FrameInfo as Lz4FrameInfo
from ry.ryo3._lz4rip import lz4_compress as lz4_compress
from ry.ryo3._lz4rip import lz4_compress_block as lz4_compress_block
from ry.ryo3._lz4rip import lz4_decompress as lz4_decompress
from ry.ryo3._lz4rip import lz4_decompress_block as lz4_decompress_block
from ry.ryo3._lz4rip import lz4_train_dict as lz4_train_dict
from ry.ryo3._memchr import memchr as memchr
from ry.ryo3._memchr import memchr2 as memchr2
from ry.ryo3._memchr import memchr3 as memchr3
from ry.ryo3._memchr import memrchr as memrchr
from ry.ryo3._memchr import memrchr2 as memrchr2
from ry.ryo3._memchr import memrchr3 as memrchr3
from ry.ryo3._orjson import orjson_default as orjson_default
from ry.ryo3._quick_maths import quick_maths as quick_maths
from ry.ryo3._regex import Regex as Regex
from ry.ryo3._reqwest import BlockingClient as BlockingClient
from ry.ryo3._reqwest import BlockingEventStream as BlockingEventStream
from ry.ryo3._reqwest import BlockingResponse as BlockingResponse
from ry.ryo3._reqwest import BlockingResponseStream as BlockingResponseStream
from ry.ryo3._reqwest import Certificate as Certificate
from ry.ryo3._reqwest import CertificateRevocationList as CertificateRevocationList
from ry.ryo3._reqwest import Client as Client
from ry.ryo3._reqwest import ClientConfig as ClientConfig
from ry.ryo3._reqwest import EventStream as EventStream
from ry.ryo3._reqwest import FormData as FormData
from ry.ryo3._reqwest import FormPart as FormPart
from ry.ryo3._reqwest import Identity as Identity
from ry.ryo3._reqwest import Proxy as Proxy
from ry.ryo3._reqwest import RequestKwargs as RequestKwargs
from ry.ryo3._reqwest import ReqwestError as ReqwestError
from ry.ryo3._reqwest import Response as Response
from ry.ryo3._reqwest import ResponseStream as ResponseStream
from ry.ryo3._reqwest import ServerSentEvent as ServerSentEvent
from ry.ryo3._reqwest import fetch as fetch
from ry.ryo3._reqwest import fetch_sync as fetch_sync
from ry.ryo3._same_file import is_same_file as is_same_file
from ry.ryo3._sh import cd as cd
from ry.ryo3._sh import home as home
from ry.ryo3._sh import ls as ls
from ry.ryo3._sh import mkdir as mkdir
from ry.ryo3._sh import mkdirp as mkdirp
from ry.ryo3._sh import pwd as pwd
from ry.ryo3._shlex import shplit as shplit
from ry.ryo3._size import Size as Size
from ry.ryo3._size import SizeFormatter as SizeFormatter
from ry.ryo3._size import fmt_size as fmt_size
from ry.ryo3._size import parse_size as parse_size
from ry.ryo3._sqlformat import SqlfmtQueryParams as SqlfmtQueryParams
from ry.ryo3._sqlformat import SqlFormatter as SqlFormatter
from ry.ryo3._sqlformat import sqlfmt as sqlfmt
from ry.ryo3._sqlformat import sqlfmt_params as sqlfmt_params
from ry.ryo3._std import I8_BITS as I8_BITS
from ry.ryo3._std import I8_MAX as I8_MAX
from ry.ryo3._std import I8_MIN as I8_MIN
from ry.ryo3._std import I16_BITS as I16_BITS
from ry.ryo3._std import I16_MAX as I16_MAX
from ry.ryo3._std import I16_MIN as I16_MIN
from ry.ryo3._std import I32_BITS as I32_BITS
from ry.ryo3._std import I32_MAX as I32_MAX
from ry.ryo3._std import I32_MIN as I32_MIN
from ry.ryo3._std import I64_BITS as I64_BITS
from ry.ryo3._std import I64_MAX as I64_MAX
from ry.ryo3._std import I64_MIN as I64_MIN
from ry.ryo3._std import I128_BITS as I128_BITS
from ry.ryo3._std import I128_MAX as I128_MAX
from ry.ryo3._std import I128_MIN as I128_MIN
from ry.ryo3._std import ISIZE_BITS as ISIZE_BITS
from ry.ryo3._std import ISIZE_MAX as ISIZE_MAX
from ry.ryo3._std import ISIZE_MIN as ISIZE_MIN
from ry.ryo3._std import U8_BITS as U8_BITS
from ry.ryo3._std import U8_MAX as U8_MAX
from ry.ryo3._std import U8_MIN as U8_MIN
from ry.ryo3._std import U16_BITS as U16_BITS
from ry.ryo3._std import U16_MAX as U16_MAX
from ry.ryo3._std import U16_MIN as U16_MIN
from ry.ryo3._std import U32_BITS as U32_BITS
from ry.ryo3._std import U32_MAX as U32_MAX
from ry.ryo3._std import U32_MIN as U32_MIN
from ry.ryo3._std import U64_BITS as U64_BITS
from ry.ryo3._std import U64_MAX as U64_MAX
from ry.ryo3._std import U64_MIN as U64_MIN
from ry.ryo3._std import U128_BITS as U128_BITS
from ry.ryo3._std import U128_MAX as U128_MAX
from ry.ryo3._std import U128_MIN as U128_MIN
from ry.ryo3._std import USIZE_BITS as USIZE_BITS
from ry.ryo3._std import USIZE_MAX as USIZE_MAX
from ry.ryo3._std import USIZE_MIN as USIZE_MIN
from ry.ryo3._std import DirEntry as DirEntry
from ry.ryo3._std import Duration as Duration
from ry.ryo3._std import FileReadStream as FileReadStream
from ry.ryo3._std import FileType as FileType
from ry.ryo3._std import Instant as Instant
from ry.ryo3._std import IpAddr as IpAddr
from ry.ryo3._std import Ipv4Addr as Ipv4Addr
from ry.ryo3._std import Ipv6Addr as Ipv6Addr
from ry.ryo3._std import Metadata as Metadata
from ry.ryo3._std import ReadDir as ReadDir
from ry.ryo3._std import SocketAddr as SocketAddr
from ry.ryo3._std import SocketAddrV4 as SocketAddrV4
from ry.ryo3._std import SocketAddrV6 as SocketAddrV6
from ry.ryo3._std import canonicalize as canonicalize
from ry.ryo3._std import copy as copy
from ry.ryo3._std import create_dir as create_dir
from ry.ryo3._std import create_dir_all as create_dir_all
from ry.ryo3._std import duration as duration
from ry.ryo3._std import exists as exists
from ry.ryo3._std import hard_link as hard_link
from ry.ryo3._std import instant as instant
from ry.ryo3._std import is_dir as is_dir
from ry.ryo3._std import is_file as is_file
from ry.ryo3._std import is_symlink as is_symlink
from ry.ryo3._std import metadata as metadata
from ry.ryo3._std import read as read
from ry.ryo3._std import read_bytes as read_bytes
from ry.ryo3._std import read_dir as read_dir
from ry.ryo3._std import read_link as read_link
from ry.ryo3._std import read_str as read_str
from ry.ryo3._std import read_stream as read_stream
from ry.ryo3._std import read_text as read_text
from ry.ryo3._std import read_to_string as read_to_string
from ry.ryo3._std import remove_dir as remove_dir
from ry.ryo3._std import remove_dir_all as remove_dir_all
from ry.ryo3._std import remove_file as remove_file
from ry.ryo3._std import rename as rename
from ry.ryo3._std import set_permissions as set_permissions
from ry.ryo3._std import sleep as sleep
from ry.ryo3._std import soft_link as soft_link
from ry.ryo3._std import symlink_metadata as symlink_metadata
from ry.ryo3._std import write as write
from ry.ryo3._std import write_bytes as write_bytes
from ry.ryo3._std import write_text as write_text
from ry.ryo3._tokio import AsyncDirEntry as AsyncDirEntry
from ry.ryo3._tokio import AsyncFile as AsyncFile
from ry.ryo3._tokio import AsyncFileReadStream as AsyncFileReadStream
from ry.ryo3._tokio import AsyncReadDir as AsyncReadDir
from ry.ryo3._tokio import aopen as aopen
from ry.ryo3._tokio import asleep as asleep
from ry.ryo3._tokio import canonicalize_async as canonicalize_async
from ry.ryo3._tokio import copy_async as copy_async
from ry.ryo3._tokio import create_dir_all_async as create_dir_all_async
from ry.ryo3._tokio import create_dir_async as create_dir_async
from ry.ryo3._tokio import exists_async as exists_async
from ry.ryo3._tokio import hard_link_async as hard_link_async
from ry.ryo3._tokio import metadata_async as metadata_async
from ry.ryo3._tokio import read_async as read_async
from ry.ryo3._tokio import read_dir_async as read_dir_async
from ry.ryo3._tokio import read_link_async as read_link_async
from ry.ryo3._tokio import read_stream_async as read_stream_async
from ry.ryo3._tokio import read_to_string_async as read_to_string_async
from ry.ryo3._tokio import remove_dir_all_async as remove_dir_all_async
from ry.ryo3._tokio import remove_dir_async as remove_dir_async
from ry.ryo3._tokio import remove_file_async as remove_file_async
from ry.ryo3._tokio import rename_async as rename_async
from ry.ryo3._tokio import sleep_async as sleep_async
from ry.ryo3._tokio import write_async as write_async
from ry.ryo3._tokio import write_string_async as write_string_async
from ry.ryo3._tokio_websockets import WebSocket as WebSocket
from ry.ryo3._tokio_websockets import WsMessage as WsMessage
from ry.ryo3._tokio_websockets import websocket as websocket
from ry.ryo3._twox_hash import xxh3_64 as xxh3_64
from ry.ryo3._twox_hash import xxh3_128 as xxh3_128
from ry.ryo3._twox_hash import xxh32 as xxh32
from ry.ryo3._twox_hash import xxh64 as xxh64
from ry.ryo3._ulid import ULID as ULID
from ry.ryo3._unindent import unindent as unindent
from ry.ryo3._unindent import unindent_bytes as unindent_bytes
from ry.ryo3._url import URL as URL
from ry.ryo3._uuid import UUID as UUID
from ry.ryo3._uuid import uuid1 as uuid1
from ry.ryo3._uuid import uuid3 as uuid3
from ry.ryo3._uuid import uuid4 as uuid4
from ry.ryo3._uuid import uuid5 as uuid5
from ry.ryo3._uuid import uuid6 as uuid6
from ry.ryo3._uuid import uuid7 as uuid7
from ry.ryo3._uuid import uuid8 as uuid8
from ry.ryo3._walkdir import WalkDirEntry as WalkDirEntry
from ry.ryo3._walkdir import WalkDirIter as WalkDirIter
from ry.ryo3._walkdir import walkdir as walkdir
from ry.ryo3._which import which as which
from ry.ryo3._which import which_all as which_all
from ry.ryo3._which import which_re as which_re
from ry.ryo3._zstd import ZSTD_VERSION as ZSTD_VERSION
from ry.ryo3._zstd import ZSTD_VERSION_INFO as ZSTD_VERSION_INFO
from ry.ryo3._zstd import is_zstd as is_zstd
from ry.ryo3._zstd import zstd_compress as zstd_compress
from ry.ryo3._zstd import zstd_decompress as zstd_decompress
```

<h2 id="ry.ryo3.__about__"><code>ry.ryo3.__about__</code></h2>

```python
import typing as t


class _BuildInfo(t.TypedDict):
    host: str
    rustc: str
    llvm: str
    linker: str
    rustflags: str | None
    cc: str


__version__: str
__authors__: str
__build_profile__: str
__build_timestamp__: str
__pkg_name__: str
__description__: str
__target__: str
__opt_level__: t.Literal[0, 1, 2, 3, "s", "z"]
__allocator__: t.Literal["mimalloc", "system"]
__crypto_provider__: t.Literal["ring", "aws-lc-rs"]
__git_repo__: str
__git_sha__: str


def _build_info() -> _BuildInfo: ...
```

<h2 id="ry.ryo3._aws_lc"><code>ry.ryo3._aws_lc</code></h2>

```python
"""ryo3-aws-lc ~ types"""

import typing as t

from ry._types import Buffer


def awslc_version() -> str:
    """Return aws-lc-sys version"""


_Sha1Name: t.TypeAlias = t.Literal["sha1"]
_Sha1BlockSize: t.TypeAlias = t.Literal[64]
_Sha1DigestSize: t.TypeAlias = t.Literal[20]

_Sha224Name: t.TypeAlias = t.Literal["sha224"]
_Sha224BlockSize: t.TypeAlias = t.Literal[64]
_Sha224DigestSize: t.TypeAlias = t.Literal[28]

_Sha256Name: t.TypeAlias = t.Literal["sha256"]
_Sha256BlockSize: t.TypeAlias = t.Literal[64]
_Sha256DigestSize: t.TypeAlias = t.Literal[32]

_Sha384Name: t.TypeAlias = t.Literal["sha384"]
_Sha384BlockSize: t.TypeAlias = t.Literal[128]
_Sha384DigestSize: t.TypeAlias = t.Literal[48]

_Sha3_256Name: t.TypeAlias = t.Literal["sha3_256"]
_Sha3_256BlockSize: t.TypeAlias = t.Literal[136]
_Sha3_256DigestSize: t.TypeAlias = t.Literal[32]

_Sha3_384Name: t.TypeAlias = t.Literal["sha3_384"]
_Sha3_384BlockSize: t.TypeAlias = t.Literal[104]
_Sha3_384DigestSize: t.TypeAlias = t.Literal[48]

_Sha3_512Name: t.TypeAlias = t.Literal["sha3_512"]
_Sha3_512BlockSize: t.TypeAlias = t.Literal[72]
_Sha3_512DigestSize: t.TypeAlias = t.Literal[64]

_Sha512Name: t.TypeAlias = t.Literal["sha512"]
_Sha512BlockSize: t.TypeAlias = t.Literal[128]
_Sha512DigestSize: t.TypeAlias = t.Literal[64]

_Sha512_256Name: t.TypeAlias = t.Literal["sha512_256"]
_Sha512_256BlockSize: t.TypeAlias = t.Literal[128]
_Sha512_256DigestSize: t.TypeAlias = t.Literal[32]

_TName = t.TypeVar("_TName", bound=str)
_TBlockSize = t.TypeVar("_TBlockSize", bound=int)
_TDigestSize = t.TypeVar("_TDigestSize", bound=int)


@t.type_check_only
class _Sha(t.Generic[_TName, _TBlockSize, _TDigestSize]):
    name: _TName
    digest_size: _TDigestSize
    block_size: _TBlockSize

    def copy(self) -> t.Self: ...
    def digest(self) -> bytes: ...
    def hexdigest(self) -> str: ...
    def update(self, obj: Buffer, /) -> None: ...
    @staticmethod
    def oneshot(data: Buffer) -> bytes: ...
    @staticmethod
    def oneshot_hex(data: Buffer) -> str: ...


sha1: type[_Sha[_Sha1Name, _Sha1BlockSize, _Sha1DigestSize]]
sha224: type[_Sha[_Sha224Name, _Sha224BlockSize, _Sha224DigestSize]]
sha256: type[_Sha[_Sha256Name, _Sha256BlockSize, _Sha256DigestSize]]
sha384: type[_Sha[_Sha384Name, _Sha384BlockSize, _Sha384DigestSize]]
sha3_256: type[_Sha[_Sha3_256Name, _Sha3_256BlockSize, _Sha3_256DigestSize]]
sha3_384: type[_Sha[_Sha3_384Name, _Sha3_384BlockSize, _Sha3_384DigestSize]]
sha3_512: type[_Sha[_Sha3_512Name, _Sha3_512BlockSize, _Sha3_512DigestSize]]
sha512: type[_Sha[_Sha512Name, _Sha512BlockSize, _Sha512DigestSize]]
sha512_256: type[_Sha[_Sha512_256Name, _Sha512_256BlockSize, _Sha512_256DigestSize]]
```

<h2 id="ry.ryo3._brotli"><code>ry.ryo3._brotli</code></h2>

```python
"""ryo3-brotli ~ types"""

from ry._types import Buffer
from ry.ryo3._bytes import Bytes


def brotli_decompress(data: Buffer, /) -> Bytes: ...
```

<h2 id="ry.ryo3._burli"><code>ry.ryo3._burli</code></h2>

```python
"""ryo3-burli ~ types"""

import typing as t

from ry._types import Buffer
from ry.ryo3._bytes import Bytes

_BrotliLevel: t.TypeAlias = t.Literal[0, 1, 2, 3, 4, 5]


def brotli_compress(data: Buffer, /, level: _BrotliLevel = 5) -> Bytes: ...
```

<h2 id="ry.ryo3._bytes"><code>ry.ryo3._bytes</code></h2>

```python
"""ryo3-bytes ~ types"""

import sys
import typing as t

if sys.version_info >= (3, 12):
    from collections.abc import Buffer as Buffer
else:
    from typing_extensions import Buffer as Buffer


@t.final
class Bytes(Buffer):
    """
    A buffer implementing the Python buffer protocol, allowing zero-copy access
    to underlying Rust memory.

    You can pass this to `memoryview` for a zero-copy view into the underlying
    data or to `bytes` to copy the underlying data into a Python `bytes`.

    Many methods from the Python `bytes` class are implemented on this,
    """

    def __new__(cls, buf: Buffer = b"") -> t.Self:
        """Construct a new Bytes object.

        This will be a zero-copy view on the Python byte slice.
        """

    @staticmethod
    def copy_from(buf: Buffer) -> Bytes:
        """Construct a new Bytes object by copying the given buffer.

        Examples
        --------
        >>> from ry import Bytes
        >>> b = Bytes.copy_from(b"hello")
        >>> b
        Bytes(b"hello")

        """

    def clone(self) -> Bytes:
        """Return a new `Bytes` object that shares the same underlying buffer.

        Examples
        --------
        >>> from ry import Bytes
        >>> b = Bytes.copy_from(b"hello")
        >>> b.is_unique()
        True
        >>> c = b.clone()
        >>> b.is_unique()
        False
        >>> c.is_unique()
        False

        """

    def __add__(self, other: Buffer, /) -> Bytes: ...
    def __radd__(self, other: Bytes, /) -> Bytes: ...
    def __buffer__(self, flags: int, /) -> memoryview: ...
    def __contains__(self, other: Buffer, /) -> bool: ...
    def __hash__(self) -> int: ...
    def __eq__(self, other: object, /) -> bool: ...
    @t.overload
    def __getitem__(self, other: int, /) -> int: ...
    @t.overload
    def __getitem__(self, other: slice, /) -> Bytes: ...
    def __mul__(self, other: int, /) -> Bytes: ...
    def __rmul__(self, other: int, /) -> Bytes: ...
    def __len__(self) -> int: ...
    def __bytes__(self) -> bytes:
        """Return the underlying data as a Python `bytes` object."""

    def __iter__(self) -> _BytesIter: ...
    def removeprefix(self, prefix: Buffer, /) -> Bytes:
        """
        If the binary data starts with the prefix string, return `bytes[len(prefix):]`.
        Otherwise, return the original binary data.
        """

    def removesuffix(self, suffix: Buffer, /) -> Bytes:
        """
        If the binary data ends with the suffix string and that suffix is not empty,
        return `bytes[:-len(suffix)]`. Otherwise, return the original binary data.
        """

    def isalnum(self) -> bool:
        """
        Return `True` if all bytes in the sequence are alphabetical ASCII characters or
        ASCII decimal digits and the sequence is not empty, `False` otherwise.

        Alphabetic ASCII characters are those byte values in the sequence
        `b'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'`. ASCII decimal digits
        are those byte values in the sequence `b'0123456789'`.
        """

    def isalpha(self) -> bool:
        """
        Return `True` if all bytes in the sequence are alphabetic ASCII characters and
        the sequence is not empty, `False` otherwise.

        Alphabetic ASCII characters are those byte values in the sequence
        `b'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'`.
        """

    def isascii(self) -> bool:
        """
        Return `True` if the sequence is empty or all bytes in the sequence are ASCII,
        `False` otherwise.

        ASCII bytes are in the range `0-0x7F`.
        """

    def isdigit(self) -> bool:
        """
        Return `True` if all bytes in the sequence are ASCII decimal digits and the
        sequence is not empty, `False` otherwise.

        ASCII decimal digits are those byte values in the sequence `b'0123456789'`.
        """

    def islower(self) -> bool:
        """
        Return `True` if there is at least one lowercase ASCII character in the sequence
        and no uppercase ASCII characters, `False` otherwise.
        """

    def isspace(self) -> bool:
        r"""
        Return `True` if all bytes in the sequence are ASCII whitespace and the sequence
        is not empty, `False` otherwise.

        ASCII whitespace characters are those byte values
        in the sequence `b' \t\n\r\x0b\f'` (space, tab, newline, carriage return,
        vertical tab, form feed).
        """

    def isupper(self) -> bool:
        """
        Return `True` if there is at least one uppercase alphabetic ASCII character in
        the sequence and no lowercase ASCII characters, `False` otherwise.
        """

    def lower(self) -> Bytes:
        """
        Return a copy of the sequence with all the uppercase ASCII characters converted
        to their corresponding lowercase counterpart.
        """

    def upper(self) -> Bytes:
        """
        Return a copy of the sequence with all the lowercase ASCII characters converted
        to their corresponding uppercase counterpart.
        """

    def to_bytes(self) -> bytes:
        """Copy this buffer's contents into a Python `bytes` object."""

    # =========================================================================
    # IMPL IN RY
    # =========================================================================

    def istitle(self) -> bool:
        """
        Return `True` if the sequence is non-empty and contains only ASCII letters,
        digits, underscores, and hyphens, and starts with an ASCII letter or underscore.
        Otherwise, return `False`.
        """

    def decode(self, encoding: str = "utf-8", errors: str = "strict") -> str:
        """Decode the binary data using the given encoding."""

    def hex(self, sep: str | None = None, *, bytes_per_sep: int = 1) -> str:
        """Return a hexadecimal representation of the binary data."""

    @classmethod
    def fromhex(cls, string: str) -> Bytes:
        """Construct a `Bytes` object from a hexadecimal string."""

    def startswith(self, prefix: Buffer, /) -> bool:
        """Return `True` if the binary data starts with the prefix string, `False` otherwise."""

    def endswith(self, suffix: Buffer, /) -> bool:
        """Return `True` if the binary data ends with the suffix string, `False` otherwise."""

    def capitalize(self) -> Bytes:
        """
        Return a copy of the sequence with the first byte converted to uppercase and
        all other bytes converted to lowercase.
        """

    def strip(self, chars: Buffer | None = None, /) -> Bytes:
        """
        Return a copy of the sequence with leading and trailing bytes removed.
        If `chars` is provided, remove all bytes in `chars` from both ends.
        If `chars` is not provided, remove all ASCII whitespace bytes.
        """

    def lstrip(self, chars: Buffer | None = None, /) -> Bytes:
        """
        Return a copy of the sequence with leading bytes removed.
        If `chars` is provided, remove all bytes in `chars` from the left end.
        If `chars` is not provided, remove all ASCII whitespace bytes.
        """

    def rstrip(self, chars: Buffer | None = None, /) -> Bytes:
        """
        Return a copy of the sequence with trailing bytes removed.
        If `chars` is provided, remove all bytes in `chars` from the right end.
        If `chars` is not provided, remove all ASCII whitespace bytes.
        """

    def expandtabs(self, tabsize: int = 8) -> Bytes:
        """
        Return a copy of the sequence with all ASCII tab characters replaced by spaces.
        The number of spaces is determined by the `tabsize` parameter.
        """

    def title(self) -> Bytes:
        """
        Return a copy of the sequence with the first byte of each word converted to
        uppercase and all other bytes converted to lowercase.
        """

    def swapcase(self) -> Bytes:
        """
        Return a copy of the sequence with all uppercase ASCII characters converted to
        their corresponding lowercase counterpart and vice versa.
        """

    def replace(self, old: Buffer, new: Buffer, count: int = -1, /) -> Bytes:
        """
        Return a copy of the sequence with all occurrences of `old` replaced by `new`.
        If `count` is given and not negative, only the first `count` occurrences are
        replaced.
        """

    def find(
        self,
        sub: Buffer | int,
        start: int | None = None,
        end: int | None = None,
        /,
    ) -> int:
        """Return the lowest index where `sub` is found, or `-1`."""

    def rfind(
        self,
        sub: Buffer | int,
        start: int | None = None,
        end: int | None = None,
        /,
    ) -> int:
        """Return the highest index where `sub` is found, or `-1`."""

    def index(
        self,
        sub: Buffer | int,
        start: int | None = None,
        end: int | None = None,
        /,
    ) -> int:
        """Return the lowest index where `sub` is found or raise `ValueError`."""

    def rindex(
        self,
        sub: Buffer | int,
        start: int | None = None,
        end: int | None = None,
        /,
    ) -> int:
        """Return the highest index where `sub` is found or raise `ValueError`."""

    def split(self, sep: Buffer | None = None, maxsplit: int = -1, /) -> list[Bytes]:
        """Return a list of the words in the bytes, using `sep` as the delimiter."""

    def rsplit(self, sep: Buffer | None = None, maxsplit: int = -1, /) -> list[Bytes]:
        """Return a list of the words in the bytes, using `sep` as the delimiter."""

    def partition(self, sep: Buffer, /) -> tuple[Bytes, Bytes, Bytes]:
        """Partition the bytes into three parts using the given separator.

        This will search for the separator sep in the bytes. If the separator is found,
        returns a 3-tuple containing the part before the separator, the separator
        itself, and the part after it.

        If the separator is not found, returns a 3-tuple containing the original bytes
        object and two empty bytes objects.
        """

    def rpartition(self, sep: Buffer, /) -> tuple[Bytes, Bytes, Bytes]:
        """Partition the bytes into three parts using the given separator.

        This will search for the separator sep in the bytes, starting at the end. If
        the separator is found, returns a 3-tuple containing the part before the
        separator, the separator itself, and the part after it.

        If the separator is not found, returns a 3-tuple containing two empty bytes
        objects and the original bytes object.
        """

    def is_unique(self) -> bool:
        """Return `True` if this is the only reference to the underlying buffer.

        Notes
        -----
        This will usually return `False` for `Bytes` objects created from Python
        buffer objects, since they use `::bytes::Bytes::from_owner`.

        Examples
        --------
        >>> from ry import Bytes
        >>> b = Bytes.copy_from(b"unique-nu-yawk")
        >>> b.is_unique()
        True
        >>> shared = b.clone()
        >>> b.is_unique()
        False

        """

    def is_empty(self) -> bool:
        """Return `True` if the sequence is empty, `False` otherwise.

        Examples
        --------
        >>> from ry import Bytes
        >>> b = Bytes(b"")
        >>> b.is_empty()
        True
        >>> b = Bytes(b"abc")
        >>> b.is_empty()
        False

        """

    def windows(self, size: int, /, *, reverse: bool = False) -> _BytesSliceIter:
        """Returns an iterator over all contiguous windows of length size.

        The windows overlap. If the slice is shorter than size, the iterator returns no values.

        Parameters
        ----------
        size : int
            The size of the windows to return.

        Examples
        --------
        >>> from ry import Bytes
        >>> b = Bytes(b"abcdefg")
        >>> list(b.windows(3))
        [Bytes(b"abc"), Bytes(b"bcd"), Bytes(b"cde"), Bytes(b"def"), Bytes(b"efg")]
        >>> list(b.windows(3, reverse=True))
        [Bytes(b"efg"), Bytes(b"def"), Bytes(b"cde"), Bytes(b"bcd"), Bytes(b"abc")]

        """

    def py_hashbuffer(self) -> int:
        """Return the hash via `pyo3::ffi::compat::Py_HashBuffer`"""


class _BytesIter(t.Protocol):
    def __iter__(self) -> t.Self: ...
    def __next__(self) -> int: ...
    def __len__(self) -> int: ...


class _BytesSliceIter(t.Protocol):
    def __iter__(self) -> t.Self: ...
    def __next__(self) -> Bytes: ...
    def next(self) -> Bytes | None: ...
    def collect(self) -> list[Bytes]: ...
    def take(self, n: int = 1, /) -> list[Bytes]: ...
    def count(self) -> int: ...
    def size_hint(self) -> tuple[int, int | None]: ...
    def last(self) -> Bytes | None: ...
    def nth(self, n: int, /) -> Bytes | None: ...
    @property
    def kind(self) -> t.Literal["windows", "windows-reverse"]: ...
    def __len__(self) -> int: ...


ReadableBuffer: t.TypeAlias = Buffer | bytes | bytearray | memoryview | Bytes
```

<h2 id="ry.ryo3._cookie"><code>ry.ryo3._cookie</code></h2>

```python
"""ryo3-cookie ~ types"""

import typing as t

from ry.protocols import FromStr, _Parse
from ry.ryo3._std import Duration

_SameSiteKw: t.TypeAlias = t.Literal["Lax", "lax", "Strict", "strict", "None", "none"]
"""same-site kwarg allows title-case and lower-case values"""


@t.final
class Cookie(FromStr, _Parse):
    def __new__(
        cls,
        name: str,
        value: str,
        *,
        domain: str | None = None,
        expires: int | None = None,
        http_only: bool | None = None,
        max_age: Duration | None = None,
        partitioned: bool | None = None,
        path: str | None = None,
        permanent: bool = False,
        removal: bool = False,
        same_site: _SameSiteKw | None = None,
        secure: bool | None = None,
    ) -> t.Self:
        """Create a new cookie with the given name and value, and optional attributes

        Parameters
        ----------
        name : str
            name of the cookie
        value : str
            value of the cookie
        domain : str | None, optional
            domain of the cookie, by default None
        expires : int | None, optional
            expiration time of the cookie as a UNIX timestamp, by default None
        http_only : bool | None, optional
            whether the cookie is HTTP-only, by default None
        max_age : Duration | None, optional
            maximum age of the cookie as a Duration, by default None
        partitioned : bool | None, optional
            whether the cookie is partitioned, by default None
        path : str | None, optional
            path of the cookie, by default None
        permanent : bool, optional
            whether the cookie is permanent, by default False
        removal : bool, optional
            whether the cookie is marked for removal, by default False
        same_site : _SameSiteKw | None, optional
            same-site attribute of the cookie, by default None
        secure : bool | None, optional
            whether the cookie is secure, by default None

        Examples
        --------
        >>> from ry import Cookie
        >>> c = Cookie("id", "cookie-monster")
        >>> c
        Cookie("id", "cookie-monster")
        >>> str(c)
        'id=cookie-monster'

        """

    @classmethod
    def from_str(cls, s: str, /) -> t.Self: ...
    @classmethod
    def parse(cls, value: str | bytes, /) -> t.Self: ...
    @staticmethod
    def parse_encoded(s: str, /) -> Cookie: ...

    # -------------------------------------------------------------------------
    # METHODS
    # -------------------------------------------------------------------------
    # -- STRING --
    def to_string(self) -> str: ...
    def encoded(self) -> str: ...
    def stripped(self) -> str: ...
    def encoded_stripped(self) -> str: ...
    def stripped_encoded(self) -> str: ...

    # -------------------------------------------------------------------------
    # PROPERTIES
    # -------------------------------------------------------------------------
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> str: ...
    @property
    def value_trimmed(self) -> str: ...
    @property
    def name_value(self) -> tuple[str, str]: ...
    @property
    def name_value_trimmed(self) -> tuple[str, str]: ...
    @property
    def domain(self) -> str | None: ...
    @property
    def expires(self) -> int | None: ...
    @property
    def http_only(self) -> bool | None: ...
    @property
    def max_age(self) -> Duration | None: ...
    @property
    def partitioned(self) -> bool | None: ...
    @property
    def path(self) -> str | None: ...
    @property
    def same_site(self) -> t.Literal["Lax", "Strict", "None"] | None: ...
    @property
    def secure(self) -> bool | None: ...
```

<h2 id="ry.ryo3._crc32fast"><code>ry.ryo3._crc32fast</code></h2>

```python
"""ryo3-fnv ~ types"""

import typing as t

from ry._types import Buffer


@t.final
class crc32:  # noqa: N801
    name: t.Literal["crc32"]
    digest_size: t.Literal[4]
    block_size: t.Literal[1]
    default_seed: t.Literal[0]

    def __new__(
        cls, data: Buffer | None = None, *, seed: int | bytes = 0
    ) -> t.Self: ...
    def update(self, data: Buffer) -> None: ...
    def digest(self) -> bytes: ...
    def intdigest(self) -> int: ...
    def hexdigest(self) -> str: ...
    def copy(self) -> t.Self: ...
    @staticmethod
    def oneshot(data: Buffer, *, seed: int | bytes = 0) -> bytes: ...
    @staticmethod
    def oneshot_int(data: Buffer, *, seed: int | bytes = 0) -> int: ...
    @staticmethod
    def oneshot_hex(data: Buffer, *, seed: int | bytes = 0) -> str: ...

    # FUTURE/DEV/TBD
    def _combine(self, other: t.Self) -> t.Self:
        """Return new crc32 hash state after combining with other

        Used for combining the current hash state with the hash state for the subsequent block of bytes.

        Parameters
        ----------
        other : t.Self
            other crc32 hash state

        Returns
        -------
        t.Self

        """
```

<h2 id="ry.ryo3._dev"><code>ry.ryo3._dev</code></h2>

```python
"""ry.ryo3.dev"""

import typing as t


def devfn() -> t.Literal["_ryo3-dev"]: ...
```

<h2 id="ry.ryo3._dirs"><code>ry.ryo3._dirs</code></h2>

```python
"""ryo3-dirs ~ types"""


def audio_dir() -> str | None:
    """Return audio directory or None.

    - lin: `Some(XDG_MUSIC_DIR)` or `None`
    - win: `Some({FOLDERID_Music})`
    - mac: `Some($HOME/Music/)`
    """


def cache_dir() -> str | None:
    """Return cache directory or None.

    - lin: `Some($XDG_CACHE_HOME)` or `Some($HOME/.cache)`
    - win: `Some({FOLDERID_LocalAppData})`
    - mac: `Some($HOME/Library/Caches)`
    """


def config_dir() -> str | None:
    """Return config directory or None.

    - lin: `Some($XDG_CONFIG_HOME)` or `Some($HOME/.config)`
    - win: `Some({FOLDERID_RoamingAppData})`
    - mac: `Some($HOME/Library/Application Support)`
    """


def config_local_dir() -> str | None:
    """Return local config directory or None.

    - lin: `Some($XDG_CONFIG_HOME)` or `Some($HOME/.config)`
    - win: `Some({FOLDERID_LocalAppData})`
    - mac: `Some($HOME/Library/Application Support)`
    """


def data_dir() -> str | None:
    """Return data directory or None.

    - lin: `Some($XDG_DATA_HOME)` or `Some($HOME/.local/share)`
    - win: `Some({FOLDERID_RoamingAppData})`
    - mac: `Some($HOME/Library/Application Support)`
    """


def data_local_dir() -> str | None:
    """Return local data directory or None.

    - lin: `Some($XDG_DATA_HOME)` or `Some($HOME/.local/share)`
    - win: `Some({FOLDERID_LocalAppData})`
    - mac: `Some($HOME/Library/Application Support)`
    """


def desktop_dir() -> str | None:
    """Return desktop directory or None.

    - lin: `Some(XDG_DESKTOP_DIR)` or `None`
    - win: `Some({FOLDERID_Desktop})`
    - mac: `Some($HOME/Desktop/)`
    """


def document_dir() -> str | None:
    """Return document directory or None.

    - lin: `Some(XDG_DOCUMENTS_DIR)` or `None`
    - win: `Some({FOLDERID_Documents})`
    - mac: `Some($HOME/Documents/)`
    """


def download_dir() -> str | None:
    """Return download directory or None.

    - lin: `Some(XDG_DOWNLOAD_DIR)` or `None`
    - win: `Some({FOLDERID_Downloads})`
    - mac: `Some($HOME/Downloads/)`
    """


def executable_dir() -> str | None:
    """Return executable directory or None.

    - lin: `Some($XDG_BIN_HOME)` or `Some($HOME/.local/bin)`
    - win: `None`
    - mac: `None`
    """


def font_dir() -> str | None:
    """Return font directory or None.

    - lin: `Some($XDG_DATA_HOME/fonts/)` or `Some($HOME/.local/share/fonts/)`
    - win: `None`
    - mac: `Some($HOME/Library/Fonts/)`
    """


def home_dir() -> str | None:
    """Return home directory or None.

    - lin: `Some($HOME)`
    - win: `Some({FOLDERID_Profile})`
    - mac: `Some($HOME)`
    """


def picture_dir() -> str | None:
    """Return picture directory or None.

    - lin: `Some(XDG_PICTURES_DIR)` or `None`
    - win: `Some({FOLDERID_Pictures})`
    - mac: `Some($HOME/Pictures/)`
    """


def preference_dir() -> str | None:
    """Return preference directory or None.

    - lin: `Some($XDG_CONFIG_HOME)` or `Some($HOME/.config)`
    - win: `Some({FOLDERID_RoamingAppData})`
    - mac: `Some($HOME/Library/Preferences)`
    """


def public_dir() -> str | None:
    """Return public directory or None.

    - lin: `Some(XDG_PUBLICSHARE_DIR)` or `None`
    - win: `Some({FOLDERID_Public})`
    - mac: `Some($HOME/Public/)`
    """


def runtime_dir() -> str | None:
    """Return runtime directory or None.

    - lin: `Some($XDG_RUNTIME_DIR)` or `None`
    - win: `None`
    - mac: `None`
    """


def state_dir() -> str | None:
    """Return state directory or None.

    - lin: `Some($XDG_STATE_HOME)` or `Some($HOME/.local/state)`
    - win: `None`
    - mac: `None`
    """


def template_dir() -> str | None:
    """Return template directory or None.

    - lin: `Some(XDG_TEMPLATES_DIR)` or `None`
    - win: `Some({FOLDERID_Templates})`
    - mac: `None`
    """


def video_dir() -> str | None:
    """Return video directory or None.

    - lin: `Some(XDG_VIDEOS_DIR)` or `None`
    - win: `Some({FOLDERID_Videos})`
    - mac: `Some($HOME/Movies/)`
    """
```

<h2 id="ry.ryo3._encoding_rs"><code>ry.ryo3._encoding_rs</code></h2>

```python
"""encoding_rs ~ types"""

import typing as t

Encoding: t.TypeAlias = t.Literal[
    # UTF-8
    "utf8",
    "utf-8",
    "unicode20utf8",
    "unicode11utf8",
    "x-unicode20utf8",
    "unicode-1-1-utf-8",
    # UTF-16LE
    "ucs-2",
    "utf-16",
    "unicode",
    "utf-16le",
    "csunicode",
    "unicodefeff",
    "iso-10646-ucs-2",
    # UTF-16BE
    "utf-16be",
    "unicodefffe",
    # Big5
    "big5",
    "csbig5",
    "cn-big5",
    "x-x-big5",
    "big5-hkscs",
    # EUC-JP
    "euc-jp",
    "x-euc-jp",
    "cseucpkdfmtjapanese",
    # EUC-KR
    "korean",
    "euc-kr",
    "ksc5601",
    "cseuckr",
    "ksc_5601",
    "iso-ir-149",
    "windows-949",
    "csksc56011987",
    "ks_c_5601-1987",
    "ks_c_5601-1989",
    # GBK
    "gbk",
    "x-gbk",
    "gb2312",
    "gb_2312",
    "chinese",
    "csgb2312",
    "iso-ir-58",
    "gb_2312-80",
    "csiso58gb231280",
    # IBM866
    "866",
    "cp866",
    "ibm866",
    "csibm866",
    # ISO-2022-JP
    "iso-2022-jp",
    "csiso2022jp",
    # ISO-8859-10
    "l6",
    "latin6",
    "iso885910",
    "iso8859-10",
    "iso-ir-157",
    "iso-8859-10",
    "csisolatin6",
    # ISO-8859-13
    "iso885913",
    "iso8859-13",
    "iso-8859-13",
    # ISO-8859-14
    "iso885914",
    "iso8859-14",
    "iso-8859-14",
    # ISO-8859-15
    "l9",
    "iso885915",
    "iso8859-15",
    "iso-8859-15",
    "iso_8859-15",
    "csisolatin9",
    # ISO-8859-16
    "iso-8859-16",
    # ISO-8859-2
    "l2",
    "latin2",
    "iso88592",
    "iso8859-2",
    "iso-ir-101",
    "iso-8859-2",
    "iso_8859-2",
    "csisolatin2",
    "iso_8859-2:1987",
    # ISO-8859-3
    "l3",
    "latin3",
    "iso88593",
    "iso8859-3",
    "iso-8859-3",
    "iso_8859-3",
    "iso-ir-109",
    "csisolatin3",
    "iso_8859-3:1988",
    # ISO-8859-4
    "l4",
    "latin4",
    "iso88594",
    "iso8859-4",
    "iso-ir-110",
    "iso-8859-4",
    "iso_8859-4",
    "csisolatin4",
    "iso_8859-4:1988",
    # ISO-8859-5
    "iso88595",
    "cyrillic",
    "iso8859-5",
    "iso-ir-144",
    "iso-8859-5",
    "iso_8859-5",
    "iso_8859-5:1988",
    "csisolatincyrillic",
    # ISO-8859-6
    "arabic",
    "ecma-114",
    "iso88596",
    "asmo-708",
    "iso8859-6",
    "iso-8859-6",
    "iso_8859-6",
    "iso-ir-127",
    "csiso88596e",
    "csiso88596i",
    "iso-8859-6-e",
    "iso-8859-6-i",
    "iso_8859-6:1987",
    "csisolatinarabic",
    # ISO-8859-7
    "greek",
    "greek8",
    "iso88597",
    "ecma-118",
    "elot_928",
    "iso8859-7",
    "iso-ir-126",
    "iso-8859-7",
    "iso_8859-7",
    "sun_eu_greek",
    "iso_8859-7:1987",
    "csisolatingreek",
    # ISO-8859-8
    "visual",
    "hebrew",
    "iso88598",
    "iso8859-8",
    "iso-8859-8",
    "iso_8859-8",
    "iso-ir-138",
    "csiso88598e",
    "iso-8859-8-e",
    "iso_8859-8:1988",
    "csisolatinhebrew",
    # ISO-8859-8-I
    "logical",
    "csiso88598i",
    "iso-8859-8-i",
    # KOI8-R
    "koi",
    "koi8",
    "koi8-r",
    "koi8_r",
    "cskoi8r",
    # KOI8-U
    "koi8-u",
    "koi8-ru",
    # Shift_JIS
    "sjis",
    "ms932",
    "x-sjis",
    "ms_kanji",
    "shift-jis",
    "shift_jis",
    "csshiftjis",
    "windows-31j",
    # gb18030
    "gb18030",
    # macintosh
    "mac",
    "macintosh",
    "csmacintosh",
    "x-mac-roman",
    # replacement
    "hz-gb-2312",
    "iso-2022-cn",
    "iso-2022-kr",
    "csiso2022kr",
    "replacement",
    "iso-2022-cn-ext",
    # windows-1250
    "cp1250",
    "x-cp1250",
    "windows-1250",
    # windows-1251
    "cp1251",
    "x-cp1251",
    "windows-1251",
    # windows-1252
    "l1",
    "cp819",
    "ascii",
    "latin1",
    "cp1252",
    "ibm819",
    "iso88591",
    "x-cp1252",
    "us-ascii",
    "iso8859-1",
    "iso-ir-100",
    "iso-8859-1",
    "iso_8859-1",
    "csisolatin1",
    "windows-1252",
    "ansi_x3.4-1968",
    "iso_8859-1:1987",
    # windows-1253
    "cp1253",
    "x-cp1253",
    "windows-1253",
    # windows-1254
    "l5",
    "cp1254",
    "latin5",
    "x-cp1254",
    "iso88599",
    "iso8859-9",
    "iso-ir-148",
    "iso-8859-9",
    "iso_8859-9",
    "csisolatin5",
    "windows-1254",
    "iso_8859-9:1989",
    # windows-1255
    "cp1255",
    "x-cp1255",
    "windows-1255",
    # windows-1256
    "cp1256",
    "x-cp1256",
    "windows-1256",
    # windows-1257
    "cp1257",
    "x-cp1257",
    "windows-1257",
    # windows-1258
    "cp1258",
    "x-cp1258",
    "windows-1258",
    # windows-874
    "tis-620",
    "dos-874",
    "iso885911",
    "iso8859-11",
    "iso-8859-11",
    "windows-874",
    # x-mac-cyrillic
    "x-mac-cyrillic",
    "x-mac-ukrainian",
    # x-user-defined
    "x-user-defined",
]
```

<h2 id="ry.ryo3._errors"><code>ry.ryo3._errors</code></h2>

```python
"""ryo3-core ~ types"""

import typing as t


class PanicError(BaseException):
    """panic == fatal python error"""


class FeatureNotEnabledError(RuntimeError):
    """Raised when a feature is not enabled in the current build"""


class UnreachableError(AssertionError):
    """Raised when unreachable code is reached"""


def unreachable(msg: str | None = None) -> t.NoReturn:
    """raise `UnreachableError` with given message

    Parameters
    ----------
    msg : str | None, optional
        message to include in the error, by default None

    Returns
    -------
    t.NoReturn
        always raises UnreachableError

    Raises
    ------
    UnreachableError
        always

    Examples
    --------
    >>> from ry import unreachable
    >>> unreachable("This should never happen")
    Traceback (most recent call last):
        ...
    ry.ryo3.UnreachableError: This should never happen

    """


def panic(msg: str | None = None) -> t.NoReturn:
    """raise `PanicError` with given message

    Parameters
    ----------
    msg : str | None, optional
        message to include in the error, by default None

    Returns
    -------
    t.NoReturn
        always raises PanicError

    Raises
    ------
    PanicError
        always

    Examples
    --------
    >>> from ry import panic
    >>> panic("This is a fatal error")
    Traceback (most recent call last):
        ...
    ry.ryo3.PanicError: This is a fatal error

    """
```

<h2 id="ry.ryo3._flate2"><code>ry.ryo3._flate2</code></h2>

```python
"""ryo3-flate2 ~ types"""

import typing as t

from ry import Bytes
from ry._types import Buffer

_GzipLevel: t.TypeAlias = t.Literal[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, "best", "fast"]


def gzip_compress(data: Buffer, /, level: _GzipLevel = 6) -> Bytes: ...
def gzip_decompress(data: Buffer, /) -> Bytes: ...
def is_gzip(data: Buffer, /) -> bool: ...
```

<h2 id="ry.ryo3._fnv"><code>ry.ryo3._fnv</code></h2>

```python
"""ryo3-fnv ~ types"""

import typing as t

from ry._types import Buffer


@t.final
class fnv1a:  # noqa: N801
    name: t.Literal["fnv1a"]
    digest_size: t.Literal[8]
    block_size: t.Literal[1]
    default_seed: t.Literal[0xCBF29CE484222325]  # noqa: PYI054

    def __new__(
        cls,
        data: Buffer | None = None,
        *,
        seed: int | bytes = 0xCBF29CE484222325,  # noqa: PYI054
    ) -> t.Self: ...
    def update(self, data: Buffer) -> None: ...
    def digest(self) -> bytes: ...
    def intdigest(self) -> int: ...
    def hexdigest(self) -> str: ...
    def copy(self) -> t.Self: ...
    @staticmethod
    def oneshot(data: Buffer, *, seed: int | bytes = 0xCBF29CE484222325) -> bytes: ...  # noqa: PYI054
    @staticmethod
    def oneshot_int(data: Buffer, *, seed: int | bytes = 0xCBF29CE484222325) -> int: ...  # noqa: PYI054
    @staticmethod
    def oneshot_hex(data: Buffer, *, seed: int | bytes = 0xCBF29CE484222325) -> str: ...  # noqa: PYI054
```

<h2 id="ry.ryo3._fspath"><code>ry.ryo3._fspath</code></h2>

```python
"""ryo3-fspath ~ types"""

import typing as t
from os import PathLike
from pathlib import Path

from ry._types import Buffer
from ry.protocols import RyIterator, ToPy, ToString
from ry.ryo3._bytes import Bytes
from ry.ryo3._regex import Regex
from ry.ryo3._std import Metadata


@t.final
class FsPath(ToPy[Path], ToString):
    def __new__(cls, *args: PathLike[str] | str) -> t.Self: ...
    def __fspath__(self) -> str: ...
    def to_string(self) -> str: ...
    def to_py(self) -> Path: ...
    def to_pathlib(self) -> Path: ...
    # =========================================================================
    # IO
    # =========================================================================
    def read(self) -> Bytes: ...
    def read_bytes(self) -> bytes: ...
    def read_text(self) -> str: ...
    def write(self, data: Buffer | bytes) -> None: ...
    def write_bytes(self, data: Buffer | bytes) -> None: ...
    def write_text(self, data: str) -> None: ...
    def touch(self, mode: int | None = None, exist_ok: bool = True) -> bool:
        """Returns `True` if file was created `False` if already existed."""

    def open(
        self,
        mode: str,
        buffering: int = -1,
        encoding: str | None = None,
        errors: str | None = None,
        newline: str | None = None,
    ) -> t.IO[t.Any]: ...

    # =========================================================================
    # METHODS
    # =========================================================================
    def absolute(self) -> FsPath: ...
    def as_posix(self) -> str: ...
    def clone(self) -> FsPath: ...
    def equiv(self, other: PathLike[str] | str | FsPath) -> bool: ...
    def exists(self) -> bool: ...
    def iterdir(self) -> FsPathReaddir: ...
    def join(self, p: PathLike[str] | str | FsPath) -> FsPath: ...
    def joinpath(self, *args: PathLike[str] | str) -> FsPath: ...
    def metadata(self) -> Metadata: ...
    def mkdir(
        self, mode: int = 0o777, parents: bool = False, exist_ok: bool = False
    ) -> None: ...
    def read_dir(self) -> FsPathReaddir: ...
    def read_link(self) -> FsPath: ...
    def relative_to(self, other: PathLike[str] | str) -> FsPath: ...
    def rename(self, new_path: PathLike[str] | str) -> FsPath: ...
    def replace(self, new_path: PathLike[str] | str) -> FsPath: ...
    def resolve(self) -> FsPath: ...
    def rmdir(self, recursive: bool = False) -> None: ...
    def unlink(self, missing_ok: bool = False, recursive: bool = False) -> None: ...
    def with_name(self, name: str) -> t.Self: ...
    def with_suffix(self, suffix: str) -> t.Self: ...

    # =========================================================================
    # CLASSMETHODS
    # =========================================================================
    @classmethod
    def cwd(cls) -> t.Self: ...
    @classmethod
    def home(cls) -> t.Self: ...

    # =========================================================================
    # PROPERTIES
    # =========================================================================
    @property
    def anchor(self) -> str: ...
    @property
    def drive(self) -> str: ...
    @property
    def name(self) -> str: ...
    @property
    def parent(self) -> t.Self: ...
    @property
    def parents(self) -> t.Sequence[t.Self]: ...
    @property
    def parts(self) -> tuple[str, ...]: ...
    @property
    def root(self) -> t.Self | None: ...
    @property
    def stem(self) -> str: ...
    @property
    def suffix(self) -> str: ...
    @property
    def suffixes(self) -> list[str]: ...

    # =========================================================================
    # std::path::PathBuf (deref -> std::path::Path)
    # =========================================================================
    def ancestors(self) -> RyIterator[t.Self]: ...
    def canonicalize(self) -> t.Self: ...
    def components(self) -> t.Iterator[t.Self]: ...
    def display(self) -> str: ...
    def ends_with(self, child: PathLike[str] | str) -> bool: ...
    def extension(self) -> str: ...
    def file_name(self) -> str: ...
    def file_prefix(self) -> t.Self: ...
    def file_stem(self) -> str: ...
    def has_root(self) -> bool: ...
    def is_absolute(self) -> bool: ...
    def is_dir(self) -> bool: ...
    def is_file(self) -> bool: ...
    def is_relative(self) -> bool: ...
    def is_symlink(self) -> bool: ...
    def starts_with(self, base: PathLike[str] | str) -> bool: ...
    def strip_prefix(self, base: PathLike[str] | str) -> t.Self: ...
    def with_extension(self, extension: str) -> t.Self: ...
    def with_file_name(self, name: str) -> t.Self: ...

    # =========================================================================
    # FEATURE: `same-file`
    # =========================================================================
    def samefile(self, other: PathLike[str] | str | t.Self) -> bool: ...
    def symlink_metadata(self) -> Metadata: ...

    # =========================================================================
    # FEATURE: `which` & `which-regex`
    # =========================================================================
    @staticmethod
    def which(cmd: str, path: str | None = None) -> FsPath | None: ...
    @staticmethod
    def which_all(cmd: str, path: str | None = None) -> list[FsPath]: ...
    @staticmethod
    def which_re(regex: str | Regex, path: str | None = None) -> list[FsPath]: ...

    # =========================================================================
    # DUNDERS
    # =========================================================================
    def __truediv__(self, other: PathLike[str] | str, /) -> t.Self: ...
    def __rtruediv__(self, other: PathLike[str] | str, /) -> t.Self: ...
    def __lt__(self, other: PathLike[str] | str, /) -> bool: ...
    def __le__(self, other: PathLike[str] | str, /) -> bool: ...
    def __eq__(self, other: object, /) -> bool: ...
    def __ne__(self, other: object, /) -> bool: ...
    def __gt__(self, other: PathLike[str] | str, /) -> bool: ...
    def __ge__(self, other: PathLike[str] | str, /) -> bool: ...
    def __hash__(self) -> int: ...
    def __bytes__(self) -> bytes: ...


class FsPathReaddir(RyIterator[FsPath]):
    def __new__(cls) -> t.NoReturn: ...
    def __iter__(self) -> t.Self: ...
    def __next__(self) -> FsPath: ...
    def collect(self) -> list[FsPath]: ...
    def take(self, n: int = 1) -> list[FsPath]: ...
```

<h2 id="ry.ryo3._glob"><code>ry.ryo3._glob</code></h2>

```python
"""ryo3-glob ~ types"""

import typing as t
from os import PathLike
from pathlib import Path

from ry.protocols import RyIterator
from ry.ryo3._fspath import FsPath

_TGlobPath = t.TypeVar("_TGlobPath", bound=str | Path | FsPath)


@t.final
class GlobPaths(RyIterator[_TGlobPath]):
    """glob::Paths iterable wrapper"""

    def __next__(self) -> _TGlobPath: ...
    def __iter__(self) -> GlobPaths[_TGlobPath]: ...
    def collect(self) -> list[_TGlobPath]: ...
    def take(self, n: int = 1) -> list[_TGlobPath]: ...


@t.overload
def glob(
    pattern: str,
    *,
    case_sensitive: bool = True,
    require_literal_separator: bool = False,
    require_literal_leading_dot: bool = False,
    strict: bool = False,
    dtype: None = None,
) -> GlobPaths[Path]: ...
@t.overload
def glob(
    pattern: str,
    *,
    case_sensitive: bool = True,
    require_literal_separator: bool = False,
    require_literal_leading_dot: bool = False,
    strict: bool = False,
    dtype: type[_TGlobPath],
) -> GlobPaths[_TGlobPath]: ...


@t.final
class GlobPattern:
    """Glob pattern matching ~ `::glob::Pattern`

    [DOCS](https://docs.rs/glob/latest/glob/struct.Pattern.html)

    Prefer the `::globset` wrappers (`Glob` | `Globset` | `Globster`).
    """

    def __new__(
        cls,
        pattern: str,
        *,
        case_sensitive: bool = True,
        require_literal_separator: bool = False,
        require_literal_leading_dot: bool = False,
    ) -> t.Self: ...
    def __call__(
        self,
        ob: str | PathLike[str],
        *,
        case_sensitive: bool | None = None,
        require_literal_separator: bool | None = None,
        require_literal_leading_dot: bool | None = None,
    ) -> bool: ...
    def matches(self, s: str) -> bool: ...
    def matches_path(self, path: PathLike[str]) -> bool: ...
    def matches_with(
        self,
        s: str,
        *,
        case_sensitive: bool | None = None,
        require_literal_separator: bool | None = None,
        require_literal_leading_dot: bool | None = None,
    ) -> bool: ...
    def matches_path_with(
        self,
        path: PathLike[str],
        *,
        case_sensitive: bool | None = None,
        require_literal_separator: bool | None = None,
        require_literal_leading_dot: bool | None = None,
    ) -> bool: ...
    @staticmethod
    def escape(pattern: str) -> str: ...
    @property
    def pattern(self) -> str: ...
    def __hash__(self) -> int: ...
```

<h2 id="ry.ryo3._globset"><code>ry.ryo3._globset</code></h2>

```python
"""ryo3-globset ~ types"""

import typing as t
from os import PathLike


@t.final
class Glob:
    """globset::Glob wrapper"""

    def __new__(
        cls,
        pattern: str,
        /,
        *,
        case_insensitive: bool = False,
        literal_separator: bool = False,
        backslash_escape: bool = ...,  # True on windows, False otherwise
    ) -> t.Self: ...
    @property
    def regex(self) -> str: ...
    def is_match(self, path: str | PathLike[str]) -> bool: ...
    def is_match_str(self, path: str) -> bool: ...
    def __call__(self, path: str | PathLike[str]) -> bool: ...
    def __eq__(self, other: object, /) -> bool: ...
    def __ne__(self, other: object, /) -> bool: ...
    def globset(self) -> GlobSet: ...
    def globster(self) -> Globster: ...


@t.final
class GlobSet:
    """globset::GlobSet wrapper"""

    def __new__(
        cls,
        *patterns: str | Glob | t.Sequence[str | Glob],
        case_insensitive: bool = False,
        literal_separator: bool = False,
        backslash_escape: bool = ...,  # True on windows, False otherwise
    ) -> t.Self: ...
    def is_empty(self) -> bool: ...
    def is_match(self, path: str) -> bool: ...
    def is_match_str(self, path: str) -> bool: ...
    def matches(self, path: str) -> list[int]: ...
    def __call__(self, path: str) -> bool: ...
    def globster(self) -> Globster: ...
    @property
    def patterns(self) -> tuple[str, ...]: ...


@t.final
class Globster:
    """Globster is a matcher with claws!

    Note: The north american `Globster` is similar to the european `Globset`
          but allows for negative patterns (prefixed with '!')

    """

    def __new__(
        cls,
        *patterns: str | Glob | GlobSet | Globster | t.Sequence[str],
        case_insensitive: bool = False,
        literal_separator: bool = False,
        backslash_escape: bool = ...,  # True on windows, False otherwise
    ) -> t.Self: ...
    def is_empty(self) -> bool: ...
    def is_match(self, path: str | PathLike[str]) -> bool: ...
    def is_match_str(self, path: str) -> bool: ...
    def __call__(self, path: str | PathLike[str]) -> bool: ...
    @property
    def patterns(self) -> tuple[str, ...]: ...


def globster(
    *patterns: str | Glob | GlobSet | Globster | t.Sequence[str],
    case_insensitive: bool = False,
    literal_separator: bool = False,
    backslash_escape: bool = ...,  # True on windows, False otherwise
) -> Globster: ...
```

<h2 id="ry.ryo3._heck"><code>ry.ryo3._heck</code></h2>

```python
"""ryo3-heck ~ types"""


def camel_case(string: str) -> str: ...
def kebab_case(string: str) -> str: ...
def pascal_case(string: str) -> str: ...
def shouty_kebab_case(string: str) -> str: ...
def shouty_snake_case(string: str) -> str: ...
def snake_case(string: str) -> str: ...
def snek_case(string: str) -> str: ...
def title_case(string: str) -> str: ...
def train_case(string: str) -> str: ...
```

<h2 id="ry.ryo3._http"><code>ry.ryo3._http</code></h2>

```python
"""ryo3-http ~ types"""

import typing as t
from collections.abc import Mapping

# fmt: off
HttpMethodLike: t.TypeAlias = t.Literal[
    "GET",     "get",
    "POST",    "post",
    "PUT",     "put",
    "DELETE",  "delete",
    "HEAD",    "head",
    "OPTIONS", "options",
    "CONNECT", "connect",
    "PATCH",   "patch",
    "TRACE",   "trace",
    "QUERY",   "query",
]
HttpVersionLike: t.TypeAlias = t.Literal[
    "HTTP/0.9", "0.9", 0,
    "HTTP/1.0", "1.0", 1, 10,
    "HTTP/1.1", "1.1", 11,
    "HTTP/2.0", "2.0", 2, 20,
    "HTTP/3.0", "3.0", 3, 30,
]
# fmt: on

_TStandardHttpHeader: t.TypeAlias = t.Literal[
    "accept",
    "accept-charset",
    "accept-encoding",
    "accept-language",
    "accept-ranges",
    "access-control-allow-credentials",
    "access-control-allow-headers",
    "access-control-allow-methods",
    "access-control-allow-origin",
    "access-control-expose-headers",
    "access-control-max-age",
    "access-control-request-headers",
    "access-control-request-method",
    "age",
    "allow",
    "alt-svc",
    "authorization",
    "cache-control",
    "cache-status",
    "cdn-cache-control",
    "connection",
    "content-disposition",
    "content-encoding",
    "content-language",
    "content-length",
    "content-location",
    "content-range",
    "content-security-policy",
    "content-security-policy-report-only",
    "content-type",
    "cookie",
    "dnt",
    "date",
    "etag",
    "expect",
    "expires",
    "forwarded",
    "from",
    "host",
    "if-match",
    "if-modified-since",
    "if-none-match",
    "if-range",
    "if-unmodified-since",
    "last-modified",
    "link",
    "location",
    "max-forwards",
    "origin",
    "pragma",
    "proxy-authenticate",
    "proxy-authorization",
    "public-key-pins",
    "public-key-pins-report-only",
    "range",
    "referer",
    "referrer-policy",
    "refresh",
    "retry-after",
    "sec-websocket-accept",
    "sec-websocket-extensions",
    "sec-websocket-key",
    "sec-websocket-protocol",
    "sec-websocket-version",
    "server",
    "set-cookie",
    "strict-transport-security",
    "te",
    "trailer",
    "transfer-encoding",
    "user-agent",
    "upgrade",
    "upgrade-insecure-requests",
    "vary",
    "via",
    "warning",
    "www-authenticate",
    "x-content-type-options",
    "x-dns-prefetch-control",
    "x-frame-options",
    "x-xss-protection",
]
_HeaderName: t.TypeAlias = _TStandardHttpHeader | str
_HeaderValue: t.TypeAlias = str | t.Sequence[str]


@t.final
class Headers:
    """python-ryo3-http `http::HeadersMap` wrapper"""

    def __new__(
        cls,
        headers: Mapping[_HeaderName, _HeaderValue] | t.Self | None = None,
        /,
        **kwargs: _HeaderValue,
    ) -> t.Self: ...

    # =========================================================================
    # STRING
    # =========================================================================
    def __dbg__(self) -> str: ...

    # =========================================================================
    # MAGIC METHODS
    # =========================================================================
    def __len__(self) -> int: ...
    def __getitem__(self, key: _HeaderName, /) -> str: ...
    def __setitem__(self, key: _HeaderName, value: str, /) -> None: ...
    def __delitem__(self, key: _HeaderName, /) -> None: ...
    def __contains__(self, key: _HeaderName, /) -> bool: ...
    def __or__(self, other: t.Self | dict[str, str], /) -> t.Self: ...
    def __ror__(self, other: t.Self | dict[str, str], /) -> t.Self: ...
    def __iter__(self) -> t.Iterator[_HeaderName]: ...
    def __bool__(self) -> bool: ...

    # =========================================================================
    # INSTANCE METHODS
    # =========================================================================
    def to_py(self) -> dict[str, str | t.Sequence[str]]: ...
    def to_dict(self) -> dict[str, str | t.Sequence[str]]: ...
    def stringify(self, *, fmt: bool = False) -> str: ...
    def append(self, key: _HeaderName, value: str) -> None: ...
    def clear(self) -> None: ...
    def contains_key(self, key: _HeaderName) -> bool: ...
    def get(self, key: _HeaderName) -> str | None: ...
    def get_all(self, key: _HeaderName) -> list[str]: ...
    def insert(self, key: _HeaderName, value: str) -> None: ...
    def is_empty(self) -> bool: ...
    def keys(self) -> list[str]: ...
    def keys_len(self) -> int: ...
    def len(self) -> int: ...
    def pop(self, key: _HeaderName) -> str: ...
    def remove(self, key: _HeaderName) -> None: ...
    def update(
        self, headers: t.Self | dict[str, str], *, append: bool = False
    ) -> None: ...
    def values(self) -> list[str]: ...
    @property
    def is_flat(self) -> bool: ...
    @staticmethod
    def from_json(data: str) -> Headers: ...


@t.final
class HttpStatus:
    def __new__(cls, code: int) -> t.Self: ...
    def __int__(self) -> int: ...
    def __bool__(self) -> bool: ...
    def __hash__(self) -> int: ...
    def __eq__(self, other: object, /) -> bool: ...
    def __ne__(self, other: object, /) -> bool: ...
    def __lt__(self, other: t.Self | int, /) -> bool: ...
    def __le__(self, other: t.Self | int, /) -> bool: ...
    def __gt__(self, other: t.Self | int, /) -> bool: ...
    def __ge__(self, other: t.Self | int, /) -> bool: ...
    def to_py(self) -> int: ...
    @property
    def reason(self) -> str: ...
    @property
    def canonical_reason(self) -> str: ...
    @property
    def is_informational(self) -> bool: ...
    @property
    def is_success(self) -> bool: ...
    @property
    def is_redirect(self) -> bool: ...
    @property
    def is_redirection(self) -> bool: ...
    @property
    def is_client_error(self) -> bool: ...
    @property
    def is_server_error(self) -> bool: ...
    @property
    def is_error(self) -> bool: ...
    @property
    def is_ok(self) -> bool: ...
    @property
    def ok(self) -> bool: ...

    # =========================================================================
    # CONST STATUS CODES
    # =========================================================================
    # fmt: off
    # 1xx: Informational
    CONTINUE: t.Final[HttpStatus]  # 100 ~ Continue
    SWITCHING_PROTOCOLS: t.Final[HttpStatus]  # 101 ~ Switching Protocols
    PROCESSING: t.Final[HttpStatus]  # 102 ~ Processing
    EARLY_HINTS: t.Final[HttpStatus]  # 103 ~ Early Hints
    # 2xx: Success
    OK: t.Final[HttpStatus]  # 200 ~ OK
    CREATED: t.Final[HttpStatus]  # 201 ~ Created
    ACCEPTED: t.Final[HttpStatus]  # 202 ~ Accepted
    NON_AUTHORITATIVE_INFORMATION: t.Final[HttpStatus]  # 203 ~ Non Authoritative Information
    NO_CONTENT: t.Final[HttpStatus]  # 204 ~ No Content
    RESET_CONTENT: t.Final[HttpStatus]  # 205 ~ Reset Content
    PARTIAL_CONTENT: t.Final[HttpStatus]  # 206 ~ Partial Content
    MULTI_STATUS: t.Final[HttpStatus]  # 207 ~ Multi-Status
    ALREADY_REPORTED: t.Final[HttpStatus]  # 208 ~ Already Reported
    IM_USED: t.Final[HttpStatus]  # 226 ~ IM Used
    # 3xx: Redirection
    MULTIPLE_CHOICES: t.Final[HttpStatus]  # 300 ~ Multiple Choices
    MOVED_PERMANENTLY: t.Final[HttpStatus]  # 301 ~ Moved Permanently
    FOUND: t.Final[HttpStatus]  # 302 ~ Found
    SEE_OTHER: t.Final[HttpStatus]  # 303 ~ See Other
    NOT_MODIFIED: t.Final[HttpStatus]  # 304 ~ Not Modified
    USE_PROXY: t.Final[HttpStatus]  # 305 ~ Use Proxy
    TEMPORARY_REDIRECT: t.Final[HttpStatus]  # 307 ~ Temporary Redirect
    PERMANENT_REDIRECT: t.Final[HttpStatus]  # 308 ~ Permanent Redirect
    # 4xx: Client Error
    BAD_REQUEST: t.Final[HttpStatus]  # 400 ~ Bad Request
    UNAUTHORIZED: t.Final[HttpStatus]  # 401 ~ Unauthorized
    PAYMENT_REQUIRED: t.Final[HttpStatus]  # 402 ~ Payment Required
    FORBIDDEN: t.Final[HttpStatus]  # 403 ~ Forbidden
    NOT_FOUND: t.Final[HttpStatus]  # 404 ~ Not Found
    METHOD_NOT_ALLOWED: t.Final[HttpStatus]  # 405 ~ Method Not Allowed
    NOT_ACCEPTABLE: t.Final[HttpStatus]  # 406 ~ Not Acceptable
    PROXY_AUTHENTICATION_REQUIRED: t.Final[HttpStatus]  # 407 ~ Proxy Authentication Required
    REQUEST_TIMEOUT: t.Final[HttpStatus]  # 408 ~ Request Timeout
    CONFLICT: t.Final[HttpStatus]  # 409 ~ Conflict
    GONE: t.Final[HttpStatus]  # 410 ~ Gone
    LENGTH_REQUIRED: t.Final[HttpStatus]  # 411 ~ Length Required
    PRECONDITION_FAILED: t.Final[HttpStatus]  # 412 ~ Precondition Failed
    PAYLOAD_TOO_LARGE: t.Final[HttpStatus]  # 413 ~ Payload Too Large
    URI_TOO_LONG: t.Final[HttpStatus]  # 414 ~ URI Too Long
    UNSUPPORTED_MEDIA_TYPE: t.Final[HttpStatus]  # 415 ~ Unsupported Media Type
    RANGE_NOT_SATISFIABLE: t.Final[HttpStatus]  # 416 ~ Range Not Satisfiable
    EXPECTATION_FAILED: t.Final[HttpStatus]  # 417 ~ Expectation Failed
    IM_A_TEAPOT: t.Final[HttpStatus]  # 418 ~ I'm a teapot
    MISDIRECTED_REQUEST: t.Final[HttpStatus]  # 421 ~ Misdirected Request
    UNPROCESSABLE_ENTITY: t.Final[HttpStatus]  # 422 ~ Unprocessable Entity
    LOCKED: t.Final[HttpStatus]  # 423 ~ Locked
    FAILED_DEPENDENCY: t.Final[HttpStatus]  # 424 ~ Failed Dependency
    TOO_EARLY: t.Final[HttpStatus]  # 425 ~ Too Early
    UPGRADE_REQUIRED: t.Final[HttpStatus]  # 426 ~ Upgrade Required
    PRECONDITION_REQUIRED: t.Final[HttpStatus]  # 428 ~ Precondition Required
    TOO_MANY_REQUESTS: t.Final[HttpStatus]  # 429 ~ Too Many Requests
    REQUEST_HEADER_FIELDS_TOO_LARGE: t.Final[HttpStatus]  # 431 ~ Request Header Fields Too Large
    UNAVAILABLE_FOR_LEGAL_REASONS: t.Final[HttpStatus]  # 451 ~ Unavailable For Legal Reasons
    # 5xx: Server Error
    INTERNAL_SERVER_ERROR: t.Final[HttpStatus]  # 500 ~ Internal Server Error
    NOT_IMPLEMENTED: t.Final[HttpStatus]  # 501 ~ Not Implemented
    BAD_GATEWAY: t.Final[HttpStatus]  # 502 ~ Bad Gateway
    SERVICE_UNAVAILABLE: t.Final[HttpStatus]  # 503 ~ Service Unavailable
    GATEWAY_TIMEOUT: t.Final[HttpStatus]  # 504 ~ Gateway Timeout
    HTTP_VERSION_NOT_SUPPORTED: t.Final[HttpStatus]  # 505 ~ HTTP Version Not Supported
    VARIANT_ALSO_NEGOTIATES: t.Final[HttpStatus]  # 506 ~ Variant Also Negotiates
    INSUFFICIENT_STORAGE: t.Final[HttpStatus]  # 507 ~ Insufficient Storage
    LOOP_DETECTED: t.Final[HttpStatus]  # 508 ~ Loop Detected
    NOT_EXTENDED: t.Final[HttpStatus]  # 510 ~ Not Extended
    NETWORK_AUTHENTICATION_REQUIRED: t.Final[HttpStatus]  # 511 ~ Network Authentication Required
    # fmt: on
```

<h2 id="ry.ryo3._jiff"><code>ry.ryo3._jiff</code></h2>

```python
"""ryo3-jiff ~ types"""

import datetime as pydt
import sys
import typing as t
from collections.abc import Mapping

from ry.protocols import (
    FromStr,
    Strftime,
    ToPy,
    ToPyDate,
    ToPyDateTime,
    ToPyTime,
    ToPyTimeDelta,
    ToPyTzInfo,
    ToString,
    _Parse,
)
from ry.ryo3 import Duration
from ry.ryo3._jiff_tz import TimezoneDbName

if sys.version_info >= (3, 13):
    from warnings import deprecated
else:
    from typing_extensions import deprecated

# ==== TYPE-VARS ====
_T = t.TypeVar("_T")
_TTemporal = t.TypeVar(
    "_TTemporal", bound=ZonedDateTime | DateTime | Timestamp | Date | Time
)
_TObj = t.TypeVar(
    "_TObj", Date, DateTime, Time, Timestamp, ZonedDateTime, SignedDuration, Offset
)
_TUnit = t.TypeVar("_TUnit", bound=_Unit)
_TzName: t.TypeAlias = TimezoneDbName | str

# ==== TYPE-ALIASES ====
# fmt: off
_ExactUnit: t.TypeAlias = t.Literal[
    "hour", "minute", "second",
    "millisecond", "microsecond", "nanosecond"
]
_CalendarUnit: t.TypeAlias = t.Literal["year", "month", "week", "day"]
_Unit: t.TypeAlias = _CalendarUnit | _ExactUnit
_OffsetUnit: t.TypeAlias = t.Literal["hour", "minute", "second"]
_RoundUnit: t.TypeAlias =  t.Literal["day"] | _ExactUnit
_RoundMode: t.TypeAlias = t.Literal[
    "ceil",   "half-ceil",
    "expand", "half-expand",
    "floor",  "half-floor",
    "trunc",  "half-trunc",
              "half-even",
]
# fmt: on
_WeekdayStr: t.TypeAlias = t.Literal[
    "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"
]
_WeekdayInt: t.TypeAlias = t.Literal[
    1,  # Monday
    2,  # Tuesday
    3,  # Wednesday
    4,  # Thursday
    5,  # Friday
    6,  # Saturday
    7,  # Sunday
]
_Weekday: t.TypeAlias = _WeekdayStr | _WeekdayInt


@t.final
class Date(
    # protocols
    FromStr,
    Strftime,
    ToPyDate,
    ToPy[pydt.date],
    ToString,
    _Parse,
):
    MIN: t.Final[Date]
    MAX: t.Final[Date]
    ZERO: t.Final[Date]
    __match_args__: t.Final = ("year", "month", "day")

    def __new__(cls, year: int, month: int, day: int) -> t.Self: ...
    def __eq__(self, other: object, /) -> bool: ...
    def __ne__(self, other: object, /) -> bool: ...
    def __lt__(self, other: t.Self, /) -> bool: ...
    def __le__(self, other: t.Self, /) -> bool: ...
    def __gt__(self, other: t.Self, /) -> bool: ...
    def __ge__(self, other: t.Self, /) -> bool: ...
    # =========================================================================
    # STRING
    # =========================================================================
    def to_string(self) -> str: ...
    def isoformat(self) -> str: ...

    # =========================================================================
    # PYTHON_CONVERSIONS
    # =========================================================================
    def to_py(self) -> pydt.date: ...
    def to_pydate(self) -> pydt.date: ...
    @classmethod
    def from_pydate(cls, date: pydt.date) -> t.Self: ...

    # =========================================================================
    # PROPERTIES
    # =========================================================================
    @property
    def year(self) -> int: ...
    @property
    def month(self) -> int: ...
    @property
    def day(self) -> int: ...
    @property
    def weekday(self) -> int: ...

    # =========================================================================
    # CLASSMETHODS
    # =========================================================================
    @classmethod
    def from_iso_week_date(cls, iso_week_date: ISOWeekDate) -> t.Self: ...
    @classmethod
    def today(cls) -> t.Self: ...
    @classmethod
    def now(cls) -> t.Self:
        """Same as today for parity with other date/time types"""

    @classmethod
    def from_str(cls, s: str, /) -> t.Self: ...
    @classmethod
    def parse(cls, value: str | bytes, /) -> t.Self: ...

    # =========================================================================
    # STRPTIME/STRFTIME
    # =========================================================================
    @classmethod
    def strptime(cls, string: str, /, fmt: str) -> t.Self: ...
    def strftime(self, fmt: str) -> str: ...
    def __format__(self, fmt: str) -> str: ...

    # =========================================================================
    # OPERATORS
    # =========================================================================
    def __add__(
        self, other: TimeSpan | SignedDuration | Duration | pydt.timedelta, /
    ) -> Date: ...
    def __radd__(self, other: Duration | pydt.timedelta, /) -> Date: ...
    @t.overload
    def __sub__(self, other: Date, /) -> TimeSpan: ...
    @t.overload
    def __sub__(
        self, other: TimeSpan | SignedDuration | Duration | pydt.timedelta, /
    ) -> Date: ...
    def __rsub__(self, other: t.Self, /) -> TimeSpan: ...

    # =========================================================================
    # ARITHMETIC METHODS
    # =========================================================================
    @t.overload
    def add(
        self, other: TimeSpan | SignedDuration | Duration | pydt.timedelta, /
    ) -> Date: ...
    @t.overload
    def add(
        self,
        other: None = None,
        /,
        *,
        years: int = 0,
        months: int = 0,
        weeks: int = 0,
        days: int = 0,
        hours: int = 0,
        minutes: int = 0,
        seconds: int = 0,
        milliseconds: int = 0,
        microseconds: int = 0,
        nanoseconds: int = 0,
    ) -> Date: ...
    @t.overload
    def sub(self, other: t.Self, /) -> TimeSpan: ...
    @t.overload
    def sub(
        self, other: TimeSpan | SignedDuration | Duration | pydt.timedelta, /
    ) -> Date: ...
    @t.overload
    def sub(
        self,
        other: None = None,
        /,
        *,
        years: int = 0,
        months: int = 0,
        weeks: int = 0,
        days: int = 0,
        hours: int = 0,
        minutes: int = 0,
        seconds: int = 0,
        milliseconds: int = 0,
        microseconds: int = 0,
        nanoseconds: int = 0,
    ) -> Date: ...
    def saturating_add(
        self,
        other: TimeSpan | SignedDuration | Duration | pydt.timedelta,
    ) -> Date: ...
    def saturating_sub(
        self,
        other: TimeSpan | SignedDuration | Duration | pydt.timedelta,
    ) -> Date: ...

    # =========================================================================
    # INSTANCE METHODS
    # =========================================================================
    def at(
        self, hour: int, minute: int, second: int, nanosecond: int = 0
    ) -> DateTime: ...
    def to_dict(self) -> _DateDict: ...
    def astuple(self) -> tuple[int, int, int]: ...
    def day_of_year(self) -> int: ...
    def day_of_year_no_leap(self) -> int | None: ...
    def days_in_month(self) -> int: ...
    def days_in_year(self) -> int: ...
    def duration_since(self, other: t.Self) -> SignedDuration: ...
    def duration_until(self, other: t.Self) -> SignedDuration: ...
    def era_year(self) -> tuple[int, t.Literal["BCE", "CE"]]: ...
    def first_of_month(self) -> t.Self: ...
    def first_of_year(self) -> t.Self: ...
    def iso_week_date(self) -> ISOWeekDate: ...
    def in_leap_year(self) -> bool: ...
    def in_tz(self, tz: _TzName) -> ZonedDateTime: ...
    def last_of_month(self) -> t.Self: ...
    def last_of_year(self) -> t.Self: ...
    def nth_weekday(self, nth: int, weekday: _Weekday) -> t.Self: ...
    def nth_weekday_of_month(self, nth: int, weekday: _Weekday) -> t.Self: ...
    def replace(
        self,
        *,
        year: int | None = None,
        month: int | None = None,
        day: int | None = None,
        era_year: tuple[int, t.Literal["BCE", "CE"]] | None = None,
        day_of_year: int | None = None,
        day_of_year_no_leap: int | None = None,
    ) -> t.Self: ...
    def series(self, period: TimeSpan) -> _JiffSeries[t.Self]: ...
    def to_datetime(self, time: Time) -> DateTime: ...
    def to_zoned_datetime(self, tz: TimeZone) -> ZonedDateTime: ...
    @deprecated(
        "`Date.to_zoned` is deprecated; use `Date.to_zoned_datetime` instead [removal: v0.0.112]"
    )
    def to_zoned(self, tz: TimeZone) -> ZonedDateTime: ...
    def tomorrow(self) -> t.Self: ...
    def yesterday(self) -> t.Self: ...

    # =========================================================================
    # SINCE/UNTIL
    # =========================================================================
    def _since(self, other: DateDifference) -> TimeSpan: ...
    def _until(self, other: DateDifference) -> TimeSpan: ...
    def since(
        self,
        other: Date | DateTime | ZonedDateTime,
        *,
        smallest: _CalendarUnit = "day",
        largest: _CalendarUnit | None = None,
        mode: _RoundMode = "trunc",
        increment: int = 1,
    ) -> TimeSpan: ...
    def until(
        self,
        other: Date | DateTime | ZonedDateTime,
        *,
        smallest: _CalendarUnit = "day",
        largest: _CalendarUnit | None = None,
        mode: _RoundMode = "trunc",
        increment: int = 1,
    ) -> TimeSpan: ...


@t.final
class Time(
    # protocols
    FromStr,
    Strftime,
    ToPyTime,
    ToPy[pydt.time],
    _Parse,
):
    MIN: t.Final[Time]
    MAX: t.Final[Time]
    __match_args__: t.Final = (
        "hour",
        "minute",
        "second",
        "subsec_nanosecond",
    )

    def __new__(
        cls,
        hour: int = 0,
        minute: int = 0,
        second: int = 0,
        nanosecond: int = 0,
    ) -> t.Self: ...

    # =========================================================================
    # STRING
    # =========================================================================
    def to_string(self) -> str: ...
    def isoformat(self) -> str: ...

    # =========================================================================
    # OPERATORS/DUNDERS
    # =========================================================================
    def __add__(
        self, other: TimeSpan | SignedDuration | Duration | pydt.timedelta, /
    ) -> t.Self: ...
    def __radd__(self, other: Duration | pydt.timedelta, /) -> t.Self: ...
    @t.overload
    def __sub__(self, other: Time, /) -> TimeSpan: ...
    @t.overload
    def __sub__(
        self, other: TimeSpan | SignedDuration | Duration | pydt.timedelta, /
    ) -> t.Self: ...
    def __rsub__(self, other: t.Self, /) -> TimeSpan: ...

    # =========================================================================
    # STRPTIME/STRFTIME/PARSE
    # =========================================================================
    @classmethod
    def strptime(cls, string: str, /, fmt: str) -> t.Self: ...
    def strftime(self, fmt: str) -> str: ...
    def __format__(self, fmt: str) -> str: ...

    # =========================================================================
    # PYTHON CONVERSIONS
    # =========================================================================
    def to_py(self) -> pydt.time: ...
    def to_pytime(self) -> pydt.time: ...
    @classmethod
    def from_pytime(cls, time: pydt.time) -> t.Self: ...

    # =========================================================================
    # CLASS METHODS
    # =========================================================================
    @classmethod
    def midnight(cls) -> t.Self: ...
    @classmethod
    def now(cls) -> t.Self: ...
    @classmethod
    def utcnow(cls) -> t.Self: ...
    @classmethod
    def from_str(cls, s: str, /) -> t.Self: ...
    @classmethod
    def parse(cls, value: str | bytes, /) -> t.Self: ...

    # =========================================================================
    # PROPERTIES
    # =========================================================================
    @property
    def hour(self) -> int: ...
    @property
    def minute(self) -> int: ...
    @property
    def second(self) -> int: ...
    @property
    def millisecond(self) -> int: ...
    @property
    def microsecond(self) -> int: ...
    @property
    def nanosecond(self) -> int: ...
    @property
    def subsec_nanosecond(self) -> int: ...

    # =========================================================================
    # ARITHMETIC METHODS
    # =========================================================================
    @t.overload
    def add(
        self, other: TimeSpan | SignedDuration | Duration | pydt.timedelta, /
    ) -> t.Self: ...
    @t.overload
    def add(
        self,
        other: None = None,
        /,
        *,
        hours: int = 0,
        minutes: int = 0,
        seconds: int = 0,
        milliseconds: int = 0,
        microseconds: int = 0,
        nanoseconds: int = 0,
    ) -> t.Self: ...
    @t.overload
    def sub(self, other: t.Self, /) -> TimeSpan: ...
    @t.overload
    def sub(
        self, other: TimeSpan | SignedDuration | Duration | pydt.timedelta, /
    ) -> t.Self: ...
    @t.overload
    def sub(
        self,
        other: None = None,
        /,
        *,
        hours: int = 0,
        minutes: int = 0,
        seconds: int = 0,
        milliseconds: int = 0,
        microseconds: int = 0,
        nanoseconds: int = 0,
    ) -> t.Self: ...
    def saturating_add(
        self, other: TimeSpan | SignedDuration | Duration | pydt.timedelta
    ) -> t.Self: ...
    def saturating_sub(
        self, other: TimeSpan | SignedDuration | Duration | pydt.timedelta
    ) -> t.Self: ...
    def wrapping_add(
        self, other: TimeSpan | SignedDuration | Duration | pydt.timedelta
    ) -> t.Self: ...
    def wrapping_sub(
        self, other: TimeSpan | SignedDuration | Duration | pydt.timedelta
    ) -> t.Self: ...

    # =========================================================================
    # INSTANCE METHODS
    # =========================================================================
    def astuple(self) -> tuple[int, int, int, int]: ...
    def to_dict(self) -> _TimeDict: ...
    def duration_until(self, other: Time) -> SignedDuration: ...
    def duration_since(self, other: Time) -> SignedDuration: ...
    def on(self, year: int, month: int, day: int) -> DateTime: ...
    def replace(
        self,
        *,
        hour: int | None = None,
        minute: int | None = None,
        second: int | None = None,
        millisecond: int | None = None,
        microsecond: int | None = None,
        nanosecond: int | None = None,
        subsec_nanosecond: int | None = None,
    ) -> t.Self: ...
    def round(
        self,
        smallest: _ExactUnit = "nanosecond",
        *,
        mode: _RoundMode = "half-expand",
        increment: int = 1,
    ) -> t.Self: ...
    def _round(self, options: TimeRound) -> t.Self: ...
    def series(self, period: TimeSpan) -> _JiffSeries[t.Self]: ...
    def to_datetime(self, date: Date) -> DateTime: ...

    # =========================================================================
    # SINCE/UNTIL
    # =========================================================================
    def _since(self, other: TimeDifference) -> TimeSpan: ...
    def _until(self, other: TimeDifference) -> TimeSpan: ...
    def since(
        self,
        t: Time | DateTime | ZonedDateTime,
        *,
        smallest: t.Literal[
            "hour", "minute", "second", "millisecond", "microsecond", "nanosecond"
        ] = "nanosecond",
        largest: t.Literal[
            "hour", "minute", "second", "millisecond", "microsecond", "nanosecond"
        ]
        | None = None,
        mode: _RoundMode = "trunc",
        increment: int = 1,
    ) -> TimeSpan: ...
    def until(
        self,
        t: Time | DateTime | ZonedDateTime,
        *,
        smallest: t.Literal[
            "hour", "minute", "second", "millisecond", "microsecond", "nanosecond"
        ] = "nanosecond",
        largest: t.Literal[
            "hour", "minute", "second", "millisecond", "microsecond", "nanosecond"
        ]
        | None = None,
        mode: _RoundMode = "trunc",
        increment: int = 1,
    ) -> TimeSpan: ...


@t.final
class DateTime(
    # protocols
    FromStr,
    Strftime,
    ToPyDate,
    ToPyDateTime,
    ToPyTime,
    ToPy[pydt.datetime],
    _Parse,
):
    MIN: t.Final[DateTime]
    MAX: t.Final[DateTime]
    ZERO: t.Final[DateTime]
    __match_args__: t.Final = (
        "year",
        "month",
        "day",
        "hour",
        "minute",
        "second",
        "subsec_nanosecond",
    )

    def __new__(
        cls,
        year: int,
        month: int,
        day: int,
        hour: int = 0,
        minute: int = 0,
        second: int = 0,
        subsec_nanosecond: int = 0,
    ) -> t.Self: ...
    def to_string(self) -> str: ...
    def isoformat(self) -> str: ...

    # =========================================================================
    # STRPTIME/STRFTIME/PARSE
    # =========================================================================
    def strftime(self, fmt: str) -> str: ...
    @classmethod
    def strptime(cls, string: str, /, fmt: str) -> t.Self: ...
    def __format__(self, fmt: str) -> str: ...
    @classmethod
    def from_str(cls, s: str, /) -> t.Self: ...
    @classmethod
    def parse(cls, value: str | bytes, /) -> t.Self: ...

    # =========================================================================
    # PYTHON CONVERSIONS
    # =========================================================================
    @classmethod
    def from_pydatetime(cls, datetime: pydt.datetime) -> t.Self: ...
    def to_py(self) -> pydt.datetime: ...
    def to_pydate(self) -> pydt.date: ...
    def to_pydatetime(self) -> pydt.datetime: ...
    def to_pytime(self) -> pydt.time: ...

    # =========================================================================
    # CLASS METHODS
    # =========================================================================
    @classmethod
    def now(cls) -> t.Self: ...
    @classmethod
    def today(cls) -> t.Self: ...
    @classmethod
    def from_parts(cls, date: Date, time: Time) -> t.Self: ...

    # =========================================================================
    # OPERATORS
    # =========================================================================
    def __add__(
        self, other: TimeSpan | SignedDuration | Duration | pydt.timedelta, /
    ) -> t.Self: ...
    def __radd__(self, other: Duration | pydt.timedelta, /) -> t.Self: ...
    @t.overload
    def __sub__(self, other: t.Self, /) -> TimeSpan: ...
    @t.overload
    def __sub__(
        self, other: TimeSpan | SignedDuration | Duration | pydt.timedelta, /
    ) -> t.Self: ...
    def __rsub__(self, other: t.Self, /) -> TimeSpan: ...

    # =========================================================================
    # ARITHMETIC METHODS
    # =========================================================================
    @t.overload
    def add(
        self, other: TimeSpan | SignedDuration | Duration | pydt.timedelta, /
    ) -> t.Self: ...
    @t.overload
    def add(
        self,
        other: None = None,
        /,
        *,
        years: int = 0,
        months: int = 0,
        weeks: int = 0,
        days: int = 0,
        hours: int = 0,
        minutes: int = 0,
        seconds: int = 0,
        milliseconds: int = 0,
        microseconds: int = 0,
        nanoseconds: int = 0,
    ) -> t.Self: ...
    @t.overload
    def sub(self, other: t.Self, /) -> TimeSpan: ...
    @t.overload
    def sub(
        self, other: TimeSpan | SignedDuration | Duration | pydt.timedelta, /
    ) -> t.Self: ...
    @t.overload
    def sub(
        self,
        other: None = None,
        /,
        *,
        years: int = 0,
        months: int = 0,
        weeks: int = 0,
        days: int = 0,
        hours: int = 0,
        minutes: int = 0,
        seconds: int = 0,
        milliseconds: int = 0,
        microseconds: int = 0,
        nanoseconds: int = 0,
    ) -> t.Self: ...
    def saturating_sub(
        self, other: TimeSpan | SignedDuration | Duration | pydt.timedelta
    ) -> t.Self: ...

    # =========================================================================
    # INSTANCE METHODS
    # =========================================================================
    def to_dict(self) -> _DateTimeDict: ...
    def date(self) -> Date: ...
    def day_of_year(self) -> int: ...
    def day_of_year_no_leap(self) -> int | None: ...
    def days_in_month(self) -> int: ...
    def days_in_year(self) -> int: ...
    def duration_since(self, other: t.Self) -> SignedDuration: ...
    def duration_until(self, other: t.Self) -> SignedDuration: ...
    def end_of_day(self) -> t.Self: ...
    def era_year(self) -> tuple[int, t.Literal["BCE", "CE"]]: ...
    def first_of_month(self) -> t.Self: ...
    def first_of_year(self) -> t.Self: ...
    def in_leap_year(self) -> bool: ...
    def in_tz(self, tz: _TzName) -> ZonedDateTime: ...
    def iso_week_date(self) -> ISOWeekDate: ...
    def last_of_month(self) -> t.Self: ...
    def last_of_year(self) -> t.Self: ...
    def nth_weekday(self, nth: int, weekday: _Weekday) -> t.Self: ...
    def nth_weekday_of_month(self, nth: int, weekday: _Weekday) -> t.Self: ...
    def replace(
        self,
        obj: Date | DateTime | Time | None = None,
        *,
        date: Date | None = None,
        time: Time | None = None,
        year: int | None = None,
        era_year: tuple[int, t.Literal["BCE", "CE"]] | None = None,
        month: int | None = None,
        day: int | None = None,
        day_of_year: int | None = None,
        day_of_year_no_leap: int | None = None,
        hour: int | None = None,
        minute: int | None = None,
        second: int | None = None,
        millisecond: int | None = None,
        microsecond: int | None = None,
        nanosecond: int | None = None,
        subsec_nanosecond: int | None = None,
    ) -> t.Self: ...
    def round(
        self,
        smallest: _ExactUnit | t.Literal["day"] = "nanosecond",
        *,
        mode: _RoundMode = "half-expand",
        increment: int = 1,
    ) -> t.Self: ...
    def _round(self, options: DateTimeRound) -> t.Self: ...
    def saturating_add(
        self, other: TimeSpan | SignedDuration | Duration | pydt.timedelta
    ) -> t.Self: ...
    def series(self, period: TimeSpan) -> _JiffSeries[t.Self]: ...
    def start_of_day(self) -> t.Self: ...
    def time(self) -> Time: ...
    def to_zoned_datetime(self, tz: TimeZone) -> ZonedDateTime: ...
    @deprecated(
        "`DateTime.to_zoned` is deprecated; use `DateTime.to_zoned_datetime` instead [removal: v0.0.112]"
    )
    def to_zoned(self, tz: TimeZone) -> ZonedDateTime: ...
    def tomorrow(self) -> t.Self: ...
    def yesterday(self) -> t.Self: ...

    # =========================================================================
    # PROPERTIES
    # =========================================================================
    @property
    def year(self) -> int: ...
    @property
    def month(self) -> int: ...
    @property
    def day(self) -> int: ...
    @property
    def hour(self) -> int: ...
    @property
    def minute(self) -> int: ...
    @property
    def second(self) -> int: ...
    @property
    def millisecond(self) -> int: ...
    @property
    def microsecond(self) -> int: ...
    @property
    def nanosecond(self) -> int: ...
    @property
    def subsec_nanosecond(self) -> int: ...
    @property
    def weekday(self) -> int: ...

    # =========================================================================
    # SINCE/UNTIL
    # =========================================================================
    def _since(self, other: DateTimeDifference) -> TimeSpan: ...
    def _until(self, other: DateTimeDifference) -> TimeSpan: ...
    def since(
        self,
        other: Date | DateTime | ZonedDateTime,
        *,
        smallest: _Unit = "nanosecond",
        largest: _Unit | None = None,
        mode: _RoundMode = "trunc",
        increment: int = 1,
    ) -> TimeSpan: ...
    def until(
        self,
        other: Date | DateTime | ZonedDateTime,
        *,
        smallest: _Unit = "nanosecond",
        largest: _Unit | None = None,
        mode: _RoundMode = "trunc",
        increment: int = 1,
    ) -> TimeSpan: ...


class TimeZoneTransition(t.TypedDict):
    timestamp: Timestamp
    offset: Offset
    dst: bool
    abbreviation: str


class TimeZoneLocation(t.TypedDict):
    country: str  # ISO 3166 (eg "DK")
    latitude: float
    longitude: float


@t.final
class TimeZone(
    # protocols
    FromStr,
    ToPyTzInfo,
    ToPy[pydt.tzinfo],
    _Parse,
):
    UTC: t.Final[TimeZone]

    def __new__(cls, time_zone_name: _TzName) -> t.Self: ...
    def __eq__(self, other: object, /) -> bool: ...
    def __call__(self, *args: t.Any, **kwargs: t.Any) -> t.Self: ...

    # =========================================================================
    # PYTHON CONVERSIONS
    # =========================================================================

    def to_py(self) -> pydt.tzinfo: ...
    def to_pytzinfo(self) -> pydt.tzinfo: ...
    def to_dict(self) -> _TimeZoneDict: ...
    @classmethod
    def from_str(cls, s: _TzName) -> t.Self: ...
    @classmethod
    def parse(cls, value: str | bytes, /) -> t.Self: ...
    @classmethod
    def from_pytzinfo(cls, tz: pydt.tzinfo) -> t.Self: ...
    def to_offset_info(self, timestamp: Timestamp) -> _OffsetInfoDict: ...

    # =========================================================================
    # PROPERTIES
    # =========================================================================
    @property
    def name(self) -> str: ...
    @property
    def is_unknown(self) -> bool: ...

    # =========================================================================
    # CLASS METHODS
    # =========================================================================
    @classmethod
    def fixed(cls, offset: Offset) -> t.Self: ...
    @classmethod
    def get(cls, tz_name: _TzName) -> t.Self: ...
    @classmethod
    def posix(cls, tz_name: _TzName) -> t.Self: ...
    @classmethod
    def system(cls) -> t.Self: ...
    @classmethod
    def try_system(cls) -> t.Self: ...
    @classmethod
    def tzif(cls, name: str, data: bytes) -> t.Self: ...
    @classmethod
    def utc(cls) -> t.Self: ...
    def equiv(self, other: t.Self | pydt.tzinfo | str) -> bool: ...
    # =========================================================================
    # INSTANCE METHODS
    # =========================================================================
    def iana_name(self) -> str | None: ...
    def primary_iana_name(self) -> str | None:
        """Return the primary (ECMAScript preferred) IANA name

        Examples
        --------
        >>> import ry
        >>> ry.TimeZone("Asia/Calcutta").primary_iana_name()
        'Asia/Kolkata'

        """

    def is_primary(self) -> bool:
        """Return True if the IANA name is the primary IANA name

        Examples
        --------
        >>> import ry
        >>> ry.TimeZone("Asia/Calcutta").is_primary()
        False
        >>> ry.TimeZone("Asia/Kolkata").is_primary()
        True

        """

    def location(self) -> TimeZoneLocation | None:
        """Return the country + coordinates for the primary time zone id

        Examples
        --------
        >>> import ry
        >>> ry.TimeZone("Europe/Copenhagen").location()["country"]
        'DK'
        >>> ry.TimeZone.UTC.location() is None
        True

        """

    def to_datetime(self, timestamp: Timestamp) -> DateTime: ...
    def to_fixed_offset(self) -> Offset:
        """Return a TimeZone with a fixed offset equivalent to this TimeZone.

        Examples
        --------
        >>> import ry
        >>> tz = ry.TimeZone.fixed(ry.Offset(hours=-5))
        >>> fixed_tz = tz.to_fixed_offset()
        >>> fixed_tz
        Offset(hours=-5)

        """

    def to_offset(self, timestamp: Timestamp) -> Offset: ...
    def to_timestamp(self, datetime: DateTime) -> Timestamp: ...
    def to_zoned_datetime(self, datetime: DateTime) -> ZonedDateTime: ...
    @deprecated(
        "`TimeZone.to_zoned` is deprecated; use `TimeZone.to_zoned_datetime` instead [removal: v0.0.112]"
    )
    def to_zoned(self, datetime: DateTime) -> ZonedDateTime: ...
    def preceding(
        self,
        timestamp: Timestamp,
        /,
        limit: int | None = None,
    ) -> list[TimeZoneTransition]: ...
    def following(
        self,
        timestamp: Timestamp,
        /,
        limit: int | None = None,
    ) -> list[TimeZoneTransition]: ...
    # =========================================================================
    # NOT IMPLEMENTED
    # =========================================================================
    def to_ambiguous_timestamp(self) -> t.NoReturn: ...
    def to_ambiguous_zoned_datetime(self) -> t.NoReturn: ...


@t.final
class SignedDuration(
    # protocols
    FromStr,
    ToPyTimeDelta,
    ToPy[pydt.timedelta],
    _Parse,
):
    """signed duration of time represented as seconds and nanoseconds

    Examples
    --------
    >>> import ry
    >>> ry.SignedDuration.MIN
    SignedDuration(secs=-9223372036854775808, nanos=-999999999)
    >>> ry.SignedDuration.MAX
    SignedDuration(secs=9223372036854775807, nanos=999999999)
    >>> ry.SignedDuration.ZERO
    SignedDuration(secs=0, nanos=0)
    >>> ry.SignedDuration.NANOSECOND
    SignedDuration(secs=0, nanos=1)
    >>> ry.SignedDuration.MILLISECOND
    SignedDuration(secs=0, nanos=1000000)
    >>> ry.SignedDuration.SECOND
    SignedDuration(secs=1, nanos=0)
    >>> ry.SignedDuration.MINUTE
    SignedDuration(secs=60, nanos=0)
    >>> ry.SignedDuration.HOUR
    SignedDuration(secs=3600, nanos=0)

    """

    MIN: t.Final[SignedDuration]
    MAX: t.Final[SignedDuration]
    ZERO: t.Final[SignedDuration]
    NANOSECOND: t.Final[SignedDuration]
    MICROSECOND: t.Final[SignedDuration]
    MILLISECOND: t.Final[SignedDuration]
    SECOND: t.Final[SignedDuration]
    MINUTE: t.Final[SignedDuration]
    HOUR: t.Final[SignedDuration]
    __match_args__: t.Final = ("secs", "nanos")

    def __new__(cls, secs: int = 0, nanos: int = 0) -> t.Self: ...

    # =========================================================================
    # OPERATORS/DUNDERS
    # =========================================================================
    def __hash__(self) -> int: ...
    def __eq__(self, other: object, /) -> bool: ...
    def __ne__(self, other: object, /) -> bool: ...
    def __lt__(self, other: t.Self, /) -> bool: ...
    def __le__(self, other: t.Self, /) -> bool: ...
    def __gt__(self, other: t.Self, /) -> bool: ...
    def __ge__(self, other: t.Self, /) -> bool: ...
    def __neg__(self) -> t.Self: ...
    @t.overload
    def __add__(self, other: t.Self | Duration | pydt.timedelta, /) -> t.Self: ...
    @t.overload
    def __add__(self, val: _TTemporal, /) -> _TTemporal: ...
    def __radd__(self, other: t.Self | Duration | pydt.timedelta, /) -> t.Self: ...
    def __sub__(self, other: t.Self | Duration | pydt.timedelta, /) -> t.Self: ...
    def __rsub__(self, other: t.Self | Duration | pydt.timedelta, /) -> t.Self: ...
    def __mul__(self, other: int, /) -> t.Self: ...
    def __rmul__(self, other: int, /) -> t.Self: ...
    def __abs__(self) -> t.Self: ...
    def __float__(self) -> float: ...
    def __bool__(self) -> bool: ...
    @t.overload
    def __truediv__(self, other: t.Self | Duration | pydt.timedelta, /) -> float: ...
    @t.overload
    def __truediv__(self, other: float, /) -> t.Self: ...
    def __rtruediv__(self, other: t.Self, /) -> float: ...
    def abs(self) -> t.Self: ...
    def unsigned_abs(self) -> Duration: ...
    def replace(self, *, secs: int | None = None, nanos: int | None = None) -> t.Self:
        """Return duration with parts replaced


        Examples
        --------
        >>> from ry import SignedDuration
        >>> d = SignedDuration(5, 500_000_000)  # 5.5 seconds
        >>> d.replace(secs=10)  # 10.5 seconds
        SignedDuration(secs=10, nanos=500000000)

        """

    # =========================================================================
    # EQUIV
    # =========================================================================
    def equiv(self, other: t.Self | Duration | pydt.timedelta) -> bool: ...
    # =========================================================================
    # STRING
    # =========================================================================
    def isoformat(self) -> str: ...
    @classmethod
    def fromisoformat(cls, s: str) -> t.Self: ...
    def to_string(self, *, friendly: bool = False) -> str: ...
    def friendly(
        self,
        designator: t.Literal[
            "compact", "human", "human-time", "short", "verbose"
        ] = "compact",
    ) -> str:
        """Return friendly string representation

        Parameters
        ----------
        designator : str, optional
            The designator to use for the friendly string representation.
            Options are "compact", "human", "human-time", "short", and "verbose".
            Default is "compact".

        Examples
        --------
        >>> import ry
        >>> span = ry.SignedDuration(
        ...     secs=93790, nanos=10000000
        ... )  # 1 day, 2 hours, 30 minutes, 10 seconds, and 10 milliseconds
        >>> span
        SignedDuration(secs=93790, nanos=10000000)
        >>> f"{span}"  # isoformat
        'PT26H3M10.01S'
        >>> f"{span:#}"  # '#' in format spec is friendly
        '26h 3m 10s 10ms'
        >>> span.friendly()  # default 'compact'
        '26h 3m 10s 10ms'
        >>> span.friendly("human")
        '26h 3m 10s 10ms'
        >>> span.friendly("short")
        '26hrs 3mins 10secs 10msecs'
        >>> span.friendly("verbose")
        '26hours 3minutes 10seconds 10milliseconds'

        """

    # =========================================================================
    # PYTHON CONVERSIONS
    # =========================================================================
    @classmethod
    def from_pytimedelta(cls, delta: pydt.timedelta) -> t.Self: ...
    def to_py(self) -> pydt.timedelta: ...
    def to_pytimedelta(self) -> pydt.timedelta: ...
    def to_dict(self) -> _SignedDurationDict: ...
    # =========================================================================
    # CLASS METHODS
    # =========================================================================
    @classmethod
    def from_str(cls, s: str, /) -> t.Self: ...
    @classmethod
    def parse(cls, value: str | bytes, /) -> t.Self: ...
    @classmethod
    def from_hours(cls, hours: int) -> t.Self: ...
    @classmethod
    def from_micros(cls, micros: int) -> t.Self: ...
    @classmethod
    def from_millis(cls, millis: int) -> t.Self: ...
    @classmethod
    def from_mins(cls, mins: int) -> t.Self: ...
    @classmethod
    def from_nanos(cls, nanos: int) -> t.Self: ...
    @classmethod
    def from_secs(cls, secs: float) -> t.Self: ...
    @classmethod
    def from_secs_f32(cls, secs: float) -> t.Self: ...
    @classmethod
    def from_secs_f64(cls, secs: float) -> t.Self: ...
    # =========================================================================
    # PROPERTIES
    # =========================================================================
    @property
    def is_absolute(self) -> bool: ...
    @property
    def is_negative(self) -> bool: ...
    @property
    def is_positive(self) -> bool: ...
    @property
    def is_zero(self) -> bool: ...
    @property
    def secs(self) -> int: ...
    @property
    def nanos(self) -> int: ...
    @property
    def days(self) -> int: ...
    @property
    def seconds(self) -> int: ...
    @property
    def seconds_remainder(self) -> int: ...
    @property
    def microseconds(self) -> int: ...
    @property
    def subsec_micros(self) -> int: ...
    @property
    def subsec_millis(self) -> int: ...
    @property
    def subsec_nanos(self) -> int: ...
    @property
    def ns(self) -> int:
        """Alias for `nanos`"""

    @property
    def nanoseconds(self) -> int:
        """Alias for `nanos`"""

    # =========================================================================
    # INSTANCE METHODS
    # =========================================================================
    def as_hours(self) -> int: ...
    def as_micros(self) -> int: ...
    def as_millis(self) -> int: ...
    def as_millis_f32(self) -> float: ...
    def as_millis_f64(self) -> float: ...
    def as_mins(self) -> int: ...
    def as_nanos(self) -> int: ...
    def as_secs(self) -> int: ...
    def as_secs_f32(self) -> float: ...
    def as_secs_f64(self) -> float: ...
    def checked_add(self, other: t.Self) -> t.Self | None: ...
    def checked_div(self, other: int) -> t.Self | None: ...
    def checked_mul(self, other: int) -> t.Self | None: ...
    def checked_neg(self) -> t.Self | None: ...
    def checked_sub(self, other: t.Self) -> t.Self | None: ...
    def div_duration_f32(self, other: t.Self) -> float: ...
    def div_duration_f64(self, other: t.Self) -> float: ...
    def div_f32(self, n: float) -> float: ...
    def div_f64(self, n: float) -> float: ...
    def mul_f32(self, n: float) -> t.Self: ...
    def mul_f64(self, n: float) -> t.Self: ...
    def saturating_add(self, other: t.Self) -> t.Self: ...
    def saturating_mul(self, other: int) -> t.Self: ...
    def saturating_sub(self, other: t.Self) -> t.Self: ...
    def signum(self) -> t.Literal[-1, 0, 1]: ...
    def to_timespan(self) -> TimeSpan: ...
    @t.overload
    def add(self, other: t.Self | Duration | pydt.timedelta, /) -> t.Self: ...
    @t.overload
    def add(self, other: _TTemporal, /) -> _TTemporal: ...
    @t.overload
    def add(
        self,
        other: None = None,
        /,
        *,
        hours: int | None = None,
        minutes: int | None = None,
        seconds: int | None = None,
        milliseconds: int | None = None,
        microseconds: int | None = None,
        nanoseconds: int | None = None,
    ) -> t.Self: ...
    @t.overload
    def sub(self, other: t.Self | Duration | pydt.timedelta, /) -> t.Self: ...
    @t.overload
    def sub(
        self,
        other: None = None,
        /,
        *,
        hours: int | None = None,
        minutes: int | None = None,
        seconds: int | None = None,
        milliseconds: int | None = None,
        microseconds: int | None = None,
        nanoseconds: int | None = None,
    ) -> t.Self: ...
    def round(
        self,
        smallest: _ExactUnit = "nanosecond",
        *,
        mode: _RoundMode = "half-expand",
        increment: int = 1,
    ) -> t.Self: ...
    def _round(self, options: SignedDurationRound) -> t.Self: ...


_TimeSpanArithmetic: t.TypeAlias = (
    TimeSpan
    | Duration
    | SignedDuration
    | pydt.timedelta
    | tuple[
        TimeSpan | Duration | SignedDuration | pydt.timedelta,
        ZonedDateTime | Date | DateTime,
    ]
)

_TimeSpanKey: t.TypeAlias = t.Literal[
    "years",
    "months",
    "weeks",
    "days",
    "hours",
    "minutes",
    "seconds",
    "milliseconds",
    "microseconds",
    "nanoseconds",
]


@t.final
class TimeSpan(
    Mapping[_TimeSpanKey, int],
    # protocols
    ToPy[pydt.timedelta],
    ToPyTimeDelta,
    FromStr,
    _Parse,
):
    MIN: t.Final[TimeSpan]
    MAX: t.Final[TimeSpan]

    def __new__(
        cls,
        *,
        years: int = 0,
        months: int = 0,
        weeks: int = 0,
        days: int = 0,
        hours: int = 0,
        minutes: int = 0,
        seconds: int = 0,
        milliseconds: int = 0,
        microseconds: int = 0,
        nanoseconds: int = 0,
    ) -> t.Self: ...

    # =========================================================================
    # STRING
    # =========================================================================
    def isoformat(self) -> str: ...
    def to_string(self, *, friendly: bool = False) -> str: ...
    def friendly(
        self,
        designator: t.Literal[
            "compact", "human", "human-time", "short", "verbose"
        ] = "compact",
    ) -> str:
        """Return friendly string representation of the TimeSpan.

        Parameters
        ----------
        designator : str, optional
            The designator to use for the friendly string representation.
            Options are "compact", "human", "human-time", "short", and "verbose".
            Default is "compact".

        Examples
        --------
        >>> import ry
        >>> span = ry.TimeSpan(days=1, hours=2, minutes=30, seconds=10)
        >>> span
        TimeSpan(days=1, hours=2, minutes=30, seconds=10)
        >>> span.friendly()  # default 'compact'
        '1d 2h 30m 10s'
        >>> span.friendly("human")
        '1d 2h 30m 10s'
        >>> span.friendly("short")
        '1day 2hrs 30mins 10secs'
        >>> span.friendly("verbose")
        '1day 2hours 30minutes 10seconds'

        """

    def repr_full(self) -> str: ...

    # =========================================================================
    # PYTHON CONVERSIONS
    # =========================================================================
    @classmethod
    def from_pytimedelta(cls, delta: pydt.timedelta) -> t.Self: ...
    def to_pytimedelta(self) -> pydt.timedelta: ...
    def to_py(self) -> pydt.timedelta: ...

    # =========================================================================
    # PARSING
    # =========================================================================
    @classmethod
    def from_str(cls, s: str, /) -> t.Self: ...
    @classmethod
    def parse(cls, value: str | bytes, /) -> t.Self: ...
    @classmethod
    def fromisoformat(cls, s: str) -> t.Self: ...

    # =========================================================================
    # PROPERTIES
    # =========================================================================
    @property
    def is_absolute(self) -> bool: ...
    @property
    def is_calendar(self) -> bool:
        """`True` if contains calendar units (years, months, weeks, days)"""

    @property
    def is_exact(self) -> bool:
        """`True` if contains only exact units (hours, minutes, seconds, milliseconds, microseconds, nanoseconds)"""

    @property
    def is_positive(self) -> bool: ...
    @property
    def is_negative(self) -> bool: ...
    @property
    def is_zero(self) -> bool: ...
    @property
    def years(self) -> int: ...
    @property
    def months(self) -> int: ...
    @property
    def weeks(self) -> int: ...
    @property
    def days(self) -> int: ...
    @property
    def hours(self) -> int: ...
    @property
    def minutes(self) -> int: ...
    @property
    def seconds(self) -> int: ...
    @property
    def milliseconds(self) -> int: ...
    @property
    def microseconds(self) -> int: ...
    @property
    def nanoseconds(self) -> int: ...

    # =========================================================================
    # OPERATORS
    # =========================================================================
    @t.overload
    def __add__(self, val: _TimeSpanArithmetic, /) -> t.Self: ...
    @t.overload
    def __add__(self, val: _TTemporal, /) -> _TTemporal: ...
    def __radd__(self, other: t.Self, /) -> t.Self: ...
    def __sub__(
        self,
        val: _TimeSpanArithmetic,
        /,
    ) -> t.Self: ...
    def __rsub__(self, other: t.Self, /) -> t.Self: ...
    def __mul__(self, other: int, /) -> t.Self: ...
    def __neg__(self) -> t.Self: ...
    def __abs__(self) -> t.Self: ...
    def __invert__(self) -> t.Self: ...
    def __eq__(self, other: object, /) -> bool: ...
    def __ge__(self, other: t.Self, /) -> bool: ...
    def __gt__(self, other: t.Self, /) -> bool: ...
    def __le__(self, other: t.Self, /) -> bool: ...
    def __lt__(self, other: t.Self, /) -> bool: ...
    def __ne__(self, other: object, /) -> bool: ...
    def __rmul__(self, other: int, /) -> t.Self: ...
    def __hash__(self) -> int: ...
    def __iter__(
        self,
    ) -> t.Iterator[_TimeSpanKey]: ...
    def __len__(self) -> int: ...
    def __contains__(self, key: object, /) -> bool: ...
    def __getitem__(self, key: _TimeSpanKey, /) -> int: ...

    # =========================================================================
    # ARITHMETIC METHODS
    # =========================================================================
    @t.overload
    def add(self, other: _TimeSpanArithmetic, /) -> t.Self: ...
    @t.overload
    def add(
        self,
        other: None = None,
        /,
        *,
        years: int | None = None,
        months: int | None = None,
        weeks: int | None = None,
        days: int | None = None,
        hours: int | None = None,
        minutes: int | None = None,
        seconds: int | None = None,
        milliseconds: int | None = None,
        microseconds: int | None = None,
        nanoseconds: int | None = None,
    ) -> t.Self: ...
    def mul(self, other: int) -> t.Self: ...
    @t.overload
    def sub(self, other: _TimeSpanArithmetic, /) -> t.Self: ...
    @t.overload
    def sub(
        self,
        other: None = None,
        /,
        *,
        years: int | None = None,
        months: int | None = None,
        weeks: int | None = None,
        days: int | None = None,
        hours: int | None = None,
        minutes: int | None = None,
        seconds: int | None = None,
        milliseconds: int | None = None,
        microseconds: int | None = None,
        nanoseconds: int | None = None,
    ) -> t.Self: ...

    # =========================================================================
    # INSTANCE METHODS
    # =========================================================================

    def abs(self) -> t.Self: ...
    def to_dict(self) -> _TimeSpanDict: ...
    def fieldwise(self) -> _TimeSpanDict: ...
    def compare(
        self,
        other: t.Self,
        relative: ZonedDateTime | DateTime | Date | None = None,
        *,
        days_are_24_hours: bool = False,
    ) -> int: ...
    def negate(self) -> t.Self: ...
    def replace(
        self,
        *,
        years: int | None = None,
        months: int | None = None,
        weeks: int | None = None,
        days: int | None = None,
        hours: int | None = None,
        minutes: int | None = None,
        seconds: int | None = None,
        milliseconds: int | None = None,
        microseconds: int | None = None,
        nanoseconds: int | None = None,
    ) -> t.Self: ...
    def round(
        self,
        smallest: _Unit = "nanosecond",
        increment: int = 1,
        *,
        relative: ZonedDateTime | Date | DateTime | None = None,
        largest: _Unit | None = None,
        mode: _RoundMode = "half-expand",
        days_are_24_hours: bool = False,
    ) -> t.Self: ...
    def signum(self) -> t.Literal[-1, 0, 1]: ...
    def to_signed_duration(
        self,
        relative: ZonedDateTime | Date | DateTime | None = None,
    ) -> SignedDuration: ...
    def total(
        self,
        unit: _Unit,
        relative: ZonedDateTime | Date | DateTime | None = None,
        *,
        days_are_24_hours: bool = False,
    ) -> float: ...
    def total_seconds(
        self,
        relative: ZonedDateTime | Date | DateTime | None = None,
        *,
        days_are_24_hours: bool = False,
    ) -> float: ...
    def _years(self, years: int, /) -> t.Self: ...
    def _months(self, months: int, /) -> t.Self: ...
    def _weeks(self, weeks: int, /) -> t.Self: ...
    def _days(self, days: int, /) -> t.Self: ...
    def _hours(self, hours: int, /) -> t.Self: ...
    def _minutes(self, minutes: int, /) -> t.Self: ...
    def _seconds(self, seconds: int, /) -> t.Self: ...
    def _milliseconds(self, milliseconds: int, /) -> t.Self: ...
    def _microseconds(self, microseconds: int, /) -> t.Self: ...
    def _nanoseconds(self, nanoseconds: int, /) -> t.Self: ...


@t.final
class Timestamp(
    # protocols
    FromStr,
    Strftime,
    ToPyDate,
    ToPyDateTime,
    ToPyTime,
    ToPy[pydt.datetime],
    _Parse,
):
    """An instant in time represented as the number of nanoseconds since the Unix epoch.

    A timestamp is always in the Unix timescale with a UTC offset of zero.
    """

    MIN: t.Final[Timestamp]
    MAX: t.Final[Timestamp]
    UNIX_EPOCH: t.Final[Timestamp]
    __match_args__: t.Final = ("second", "nanosecond")

    def __new__(cls, second: int = 0, nanosecond: int = 0) -> t.Self: ...

    # =========================================================================
    # CLASS METHODS
    # =========================================================================
    @classmethod
    def now(cls) -> t.Self: ...
    @classmethod
    def from_str(cls, s: str, /) -> t.Self: ...
    @classmethod
    def parse(cls, value: str | bytes, /) -> t.Self: ...
    @classmethod
    def from_millisecond(cls, millisecond: int) -> t.Self: ...
    @classmethod
    def from_microsecond(cls, microsecond: int) -> t.Self: ...
    @classmethod
    def from_nanosecond(cls, nanosecond: int) -> t.Self: ...
    @classmethod
    def from_second(cls, second: float) -> t.Self: ...
    @classmethod
    def from_second_f64(cls, second: float) -> t.Self: ...
    # =========================================================================
    # OPERATORS/DUNDERS
    # =========================================================================
    def __add__(
        self, other: TimeSpan | SignedDuration | Duration | pydt.timedelta, /
    ) -> t.Self: ...
    def __radd__(self, other: Duration | pydt.timedelta, /) -> t.Self: ...
    def __eq__(self, other: object, /) -> bool: ...
    def __ne__(self, other: object, /) -> bool: ...
    def __ge__(self, other: t.Self, /) -> bool: ...
    def __gt__(self, other: t.Self, /) -> bool: ...
    def __le__(self, other: t.Self, /) -> bool: ...
    def __lt__(self, other: t.Self, /) -> bool: ...

    # =========================================================================
    # OPERATORS/DUNDERS W/ OVERLOADS
    # =========================================================================
    @t.overload
    def __sub__(self, other: t.Self, /) -> SignedDuration: ...
    @t.overload
    def __sub__(
        self, other: TimeSpan | SignedDuration | Duration | pydt.timedelta, /
    ) -> t.Self: ...
    def __rsub__(self, other: t.Self, /) -> SignedDuration: ...

    # =========================================================================
    # PYTHON CONVERSIONS
    # =========================================================================
    @classmethod
    def from_pydatetime(cls, datetime: pydt.datetime) -> t.Self: ...
    def to_py(self) -> pydt.datetime: ...
    def to_pydate(self) -> pydt.date: ...
    def to_pydatetime(self) -> pydt.datetime: ...
    def to_pytime(self) -> pydt.time: ...
    def to_dict(self) -> _TimestampDict: ...

    # =========================================================================
    # ARITHMETIC METHODS
    # =========================================================================
    @t.overload
    def add(
        self, other: TimeSpan | SignedDuration | Duration | pydt.timedelta, /
    ) -> t.Self: ...
    @t.overload
    def add(
        self,
        other: None = None,
        /,
        *,
        hours: int = 0,
        minutes: int = 0,
        seconds: int = 0,
        milliseconds: int = 0,
        microseconds: int = 0,
        nanoseconds: int = 0,
    ) -> t.Self: ...
    @t.overload
    def sub(self, other: t.Self, /) -> SignedDuration: ...
    @t.overload
    def sub(
        self, other: TimeSpan | SignedDuration | Duration | pydt.timedelta, /
    ) -> t.Self: ...
    @t.overload
    def sub(
        self,
        other: None = None,
        /,
        *,
        hours: int = 0,
        minutes: int = 0,
        seconds: int = 0,
        milliseconds: int = 0,
        microseconds: int = 0,
        nanoseconds: int = 0,
    ) -> t.Self: ...
    def saturating_add(
        self, other: TimeSpan | SignedDuration | Duration | pydt.timedelta
    ) -> t.Self: ...
    def saturating_sub(
        self, other: TimeSpan | SignedDuration | Duration | pydt.timedelta
    ) -> t.Self: ...

    # =========================================================================
    # STRPTIME/STRFTIME
    # =========================================================================
    @classmethod
    def strptime(cls, string: str, /, fmt: str) -> t.Self: ...
    def strftime(self, fmt: str) -> str: ...
    def __format__(self, fmt: str) -> str: ...

    # =========================================================================
    # PROPERTIES
    # =========================================================================
    @property
    def second(self) -> int:
        """Return the second component of the timestamp

        Examples
        --------
        >>> import ry
        >>> ts = ry.Timestamp(5, 123_456_789)
        >>> ts.second
        5
        >>> ts = ry.Timestamp(-5, -123_456_789)
        >>> ts.second
        -5

        """

    @property
    def nanosecond(self) -> int:
        """Return the nanosecond component (-999_999_999..999_999_999)

        Examples
        --------
        >>> import ry
        >>> ts = ry.Timestamp(5, 123_456_789)
        >>> ts.nanosecond
        123456789
        >>> ts = ry.Timestamp(5, 999_999_999)
        >>> ts.nanosecond
        999999999
        >>> ts = ry.Timestamp(-5, -123_456_789)
        >>> ts.nanosecond
        -123456789
        >>> ts = ry.Timestamp(-5, -999_999_999)
        >>> ts.nanosecond
        -999999999

        """

    @property
    def subsec_microsecond(self) -> int:
        """Return the subsecond microsecond component (-999_999..999_999)

        Examples
        --------
        >>> import ry
        >>> ts = ry.Timestamp(5, 123_456_789)
        >>> ts.subsec_microsecond
        123456
        >>> ts = ry.Timestamp(5, 999_999_999)
        >>> ts.subsec_microsecond
        999999
        >>> ts = ry.Timestamp(-5, -123_456_789)
        >>> ts.subsec_microsecond
        -123456
        >>> ts = ry.Timestamp(-5, -999_999_999)
        >>> ts.subsec_microsecond
        -999999

        """

    @property
    def subsec_millisecond(self) -> int:
        """Return the subsecond millisecond component (-999..999)

        Examples
        --------
        >>> import ry
        >>> ts = ry.Timestamp(5, 123_456_789)
        >>> ts.subsec_millisecond
        123
        >>> ts = ry.Timestamp(5, 999_999_999)
        >>> ts.subsec_millisecond
        999
        >>> ts = ry.Timestamp(-5, -123_456_789)
        >>> ts.subsec_millisecond
        -123
        >>> ts = ry.Timestamp(-5, -999_999_999)
        >>> ts.subsec_millisecond
        -999

        """

    @property
    def subsec_nanosecond(self) -> int:
        """Return the subsecond nanosecond component (-999_999_999..999_999_999)

        Examples
        --------
        >>> import ry
        >>> ts = ry.Timestamp(5, 123_456_789)
        >>> ts.subsec_nanosecond
        123456789
        >>> ts = ry.Timestamp(5, 999_999_999)
        >>> ts.subsec_nanosecond
        999999999
        >>> ts = ry.Timestamp(-5, -123_456_789)
        >>> ts.subsec_nanosecond
        -123456789
        >>> ts = ry.Timestamp(-5, -999_999_999)
        >>> ts.subsec_nanosecond
        -999999999

        """

    # =========================================================================
    # INSTANCE METHODS
    # =========================================================================
    def date(self) -> Date: ...
    def datetime(self) -> DateTime: ...
    def isoformat(self) -> str: ...
    def iso_week_date(self) -> ISOWeekDate: ...
    def time(self) -> Time: ...
    def as_microsecond(self) -> int: ...
    def as_millisecond(self) -> int: ...
    def as_nanosecond(self) -> int: ...
    def as_second(self) -> int: ...
    def display_with_offset(self, offset: Offset) -> str: ...
    def in_tz(self, tz: _TzName) -> ZonedDateTime: ...
    @property
    def is_zero(self) -> bool: ...
    def series(self, period: TimeSpan) -> _JiffSeries[t.Self]: ...
    def signum(self) -> t.Literal[-1, 0, 1]: ...
    def to_string(self) -> str: ...
    def to_zoned_datetime(self, time_zone: TimeZone) -> ZonedDateTime: ...
    @deprecated(
        "`Timestamp.to_zoned` is deprecated; use `Timestamp.to_zoned_datetime` instead [removal: v0.0.112]"
    )
    def to_zoned(self, time_zone: TimeZone) -> ZonedDateTime: ...

    # =========================================================================
    # SINCE/UNTIL
    # =========================================================================
    def _since(self, other: TimestampDifference) -> TimeSpan: ...
    def _until(self, other: TimestampDifference) -> TimeSpan: ...
    def since(
        self,
        other: Timestamp | ZonedDateTime,
        *,
        smallest: _ExactUnit = "nanosecond",
        largest: _ExactUnit | None = None,
        mode: _RoundMode = "trunc",
        increment: int = 1,
    ) -> TimeSpan: ...
    def until(
        self,
        other: Timestamp | ZonedDateTime,
        *,
        smallest: _ExactUnit = "nanosecond",
        largest: _ExactUnit | None = None,
        mode: _RoundMode = "trunc",
        increment: int = 1,
    ) -> TimeSpan: ...
    def duration_since(self, other: t.Self) -> SignedDuration: ...
    def duration_until(self, other: t.Self) -> SignedDuration: ...
    def round(
        self,
        smallest: _ExactUnit = "nanosecond",
        *,
        mode: _RoundMode = "half-expand",
        increment: int = 1,
    ) -> t.Self: ...
    def _round(self, options: TimestampRound) -> t.Self: ...


@t.final
class ZonedDateTime(
    # protocols
    ToPy[pydt.datetime],
    ToPyDate,
    ToPyTime,
    ToPyDateTime,
    ToPyTzInfo,
    FromStr,
    _Parse,
    Strftime,
):
    __match_args__: t.Final = (
        "year",
        "month",
        "day",
        "hour",
        "minute",
        "second",
        "subsec_nanosecond",
    )
    UNIX_EPOCH: t.Final[ZonedDateTime]

    def __new__(
        cls,
        year: int,
        month: int,
        day: int,
        hour: int = 0,
        minute: int = 0,
        second: int = 0,
        nanosecond: int = 0,
        tz: _TzName | None = None,
    ) -> t.Self: ...

    # =========================================================================
    # PYTHON CONVERSIONS
    # =========================================================================
    @classmethod
    def from_pydatetime(cls, datetime: pydt.datetime) -> t.Self: ...
    def to_dict(self) -> _ZonedDateTimeDict: ...
    def to_py(self) -> pydt.datetime: ...
    def to_pydate(self) -> pydt.date: ...
    def to_pydatetime(self) -> pydt.datetime: ...
    def to_pytime(self) -> pydt.time: ...
    def to_pytzinfo(self) -> pydt.tzinfo: ...

    # =========================================================================
    # CLASS METHODS
    # =========================================================================
    @classmethod
    def now(cls, tz: _TzName | None = None) -> t.Self: ...
    @classmethod
    def utcnow(cls) -> t.Self: ...
    @classmethod
    def from_str(cls, s: str, /) -> t.Self: ...
    @classmethod
    def parse(cls, value: str | bytes, /) -> t.Self: ...
    @classmethod
    def from_rfc2822(cls, s: str) -> t.Self: ...
    @classmethod
    def parse_rfc2822(cls, s: str) -> t.Self: ...
    @classmethod
    def from_parts(cls, timestamp: Timestamp, time_zone: TimeZone) -> t.Self: ...

    # =========================================================================
    # STRPTIME/STRFTIME
    # =========================================================================
    @classmethod
    def strptime(cls, string: str, /, fmt: str) -> t.Self: ...
    def strftime(self, fmt: str) -> str: ...
    def __format__(self, fmt: str) -> str: ...

    # =========================================================================
    # PROPERTIES
    # =========================================================================
    @property
    def year(self) -> int: ...
    @property
    def month(self) -> int: ...
    @property
    def day(self) -> int: ...
    @property
    def hour(self) -> int: ...
    @property
    def minute(self) -> int: ...
    @property
    def second(self) -> int: ...
    @property
    def millisecond(self) -> int: ...
    @property
    def microsecond(self) -> int: ...
    @property
    def nanosecond(self) -> int: ...
    @property
    def subsec_nanosecond(self) -> int: ...
    @property
    def weekday(self) -> int: ...
    @property
    def timezone(self) -> TimeZone: ...
    @property
    def tz(self) -> TimeZone: ...

    # =========================================================================
    # STRING/FORMAT
    # =========================================================================
    def to_string(self) -> str: ...
    def to_rfc2822(self) -> str: ...
    def format_rfc2822(self) -> str: ...
    def isoformat(self) -> str: ...

    # =========================================================================
    # OPERATORS/DUNDERS
    # =========================================================================
    def __add__(
        self, other: TimeSpan | SignedDuration | Duration | pydt.timedelta, /
    ) -> t.Self: ...
    def __radd__(self, other: Duration | pydt.timedelta, /) -> t.Self: ...
    def __eq__(self, other: object, /) -> bool: ...
    def __ge__(self, other: t.Self, /) -> bool: ...
    def __gt__(self, other: t.Self, /) -> bool: ...
    def __hash__(self) -> int: ...
    def __le__(self, other: t.Self, /) -> bool: ...
    def __lt__(self, other: t.Self, /) -> bool: ...
    def __ne__(self, other: object, /) -> bool: ...

    # =========================================================================
    # OPERATORS/DUNDERS W/ OVERLOADS
    # =========================================================================
    @t.overload
    def __sub__(self, other: t.Self, /) -> TimeSpan: ...
    @t.overload
    def __sub__(
        self, other: TimeSpan | SignedDuration | Duration | pydt.timedelta, /
    ) -> t.Self: ...
    def __rsub__(self, other: t.Self, /) -> TimeSpan: ...

    # =========================================================================
    # ARITHMETIC METHODS
    # =========================================================================
    @t.overload
    def add(
        self, other: TimeSpan | SignedDuration | Duration | pydt.timedelta, /
    ) -> t.Self: ...
    @t.overload
    def add(
        self,
        other: None = None,
        /,
        *,
        years: int = 0,
        months: int = 0,
        weeks: int = 0,
        days: int = 0,
        hours: int = 0,
        minutes: int = 0,
        seconds: int = 0,
        milliseconds: int = 0,
        microseconds: int = 0,
        nanoseconds: int = 0,
    ) -> t.Self: ...
    @t.overload
    def sub(self, other: t.Self, /) -> TimeSpan: ...
    @t.overload
    def sub(
        self, other: TimeSpan | SignedDuration | Duration | pydt.timedelta, /
    ) -> t.Self: ...
    @t.overload
    def sub(
        self,
        other: None = None,
        /,
        *,
        years: int = 0,
        months: int = 0,
        weeks: int = 0,
        days: int = 0,
        hours: int = 0,
        minutes: int = 0,
        seconds: int = 0,
        milliseconds: int = 0,
        microseconds: int = 0,
        nanoseconds: int = 0,
    ) -> t.Self: ...
    def saturating_add(
        self, other: TimeSpan | SignedDuration | Duration | pydt.timedelta
    ) -> t.Self: ...
    def saturating_sub(
        self, other: TimeSpan | SignedDuration | Duration | pydt.timedelta
    ) -> t.Self: ...

    # =========================================================================
    # INSTANCE METHODS
    # =========================================================================
    def astimezone(self, tz: str) -> t.Self: ...
    def date(self) -> Date: ...
    def datetime(self) -> DateTime: ...
    def iso_week_date(self) -> ISOWeekDate: ...
    def day_of_year(self) -> int: ...
    def day_of_year_no_leap(self) -> int | None: ...
    def days_in_month(self) -> int: ...
    def days_in_year(self) -> int: ...
    def duration_since(self, other: t.Self) -> SignedDuration: ...
    def duration_until(self, other: t.Self) -> SignedDuration: ...
    def end_of_day(self) -> t.Self: ...
    def era_year(self) -> tuple[int, t.Literal["CE", "BCE"]]: ...
    def first_of_month(self) -> t.Self: ...
    def first_of_year(self) -> t.Self: ...
    def in_leap_year(self) -> bool: ...
    def in_tz(self, tz: _TzName) -> t.Self: ...
    def inutc(self) -> t.Self: ...
    def last_of_month(self) -> t.Self: ...
    def last_of_year(self) -> t.Self: ...
    def nth_weekday(self, nth: int, weekday: _Weekday) -> Date: ...
    def nth_weekday_of_month(self, nth: int, weekday: _Weekday) -> Date: ...
    def offset(self) -> Offset: ...
    def replace(
        self,
        obj: Date | DateTime | Time | Offset | None = None,
        *,
        date: Date | None = None,
        time: Time | None = None,
        year: int | None = None,
        era_year: tuple[int, t.Literal["BCE", "CE"]] | None = None,
        month: int | None = None,
        day: int | None = None,
        day_of_year: int | None = None,
        day_of_year_no_leap: int | None = None,
        hour: int | None = None,
        minute: int | None = None,
        second: int | None = None,
        millisecond: int | None = None,
        microsecond: int | None = None,
        nanosecond: int | None = None,
        subsec_nanosecond: int | None = None,
        offset: Offset | None = None,
        offset_conflict: t.Literal[
            "always-offset", "always-timezone", "prefer-offset", "reject"
        ]
        | None = None,
        disambiguation: t.Literal["compatible", "earliest", "latest", "reject"]
        | None = None,
    ) -> t.Self: ...
    def round(
        self,
        smallest: _ExactUnit | t.Literal["day"] = "nanosecond",
        *,
        mode: _RoundMode = "half-expand",
        increment: int = 1,
    ) -> t.Self: ...
    def _round(self, options: ZonedDateTimeRound) -> t.Self: ...
    def series(self, period: TimeSpan) -> _JiffSeries[t.Self]: ...
    def start_of_day(self) -> t.Self: ...
    def time(self) -> Time: ...
    def timestamp(self) -> Timestamp: ...
    def tomorrow(self) -> t.Self: ...
    def with_time_zone(self, tz: TimeZone) -> t.Self: ...
    def yesterday(self) -> t.Self: ...

    # =========================================================================
    # SINCE/UNTIL
    # =========================================================================
    def since(
        self,
        other: t.Self,
        *,
        smallest: _Unit = "nanosecond",
        largest: _Unit | None = None,
        mode: _RoundMode = "trunc",
        increment: int = 1,
    ) -> TimeSpan: ...
    def until(
        self,
        other: t.Self,
        *,
        smallest: _Unit = "nanosecond",
        largest: _Unit | None = None,
        mode: _RoundMode = "trunc",
        increment: int = 1,
    ) -> TimeSpan: ...


@t.final
class ISOWeekDate(
    # protocols
    ToPy[pydt.date],
    ToPyDate,
    FromStr,
    _Parse,
):
    MIN: t.Final[ISOWeekDate]
    MAX: t.Final[ISOWeekDate]
    ZERO: t.Final[ISOWeekDate]
    __match_args__: t.Final = ("year", "week", "weekday")

    def __new__(cls, year: int, week: int, weekday: _Weekday) -> t.Self: ...

    # =========================================================================
    # OPERATORS/DUNDERS
    # =========================================================================

    def __eq__(self, other: object, /) -> bool: ...
    def __ne__(self, other: object, /) -> bool: ...
    def __lt__(self, other: t.Self, /) -> bool: ...
    def __le__(self, other: t.Self, /) -> bool: ...
    def __gt__(self, other: t.Self, /) -> bool: ...
    def __ge__(self, other: t.Self, /) -> bool: ...
    def __hash__(self) -> int: ...

    # =========================================================================
    # CLASS METHODS
    # =========================================================================
    @classmethod
    def from_date(cls, date: Date) -> t.Self: ...
    @classmethod
    def from_pydate(cls, date: pydt.date) -> t.Self: ...
    @classmethod
    def from_str(cls, s: str, /) -> t.Self: ...
    @classmethod
    def parse(cls, value: str | bytes, /) -> t.Self: ...
    @classmethod
    def today(cls) -> t.Self: ...
    @classmethod
    def now(cls) -> t.Self: ...

    # =========================================================================
    # PROPERTIES
    # =========================================================================
    @property
    def year(self) -> int: ...
    @property
    def week(self) -> int: ...
    @property
    def weekday(self) -> _WeekdayInt: ...

    # =========================================================================
    # INSTANCE METHODS
    # =========================================================================
    def date(self) -> Date: ...
    def days_in_year(self) -> int: ...
    def weeks_in_year(self) -> int: ...
    def in_long_year(self) -> bool: ...
    def first_of_week(self) -> t.Self: ...
    def last_of_week(self) -> t.Self: ...
    def first_of_year(self) -> t.Self: ...
    def last_of_year(self) -> t.Self: ...
    def tomorrow(self) -> t.Self: ...
    def yesterday(self) -> t.Self: ...
    def isoformat(self) -> str: ...
    def to_py(self) -> pydt.date: ...
    def to_pydate(self) -> pydt.date: ...
    def to_string(self) -> str: ...
    def to_dict(self) -> _ISOWeekDateDict: ...


@t.final
class Offset(
    # protocols
    ToPy[pydt.tzinfo],
    ToPyTzInfo,
    ToPyTimeDelta,
    FromStr,
    _Parse,
):
    MIN: t.Final[Offset]
    MAX: t.Final[Offset]
    UTC: t.Final[Offset]
    ZERO: t.Final[Offset]

    def __new__(
        cls,
        hours: int = 0,
        minutes: int = 0,
        seconds: int = 0,
    ) -> t.Self: ...

    # =========================================================================
    # STRING
    # =========================================================================
    def to_string(self) -> str: ...

    # =========================================================================
    # OPERATORS/DUNDERS
    # =========================================================================
    def __neg__(self) -> t.Self: ...
    def __eq__(self, other: object, /) -> bool: ...
    def __ne__(self, other: object, /) -> bool: ...
    def __lt__(self, other: t.Self, /) -> bool: ...
    def __le__(self, other: t.Self, /) -> bool: ...
    def __gt__(self, other: t.Self, /) -> bool: ...
    def __ge__(self, other: t.Self, /) -> bool: ...
    def __hash__(self) -> int: ...

    # =========================================================================
    # PYTHON CONVERSIONS
    # =========================================================================
    # __FROM__
    @classmethod
    def from_pytimedelta(cls, delta: pydt.timedelta) -> t.Self: ...
    @classmethod
    def from_pytzinfo(cls, tz: pydt.tzinfo) -> t.Self: ...
    @classmethod
    def parse(cls, value: str | bytes, /) -> t.Self: ...
    @classmethod
    def from_str(cls, s: str, /) -> t.Self: ...

    # __TO__
    def to_dict(self) -> _OffsetDict: ...
    def to_py(self) -> pydt.tzinfo: ...
    def to_pytimedelta(self) -> pydt.timedelta: ...
    def to_pytzinfo(self) -> pydt.tzinfo: ...

    # =========================================================================
    # PROPERTIES
    # =========================================================================
    @property
    def seconds(self) -> int: ...
    @property
    def is_negative(self) -> bool: ...
    @property
    def is_positive(self) -> bool: ...

    # =========================================================================
    # FROM
    # =========================================================================
    @classmethod
    def utc(cls) -> t.Self: ...
    @classmethod
    def from_hours(cls, hours: int) -> t.Self: ...
    @classmethod
    def from_seconds(cls, seconds: int) -> t.Self: ...

    # =========================================================================
    # TO
    # =========================================================================
    def to_datetime(self, timestamp: Timestamp) -> DateTime: ...
    def to_timestamp(self, datetime: DateTime) -> Timestamp: ...
    def to_timezone(self) -> TimeZone: ...

    # =========================================================================
    # ARITHMETIC METHODS
    # =========================================================================
    @t.overload
    def add(
        self, other: Duration | SignedDuration | TimeSpan | pydt.timedelta, /
    ) -> t.Self: ...
    @t.overload
    def add(
        self,
        other: None = None,
        /,
        *,
        hours: int = 0,
        minutes: int = 0,
        seconds: int = 0,
        milliseconds: int = 0,
        microseconds: int = 0,
        nanoseconds: int = 0,
    ) -> t.Self: ...
    @t.overload
    def sub(
        self, other: Duration | SignedDuration | TimeSpan | pydt.timedelta, /
    ) -> t.Self: ...
    @t.overload
    def sub(
        self,
        other: None = None,
        /,
        *,
        hours: int = 0,
        minutes: int = 0,
        seconds: int = 0,
        milliseconds: int = 0,
        microseconds: int = 0,
        nanoseconds: int = 0,
    ) -> t.Self: ...
    def saturating_add(
        self, other: Duration | SignedDuration | TimeSpan | pydt.timedelta
    ) -> t.Self: ...
    def saturating_sub(
        self, other: Duration | SignedDuration | TimeSpan | pydt.timedelta
    ) -> t.Self: ...

    # =========================================================================
    # INSTANCE METHODS
    # =========================================================================
    def duration_since(self, other: Offset) -> SignedDuration: ...
    def duration_until(self, other: Offset) -> SignedDuration: ...
    def isoformat(self) -> str: ...
    def negate(self) -> t.Self: ...
    def since(self, other: t.Self) -> TimeSpan: ...
    def until(self, other: t.Self) -> TimeSpan: ...
    def round(
        self,
        smallest: _OffsetUnit = "second",
        *,
        mode: _RoundMode = "half-expand",
        increment: int = 1,
    ) -> t.Self: ...
    def _round(self, options: OffsetRound) -> t.Self: ...


# =============================================================================
# DIFFERENCE
# =============================================================================


@t.type_check_only
class _Difference(t.Generic[_TObj, _TUnit]):
    def __new__(
        cls,
        obj: _TObj,
        *,
        smallest: _TUnit,
        largest: _TUnit | None = None,
        mode: _RoundMode = "trunc",
        increment: int | None = None,
    ) -> t.Self: ...
    def __eq__(self, other: object, /) -> bool: ...
    @property
    def temporal(self) -> _TObj: ...
    @property
    def smallest(self) -> _TUnit: ...
    @property
    def largest(self) -> _TUnit | None: ...
    @property
    def mode(self) -> _RoundMode: ...
    @property
    def increment(self) -> int: ...
    def _smallest(self, unit: _TUnit) -> t.Self: ...
    def _largest(self, unit: _TUnit) -> t.Self: ...
    def _mode(self, mode: _RoundMode) -> t.Self: ...
    def _increment(self, increment: int) -> t.Self: ...
    def to_dict(self) -> _DifferenceDict[_TObj, _TUnit]: ...


@t.final
class DateDifference(_Difference[Date, _CalendarUnit]):
    def __new__(
        cls,
        date: Date,
        /,
        *,
        smallest: _Unit = "day",
        largest: _Unit | None = None,
        mode: _RoundMode = "trunc",
        increment: int = 1,
    ) -> t.Self: ...
    @property
    def date(self) -> Date: ...


@t.final
class DateTimeDifference(_Difference[DateTime, _Unit]):
    def __new__(
        cls,
        datetime: DateTime,
        /,
        *,
        smallest: _Unit = "nanosecond",
        largest: _Unit | None = None,
        mode: _RoundMode = "trunc",
        increment: int = 1,
    ) -> t.Self: ...
    @property
    def datetime(self) -> DateTime: ...


@t.final
class TimeDifference(_Difference[Time, _ExactUnit]):
    def __new__(
        cls,
        time: Time,
        /,
        *,
        smallest: _Unit = "nanosecond",
        largest: _Unit | None = None,
        mode: _RoundMode = "trunc",
        increment: int = 1,
    ) -> t.Self: ...
    @property
    def time(self) -> Time: ...


@t.final
class TimestampDifference(_Difference[Timestamp, _ExactUnit]):
    def __new__(
        cls,
        timestamp: Timestamp,
        /,
        *,
        smallest: _Unit = "nanosecond",
        largest: _Unit | None = None,
        mode: _RoundMode = "trunc",
        increment: int = 1,
    ) -> t.Self: ...
    @property
    def timestamp(self) -> Timestamp: ...


@t.final
class ZonedDateTimeDifference(_Difference[ZonedDateTime, _Unit]):
    def __new__(
        cls,
        zoned: ZonedDateTime,
        /,
        *,
        smallest: _Unit = "nanosecond",
        largest: _Unit | None = None,
        mode: _RoundMode = "trunc",
        increment: int = 1,
    ) -> t.Self: ...
    @property
    def zoned(self) -> ZonedDateTime: ...


# =============================================================================
# ROUND
# =============================================================================


@t.type_check_only
class _Round(t.Generic[_TObj, _TUnit]):
    def __eq__(self, other: object, /) -> bool: ...
    def _mode(self, mode: _RoundMode) -> t.Self: ...
    def _smallest(self, smallest: _TUnit) -> t.Self: ...
    def _increment(self, increment: int) -> t.Self: ...
    @property
    def smallest(self) -> _TUnit: ...
    @property
    def mode(self) -> _RoundMode: ...
    @property
    def increment(self) -> int: ...
    def replace(
        self,
        smallest: _TUnit | None = None,
        mode: _RoundMode | None = None,
        increment: int | None = None,
    ) -> t.Self: ...
    def to_dict(self) -> _RoundDict[_TUnit]: ...
    def round(self, ob: _TObj) -> _TObj: ...
    def __call__(self, ob: _TObj) -> _TObj: ...


@t.final
class DateTimeRound(_Round[DateTime, _RoundUnit]):
    def __new__(
        cls,
        smallest: _ExactUnit | t.Literal["day"] = "nanosecond",
        *,
        mode: _RoundMode = "half-expand",
        increment: int = 1,
    ) -> t.Self: ...
    def round(self, ob: DateTime) -> DateTime: ...


@t.final
class SignedDurationRound(_Round[SignedDuration, _ExactUnit]):
    def __new__(
        cls,
        smallest: _ExactUnit = "nanosecond",
        *,
        mode: _RoundMode = "half-expand",
        increment: int = 1,
    ) -> t.Self: ...
    def round(self, ob: SignedDuration) -> SignedDuration: ...


@t.final
class TimeRound(_Round[Time, _ExactUnit]):
    def __new__(
        cls,
        smallest: _ExactUnit = "nanosecond",
        *,
        mode: _RoundMode = "half-expand",
        increment: int = 1,
    ) -> t.Self: ...
    def round(self, ob: Time) -> Time: ...


@t.final
class TimestampRound(_Round[Timestamp, _ExactUnit]):
    def __new__(
        cls,
        smallest: _ExactUnit = "nanosecond",
        *,
        mode: _RoundMode = "half-expand",
        increment: int = 1,
    ) -> t.Self: ...
    def round(self, ob: Timestamp) -> Timestamp: ...


@t.final
class ZonedDateTimeRound(_Round[ZonedDateTime, _ExactUnit | t.Literal["day"]]):
    def __new__(
        cls,
        smallest: _ExactUnit | t.Literal["day"] = "nanosecond",
        *,
        mode: _RoundMode = "half-expand",
        increment: int = 1,
    ) -> t.Self: ...
    def round(self, ob: ZonedDateTime) -> ZonedDateTime: ...


@t.final
class OffsetRound(_Round[Offset, _OffsetUnit]):
    def __new__(
        cls,
        smallest: _OffsetUnit = "second",
        *,
        mode: _RoundMode = "half-expand",
        increment: int = 1,
    ) -> t.Self: ...
    def round(self, ob: Offset) -> Offset: ...


@t.type_check_only
class _JiffSeries(t.Protocol[_T]):
    def __iter__(self) -> _JiffSeries[_T]: ...
    def __next__(self) -> _T: ...
    def take(self, n: int = 1) -> list[_T]: ...
    def take_until(self, value: _T) -> list[_T]: ...
    def collect(self) -> list[_T]: ...


def date(year: int, month: int, day: int) -> Date: ...
def time(
    hour: int = 0, minute: int = 0, second: int = 0, nanosecond: int = 0
) -> Time: ...
def datetime(
    year: int,
    month: int,
    day: int,
    hour: int = 0,
    minute: int = 0,
    second: int = 0,
    nanosecond: int = 0,
) -> DateTime: ...
def zoned(
    year: int,
    month: int,
    day: int,
    hour: int = 0,
    minute: int = 0,
    second: int = 0,
    nanosecond: int = 0,
    tz: _TzName | None = None,
) -> ZonedDateTime: ...
def timespan(
    *,
    years: int = 0,
    months: int = 0,
    weeks: int = 0,
    days: int = 0,
    hours: int = 0,
    minutes: int = 0,
    seconds: int = 0,
    milliseconds: int = 0,
    microseconds: int = 0,
    nanoseconds: int = 0,
) -> TimeSpan: ...
def offset(hours: int) -> Offset: ...
def now() -> ZonedDateTime: ...
def utcnow() -> ZonedDateTime: ...


# =============================================================================
# TIMEZONE-DATABASE
# =============================================================================
@t.final
class TimeZoneDatabase:
    def __new__(cls) -> t.Self:
        """Defaults to using the `self.from_env`"""

    @t.overload
    def get(self, name: _TzName, err: t.Literal[False]) -> TimeZone | None:
        """Returns TimeZone or None if the timezone is not found"""

    @t.overload
    def get(self, name: _TzName, err: t.Literal[True] = True) -> TimeZone:
        """Returns TimeZone, if not found raises a ValueError"""

    def available(self) -> list[str]: ...
    def __getitem__(self, name: _TzName, /) -> TimeZone: ...
    def __len__(self) -> int: ...
    def is_definitively_empty(self) -> bool: ...
    @classmethod
    def from_env(cls) -> t.Self: ...
    @classmethod
    def from_dir(cls, path: str) -> t.Self: ...
    @classmethod
    def from_concatenated_path(cls, path: str) -> t.Self: ...
    @classmethod
    def bundled(cls) -> t.Self: ...


# =============================================================================
# TYPED-DICTS
# =============================================================================


class _DateDict(t.TypedDict):
    year: int
    month: int
    day: int


class _TimeDict(t.TypedDict):
    hour: int
    minute: int
    second: int
    nanosecond: int


class _DateTimeDict(t.TypedDict):
    year: int
    month: int
    day: int
    hour: int
    minute: int
    second: int
    nanosecond: int


class _ZonedDateTimeDict(t.TypedDict):
    year: int
    month: int
    day: int
    hour: int
    minute: int
    second: int
    nanosecond: int
    tz: str


class _TimestampDict(t.TypedDict):
    second: int
    nanosecond: int


class _SignedDurationDict(t.TypedDict):
    secs: int
    nanos: int


class _TimeSpanDict(t.TypedDict, total=False):
    """Timespan TypedDict

    Examples
    --------
    >>> import ry
    >>> ts = ry.timespan(years=1, months=2, weeks=3)
    >>> ts.to_dict()
    {'years': 1, 'months': 2, 'weeks': 3}
    >>> {**ts}
    {'years': 1, 'months': 2, 'weeks': 3}

    """

    years: int
    months: int
    weeks: int
    days: int
    hours: int
    minutes: int
    seconds: int
    milliseconds: int
    microseconds: int
    nanoseconds: int


class _TimeZoneDict(t.TypedDict):
    tz: str


class _OffsetDict(t.TypedDict):
    seconds: int
    fmt: str


class _OffsetInfoDict(t.TypedDict):
    offset: _OffsetDict
    dst: bool
    abbreviation: str


class _ISOWeekDateDict(t.TypedDict):
    year: int
    week: int
    weekday: int


class _DifferenceDict(t.TypedDict, t.Generic[_TObj, _TUnit]):
    mode: _RoundMode
    temporal: _TObj
    increment: int
    smallest: _TUnit
    largest: _TUnit | None


class _RoundDict(t.TypedDict, t.Generic[_TUnit]):
    smallest: _TUnit
    mode: _RoundMode
    increment: int
```

<h2 id="ry.ryo3._jiff_tz"><code>ry.ryo3._jiff_tz</code></h2>

```python
"""ryo3-jiff ~ tz types"""

import typing as t

TimezoneDbName: t.TypeAlias = t.Literal[
    "Africa/Abidjan",
    "Africa/Accra",
    "Africa/Addis_Ababa",
    "Africa/Algiers",
    "Africa/Asmara",
    "Africa/Asmera",
    "Africa/Bamako",
    "Africa/Bangui",
    "Africa/Banjul",
    "Africa/Bissau",
    "Africa/Blantyre",
    "Africa/Brazzaville",
    "Africa/Bujumbura",
    "Africa/Cairo",
    "Africa/Casablanca",
    "Africa/Ceuta",
    "Africa/Conakry",
    "Africa/Dakar",
    "Africa/Dar_es_Salaam",
    "Africa/Djibouti",
    "Africa/Douala",
    "Africa/El_Aaiun",
    "Africa/Freetown",
    "Africa/Gaborone",
    "Africa/Harare",
    "Africa/Johannesburg",
    "Africa/Juba",
    "Africa/Kampala",
    "Africa/Khartoum",
    "Africa/Kigali",
    "Africa/Kinshasa",
    "Africa/Lagos",
    "Africa/Libreville",
    "Africa/Lome",
    "Africa/Luanda",
    "Africa/Lubumbashi",
    "Africa/Lusaka",
    "Africa/Malabo",
    "Africa/Maputo",
    "Africa/Maseru",
    "Africa/Mbabane",
    "Africa/Mogadishu",
    "Africa/Monrovia",
    "Africa/Nairobi",
    "Africa/Ndjamena",
    "Africa/Niamey",
    "Africa/Nouakchott",
    "Africa/Ouagadougou",
    "Africa/Porto-Novo",
    "Africa/Sao_Tome",
    "Africa/Timbuktu",
    "Africa/Tripoli",
    "Africa/Tunis",
    "Africa/Windhoek",
    "America/Adak",
    "America/Anchorage",
    "America/Anguilla",
    "America/Antigua",
    "America/Araguaina",
    "America/Argentina/Buenos_Aires",
    "America/Argentina/Catamarca",
    "America/Argentina/ComodRivadavia",
    "America/Argentina/Cordoba",
    "America/Argentina/Jujuy",
    "America/Argentina/La_Rioja",
    "America/Argentina/Mendoza",
    "America/Argentina/Rio_Gallegos",
    "America/Argentina/Salta",
    "America/Argentina/San_Juan",
    "America/Argentina/San_Luis",
    "America/Argentina/Tucuman",
    "America/Argentina/Ushuaia",
    "America/Aruba",
    "America/Asuncion",
    "America/Atikokan",
    "America/Atka",
    "America/Bahia",
    "America/Bahia_Banderas",
    "America/Barbados",
    "America/Belem",
    "America/Belize",
    "America/Blanc-Sablon",
    "America/Boa_Vista",
    "America/Bogota",
    "America/Boise",
    "America/Buenos_Aires",
    "America/Cambridge_Bay",
    "America/Campo_Grande",
    "America/Cancun",
    "America/Caracas",
    "America/Catamarca",
    "America/Cayenne",
    "America/Cayman",
    "America/Chicago",
    "America/Chihuahua",
    "America/Ciudad_Juarez",
    "America/Coral_Harbour",
    "America/Cordoba",
    "America/Costa_Rica",
    "America/Coyhaique",
    "America/Creston",
    "America/Cuiaba",
    "America/Curacao",
    "America/Danmarkshavn",
    "America/Dawson",
    "America/Dawson_Creek",
    "America/Denver",
    "America/Detroit",
    "America/Dominica",
    "America/Edmonton",
    "America/Eirunepe",
    "America/El_Salvador",
    "America/Ensenada",
    "America/Fort_Nelson",
    "America/Fort_Wayne",
    "America/Fortaleza",
    "America/Glace_Bay",
    "America/Godthab",
    "America/Goose_Bay",
    "America/Grand_Turk",
    "America/Grenada",
    "America/Guadeloupe",
    "America/Guatemala",
    "America/Guayaquil",
    "America/Guyana",
    "America/Halifax",
    "America/Havana",
    "America/Hermosillo",
    "America/Indiana/Indianapolis",
    "America/Indiana/Knox",
    "America/Indiana/Marengo",
    "America/Indiana/Petersburg",
    "America/Indiana/Tell_City",
    "America/Indiana/Vevay",
    "America/Indiana/Vincennes",
    "America/Indiana/Winamac",
    "America/Indianapolis",
    "America/Inuvik",
    "America/Iqaluit",
    "America/Jamaica",
    "America/Jujuy",
    "America/Juneau",
    "America/Kentucky/Louisville",
    "America/Kentucky/Monticello",
    "America/Knox_IN",
    "America/Kralendijk",
    "America/La_Paz",
    "America/Lima",
    "America/Los_Angeles",
    "America/Louisville",
    "America/Lower_Princes",
    "America/Maceio",
    "America/Managua",
    "America/Manaus",
    "America/Marigot",
    "America/Martinique",
    "America/Matamoros",
    "America/Mazatlan",
    "America/Mendoza",
    "America/Menominee",
    "America/Merida",
    "America/Metlakatla",
    "America/Mexico_City",
    "America/Miquelon",
    "America/Moncton",
    "America/Monterrey",
    "America/Montevideo",
    "America/Montreal",
    "America/Montserrat",
    "America/Nassau",
    "America/New_York",
    "America/Nipigon",
    "America/Nome",
    "America/Noronha",
    "America/North_Dakota/Beulah",
    "America/North_Dakota/Center",
    "America/North_Dakota/New_Salem",
    "America/Nuuk",
    "America/Ojinaga",
    "America/Panama",
    "America/Pangnirtung",
    "America/Paramaribo",
    "America/Phoenix",
    "America/Port-au-Prince",
    "America/Port_of_Spain",
    "America/Porto_Acre",
    "America/Porto_Velho",
    "America/Puerto_Rico",
    "America/Punta_Arenas",
    "America/Rainy_River",
    "America/Rankin_Inlet",
    "America/Recife",
    "America/Regina",
    "America/Resolute",
    "America/Rio_Branco",
    "America/Rosario",
    "America/Santa_Isabel",
    "America/Santarem",
    "America/Santiago",
    "America/Santo_Domingo",
    "America/Sao_Paulo",
    "America/Scoresbysund",
    "America/Shiprock",
    "America/Sitka",
    "America/St_Barthelemy",
    "America/St_Johns",
    "America/St_Kitts",
    "America/St_Lucia",
    "America/St_Thomas",
    "America/St_Vincent",
    "America/Swift_Current",
    "America/Tegucigalpa",
    "America/Thule",
    "America/Thunder_Bay",
    "America/Tijuana",
    "America/Toronto",
    "America/Tortola",
    "America/Vancouver",
    "America/Virgin",
    "America/Whitehorse",
    "America/Winnipeg",
    "America/Yakutat",
    "America/Yellowknife",
    "Antarctica/Casey",
    "Antarctica/Davis",
    "Antarctica/DumontDUrville",
    "Antarctica/Macquarie",
    "Antarctica/Mawson",
    "Antarctica/McMurdo",
    "Antarctica/Palmer",
    "Antarctica/Rothera",
    "Antarctica/South_Pole",
    "Antarctica/Syowa",
    "Antarctica/Troll",
    "Antarctica/Vostok",
    "Arctic/Longyearbyen",
    "Asia/Aden",
    "Asia/Almaty",
    "Asia/Amman",
    "Asia/Anadyr",
    "Asia/Aqtau",
    "Asia/Aqtobe",
    "Asia/Ashgabat",
    "Asia/Ashkhabad",
    "Asia/Atyrau",
    "Asia/Baghdad",
    "Asia/Bahrain",
    "Asia/Baku",
    "Asia/Bangkok",
    "Asia/Barnaul",
    "Asia/Beirut",
    "Asia/Bishkek",
    "Asia/Brunei",
    "Asia/Calcutta",
    "Asia/Chita",
    "Asia/Choibalsan",
    "Asia/Chongqing",
    "Asia/Chungking",
    "Asia/Colombo",
    "Asia/Dacca",
    "Asia/Damascus",
    "Asia/Dhaka",
    "Asia/Dili",
    "Asia/Dubai",
    "Asia/Dushanbe",
    "Asia/Famagusta",
    "Asia/Gaza",
    "Asia/Harbin",
    "Asia/Hebron",
    "Asia/Ho_Chi_Minh",
    "Asia/Hong_Kong",
    "Asia/Hovd",
    "Asia/Irkutsk",
    "Asia/Istanbul",
    "Asia/Jakarta",
    "Asia/Jayapura",
    "Asia/Jerusalem",
    "Asia/Kabul",
    "Asia/Kamchatka",
    "Asia/Karachi",
    "Asia/Kashgar",
    "Asia/Kathmandu",
    "Asia/Katmandu",
    "Asia/Khandyga",
    "Asia/Kolkata",
    "Asia/Krasnoyarsk",
    "Asia/Kuala_Lumpur",
    "Asia/Kuching",
    "Asia/Kuwait",
    "Asia/Macao",
    "Asia/Macau",
    "Asia/Magadan",
    "Asia/Makassar",
    "Asia/Manila",
    "Asia/Muscat",
    "Asia/Nicosia",
    "Asia/Novokuznetsk",
    "Asia/Novosibirsk",
    "Asia/Omsk",
    "Asia/Oral",
    "Asia/Phnom_Penh",
    "Asia/Pontianak",
    "Asia/Pyongyang",
    "Asia/Qatar",
    "Asia/Qostanay",
    "Asia/Qyzylorda",
    "Asia/Rangoon",
    "Asia/Riyadh",
    "Asia/Saigon",
    "Asia/Sakhalin",
    "Asia/Samarkand",
    "Asia/Seoul",
    "Asia/Shanghai",
    "Asia/Singapore",
    "Asia/Srednekolymsk",
    "Asia/Taipei",
    "Asia/Tashkent",
    "Asia/Tbilisi",
    "Asia/Tehran",
    "Asia/Tel_Aviv",
    "Asia/Thimbu",
    "Asia/Thimphu",
    "Asia/Tokyo",
    "Asia/Tomsk",
    "Asia/Ujung_Pandang",
    "Asia/Ulaanbaatar",
    "Asia/Ulan_Bator",
    "Asia/Urumqi",
    "Asia/Ust-Nera",
    "Asia/Vientiane",
    "Asia/Vladivostok",
    "Asia/Yakutsk",
    "Asia/Yangon",
    "Asia/Yekaterinburg",
    "Asia/Yerevan",
    "Atlantic/Azores",
    "Atlantic/Bermuda",
    "Atlantic/Canary",
    "Atlantic/Cape_Verde",
    "Atlantic/Faeroe",
    "Atlantic/Faroe",
    "Atlantic/Jan_Mayen",
    "Atlantic/Madeira",
    "Atlantic/Reykjavik",
    "Atlantic/South_Georgia",
    "Atlantic/St_Helena",
    "Atlantic/Stanley",
    "Australia/ACT",
    "Australia/Adelaide",
    "Australia/Brisbane",
    "Australia/Broken_Hill",
    "Australia/Canberra",
    "Australia/Currie",
    "Australia/Darwin",
    "Australia/Eucla",
    "Australia/Hobart",
    "Australia/LHI",
    "Australia/Lindeman",
    "Australia/Lord_Howe",
    "Australia/Melbourne",
    "Australia/North",
    "Australia/NSW",
    "Australia/Perth",
    "Australia/Queensland",
    "Australia/South",
    "Australia/Sydney",
    "Australia/Tasmania",
    "Australia/Victoria",
    "Australia/West",
    "Australia/Yancowinna",
    "Brazil/Acre",
    "Brazil/DeNoronha",
    "Brazil/East",
    "Brazil/West",
    "Canada/Atlantic",
    "Canada/Central",
    "Canada/Eastern",
    "Canada/Mountain",
    "Canada/Newfoundland",
    "Canada/Pacific",
    "Canada/Saskatchewan",
    "Canada/Yukon",
    "CET",
    "Chile/Continental",
    "Chile/EasterIsland",
    "CST6CDT",
    "Cuba",
    "EET",
    "Egypt",
    "Eire",
    "EST",
    "EST5EDT",
    "Etc/GMT",
    "Etc/GMT+0",
    "Etc/GMT+1",
    "Etc/GMT+10",
    "Etc/GMT+11",
    "Etc/GMT+12",
    "Etc/GMT+2",
    "Etc/GMT+3",
    "Etc/GMT+4",
    "Etc/GMT+5",
    "Etc/GMT+6",
    "Etc/GMT+7",
    "Etc/GMT+8",
    "Etc/GMT+9",
    "Etc/GMT-0",
    "Etc/GMT-1",
    "Etc/GMT-10",
    "Etc/GMT-11",
    "Etc/GMT-12",
    "Etc/GMT-13",
    "Etc/GMT-14",
    "Etc/GMT-2",
    "Etc/GMT-3",
    "Etc/GMT-4",
    "Etc/GMT-5",
    "Etc/GMT-6",
    "Etc/GMT-7",
    "Etc/GMT-8",
    "Etc/GMT-9",
    "Etc/GMT0",
    "Etc/Greenwich",
    "Etc/UCT",
    "Etc/Universal",
    "Etc/UTC",
    "Etc/Zulu",
    "Europe/Amsterdam",
    "Europe/Andorra",
    "Europe/Astrakhan",
    "Europe/Athens",
    "Europe/Belfast",
    "Europe/Belgrade",
    "Europe/Berlin",
    "Europe/Bratislava",
    "Europe/Brussels",
    "Europe/Bucharest",
    "Europe/Budapest",
    "Europe/Busingen",
    "Europe/Chisinau",
    "Europe/Copenhagen",
    "Europe/Dublin",
    "Europe/Gibraltar",
    "Europe/Guernsey",
    "Europe/Helsinki",
    "Europe/Isle_of_Man",
    "Europe/Istanbul",
    "Europe/Jersey",
    "Europe/Kaliningrad",
    "Europe/Kiev",
    "Europe/Kirov",
    "Europe/Kyiv",
    "Europe/Lisbon",
    "Europe/Ljubljana",
    "Europe/London",
    "Europe/Luxembourg",
    "Europe/Madrid",
    "Europe/Malta",
    "Europe/Mariehamn",
    "Europe/Minsk",
    "Europe/Monaco",
    "Europe/Moscow",
    "Europe/Nicosia",
    "Europe/Oslo",
    "Europe/Paris",
    "Europe/Podgorica",
    "Europe/Prague",
    "Europe/Riga",
    "Europe/Rome",
    "Europe/Samara",
    "Europe/San_Marino",
    "Europe/Sarajevo",
    "Europe/Saratov",
    "Europe/Simferopol",
    "Europe/Skopje",
    "Europe/Sofia",
    "Europe/Stockholm",
    "Europe/Tallinn",
    "Europe/Tirane",
    "Europe/Tiraspol",
    "Europe/Ulyanovsk",
    "Europe/Uzhgorod",
    "Europe/Vaduz",
    "Europe/Vatican",
    "Europe/Vienna",
    "Europe/Vilnius",
    "Europe/Volgograd",
    "Europe/Warsaw",
    "Europe/Zagreb",
    "Europe/Zaporozhye",
    "Europe/Zurich",
    "Factory",
    "GB",
    "GB-Eire",
    "GMT",
    "GMT+0",
    "GMT-0",
    "GMT0",
    "Greenwich",
    "Hongkong",
    "HST",
    "Iceland",
    "Indian/Antananarivo",
    "Indian/Chagos",
    "Indian/Christmas",
    "Indian/Cocos",
    "Indian/Comoro",
    "Indian/Kerguelen",
    "Indian/Mahe",
    "Indian/Maldives",
    "Indian/Mauritius",
    "Indian/Mayotte",
    "Indian/Reunion",
    "Iran",
    "Israel",
    "Jamaica",
    "Japan",
    "Kwajalein",
    "Libya",
    "MET",
    "Mexico/BajaNorte",
    "Mexico/BajaSur",
    "Mexico/General",
    "MST",
    "MST7MDT",
    "Navajo",
    "NZ",
    "NZ-CHAT",
    "Pacific/Apia",
    "Pacific/Auckland",
    "Pacific/Bougainville",
    "Pacific/Chatham",
    "Pacific/Chuuk",
    "Pacific/Easter",
    "Pacific/Efate",
    "Pacific/Enderbury",
    "Pacific/Fakaofo",
    "Pacific/Fiji",
    "Pacific/Funafuti",
    "Pacific/Galapagos",
    "Pacific/Gambier",
    "Pacific/Guadalcanal",
    "Pacific/Guam",
    "Pacific/Honolulu",
    "Pacific/Johnston",
    "Pacific/Kanton",
    "Pacific/Kiritimati",
    "Pacific/Kosrae",
    "Pacific/Kwajalein",
    "Pacific/Majuro",
    "Pacific/Marquesas",
    "Pacific/Midway",
    "Pacific/Nauru",
    "Pacific/Niue",
    "Pacific/Norfolk",
    "Pacific/Noumea",
    "Pacific/Pago_Pago",
    "Pacific/Palau",
    "Pacific/Pitcairn",
    "Pacific/Pohnpei",
    "Pacific/Ponape",
    "Pacific/Port_Moresby",
    "Pacific/Rarotonga",
    "Pacific/Saipan",
    "Pacific/Samoa",
    "Pacific/Tahiti",
    "Pacific/Tarawa",
    "Pacific/Tongatapu",
    "Pacific/Truk",
    "Pacific/Wake",
    "Pacific/Wallis",
    "Pacific/Yap",
    "Poland",
    "Portugal",
    "PRC",
    "PST8PDT",
    "ROC",
    "ROK",
    "Singapore",
    "Turkey",
    "UCT",
    "Universal",
    "US/Alaska",
    "US/Aleutian",
    "US/Arizona",
    "US/Central",
    "US/East-Indiana",
    "US/Eastern",
    "US/Hawaii",
    "US/Indiana-Starke",
    "US/Michigan",
    "US/Mountain",
    "US/Pacific",
    "US/Samoa",
    "UTC",
    "W-SU",
    "WET",
    "Zulu",
]
```

<h2 id="ry.ryo3._jiter"><code>ry.ryo3._jiter</code></h2>

```python
"""ryo3-jiter ~ types"""

import typing as t
from os import PathLike

from ry._types import Buffer
from ry.ryo3._bytes import Bytes, ReadableBuffer

# =============================================================================
# JSON
# =============================================================================
_JsonPrimitive: t.TypeAlias = bool | int | float | str | None
_JsonValue: t.TypeAlias = _JsonPrimitive | dict[str, _JsonValue] | list[_JsonValue]


def parse_json(
    data: Buffer | bytes | str,
    *,
    allow_inf_nan: bool = False,
    cache_mode: t.Literal[True, False, "all", "keys", "none"] = "all",
    partial_mode: t.Literal[True, False, "off", "on", "trailing-strings"] = False,
    catch_duplicate_keys: bool = False,
) -> _JsonValue: ...
def parse_jsonl(
    data: Buffer | bytes | str,
    *,
    allow_inf_nan: bool = False,
    cache_mode: t.Literal[True, False, "all", "keys", "none"] = "all",
    partial_mode: t.Literal[True, False, "off", "on", "trailing-strings"] = False,
    catch_duplicate_keys: bool = False,
) -> list[_JsonValue]: ...
def read_json(
    p: str | PathLike[str],
    *,
    allow_inf_nan: bool = False,
    cache_mode: t.Literal[True, False, "all", "keys", "none"] = "all",
    partial_mode: t.Literal[True, False, "off", "on", "trailing-strings"] = False,
    catch_duplicate_keys: bool = False,
    lines: bool = False,
) -> _JsonValue: ...
def json_cache_clear() -> None: ...
def json_cache_usage() -> int: ...


# =============================================================================
# JSON-DECODE-ERROR
# =============================================================================
_JsonErrorKind: t.TypeAlias = t.Literal[
    "float-expecting-int",
    "duplicate-key",
    "internal-error",
    "eof-while-parsing-list",
    "eof-while-parsing-object",
    "eof-while-parsing-string",
    "eof-while-parsing-value",
    "expected-colon",
    "expected-list-comma-or-end",
    "expected-object-comma-or-end",
    "expected-some-ident",
    "expected-some-value",
    "invalid-escape",
    "invalid-number",
    "number-out-of-range",
    "invalid-unicode-code-point",
    "control-character-while-parsing-string",
    "key-must-be-a-string",
    "lone-leading-surrogate-in-hex-escape",
    "trailing-comma",
    "trailing-characters",
    "unexpected-end-of-hex-escape",
    "recursion-limit-exceeded",
]
_JsonErrorKindArg: t.TypeAlias = (
    _JsonErrorKind | tuple[t.Literal["duplicate-key", "internal-error"], str]
)


@t.final
class JSONDecodeError(ValueError):
    r"""JSON decode error; semi compatible w/ `json.JSONDecodeError`

    `doc` is only set when rust owns the bytes (response bodies, `read_json`)
    so you can still get at a consumed response body.

    Note
    ----
    This aint a subclass of `json.JSONDecodeError`; catch `ry.JSONDecodeError`
    or `ValueError`.

    Attributes
    ----------
    msg : str
        The unformatted error message.
    doc : Bytes | None
        The JSON document being parsed (or `None`); response bodies attach the
        json doc
    pos : int
        The start (byte) index of `doc` where parsing failed.
    lineno : int
        The line corresponding to `pos` (1-based).
    colno : int
        The column corresponding to `pos` (1-based).
    kind : str
        The error kind (e.g. `"trailing-comma"`).

    Examples
    --------
    >>> import ry
    >>> try:
    ...     ry.parse_json('{"a": 1,\n "b": 2,}')
    ... except ry.JSONDecodeError as e:
    ...     print(e)
    ...     print((e.msg, e.pos, e.lineno, e.colno, e.kind))
    trailing comma: line 2 column 9 (char 17)
    ('trailing comma', 17, 2, 9, 'trailing-comma')

    """

    def __new__(
        cls,
        kind: _JsonErrorKindArg,
        doc: ReadableBuffer | None = None,
        pos: int = 0,
        lineno: int | None = None,
        colno: int | None = None,
    ) -> t.Self: ...
    def __init__(
        self,
        kind: _JsonErrorKindArg,
        doc: ReadableBuffer | None = None,
        pos: int = 0,
        lineno: int | None = None,
        colno: int | None = None,
    ) -> None: ...
    @property
    def msg(self) -> str: ...
    @property
    def doc(self) -> Bytes | None: ...
    @property
    def pos(self) -> int: ...
    @property
    def lineno(self) -> int: ...
    @property
    def colno(self) -> int: ...
    @property
    def kind(self) -> _JsonErrorKind: ...
```

<h2 id="ry.ryo3._json"><code>ry.ryo3._json</code></h2>

```python
"""ryo3-json ~ types"""

import typing as t

from ry._types import Buffer
from ry.ryo3._bytes import Bytes
from ry.ryo3._jiter import JSONDecodeError as _JSONDecodeError
from ry.ryo3._jiter import _JsonValue


# `dtype=` output type ~ `ry.Bytes` (default) or `bytes`
@t.overload
def stringify(
    obj: t.Any,
    *,
    default: t.Callable[[t.Any], t.Any] | None = None,
    fmt: bool = False,
    sort_keys: bool = False,
    append_newline: bool = False,
    dtype: type[Bytes] = ...,
) -> Bytes: ...
@t.overload
def stringify(
    obj: t.Any,
    *,
    default: t.Callable[[t.Any], t.Any] | None = None,
    fmt: bool = False,
    sort_keys: bool = False,
    append_newline: bool = False,
    dtype: type[bytes],
) -> bytes: ...


@t.final
class JSON:
    """`ry.JSON` namespace (not instantiable)"""

    JSONDecodeError = _JSONDecodeError

    @staticmethod
    def minify(buf: Buffer | str, /, append_newline: bool = False) -> Bytes:
        """Return minified json data (remove whitespace, newlines)

        Parameters
        ----------
        buf : Buffer | str
            JSON buffer/string to minify

        Returns
        -------
        Bytes
            Minified JSON data as a `Bytes` object.

        Examples
        --------
        >>> import json as pyjson
        >>> from ry.ryo3 import JSON
        >>> data = {"key": "value", "number": 123, "bool": True}
        >>> json_str = pyjson.dumps(data, indent=2)
        >>> print(json_str)
        {
          "key": "value",
          "number": 123,
          "bool": true
        }
        >>> bytes(JSON.minify(json_str))
        b'{"key":"value","number":123,"bool":true}'

        """

    @staticmethod
    def fmt(buf: Buffer | str, /, append_newline: bool = False) -> Bytes:
        r"""Return formatted json data (add indentation, newlines)

        Parameters
        ----------
        buf : Buffer | str
            JSON buffer/string to format

        Returns
        -------
        Bytes
            Formatted JSON data as a `Bytes` object.

        Examples
        --------
        >>> import json as pyjson
        >>> from ry.ryo3 import JSON
        >>> data = {"key": "value", "number": 123, "bool": True}
        >>> json_str = pyjson.dumps(data, indent=2)
        >>> print(json_str)
        {
          "key": "value",
          "number": 123,
          "bool": true
        }
        >>> bytes(JSON.fmt(json_str)).decode()
        '{\n  "key": "value",\n  "number": 123,\n  "bool": true\n}'
        >>> print(bytes(JSON.fmt(json_str)).decode())
        {
          "key": "value",
          "number": 123,
          "bool": true
        }

        """

    @t.overload
    @staticmethod
    def stringify(
        obj: t.Any,
        *,
        default: t.Callable[[t.Any], t.Any] | None = None,
        fmt: bool = False,
        sort_keys: bool = False,
        append_newline: bool = False,
        dtype: type[Bytes] = ...,
    ) -> Bytes: ...
    @t.overload
    @staticmethod
    def stringify(
        obj: t.Any,
        *,
        default: t.Callable[[t.Any], t.Any] | None = None,
        fmt: bool = False,
        sort_keys: bool = False,
        append_newline: bool = False,
        dtype: type[bytes],
    ) -> bytes: ...
    @t.overload
    @staticmethod
    def dumps(
        obj: t.Any,
        *,
        default: t.Callable[[t.Any], t.Any] | None = None,
        fmt: bool = False,
        sort_keys: bool = False,
        append_newline: bool = False,
        dtype: type[Bytes] = ...,
    ) -> Bytes: ...
    @t.overload
    @staticmethod
    def dumps(
        obj: t.Any,
        *,
        default: t.Callable[[t.Any], t.Any] | None = None,
        fmt: bool = False,
        sort_keys: bool = False,
        append_newline: bool = False,
        dtype: type[bytes],
    ) -> bytes: ...
    @staticmethod
    def loads(
        data: Buffer | bytes | str,
        *,
        allow_inf_nan: bool = False,
        cache_mode: t.Literal[True, False, "all", "keys", "none"] = "all",
        partial_mode: t.Literal[True, False, "off", "on", "trailing-strings"] = False,
        catch_duplicate_keys: bool = False,
    ) -> _JsonValue: ...
    @staticmethod
    def parse(
        data: Buffer | bytes | str,
        *,
        allow_inf_nan: bool = False,
        cache_mode: t.Literal[True, False, "all", "keys", "none"] = "all",
        partial_mode: t.Literal[True, False, "off", "on", "trailing-strings"] = False,
        catch_duplicate_keys: bool = False,
    ) -> _JsonValue: ...
    @staticmethod
    def cache_clear() -> None: ...
    @staticmethod
    def cache_usage() -> int: ...
```

<h2 id="ry.ryo3._lz4rip"><code>ry.ryo3._lz4rip</code></h2>

```python
"""ryo3-lz4rip ~ types"""

import typing as t

from ry._types import Buffer
from ry.ryo3._bytes import Bytes

_Lz4BlockSize: t.TypeAlias = t.Literal[
    "auto", "max-64kb", "max-256kb", "max-1mb", "max-4mb", 0, 4, 5, 6, 7
]
_Lz4BlockMode: t.TypeAlias = t.Literal["independent", "linked"]


class Lz4FrameInfo(t.TypedDict, total=False):
    block_size: _Lz4BlockSize
    """block size for frame compression (default: `"auto"`/`0`)"""
    block_mode: _Lz4BlockMode
    """block dependency mode for frame compression (default: `"independent"`)"""
    block_checksums: bool
    """include a checksum (xxh32<seed=0>) for each frame block (default: `False`)"""
    content_checksum: bool
    """include a checksum (xxh32<seed=0>) of uncompressed data (default: `False`)"""
    content_size: int | None
    """include the total uncompressed size of data in the frame (default: `None`)"""


@t.final
class Lz4BlockCompressor:
    def __new__(cls, dictionary: Buffer | None = None, *, size: bool = False) -> t.Self:
        """lz4 block compressor

        Parameters
        ----------
        dictionary : Buffer or None, default None
            Optional compression dictionary (e.g. from `lz4_train_dict`).
        size : bool, default False
            If True (python-lz4 compatible), prepend the uncompressed size to
            the block as a u32-le integer.
        """

    def compress(self, data: Buffer, *, size: bool | None = None) -> Bytes:
        """compress a raw lz4 block

        Parameters
        ----------
        data : Buffer
            Data to compress.
        size : bool or None, default None
            If True (python-lz4 compatible), prepend the uncompressed size to
            the block as a u32-le integer. If None, use the default value
            passed to the constructor.

        """

    def __call__(self, data: Buffer, *, size: bool | None = None) -> Bytes:
        """compress a raw lz4 block (alias for `compress`)"""


@t.final
class Lz4BlockDecompressor:
    def __new__(cls, dictionary: Buffer | None = None) -> t.Self: ...
    def decompress(self, data: Buffer, size: int | None = None) -> Bytes: ...
    def __call__(self, data: Buffer, size: int | None = None) -> Bytes: ...


@t.final
class Lz4FrameCompressor:
    """streaming lz4 frame compressor

    `compress`/`flush` return the newly produced compressed bytes; `finish`
    ends the frame and returns the tail. The concatenation of all returned
    chunks is one complete lz4 frame.

    Parameters
    ----------
    dictionary : Buffer or None, default None
        Optional compression dictionary (e.g. from `lz4_train_dict`).
    dict_id : int or None, default None
        Dictionary id recorded in the frame header (default 0).
    frame_info : Lz4FrameInfo or None, default None
        Frame options (block size/mode, checksums, content size).
    """

    def __new__(
        cls,
        *,
        dictionary: Buffer | None = None,
        dict_id: int | None = None,
        frame_info: Lz4FrameInfo | None = None,
    ) -> t.Self: ...
    def compress(self, data: Buffer) -> Bytes: ...
    def flush(self) -> Bytes: ...
    def finish(self) -> Bytes: ...
    def copy(self) -> t.Self:
        """Return a new compressor with the same state (dictionary, dict_id, frame_info)"""

    def reset(self) -> None:
        """Reset the compressor to its initial state (dictionary, dict_id, frame_info)"""


def lz4_compress(
    data: Buffer,
    *,
    dictionary: Buffer | None = None,
    dict_id: int | None = None,
    frame_info: Lz4FrameInfo | None = None,
) -> Bytes:
    """compress data into a complete lz4 frame

    Parameters
    ----------
    data : Buffer
        Data to compress.
    dictionary : Buffer or None, default None
        Optional compression dictionary (e.g. from `lz4_train_dict`).
    dict_id : int or None, default None
        Dictionary id recorded in the frame header (default 0).
    frame_info : Lz4FrameInfo or None, default None
        Frame options (block size/mode, checksums, content size).

    Returns
    -------
    Bytes
        A complete lz4 frame.
    """


def lz4_compress_block(
    data: Buffer,
    *,
    size: bool = False,
    dictionary: Buffer | None = None,
) -> Bytes:
    """compress a raw lz4 block

    Parameters
    ----------
    data : Buffer
        Data to compress.
    size : bool, default False
        If True (python-lz4 compatible), prepend the uncompressed size to
        the block as a u32-le integer.
    dictionary : Buffer or None, default None
        Optional compression dictionary (e.g. from `lz4_train_dict`).

    Returns
    -------
    Bytes
        The compressed block.
    """


def lz4_decompress(
    data: Buffer,
    *,
    dictionary: Buffer | None = None,
    dict_id: int | None = None,
) -> Bytes:
    """Decompress a complete lz4 frame.

    Parameters
    ----------
    data : Buffer
        Complete lz4 frame data.
    dictionary : Buffer or None, default None
        Optional dictionary; must match the one used for compression.
    dict_id : int or None, default None
        Expected dictionary id (default 0).

    Returns
    -------
    Bytes
        The decompressed data.
    """


def lz4_decompress_block(
    data: Buffer,
    size: int | None = None,
    *,
    dictionary: Buffer | None = None,
) -> Bytes:
    """decompress a raw lz4 block

    Parameters
    ----------
    data : Buffer
        Compressed lz4 block data.
    size : int or None, default None
        If None (python-lz4 compatible), the block is expected to start
        with a u32-le uncompressed-size prefix (as written by
        `lz4_compress_block(..., size=True)`). Pass an explicit size
        (>= the actual uncompressed size) for prefix-less raw blocks.
    dictionary : Buffer or None, default None
        Optional dictionary; must match the one used for compression.

    Returns
    -------
    Bytes
        The decompressed data.
    """


def lz4_train_dict(samples: t.Iterable[Buffer], dict_size: int = 65535) -> Bytes:
    """train an lz4 dictionary from sample messages

    signature mirrors `compression.zstd.train_dict` but returns raw
    dictionary bytes usable as the `dictionary` argument of the lz4
    (de)compression functions/classes

    Parameters
    ----------
    samples : Iterable[Buffer]
        Sample messages to train on. Samples shorter than 4 bytes or
        longer than `dict_size` are silently skipped.
    dict_size : int, default 65535
        Maximum size of the trained dictionary in bytes; capped at 65535
        (the lz4 max match distance).

    Returns
    -------
    Bytes
        The trained dictionary (at most `dict_size` bytes).

    Raises
    ------
    ValueError
        If `dict_size` is not positive, or if training yields an empty
        dictionary (fewer than 2 usable samples).
    """
```

<h2 id="ry.ryo3._memchr"><code>ry.ryo3._memchr</code></h2>

```python
"""ryo3-memchr ~ types"""

import typing as t

from ry._types import Buffer

_Byte: t.TypeAlias = int | bytes


def memchr(needle: _Byte, haystack: Buffer) -> int | None: ...
def memchr2(needle1: _Byte, needle2: _Byte, haystack: Buffer) -> int | None: ...
def memchr3(
    needle1: _Byte, needle2: _Byte, needle3: _Byte, haystack: Buffer
) -> int | None: ...
def memrchr(needle: _Byte, haystack: Buffer) -> int | None: ...
def memrchr2(needle1: _Byte, needle2: _Byte, haystack: Buffer) -> int | None: ...
def memrchr3(
    needle1: _Byte, needle2: _Byte, needle3: _Byte, haystack: Buffer
) -> int | None: ...
```

<h2 id="ry.ryo3._orjson"><code>ry.ryo3._orjson</code></h2>

```python
"""orjson + ry types

orjson-types: https://github.com/ijl/orjson/blob/master/pysrc/orjson/__init__.pyi
"""

import typing as t

import orjson


def orjson_default(obj: t.Any) -> orjson.Fragment:
    """Fn to be used with `orjson.dumps` to serialize ry-compatible types

    Examples
    --------
    >>> import orjson
    >>> from ry import orjson_default, Date
    >>> data = {"key": "value", "date": Date(2023, 10, 1)}
    >>> orjson.dumps(data, default=orjson_default)
    b'{"key":"value","date":"2023-10-01"}'

    """
```

<h2 id="ry.ryo3._quick_maths"><code>ry.ryo3._quick_maths</code></h2>

```python
"""ryo3-quick-maths ~ types"""

import typing as t


def quick_maths() -> t.Literal[3]:
    """Perform "quick-maths"

    This function implements the expensive "quick-maths" algorithm, as
    formally specified in Shaq et al. (2017):

        "2 plus 2 is 4, minus one that's 3, quick maths." [1]_

    I (jesse) have verified the implementation by manually calculating using
    pen and paper.

    Notes
    -----
    This function originates from the ``_ryo3-quick-maths`` library which is
    a template (copy-pasta) library.

    References
    ----------
    .. [1] Big Shaq, M., et al. (2017). "Man's Not Hot".
       https://youtu.be/3M_5oYU-IsU?t=64

    Examples
    --------
    >>> import ry
    >>> ry.quick_maths()
    3

    """
```

<h2 id="ry.ryo3._regex"><code>ry.ryo3._regex</code></h2>

```python
"""ryo3-regex ~ types"""

import typing as t

# =============================================================================
# Regex
# =============================================================================


@t.final
class Regex:
    def __new__(
        cls,
        pattern: str,
        *,
        case_insensitive: bool = False,
        crlf: bool = False,
        dot_matches_new_line: bool = False,
        ignore_whitespace: bool = False,
        line_terminator: bytes | int | None = None,
        multi_line: bool = False,
        octal: bool = False,
        size_limit: int | None = None,
        swap_greed: bool = False,
        unicode: bool = True,
    ) -> t.Self: ...
    def is_match(self, haystack: str) -> bool: ...
    def test(self, haystack: str) -> bool: ...
    def find(self, haystack: str) -> str | None: ...
    def find_all(self, haystack: str) -> list[tuple[int, int]]: ...
    def findall(self, haystack: str) -> list[tuple[int, int]]: ...
    def replace(self, haystack: str, replacement: str) -> str: ...
    def replace_all(self, haystack: str, replacement: str) -> str: ...
    def split(self, haystack: str) -> list[str]: ...
    def splitn(self, haystack: str, n: int) -> list[str]: ...
```

<h2 id="ry.ryo3._reqwest"><code>ry.ryo3._reqwest</code></h2>

```python
"""ryo3-reqwest ~ types"""

import typing as t
from os import PathLike
from pathlib import Path
from types import TracebackType

import ry
from ry._types import Buffer, Unpack
from ry.ryo3._cookie import Cookie
from ry.ryo3._encoding_rs import Encoding
from ry.ryo3._http import Headers, HttpMethodLike, HttpStatus, HttpVersionLike
from ry.ryo3._std import Duration, SocketAddr
from ry.ryo3._url import URL

_Body: t.TypeAlias = (
    Buffer
    | FormData
    | t.Generator[Buffer]
    | t.AsyncGenerator[Buffer]
    | t.Iterable[Buffer]
    | t.AsyncIterable[Buffer]
)
# multipart
_T = t.TypeVar("_T")
_FormValue: t.TypeAlias = str | int | float | bool | Buffer | PathLike[str] | FormPart


class _FormPartDict(t.TypedDict):
    value: _FormValue
    filename: t.NotRequired[str | None]
    mime: t.NotRequired[str | None]
    headers: t.NotRequired[Headers | dict[str, str] | None]


_FormInput: t.TypeAlias = _FormValue | _FormPartDict
_FormPair: t.TypeAlias = tuple[str, _FormInput | list[_FormInput]]
_FormDataLike: t.TypeAlias = (
    FormData
    | t.Mapping[str, _FormInput | list[_FormInput]]
    | list[_FormPair]
    | tuple[_FormPair, ...]
)
# proxy
_ProxyKw: t.TypeAlias = t.Sequence[Proxy | URL | str] | Proxy | URL | str
# resolve
_ResolveMapLike: t.TypeAlias = dict[str, t.Sequence[SocketAddr]]


class RequestKwargs(t.TypedDict, total=False):
    body: _Body | None
    headers: Headers | dict[str, str] | None
    query: dict[str, t.Any] | t.Sequence[tuple[str, t.Any]] | None
    json: t.Any
    form: t.Any
    multipart: _FormDataLike | None
    timeout: Duration | None
    basic_auth: tuple[str, str | None] | None
    bearer_auth: str | None
    version: HttpVersionLike | None


class ClientConfig(t.TypedDict):
    headers: Headers | None  # default: None
    cookies: bool
    user_agent: (
        str | bool | None
    )  # None/True => default ("ry/{ry.__version__}"), False => disabled
    redirect: int | None
    resolve: _ResolveMapLike | None  # default: None
    referer: bool
    proxy: list[Proxy] | Proxy | None  # default: None
    hickory_dns: bool
    connection_verbose: bool  # default: False
    # ____ TIMEOUT ____
    timeout: Duration | None  # default: None
    connect_timeout: Duration | None  # default: None
    read_timeout: Duration | None  # default: None
    # ____ COMPRESSION / CONTENT-ENCODING ____
    gzip: bool
    brotli: bool
    deflate: bool
    zstd: bool
    # ____ HTTP1 ____
    http1_only: bool
    https_only: bool
    http1_title_case_headers: bool
    http1_max_headers: int  # default: 100
    http1_allow_obsolete_multiline_headers_in_responses: bool
    http1_allow_spaces_after_header_name_in_responses: bool
    http1_ignore_invalid_headers_in_responses: bool
    # ____ HTTP2 ____
    http2_prior_knowledge: bool
    http2_initial_stream_window_size: int | None
    http2_initial_connection_window_size: int | None
    http2_adaptive_window: bool
    http2_max_frame_size: int | None
    http2_max_header_list_size: int | None
    http2_keep_alive_interval: Duration | None
    http2_keep_alive_timeout: Duration | None
    http2_keep_alive_while_idle: bool
    # ____ POOL ____
    pool_idle_timeout: Duration | None
    pool_max_idle_per_host: int | None
    # ____ TCP ____
    tcp_keepalive: Duration | None
    tcp_keepalive_interval: Duration | None
    tcp_keepalive_retries: int | None
    tcp_nodelay: bool
    # ____ TLS ____
    identity: Identity | None
    tls_certs_merge: list[Certificate] | None
    tls_certs_only: list[Certificate] | None
    tls_crls_only: list[CertificateRevocationList] | None
    tls_info: bool
    tls_sni: bool
    tls_version_max: t.Literal["1.0", "1.1", "1.2", "1.3"] | None  # default: None
    tls_version_min: t.Literal["1.0", "1.1", "1.2", "1.3"] | None  # default: None
    tls_danger_accept_invalid_certs: bool  # default: False
    tls_danger_accept_invalid_hostnames: bool  # default: False
    # __ UNSTABLE __
    _tls_cached_native_certs: bool  # default: False


@t.final
class Client:
    """async http client"""

    def __new__(
        cls,
        *,
        headers: dict[str, str] | Headers | None = None,
        cookies: bool = False,
        user_agent: str | bool | None = None,
        timeout: Duration | None = None,
        connect_timeout: Duration | None = None,
        read_timeout: Duration | None = None,
        redirect: int | None = 10,
        resolve: _ResolveMapLike | None = None,
        referer: bool = True,
        connection_verbose: bool = False,
        gzip: bool = True,
        brotli: bool = True,
        deflate: bool = True,
        zstd: bool = True,
        hickory_dns: bool = True,
        http1_only: bool = False,
        https_only: bool = False,
        http1_title_case_headers: bool = False,
        http1_allow_obsolete_multiline_headers_in_responses: bool = False,
        http1_allow_spaces_after_header_name_in_responses: bool = False,
        http1_ignore_invalid_headers_in_responses: bool = False,
        http2_prior_knowledge: bool = False,
        http2_initial_stream_window_size: int | None = None,
        http2_initial_connection_window_size: int | None = None,
        http2_adaptive_window: bool = False,
        http2_max_frame_size: int | None = 65_536,
        http2_max_header_list_size: int | None = None,
        http2_keep_alive_interval: Duration | None = None,
        http2_keep_alive_timeout: Duration | None = None,
        http2_keep_alive_while_idle: bool = False,
        pool_idle_timeout: Duration | None = ...,  # 90 seconds
        pool_max_idle_per_host: int | None = ...,  # usize::MAX
        tcp_keepalive: Duration | None = ...,  # 15 seconds
        tcp_keepalive_interval: Duration | None = ...,  # 15 seconds
        tcp_keepalive_retries: int | None = 3,
        tcp_nodelay: bool = True,
        identity: Identity | None = None,
        tls_certs_only: list[Certificate] | None = None,
        tls_certs_merge: list[Certificate] | None = None,
        tls_crls_only: list[CertificateRevocationList] | None = None,
        tls_version_min: t.Literal["1.0", "1.1", "1.2", "1.3"] | None = None,
        tls_version_max: t.Literal["1.0", "1.1", "1.2", "1.3"] | None = None,
        tls_info: bool = False,
        tls_sni: bool = True,
        tls_danger_accept_invalid_certs: bool = False,
        tls_danger_accept_invalid_hostnames: bool = False,
        proxy: _ProxyKw | None = None,
        _tls_cached_native_certs: bool = False,
    ) -> t.Self: ...
    def config(self) -> ClientConfig: ...
    async def get(
        self,
        url: URL | str,
        **kwargs: Unpack[RequestKwargs],
    ) -> Response: ...
    async def post(
        self,
        url: URL | str,
        **kwargs: Unpack[RequestKwargs],
    ) -> Response: ...
    async def put(
        self,
        url: URL | str,
        **kwargs: Unpack[RequestKwargs],
    ) -> Response: ...
    async def delete(
        self,
        url: URL | str,
        **kwargs: Unpack[RequestKwargs],
    ) -> Response: ...
    async def head(
        self,
        url: URL | str,
        **kwargs: Unpack[RequestKwargs],
    ) -> Response: ...
    async def options(
        self,
        url: URL | str,
        **kwargs: Unpack[RequestKwargs],
    ) -> Response: ...
    async def patch(
        self,
        url: URL | str,
        **kwargs: Unpack[RequestKwargs],
    ) -> Response: ...
    async def query(
        self,
        url: URL | str,
        **kwargs: Unpack[RequestKwargs],
    ) -> Response: ...
    async def fetch(
        self,
        url: URL | str,
        *,
        method: HttpMethodLike = "GET",
        **kwargs: Unpack[RequestKwargs],
    ) -> Response: ...
    def fetch_sync(
        self,
        url: URL | str,
        *,
        method: HttpMethodLike = "GET",
        **kwargs: Unpack[RequestKwargs],
    ) -> BlockingResponse: ...
    async def __call__(
        self,
        url: URL | str,
        *,
        method: HttpMethodLike = "GET",
        **kwargs: Unpack[RequestKwargs],
    ) -> Response: ...


@t.final
class BlockingClient:
    def __new__(
        cls,
        *,
        headers: dict[str, str] | Headers | None = None,
        cookies: bool = False,
        user_agent: str | bool | None = None,
        timeout: Duration | None = None,
        connect_timeout: Duration | None = None,
        read_timeout: Duration | None = None,
        redirect: int | None = 10,
        resolve: _ResolveMapLike | None = None,
        referer: bool = True,
        connection_verbose: bool = False,
        gzip: bool = True,
        brotli: bool = True,
        deflate: bool = True,
        zstd: bool = True,
        hickory_dns: bool = True,
        http1_only: bool = False,
        https_only: bool = False,
        http1_title_case_headers: bool = False,
        http1_allow_obsolete_multiline_headers_in_responses: bool = False,
        http1_allow_spaces_after_header_name_in_responses: bool = False,
        http1_ignore_invalid_headers_in_responses: bool = False,
        http2_prior_knowledge: bool = False,
        http2_initial_stream_window_size: int | None = None,
        http2_initial_connection_window_size: int | None = None,
        http2_adaptive_window: bool = False,
        http2_max_frame_size: int | None = 65_536,
        http2_max_header_list_size: int | None = None,
        http2_keep_alive_interval: Duration | None = None,
        http2_keep_alive_timeout: Duration | None = None,
        http2_keep_alive_while_idle: bool = False,
        pool_idle_timeout: Duration | None = ...,  # 90 seconds
        pool_max_idle_per_host: int | None = ...,  # usize::MAX
        tcp_keepalive: Duration | None = ...,  # 15 seconds
        tcp_keepalive_interval: Duration | None = ...,  # 15 seconds
        tcp_keepalive_retries: int | None = 3,
        tcp_nodelay: bool = True,
        identity: Identity | None = None,
        tls_certs_only: list[Certificate] | None = None,
        tls_certs_merge: list[Certificate] | None = None,
        tls_crls_only: list[CertificateRevocationList] | None = None,
        tls_version_min: t.Literal["1.0", "1.1", "1.2", "1.3"] | None = None,
        tls_version_max: t.Literal["1.0", "1.1", "1.2", "1.3"] | None = None,
        tls_info: bool = False,
        tls_sni: bool = True,
        tls_danger_accept_invalid_certs: bool = False,
        tls_danger_accept_invalid_hostnames: bool = False,
        proxy: _ProxyKw | None = None,
        _tls_cached_native_certs: bool = False,
    ) -> t.Self: ...
    def config(self) -> ClientConfig: ...

    # ==== FETCH ====
    def fetch(
        self,
        url: URL | str,
        *,
        method: HttpMethodLike = "GET",
        **kwargs: Unpack[RequestKwargs],
    ) -> BlockingResponse: ...
    def __call__(
        self,
        url: URL | str,
        *,
        method: HttpMethodLike = "GET",
        **kwargs: Unpack[RequestKwargs],
    ) -> BlockingResponse: ...

    # ==== HTTP METHODS ====
    def get(
        self,
        url: URL | str,
        **kwargs: Unpack[RequestKwargs],
    ) -> BlockingResponse: ...
    def post(
        self,
        url: URL | str,
        **kwargs: Unpack[RequestKwargs],
    ) -> BlockingResponse: ...
    def put(
        self,
        url: URL | str,
        **kwargs: Unpack[RequestKwargs],
    ) -> BlockingResponse: ...
    def delete(
        self,
        url: URL | str,
        **kwargs: Unpack[RequestKwargs],
    ) -> BlockingResponse: ...
    def head(
        self,
        url: URL | str,
        **kwargs: Unpack[RequestKwargs],
    ) -> BlockingResponse: ...
    def options(
        self,
        url: URL | str,
        **kw: Unpack[RequestKwargs],
    ) -> BlockingResponse: ...
    def patch(
        self,
        url: URL | str,
        **kwargs: Unpack[RequestKwargs],
    ) -> BlockingResponse: ...
    def query(
        self,
        url: URL | str,
        **kwargs: Unpack[RequestKwargs],
    ) -> BlockingResponse: ...


@t.final
class ReqwestError(Exception):
    def __new__(cls, *args: t.Any, **kwargs: t.Any) -> t.Self: ...
    def __dbg__(self) -> str: ...
    def is_body(self) -> bool: ...
    def is_builder(self) -> bool: ...
    def is_connect(self) -> bool: ...
    def is_decode(self) -> bool: ...
    def is_redirect(self) -> bool: ...
    def is_request(self) -> bool: ...
    def is_status(self) -> bool: ...
    def is_timeout(self) -> bool: ...
    @property
    def status(self) -> HttpStatus | None: ...
    def url(self) -> URL | None: ...
    def without_url(self) -> None: ...
    def with_url(self, url: URL) -> ReqwestError: ...


@t.final
class Response:
    def __new__(cls) -> t.NoReturn: ...
    @property
    def headers(self) -> Headers: ...
    async def text(self, *, encoding: Encoding = "utf-8") -> str: ...
    async def text_with_charset(self, encoding: Encoding) -> str: ...
    async def json(
        self,
        *,
        allow_inf_nan: bool = False,
        cache_mode: t.Literal[True, False, "all", "keys", "none"] = "all",
        partial_mode: t.Literal[True, False, "off", "on", "trailing-strings"] = False,
        catch_duplicate_keys: bool = False,
    ) -> t.Any: ...
    async def bytes(self) -> ry.Bytes: ...
    def bytes_stream(
        self, min_read_size: int = 0, /
    ) -> ResponseStream: ...  # min_read_size=0 -> None
    def stream(
        self, min_read_size: int = 0, /
    ) -> ResponseStream: ...  # min_read_size=0 -> None
    def sse(self, *, max_event_size: int = 524288) -> EventStream: ...
    def raise_for_status(self) -> t.Self:
        """Raise `ReqwestError` if the status is 4xx/5xx, otherwise return self"""

    @property
    def url(self) -> URL: ...
    @property
    def version(
        self,
    ) -> t.Literal["HTTP/0.9", "HTTP/1.0", "HTTP/1.1", "HTTP/2.0", "HTTP/3.0"]: ...
    @property
    def http_version(
        self,
    ) -> t.Literal["HTTP/0.9", "HTTP/1.0", "HTTP/1.1", "HTTP/2.0", "HTTP/3.0"]: ...
    @property
    def redirected(self) -> bool: ...
    @property
    def content_length(self) -> int | None: ...
    @property
    def content_encoding(self) -> str | None: ...
    @property
    def cookies(self) -> list[Cookie] | None: ...
    @property
    def set_cookies(self) -> list[Cookie] | None: ...
    @property
    def body_used(self) -> bool:
        """True if the body has been consumed"""

    @property
    def ok(self) -> bool:
        """True if the status is a success (2xx)"""

    @property
    def remote_addr(self) -> SocketAddr | None: ...
    @property
    def status(self) -> int: ...
    @property
    def status_text(self) -> str: ...
    @property
    def status_code(self) -> HttpStatus: ...
    @property
    def peer_certificate(self) -> Certificate | None:
        """Peer's leaf certificate (needs `tls_info=True` on the client & https)"""

    @property
    def tls_version(self) -> t.Literal["1.0", "1.1", "1.2", "1.3"] | None:
        """Negotiated TLS version (needs `tls_info=True` on the client & https)"""

    def __bool__(self) -> bool:
        """Return `True` if the status is a success (2xx)"""


@t.final
class BlockingResponse:
    def __new__(cls) -> t.NoReturn: ...
    @property
    def headers(self) -> Headers: ...
    def text(self, *, encoding: Encoding = "utf-8") -> str: ...
    def text_with_charset(self, encoding: Encoding) -> str: ...
    def json(
        self,
        *,
        allow_inf_nan: bool = False,
        cache_mode: t.Literal[True, False, "all", "keys", "none"] = "all",
        partial_mode: t.Literal[True, False, "off", "on", "trailing-strings"] = False,
        catch_duplicate_keys: bool = False,
    ) -> t.Any: ...
    def bytes(self) -> ry.Bytes: ...
    def bytes_stream(self, min_read_size: int = 0, /) -> BlockingResponseStream: ...
    def stream(self, min_read_size: int = 0, /) -> BlockingResponseStream: ...
    def sse(self, *, max_event_size: int = 524288) -> BlockingEventStream: ...
    def raise_for_status(self) -> t.Self:
        """Raise `ReqwestError` if the status is 4xx/5xx, otherwise return self"""

    @property
    def url(self) -> URL: ...
    @property
    def version(
        self,
    ) -> t.Literal["HTTP/0.9", "HTTP/1.0", "HTTP/1.1", "HTTP/2.0", "HTTP/3.0"]: ...
    @property
    def http_version(
        self,
    ) -> t.Literal["HTTP/0.9", "HTTP/1.0", "HTTP/1.1", "HTTP/2.0", "HTTP/3.0"]: ...
    @property
    def redirected(self) -> bool: ...
    @property
    def content_length(self) -> int | None: ...
    @property
    def content_encoding(self) -> str | None: ...
    @property
    def cookies(self) -> list[Cookie] | None: ...
    @property
    def set_cookies(self) -> list[Cookie] | None: ...
    @property
    def body_used(self) -> bool:
        """True if the body has been consumed"""

    @property
    def ok(self) -> bool:
        """True if the status is a success (2xx)"""

    @property
    def remote_addr(self) -> SocketAddr | None: ...
    @property
    def status(self) -> int: ...
    @property
    def status_text(self) -> str: ...
    @property
    def status_code(self) -> HttpStatus: ...
    @property
    def peer_certificate(self) -> Certificate | None:
        """Peer's leaf certificate (needs `tls_info=True` on the client & https)"""

    @property
    def tls_version(self) -> t.Literal["1.0", "1.1", "1.2", "1.3"] | None:
        """Negotiated TLS version (needs `tls_info=True` on the client & https)"""

    def __bool__(self) -> bool:
        """Return `True` if the status is a success (2xx)"""


@t.final
class ResponseStream:
    async def __aenter__(self) -> t.Self: ...
    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None: ...
    async def close(self) -> None: ...
    def __aiter__(self) -> ResponseStream: ...
    async def __anext__(self) -> ry.Bytes: ...
    async def readall(self) -> ry.Bytes: ...
    async def take(self, n: int = 1) -> list[ry.Bytes]: ...
    @t.overload
    async def collect(self, join: t.Literal[True]) -> ry.Bytes: ...
    @t.overload
    async def collect(self, join: t.Literal[False] = False) -> list[ry.Bytes]: ...


@t.final
class BlockingResponseStream:
    def __enter__(self) -> t.Self: ...
    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None: ...
    def close(self) -> None: ...
    def __iter__(self) -> BlockingResponseStream: ...
    def __next__(self) -> ry.Bytes: ...
    def readall(self) -> ry.Bytes: ...
    def take(self, n: int = 1) -> list[ry.Bytes]: ...
    def collect(self) -> list[ry.Bytes]: ...


@t.final
class ServerSentEvent:
    @property
    def event(self) -> str: ...
    @property
    def data(self) -> str: ...
    @property
    def bytes(self) -> ry.Bytes: ...
    @property
    def last_event_id(self) -> str: ...
    def json(
        self,
        *,
        allow_inf_nan: bool = False,
        cache_mode: t.Literal[True, False, "all", "keys", "none"] = "all",
        partial_mode: t.Literal[True, False, "off", "on", "trailing-strings"] = False,
        catch_duplicate_keys: bool = False,
    ) -> t.Any: ...
    def __eq__(self, other: object) -> bool: ...


@t.final
class EventStream:
    @property
    def url(self) -> URL: ...
    @property
    def last_event_id(self) -> str: ...
    @property
    def retry(self) -> int | None: ...
    async def __aenter__(self) -> t.Self: ...
    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None: ...
    async def close(self) -> None: ...
    def __aiter__(self) -> EventStream: ...
    async def __anext__(self) -> ServerSentEvent: ...


@t.final
class BlockingEventStream:
    @property
    def url(self) -> URL: ...
    @property
    def last_event_id(self) -> str: ...
    @property
    def retry(self) -> int | None: ...
    def __enter__(self) -> t.Self: ...
    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None: ...
    def close(self) -> None: ...
    def __iter__(self) -> BlockingEventStream: ...
    def __next__(self) -> ServerSentEvent: ...


async def fetch(
    url: URL | str,
    *,
    method: HttpMethodLike = "GET",
    body: _Body | None = None,
    headers: Headers | dict[str, str] | None = None,
    query: dict[str, t.Any] | t.Sequence[tuple[str, t.Any]] | None = None,
    json: t.Any = None,
    form: t.Any = None,
    multipart: _FormDataLike | None = None,
    timeout: Duration | None = None,
    basic_auth: tuple[str, str | None] | None = None,
    bearer_auth: str | None = None,
    version: HttpVersionLike | None = None,
) -> Response: ...
def fetch_sync(
    url: URL | str,
    *,
    method: HttpMethodLike = "GET",
    body: _Body | None = None,
    headers: Headers | dict[str, str] | None = None,
    query: dict[str, t.Any] | t.Sequence[tuple[str, t.Any]] | None = None,
    json: t.Any = None,
    form: t.Any = None,
    multipart: _FormDataLike | None = None,
    timeout: Duration | None = None,
    basic_auth: tuple[str, str | None] | None = None,
    bearer_auth: str | None = None,
    version: HttpVersionLike | None = None,
) -> BlockingResponse: ...


@t.final
class Certificate:
    def __bytes__(self) -> bytes: ...
    def __hash__(self) -> int: ...
    def __eq__(self, other: object, /) -> bool: ...
    def __ne__(self, other: object, /) -> bool: ...
    @classmethod
    def from_der(cls, der: Buffer) -> t.Self: ...
    @classmethod
    def from_pem(cls, pem: Buffer) -> t.Self: ...
    @classmethod
    def from_pem_bundle(cls, pem_bundle: Buffer) -> list[t.Self]: ...


@t.final
class CertificateRevocationList:
    def __new__(cls, pem: Buffer) -> t.Self: ...
    def __bytes__(self) -> bytes: ...
    def __hash__(self) -> int: ...
    def __eq__(self, other: object, /) -> bool: ...
    def __ne__(self, other: object, /) -> bool: ...
    @classmethod
    def from_pem(cls, pem: Buffer) -> t.Self: ...
    @classmethod
    def from_pem_bundle(cls, pem_bundle: Buffer) -> list[t.Self]: ...


@t.final
class Identity:
    def __new__(cls, pem: Buffer) -> t.Self: ...
    def __bytes__(self) -> bytes: ...
    def __hash__(self) -> int: ...
    def __eq__(self, other: object, /) -> bool: ...
    def __ne__(self, other: object, /) -> bool: ...
    @classmethod
    def from_pem(cls, pem: Buffer) -> t.Self: ...


class ProxyKwargs(t.TypedDict, total=False):
    basic_auth: tuple[str, str] | None
    no_proxy: str | None
    headers: Headers | dict[str, str] | None


@t.final
class Proxy:
    def __new__(
        cls,
        url: URL | str,
        ptype: t.Literal["http", "https", "all"] = "http",
        *,
        basic_auth: tuple[str, str] | None = None,
        headers: Headers | dict[str, str] | None = None,
        no_proxy: str | None = None,
    ) -> t.Self: ...
    @staticmethod
    def all(
        url: URL | str,
        *,
        basic_auth: tuple[str, str] | None = None,
        headers: Headers | dict[str, str] | None = None,
        no_proxy: str | None = None,
    ) -> Proxy: ...
    @staticmethod
    def http(
        url: URL | str,
        *,
        basic_auth: tuple[str, str] | None = None,
        headers: Headers | dict[str, str] | None = None,
        no_proxy: str | None = None,
    ) -> Proxy: ...
    @staticmethod
    def https(
        url: URL | str,
        *,
        basic_auth: tuple[str, str] | None = None,
        headers: Headers | dict[str, str] | None = None,
        no_proxy: str | None = None,
    ) -> Proxy: ...
    # -------------------------------------------------------------------------
    # BUILDERS
    # -------------------------------------------------------------------------
    def basic_auth(self, username: str, password: str) -> Proxy: ...
    def no_proxy(self, url: str) -> Proxy: ...
    def headers(self, headers: Headers | dict[str, str]) -> Proxy: ...
    # -------------------------------------------------------------------------
    # DUNDERS
    # -------------------------------------------------------------------------
    def __eq__(self, other: object, /) -> bool: ...
    def __hash__(self) -> int: ...


# =============================================================================
# MULTIPART
# =============================================================================
@t.final
class FormPart:
    """A multipart/form-data part w/ options (filename, mime, headers)

    value types: str -> text, int/float/bool -> text, bytes-like -> binary,
    os.PathLike -> file (opened + streamed per request; filename + mime
    default from the path)
    """

    def __new__(
        cls,
        value: _FormValue,
        /,
        *,
        filename: str | None = None,
        mime: str | None = None,
        headers: Headers | dict[str, str] | None = None,
    ) -> t.Self: ...
    @property
    def value(self) -> str | ry.Bytes | Path: ...
    @property
    def filename(self) -> str | None: ...
    @property
    def mime(self) -> str | None: ...
    @property
    def headers(self) -> Headers | None: ...
    def __eq__(self, other: object, /) -> bool: ...
    def __ne__(self, other: object, /) -> bool: ...
    def __hash__(self) -> int: ...


@t.final
class FormData:
    """multipart/form-data (mutable multimap like js `FormData`)

    Values are snapshotted when a request is built ~ mutating a `FormData`
    does not affect requests already made and it can be reused.

    `get`/`get_all`/`values`/`items` give back `str` for plain text values
    and `FormPart` for everything else.
    """

    def __new__(
        cls,
        data: _FormDataLike | None = None,
        /,
        *,
        percent_encode: t.Literal["path-segment", "attr-chars", "noop"] | None = None,
    ) -> t.Self: ...
    @property
    def percent_encode(
        self,
    ) -> t.Literal["path-segment", "attr-chars", "noop"] | None: ...
    def append(
        self,
        name: str,
        value: _FormValue,
        /,
        *,
        filename: str | None = None,
        mime: str | None = None,
        headers: Headers | dict[str, str] | None = None,
    ) -> None: ...
    def set(
        self,
        name: str,
        value: _FormValue,
        /,
        *,
        filename: str | None = None,
        mime: str | None = None,
        headers: Headers | dict[str, str] | None = None,
    ) -> None: ...
    def delete(self, name: str) -> None: ...
    def extend(self, other: _FormDataLike, /) -> None: ...
    @t.overload
    def get(self, name: str) -> str | FormPart | None: ...
    @t.overload
    def get(self, name: str, default: _T) -> str | FormPart | _T: ...
    def get_all(self, name: str) -> list[str | FormPart]: ...
    def keys(self) -> list[str]: ...
    def values(self) -> list[str | FormPart]: ...
    def items(self) -> list[tuple[str, str | FormPart]]: ...
    def copy(self) -> FormData: ...
    def __copy__(self) -> FormData: ...
    def __deepcopy__(self, memo: object) -> FormData: ...
    def __len__(self) -> int: ...
    def __contains__(self, name: object, /) -> bool: ...
    def __iter__(self) -> t.Iterator[str]: ...
    def __getitem__(self, name: str, /) -> str | FormPart: ...
    def __setitem__(self, name: str, value: _FormValue, /) -> None: ...
    def __delitem__(self, name: str, /) -> None: ...
    def __eq__(self, other: object, /) -> bool: ...
    def __ne__(self, other: object, /) -> bool: ...
```

<h2 id="ry.ryo3._same_file"><code>ry.ryo3._same_file</code></h2>

```python
"""ryo3-same-file ~ types"""

from os import PathLike


def is_same_file(left: str | PathLike[str], right: str | PathLike[str]) -> bool: ...
```

<h2 id="ry.ryo3._sh"><code>ry.ryo3._sh</code></h2>

```python
import typing as t
from os import PathLike

from ry.ryo3._fspath import FsPath


def pwd() -> str: ...
def home() -> str: ...
def cd(path: str | PathLike[str]) -> None: ...
@t.overload
def ls(
    path: str | PathLike[str] | None = None,  # defaults to '.' if None
    *,
    absolute: bool = False,
    sort: bool = False,
    objects: t.Literal[False] = False,
) -> list[str]:
    """List directory contents returning a list of strings"""


@t.overload
def ls(
    path: str | PathLike[str] | None = None,  # defaults to '.' if None
    *,
    absolute: bool = False,
    sort: bool = False,
    objects: t.Literal[True],
) -> list[FsPath]:
    """List directory contents returning a list of `FsPath` objects"""


def mkdir(
    path: str | PathLike[str], *, exist_ok: bool = False, recursive: bool = False
) -> None: ...
def mkdirp(path: str | PathLike[str]) -> None: ...
```

<h2 id="ry.ryo3._shlex"><code>ry.ryo3._shlex</code></h2>

```python
"""ryo3-shlex ~ types"""


def shplit(s: str) -> list[str]:
    """shlex::split wrapper much like python's stdlib shlex.split but faster"""
```

<h2 id="ry.ryo3._size"><code>ry.ryo3._size</code></h2>

```python
"""ryo3-size ~ types"""

import builtins
import typing as t

from ry.protocols import FromStr, _Parse

_TFormatSizeBase: t.TypeAlias = t.Literal[2, 10]  # default=2
_TFormatSizeStyle: t.TypeAlias = t.Literal[  # default="default"
    "default",
    "abbreviated",
    "abbreviated-lowercase",
    "full",
    "full-lowercase",
]


def fmt_size(
    n: int,
    *,
    base: _TFormatSizeBase = 2,
    style: _TFormatSizeStyle = "default",
    scale: int | None = None,
) -> str:
    """Return human-readable string representation of bytes-size.

    Parameters
    ----------
    n : int
        Size in bytes.
    base : {2, 10}, default 2
        Base 2 (KiB, MiB, ...) or base 10 (KB, MB, ...) units.
    style : {"default", "abbreviated", "abbreviated-lowercase", "full", "full-lowercase"}, default "default"
        Unit style.
    scale : int or None, default None
        Number of decimal places 0..=255; `None` uses the per-unit default.

    Returns
    -------
    str
        Human-readable size string.

    Raises
    ------
    ValueError
        If `base` or `style` is invalid.
    OverflowError
        If `scale` is not in 0..=255.

    Examples
    --------
    >>> from ry import fmt_size
    >>> fmt_size(1000)
    '1000 bytes'
    >>> fmt_size(1024)
    '1.00 KiB'
    >>> fmt_size(1000, base=10)
    '1.00 KB'
    >>> fmt_size(1024, base=2)
    '1.00 KiB'
    >>> fmt_size(1536, scale=3)
    '1.500 KiB'

    """


def parse_size(s: str) -> int:
    """Return integer representation of human-readable bytes-size string.

    Raises
    ------
    ValueError
        If string is not a valid human-readable bytes-size string.

    Examples
    --------
    >>> from ry import parse_size
    >>> parse_size("1 KB")
    1000
    >>> parse_size("1 KiB")
    1024

    """


@t.final
class SizeFormatter:
    """Human-readable bytes-size formatter."""

    def __new__(
        cls,
        base: _TFormatSizeBase = 2,
        style: _TFormatSizeStyle = "default",
        scale: int | None = None,
    ) -> t.Self:
        """Initialize human-readable bytes-size formatter.

        Parameters
        ----------
        base : {2, 10}, default 2
            Base 2 (KiB, MiB, ...) or base 10 (KB, MB, ...) units.
        style : {"default", "abbreviated", "abbreviated-lowercase", "full", "full-lowercase"}, default "default"
            Unit style.
        scale : int or None, default None
            Number of decimal places 0..=255; `None` uses the per-unit default.

        Raises
        ------
        ValueError
            If `base` or `style` is invalid.
        OverflowError
            If `scale` is not in 0..=255.

        """

    def format(self, n: int) -> str:
        """Return human-readable string representation of bytes-size."""

    def __call__(self, n: int) -> str:
        """Return human-readable string representation of bytes-size."""

    @property
    def base(self) -> _TFormatSizeBase:
        """Return base used by formatter."""

    @property
    def style(self) -> _TFormatSizeStyle:
        """Return style used by formatter."""

    @property
    def scale(self) -> int | None:
        """Return scale (decimal places) used by formatter."""

    def with_base(self, base: _TFormatSizeBase) -> SizeFormatter:
        """Return new `SizeFormatter` with specified base."""

    def with_style(self, style: _TFormatSizeStyle) -> SizeFormatter:
        """Return new `SizeFormatter` with specified style."""

    def with_scale(self, scale: int | None) -> SizeFormatter:
        """Return new `SizeFormatter` with specified scale.

        Parameters
        ----------
        scale : int or None
            Number of decimal places 0..=255; `None` uses the per-unit default.

        Returns
        -------
        SizeFormatter
            New formatter with the same base and style.

        Raises
        ------
        OverflowError
            If `scale` is not in 0..=255.

        """


@t.final
class Size(FromStr, _Parse):
    """Bytes-size object"""

    def __new__(cls, size: int) -> t.Self: ...
    @property
    def bytes(self) -> int: ...
    def format(
        self,
        *,
        base: _TFormatSizeBase = 2,
        style: _TFormatSizeStyle = "default",
        scale: int | None = None,
    ) -> str:
        """Return human-readable string representation of the size.

        Parameters
        ----------
        base : {2, 10}, default 2
            Base 2 (KiB, MiB, ...) or base 10 (KB, MB, ...) units.
        style : {"default", "abbreviated", "abbreviated-lowercase", "full", "full-lowercase"}, default "default"
            Unit style.
        scale : int or None, default None
            Number of decimal places 0..=255; `None` uses the per-unit default.

        Returns
        -------
        str
            Human-readable size string.

        Raises
        ------
        ValueError
            If `base` or `style` is invalid.
        OverflowError
            If `scale` is not in 0..=255.

        Examples
        --------
        >>> from ry import Size
        >>> Size(1536).format(scale=1)
        '1.5 KiB'

        """

    # =========================================================================
    # CLASS-METHODS
    # =========================================================================

    # -------------------------------------------------------------------------
    # PARSING
    # -------------------------------------------------------------------------
    @classmethod
    def parse(cls, value: str | builtins.bytes, /) -> Size: ...
    @classmethod
    def from_str(cls, s: str, /) -> Size: ...

    # -------------------------------------------------------------------------
    # BYTES
    # -------------------------------------------------------------------------
    @classmethod
    def from_bytes(cls, size: float) -> Size: ...

    # -------------------------------------------------------------------------
    # KILOBYTES
    # -------------------------------------------------------------------------
    @classmethod
    def from_kb(cls, size: float) -> Size: ...
    @classmethod
    def from_kib(cls, size: float) -> Size: ...
    @classmethod
    def from_kibibytes(cls, size: float) -> Size: ...
    @classmethod
    def from_kilobytes(cls, size: float) -> Size: ...

    # -------------------------------------------------------------------------
    # MEGABYTES
    # -------------------------------------------------------------------------
    @classmethod
    def from_mb(cls, size: float) -> Size: ...
    @classmethod
    def from_mebibytes(cls, size: float) -> Size: ...
    @classmethod
    def from_megabytes(cls, size: float) -> Size: ...
    @classmethod
    def from_mib(cls, size: float) -> Size: ...

    # -------------------------------------------------------------------------
    # GIGABYTES
    # -------------------------------------------------------------------------
    @classmethod
    def from_gb(cls, size: float) -> Size: ...
    @classmethod
    def from_gib(cls, size: float) -> Size: ...
    @classmethod
    def from_gibibytes(cls, size: float) -> Size: ...
    @classmethod
    def from_gigabytes(cls, size: float) -> Size: ...

    # -------------------------------------------------------------------------
    # TERABYTES
    # -------------------------------------------------------------------------
    @classmethod
    def from_tb(cls, size: float) -> Size: ...
    @classmethod
    def from_tebibytes(cls, size: float) -> Size: ...
    @classmethod
    def from_terabytes(cls, size: float) -> Size: ...
    @classmethod
    def from_tib(cls, size: float) -> Size: ...

    # -------------------------------------------------------------------------
    # PETABYTES
    # -------------------------------------------------------------------------
    @classmethod
    def from_pb(cls, size: float) -> Size: ...
    @classmethod
    def from_pebibytes(cls, size: float) -> Size: ...
    @classmethod
    def from_petabytes(cls, size: float) -> Size: ...
    @classmethod
    def from_pib(cls, size: float) -> Size: ...

    # -------------------------------------------------------------------------
    # EXABYTES
    # -------------------------------------------------------------------------
    @classmethod
    def from_eb(cls, size: float) -> Size: ...
    @classmethod
    def from_eib(cls, size: float) -> Size: ...
    @classmethod
    def from_exabytes(cls, size: float) -> Size: ...
    @classmethod
    def from_exbibytes(cls, size: float) -> Size: ...

    # =========================================================================
    # DUNDERS
    # =========================================================================
    def __add__(self, other: Size | float, /) -> Size: ...
    def __radd__(self, other: Size | float, /) -> Size: ...
    def __sub__(self, other: Size | float, /) -> Size: ...
    def __rsub__(self, other: Size | float, /) -> Size: ...
    def __mul__(self, other: Size | float, /) -> Size: ...
    def __rmul__(self, other: Size | float, /) -> Size: ...
    def __neg__(self) -> Size: ...
    def __pos__(self) -> Size: ...
    def __abs__(self) -> Size: ...
    def __invert__(self) -> Size: ...
    def __eq__(self, other: object, /) -> bool: ...
    def __ne__(self, other: object, /) -> bool: ...
    def __lt__(self, other: Size | float, /) -> bool: ...
    def __le__(self, other: Size | float, /) -> bool: ...
    def __gt__(self, other: Size | float, /) -> bool: ...
    def __ge__(self, other: Size | float, /) -> bool: ...
    def __hash__(self) -> int: ...
    def __bool__(self) -> bool: ...
    def __int__(self) -> int: ...

    # -------------------------------------------------------------------------
    # CONSTANTS
    # -------------------------------------------------------------------------
    ZERO: t.Final[Size]  # Size(0)
    MAX: t.Final[Size]  # Size(9_223_372_036_854_775_807)
    MIN: t.Final[Size]  # Size(-9_223_372_036_854_775_808)
    # byte
    B: t.Final[Size]  # Size(1)
    BYTE: t.Final[Size]  # Size(1)
    # kilobyte
    KB: t.Final[Size]  # Size(1_000)
    KIB: t.Final[Size]  # Size(1_024)
    KIBIBYTE: t.Final[Size]  # Size(1_024)
    KILOBYTE: t.Final[Size]  # Size(1_000)
    # megabyte
    MB: t.Final[Size]  # Size(1_000_000)
    MEBIBYTE: t.Final[Size]  # Size(1_048_576)
    MEGABYTE: t.Final[Size]  # Size(1_000_000)
    MIB: t.Final[Size]  # Size(1_048_576)
    # gigabyte
    GB: t.Final[Size]  # Size(1_000_000_000)
    GIB: t.Final[Size]  # Size(1_073_741_824)
    GIBIBYTE: t.Final[Size]  # Size(1_073_741_824)
    GIGABYTE: t.Final[Size]  # Size(1_000_000_000)
    # terabyte
    TB: t.Final[Size]  # Size(1_000_000_000_000)
    TEBIBYTE: t.Final[Size]  # Size(1_099_511_627_776)
    TERABYTE: t.Final[Size]  # Size(1_000_000_000_000)
    TIB: t.Final[Size]  # Size(1_099_511_627_776)
    # petabyte
    PB: t.Final[Size]  # Size(1_000_000_000_000_000)
    PEBIBYTE: t.Final[Size]  # Size(1_125_899_906_842_624)
    PETABYTE: t.Final[Size]  # Size(1_000_000_000_000_000)
    PIB: t.Final[Size]  # Size(1_125_899_906_842_624)
    # exabyte
    EB: t.Final[Size]  # Size(1_000_000_000_000_000_000)
    EIB: t.Final[Size]  # Size(1_152_921_504_606_846_976)
    EXABYTE: t.Final[Size]  # Size(1_000_000_000_000_000_000)
    EXBIBYTE: t.Final[Size]  # Size(1_152_921_504_606_846_976)
```

<h2 id="ry.ryo3._sqlformat"><code>ry.ryo3._sqlformat</code></h2>

```python
"""ryo3-sqlformat ~ types"""

import typing as t

_SqlfmtParamValue: t.TypeAlias = str | int | float | bool
_TSqlfmtParamValue_co = t.TypeVar(
    "_TSqlfmtParamValue_co", bound=_SqlfmtParamValue, covariant=True
)
_SqlfmtParamsLike: t.TypeAlias = (
    dict[str, _TSqlfmtParamValue_co]
    | t.Sequence[tuple[str, _TSqlfmtParamValue_co]]
    | t.Sequence[_TSqlfmtParamValue_co]
)


@t.final
class SqlfmtQueryParams:
    def __new__(
        cls, params: _SqlfmtParamsLike[_TSqlfmtParamValue_co] | None = None
    ) -> t.Self: ...
    def __len__(self) -> int: ...


def sqlfmt_params(
    params: _SqlfmtParamsLike[_TSqlfmtParamValue_co] | SqlfmtQueryParams | None = None,
) -> SqlfmtQueryParams: ...
def sqlfmt(
    sql: str,
    params: _SqlfmtParamsLike[_TSqlfmtParamValue_co] | SqlfmtQueryParams | None = None,
    *,
    indent: int | t.Literal["tabs", "\t"] = 2,
    uppercase: bool | None = None,
    lines_between_queries: int = 1,
    ignore_case_convert: list[str] | None = None,
    inline: bool = False,
    max_inline_block: int = 50,
    max_inline_arguments: int | None = None,
    max_inline_top_level: int | None = None,
    joins_as_top_level: bool = False,
    dialect: t.Literal["generic", "postgresql", "sqlserver"] = "generic",
) -> str: ...


class _SqlFormatterDict(t.TypedDict):
    indent: int | t.Literal["tabs"]
    uppercase: bool | None
    lines_between_queries: int
    ignore_case_convert: list[str] | None
    inline: bool
    max_inline_block: int
    max_inline_arguments: int | None
    max_inline_top_level: int | None
    joins_as_top_level: bool
    dialect: t.Literal["generic", "postgresql", "sqlserver"]


@t.final
class SqlFormatter:
    def __new__(
        cls,
        *,
        indent: int | t.Literal["tabs", "\t"] = 2,
        uppercase: bool | None = None,
        lines_between_queries: int = 1,
        ignore_case_convert: list[str] | None = None,
        inline: bool = False,
        max_inline_block: int = 50,
        max_inline_arguments: int | None = None,
        max_inline_top_level: int | None = None,
        joins_as_top_level: bool = False,
        dialect: t.Literal["generic", "postgresql", "sqlserver"] = "generic",
    ) -> t.Self: ...
    def to_dict(self) -> _SqlFormatterDict: ...
    def fmt(
        self,
        sql: str,
        params: _SqlfmtParamsLike[_TSqlfmtParamValue_co]
        | SqlfmtQueryParams
        | None = None,
    ) -> str: ...
    def __call__(
        self,
        sql: str,
        params: _SqlfmtParamsLike[_TSqlfmtParamValue_co]
        | SqlfmtQueryParams
        | None = None,
    ) -> str: ...
    def __eq__(self, value: object, /) -> bool: ...
    def __ne__(self, value: object, /) -> bool: ...
```

<h2 id="ry.ryo3._std"><code>ry.ryo3._std</code></h2>

```python
"""ryo3-std ~ types"""

import datetime as pydt
import ipaddress
import pathlib
import typing as t
from os import PathLike
from types import TracebackType

from ry._types import (
    Buffer,
    FsPathLike,
)
from ry.protocols import FromStr, RyIterator, ToPy, ToPyTimeDelta, ToString, _Parse
from ry.ryo3._bytes import Bytes

# =============================================================================
# CONSTANTS
# =============================================================================
# u8
U8_BITS: t.Final = 8
U8_MAX: t.Final = 255
U8_MIN: t.Final = 0
# i8
I8_BITS: t.Final = 8
I8_MAX: t.Final = 127
I8_MIN: t.Final = -128
# i16
I16_BITS: t.Final = 16
I16_MAX: t.Final = 32_767
I16_MIN: t.Final = -32_768
# u16
U16_BITS: t.Final = 16
U16_MAX: t.Final = 65_535
U16_MIN: t.Final = 0
# u32
U32_BITS: t.Final = 32
U32_MAX: t.Final = 4_294_967_295  # noqa: PYI054
U32_MIN: t.Final = 0
# i32
I32_BITS: t.Final = 32
I32_MAX: t.Final = 2_147_483_647  # noqa: PYI054
I32_MIN: t.Final = -2_147_483_648  # noqa: PYI054
# u64
U64_BITS: t.Final = 64
U64_MAX: t.Final = 18_446_744_073_709_551_615  # noqa: PYI054
U64_MIN: t.Final = 0
# i64
I64_BITS: t.Final = 64
I64_MAX: t.Final = 9_223_372_036_854_775_807  # noqa: PYI054
I64_MIN: t.Final = -9_223_372_036_854_775_808  # noqa: PYI054
# u128
U128_BITS: t.Final = 128
U128_MAX: t.Final = 340_282_366_920_938_463_463_374_607_431_768_211_455  # noqa: PYI054
U128_MIN: t.Final = 0
# i128
I128_BITS: t.Final = 128
I128_MAX: t.Final = 170_141_183_460_469_231_731_687_303_715_884_105_727  # noqa: PYI054
I128_MIN: t.Final = -170_141_183_460_469_231_731_687_303_715_884_105_728  # noqa: PYI054
# usize
USIZE_BITS: t.Literal[32, 64]
USIZE_MAX: t.Literal[4_294_967_295, 18_446_744_073_709_551_615]  # noqa: PYI054
USIZE_MIN: t.Literal[0]
# isize
ISIZE_BITS: t.Literal[32, 64]
ISIZE_MAX: t.Literal[2_147_483_647, 9_223_372_036_854_775_807]  # noqa: PYI054
ISIZE_MIN: t.Literal[-2_147_483_648, -9_223_372_036_854_775_808]  # noqa: PYI054


# =============================================================================
# STD::TIME
# =============================================================================
@t.final
class Duration(FromStr, ToPyTimeDelta, ToPy[pydt.timedelta], ToString, _Parse):
    ZERO: t.Final[Duration]
    MIN: t.Final[Duration]
    MAX: t.Final[Duration]
    NANOSECOND: t.Final[Duration]
    MICROSECOND: t.Final[Duration]
    MILLISECOND: t.Final[Duration]
    SECOND: t.Final[Duration]
    MINUTE: t.Final[Duration]
    HOUR: t.Final[Duration]
    __match_args__: t.Final = ("secs", "nanos")

    def __new__(cls, secs: int = 0, nanos: int = 0) -> t.Self: ...
    def __eq__(self, other: object, /) -> bool: ...
    def __ne__(self, other: object, /) -> bool: ...
    def __add__(self, other: t.Self | pydt.timedelta, /) -> t.Self: ...
    def __sub__(self, other: t.Self | pydt.timedelta, /) -> t.Self: ...
    def __radd__(self, other: t.Self | pydt.timedelta, /) -> t.Self: ...
    def __rsub__(self, other: t.Self | pydt.timedelta, /) -> t.Self: ...
    def __lt__(self, other: t.Self, /) -> bool: ...
    def __le__(self, other: t.Self, /) -> bool: ...
    def __gt__(self, other: t.Self, /) -> bool: ...
    def __ge__(self, other: t.Self, /) -> bool: ...
    def __hash__(self) -> int: ...
    def __bool__(self) -> bool: ...
    def __float__(self) -> float: ...
    @t.overload
    def __truediv__(self, other: t.Self | pydt.timedelta, /) -> float: ...
    @t.overload
    def __truediv__(self, other: float, /) -> t.Self: ...
    def __rtruediv__(self, other: t.Self, /) -> float: ...
    def __mul__(self, other: float, /) -> t.Self: ...
    def __rmul__(self, other: float, /) -> t.Self: ...
    def abs_diff(self, other: t.Self | pydt.timedelta) -> t.Self: ...
    def replace(self, *, secs: int | None = None, nanos: int | None = None) -> t.Self:
        """Return duration with parts replaced

        Examples
        --------
        >>> from ry import Duration
        >>> d = Duration(5, 500_000_000)  # 5.5 seconds
        >>> d.replace(secs=10)  # 10.5 seconds
        Duration(secs=10, nanos=500000000)

        """

    def sleep(self, *, interval: int = 100) -> None:
        """Sleep for duration length

        Parameters
        ----------
        interval : int, optional
            check signals interval in milliseconds; range 1..=1000 (default=100)

        """

    # =========================================================================
    # PYTHON_CONVERSIONS
    # =========================================================================
    @classmethod
    def from_pytimedelta(cls, delta: pydt.timedelta) -> t.Self: ...
    def to_pytimedelta(self) -> pydt.timedelta: ...
    def to_py(self) -> pydt.timedelta: ...
    def to_dict(self) -> _DurationDict: ...
    @classmethod
    def from_dict(cls, d: _DurationDict) -> t.Self: ...

    # =========================================================================
    # TO/FROM STRING(s)
    # =========================================================================
    def to_string(self) -> str: ...
    def isoformat(self) -> str: ...
    @classmethod
    def fromisoformat(cls, s: str) -> t.Self: ...
    def friendly(
        self,
        designator: t.Literal[
            "compact", "human", "human-time", "short", "verbose"
        ] = "compact",
    ) -> str: ...
    @classmethod
    def from_str(cls, s: str, /) -> t.Self: ...
    @classmethod
    def parse(cls, value: str | bytes, /) -> t.Self: ...
    # =========================================================================
    # PROPERTIES
    # =========================================================================
    @property
    def is_zero(self) -> bool: ...
    @property
    def nanos(self) -> int: ...
    @property
    def nanoseconds(self) -> int:
        """Alias for .nanos"""

    @property
    def ns(self) -> int:
        """Alias for .nanos"""

    @property
    def secs(self) -> int: ...
    @property
    def days(self) -> int: ...
    @property
    def seconds(self) -> int: ...
    @property
    def seconds_remainder(self) -> int: ...
    @property
    def microseconds(self) -> int: ...
    @property
    def subsec_micros(self) -> int: ...
    @property
    def subsec_millis(self) -> int: ...
    @property
    def subsec_nanos(self) -> int: ...

    # =========================================================================
    # CLASSMETHODS
    # =========================================================================
    @classmethod
    def from_hours(cls, hours: int) -> t.Self: ...
    @classmethod
    def from_micros(cls, micros: int) -> t.Self: ...
    @classmethod
    def from_millis(cls, millis: int) -> t.Self: ...
    @classmethod
    def from_mins(cls, mins: int) -> t.Self: ...
    @classmethod
    def from_nanos(cls, nanos: int) -> t.Self: ...
    @classmethod
    def from_secs(cls, secs: float) -> t.Self: ...
    @classmethod
    def from_secs_f32(cls, secs: float) -> t.Self: ...
    @classmethod
    def from_secs_f64(cls, secs: float) -> t.Self: ...
    @classmethod
    def from_days(cls, days: int) -> t.Self: ...
    @classmethod
    def from_weeks(cls, weeks: int) -> t.Self: ...
    def as_micros(self) -> int: ...
    def as_millis(self) -> int: ...
    def as_nanos(self) -> int: ...
    def as_secs(self) -> int: ...
    def as_secs_f32(self) -> float: ...
    def as_secs_f64(self) -> float: ...

    # =========================================================================
    # ARITHMETIC
    # =========================================================================
    def checked_add(self, other: t.Self) -> t.Self | None: ...
    def checked_div(self, other: int) -> t.Self | None: ...
    def checked_mul(self, other: float) -> t.Self | None: ...
    def checked_sub(self, other: t.Self) -> t.Self | None: ...
    def div_duration_f32(self, other: t.Self) -> float: ...
    def div_duration_f64(self, other: t.Self) -> float: ...
    def div_f32(self, n: float) -> t.Self: ...
    def div_f64(self, n: float) -> t.Self: ...
    def mul_f32(self, n: float) -> t.Self: ...
    def mul_f64(self, n: float) -> t.Self: ...
    def saturating_add(self, other: t.Self) -> t.Self: ...
    def saturating_mul(self, other: int) -> t.Self: ...
    def saturating_sub(self, other: t.Self) -> t.Self: ...


class _DurationDict(t.TypedDict):
    secs: int
    nanos: int


@t.final
class Instant:
    def __new__(cls) -> t.Self: ...
    @classmethod
    def now(cls) -> t.Self: ...
    def __eq__(self, other: object, /) -> bool: ...
    def __ne__(self, other: object, /) -> bool: ...
    def __lt__(self, other: t.Self, /) -> bool: ...
    def __le__(self, other: t.Self, /) -> bool: ...
    def __gt__(self, other: t.Self, /) -> bool: ...
    def __ge__(self, other: t.Self, /) -> bool: ...
    def __hash__(self) -> int: ...
    def __add__(self, other: Duration, /) -> t.Self: ...
    def __radd__(self, other: Duration, /) -> t.Self: ...
    @t.overload
    def __sub__(self, other: Duration, /) -> t.Self: ...
    @t.overload
    def __sub__(self, other: t.Self, /) -> Duration: ...
    def __rsub__(self, other: t.Self, /) -> Duration: ...

    # =========================================================================
    # INSTANCE METHODS
    # =========================================================================
    def checked_add(self, other: Duration) -> t.Self | None: ...
    def checked_duration_since(self, earlier: t.Self) -> Duration | None: ...
    def checked_sub(self, other: Duration) -> t.Self | None: ...
    def duration_since(self, earlier: t.Self) -> Duration: ...
    def elapsed(self) -> Duration: ...
    def saturating_duration_since(self, earlier: t.Self) -> Duration: ...


def duration(secs: int = 0, nanos: int = 0) -> Duration:
    """Return a `Duration` ~ alias for `Duration` constructor"""


def instant() -> Instant:
    """Return an `Instant` ~ alias for `Instant` constructor"""


def sleep(secs: float, interval: int = 100) -> float:
    """Sleep for the given number of seconds.

    Parameters
    ----------
    secs : float
        number of seconds to sleep
    interval : int, optional
        check signals interval in milliseconds; range 1..=1000 (default=100)

    Returns
    -------
    float
        number of seconds slept (ideally 8 hours)

    Raises
    ------
    ValueError
        if secs is negative
    OverflowError
        if NaN or secs is too large to convert to a duration

    """


# =============================================================================
# STD::FS
# =============================================================================
_FileTypeStr: t.TypeAlias = t.Literal[
    "file",
    "dir",
    "symlink",
    # unix
    "block-device",
    "char-device",
    "fifo",
    "socket",
    # windows
    "symlink-dir",
    "symlink-file",
    # unknown
    "unknown",
]


@t.final
class FileType(ToPy[_FileTypeStr]):
    def __new__(
        cls,
        t: t.Literal[
            "f",
            "file",
            "d",
            "dir",
            "directory",
            "l",
            "symlink",
            "link",
            "block-device",
            "char-device",
            "fifo",
            "socket",
            "symlink-dir",
            "symlink-file",
            "unknown",
        ],
    ) -> t.Self: ...
    @property
    def is_dir(self) -> bool: ...
    @property
    def is_file(self) -> bool: ...
    @property
    def is_symlink(self) -> bool: ...
    @property
    def is_block_device(self) -> bool: ...
    @property
    def is_unknown(self) -> bool: ...
    @property
    def is_char_device(self) -> bool: ...
    @property
    def is_fifo(self) -> bool: ...
    @property
    def is_socket(self) -> bool: ...
    @property
    def is_symlink_dir(self) -> bool: ...
    @property
    def is_symlink_file(self) -> bool: ...
    def to_py(self) -> _FileTypeStr: ...


@t.final
class Permissions:
    @property
    def readonly(self) -> bool: ...
    def __eq__(self, value: object) -> bool: ...
    def __ne__(self, value: object) -> bool: ...


@t.final
class Metadata(ToPy[_MetadataDict]):
    def __new__(cls) -> t.NoReturn: ...
    @property
    def file_type(self) -> FileType: ...
    @property
    def len(self) -> int: ...
    @property
    def is_empty(self) -> bool: ...
    @property
    def modified(self) -> pydt.datetime: ...
    @property
    def accessed(self) -> pydt.datetime: ...
    @property
    def created(self) -> pydt.datetime: ...
    @property
    def is_dir(self) -> bool: ...
    @property
    def is_file(self) -> bool: ...
    @property
    def is_symlink(self) -> bool: ...
    @property
    def permissions(self) -> Permissions: ...
    @property
    def readonly(self) -> bool: ...
    def to_py(self) -> _MetadataDict: ...


class _MetadataDict(t.TypedDict):
    is_dir: bool
    is_file: bool
    is_symlink: bool
    len: int
    readonly: bool
    file_type: t.Literal["file", "directory", "symlink"]
    accessed: pydt.datetime
    created: pydt.datetime
    modified: pydt.datetime


@t.final
class DirEntry:
    def __new__(cls) -> t.NoReturn: ...
    def __fspath__(self) -> str: ...
    @property
    def path(self) -> pathlib.Path: ...
    @property
    def filename(self) -> str: ...
    def metadata(self) -> Metadata: ...
    def file_type(self) -> FileType: ...


@t.final
class ReadDir(RyIterator[DirEntry]):
    def __new__(cls) -> t.NoReturn: ...
    def __iter__(self) -> t.Self: ...
    def __next__(self) -> DirEntry: ...
    def collect(self) -> list[DirEntry]: ...
    def take(self, n: int = 1) -> list[DirEntry]: ...


@t.final
class FileReadStream(RyIterator[Bytes]):
    def __new__(
        cls,
        path: FsPathLike,
        *,
        read_size: int = 65536,
        offset: int = 0,
        buffered: bool = True,
        strict: bool = True,
    ) -> t.Self:
        """Synchronous file read stream/iterable

        Parameters
        ----------
        path : FsPathLike
            path-like object
        read_size : int, optional
            number of bytes to read at a time (default=65536)
        offset : int, optional
            offset to start reading from (default=0)
        buffered : bool, optional
            whether the stream is buffered (default=True)
        strict : bool, optional
            whether to raise a ValueError on offset beyond EOF (default=True)

        Raises
        ------
        FileNotFoundError
            If file does not exist.
        IsADirectoryError
            If path is a directory.
        ValueError
            If offset is beyond EOF and strict is True.

        """

    def __enter__(self) -> t.Self: ...
    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None: ...
    def __iter__(self) -> t.Self: ...
    def __next__(self) -> Bytes: ...
    def close(self) -> None: ...
    def collect(self) -> list[Bytes]: ...
    def take(self, n: int = 1) -> list[Bytes]: ...


# ============================================================================
# STD::FS ~ functions
# =============================================================================
@t.overload
def canonicalize(path: str) -> str: ...
@t.overload
def canonicalize(path: PathLike[str]) -> pathlib.Path: ...
def copy(from_path: FsPathLike, to_path: FsPathLike) -> int: ...
def create_dir(path: FsPathLike) -> None: ...
def create_dir_all(path: FsPathLike) -> None: ...
def exists(path: FsPathLike) -> bool: ...
def hard_link(original: FsPathLike, link: FsPathLike) -> None: ...
def is_dir(path: FsPathLike) -> bool: ...
def is_file(path: FsPathLike) -> bool: ...
def is_symlink(path: FsPathLike) -> bool: ...
def metadata(path: FsPathLike) -> Metadata: ...
def read(path: FsPathLike) -> Bytes: ...
def read_bytes(path: FsPathLike) -> bytes: ...
def read_dir(path: FsPathLike) -> ReadDir: ...
def read_link(path: FsPathLike) -> pathlib.Path: ...
def read_stream(
    path: FsPathLike,
    read_size: int = 65536,
    *,
    offset: int = 0,
    buffered: bool = True,
    strict: bool = True,
) -> FileReadStream:
    """Return a `FileReadStream` for the given path

    Parameters
    ----------
    path : FsPathLike
        path-like object
    read_size : int, optional
        number of bytes to read at a time (default=65536)
    offset : int, optional
        offset to start reading from (default=0)
    buffered : bool, optional
        whether the stream is buffered (default=True)
    strict : bool, optional
        whether to raise a ValueError on offset beyond EOF (default=True)

    Raises
    ------
    FileNotFoundError
        If file does not exist.
    IsADirectoryError
        If path is a directory.
    ValueError
        If offset is beyond EOF and strict is True.

    """


def read_text(path: FsPathLike) -> str: ...
def read_str(path: FsPathLike) -> str: ...
def read_to_string(path: FsPathLike) -> str: ...
def remove_dir(path: FsPathLike) -> None: ...
def remove_dir_all(path: FsPathLike) -> None: ...
def remove_file(path: FsPathLike) -> None: ...
def rename(from_path: FsPathLike, to_path: FsPathLike) -> None: ...
def set_permissions(path: FsPathLike, perm: Permissions) -> None: ...
def soft_link(original: FsPathLike, link: FsPathLike) -> None: ...
def symlink_metadata(path: FsPathLike) -> Metadata: ...
def write(path: FsPathLike, data: Buffer | str) -> int: ...
def write_bytes(path: FsPathLike, buf: bytes) -> int: ...
def write_text(path: FsPathLike, s: str) -> int: ...


# =============================================================================
# STD::NET
# =============================================================================


class _IpVersion4(t.Protocol):
    @property
    def version(self) -> t.Literal[4]: ...
    @property
    def is_ipv4(self) -> t.Literal[True]: ...
    @property
    def is_ipv6(self) -> t.Literal[False]: ...


class _IpVersion6(t.Protocol):
    @property
    def version(self) -> t.Literal[6]: ...
    @property
    def is_ipv4(self) -> t.Literal[False]: ...
    @property
    def is_ipv6(self) -> t.Literal[True]: ...


class _IpVersion(t.Protocol):
    @property
    def version(self) -> t.Literal[4, 6]: ...
    @property
    def is_ipv4(self) -> bool: ...
    @property
    def is_ipv6(self) -> bool: ...


class _IpPropertiesIntersection(t.Protocol):
    """Ipv4 & Ipv6 properties intersection"""

    @property
    def is_benchmarking(self) -> bool: ...
    @property
    def is_documentation(self) -> bool: ...
    @property
    def is_global(self) -> t.NoReturn: ...
    @property
    def is_loopback(self) -> bool: ...
    @property
    def is_multicast(self) -> bool: ...
    @property
    def is_reserved(self) -> bool: ...
    @property
    def is_shared(self) -> bool: ...
    @property
    def is_unicast(self) -> bool: ...
    @property
    def is_unspecified(self) -> bool: ...


class _Ipv4OnlyProperties(t.Protocol):
    @property
    def is_broadcast(self) -> bool: ...
    @property
    def is_link_local(self) -> bool: ...
    @property
    def is_private(self) -> bool: ...


class _Ipv6OnlyProperties(t.Protocol):
    @property
    def is_ipv4_mapped(self) -> bool: ...
    @property
    def is_unicast_global(self) -> bool: ...
    @property
    def is_unicast_link_local(self) -> bool: ...
    @property
    def is_unique_local(self) -> bool: ...


class _Ipv4AddrProperties(
    _IpPropertiesIntersection,
    _Ipv4OnlyProperties,
    t.Protocol,
): ...


class _Ipv6AddrProperties(
    _IpPropertiesIntersection,
    _Ipv6OnlyProperties,
    t.Protocol,
): ...


class _IpAddrProperties(
    _IpPropertiesIntersection,
    _Ipv4OnlyProperties,
    _Ipv6OnlyProperties,
    t.Protocol,
): ...


_T_ipaddress_co = t.TypeVar(
    "_T_ipaddress_co",
    bound=ipaddress.IPv4Address | ipaddress.IPv6Address,
    covariant=True,
)


class ToPyIpAddress(t.Protocol[_T_ipaddress_co]):
    def to_pyipaddress(self) -> _T_ipaddress_co: ...


@t.final
class Ipv4Addr(
    _Ipv4AddrProperties,
    _IpVersion4,
    FromStr,
    _Parse,
    ToPy[ipaddress.IPv4Address],
    ToPyIpAddress[ipaddress.IPv4Address],
    ToString,
):
    BROADCAST: Ipv4Addr
    LOCALHOST: Ipv4Addr
    UNSPECIFIED: Ipv4Addr

    @t.overload
    def __new__(cls, a: int, b: int, c: int, d: int) -> t.Self: ...
    @t.overload
    def __new__(
        cls,
        iplike: int | str | bytes | Ipv4Addr | ipaddress.IPv4Address,
    ) -> t.Self: ...
    def __eq__(self, other: object, /) -> bool: ...
    def __ne__(self, other: object, /) -> bool: ...
    def __lt__(self, other: t.Self, /) -> bool: ...
    def __le__(self, other: t.Self, /) -> bool: ...
    def __gt__(self, other: t.Self, /) -> bool: ...
    def __ge__(self, other: t.Self, /) -> bool: ...
    def __hash__(self) -> int: ...
    def to_py(self) -> ipaddress.IPv4Address: ...
    def to_string(self) -> str: ...
    @property
    def version(self) -> t.Literal[4]: ...
    @property
    def is_documentation(self) -> bool: ...
    @property
    def is_ipv4(self) -> t.Literal[True]: ...
    @property
    def is_ipv6(self) -> t.Literal[False]: ...
    # ========================================================================
    # CLASSMETHODS
    # ========================================================================
    @classmethod
    def from_str(cls, s: str, /) -> Ipv4Addr: ...
    @classmethod
    def parse(cls, value: str | bytes, /) -> Ipv4Addr: ...
    @classmethod
    def from_bits(cls, bits: int) -> Ipv4Addr: ...
    @classmethod
    def from_octets(cls, a: int, b: int, c: int, d: int) -> Ipv4Addr: ...

    # =======================================================================
    # METHODS
    # =======================================================================
    def to_ipaddr(self) -> IpAddr: ...
    def to_socketaddrv4(self, port: int) -> SocketAddrV4: ...
    def to_socketaddrv6(
        self, port: int, flowinfo: int = 0, scope_id: int = 0
    ) -> SocketAddrV6: ...


@t.final
class Ipv6Addr(
    _Ipv6AddrProperties,
    _IpVersion6,
    FromStr,
    _Parse,
    ToPy[ipaddress.IPv6Address],
    ToPyIpAddress[ipaddress.IPv6Address],
    ToString,
):
    LOCALHOST: Ipv6Addr
    UNSPECIFIED: Ipv6Addr

    @t.overload
    def __new__(cls, *args: int) -> t.Self: ...
    @t.overload
    def __new__(
        cls, iplike: int | str | bytes | Ipv6Addr | ipaddress.IPv6Address
    ) -> t.Self: ...
    def __eq__(self, other: object, /) -> bool: ...
    def __ne__(self, other: object, /) -> bool: ...
    def __lt__(self, other: t.Self, /) -> bool: ...
    def __le__(self, other: t.Self, /) -> bool: ...
    def __gt__(self, other: t.Self, /) -> bool: ...
    def __ge__(self, other: t.Self, /) -> bool: ...
    def __hash__(self) -> int: ...
    def to_py(self) -> ipaddress.IPv6Address: ...
    def to_string(self) -> str: ...
    @property
    def version(self) -> t.Literal[6]: ...
    @property
    def is_documentation(self) -> t.NoReturn: ...
    @property
    def is_ipv4(self) -> t.Literal[False]: ...
    @property
    def is_ipv6(self) -> t.Literal[True]: ...
    # ========================================================================
    # CLASSMETHODS
    # ========================================================================
    @classmethod
    def from_str(cls, s: str, /) -> Ipv6Addr: ...
    @classmethod
    def parse(cls, value: str | bytes, /) -> Ipv6Addr: ...
    @classmethod
    def from_bits(cls, bits: int) -> IpAddr: ...

    # =======================================================================
    # METHODS
    # =======================================================================
    def to_ipaddr(self) -> IpAddr: ...
    def to_socketaddrv4(self, port: int) -> SocketAddrV4: ...
    def to_socketaddrv6(
        self, port: int, flowinfo: int = 0, scope_id: int = 0
    ) -> SocketAddrV6: ...


@t.final
class IpAddr(
    _IpAddrProperties,
    _IpVersion,
    FromStr,
    _Parse,
    ToPy[ipaddress.IPv4Address | ipaddress.IPv6Address],
    ToPyIpAddress[ipaddress.IPv4Address | ipaddress.IPv6Address],
    ToString,
):
    BROADCAST: IpAddr
    LOCALHOST_V4: IpAddr
    UNSPECIFIED_V4: IpAddr
    LOCALHOST_V6: IpAddr
    UNSPECIFIED_V6: IpAddr

    def __new__(
        cls,
        ob: int
        | str
        | bytes
        | Ipv4Addr
        | Ipv6Addr
        | ipaddress.IPv4Address
        | ipaddress.IPv6Address,
    ) -> t.Self: ...
    def __eq__(self, other: object, /) -> bool: ...
    def __ne__(self, other: object, /) -> bool: ...
    def __lt__(self, other: t.Self | int, /) -> bool: ...
    def __le__(self, other: t.Self | int, /) -> bool: ...
    def __gt__(self, other: t.Self | int, /) -> bool: ...
    def __ge__(self, other: t.Self | int, /) -> bool: ...
    def __hash__(self) -> int: ...
    def to_string(self) -> str: ...
    def to_py(self) -> ipaddress.IPv4Address | ipaddress.IPv6Address: ...
    def to_ipv4(self) -> Ipv4Addr: ...
    def to_ipv6(self) -> Ipv6Addr: ...

    # =========================================================================
    # CLASSMETHODS
    # =========================================================================
    @classmethod
    def from_str(cls, s: str, /) -> IpAddr: ...
    @classmethod
    def parse(cls, value: str | bytes, /) -> IpAddr: ...

    # ========================================================================
    # PROPERTIES
    # ========================================================================

    @property
    def version(self) -> t.Literal[4, 6]: ...
    @property
    def is_benchmarking(self) -> t.NoReturn: ...
    @property
    def is_ipv4(self) -> bool: ...
    @property
    def is_ipv6(self) -> bool: ...
    @property
    def is_broadcast(self) -> bool: ...
    @property
    def is_documentation(self) -> bool: ...
    @property
    def is_loopback(self) -> bool: ...
    @property
    def is_multicast(self) -> bool: ...
    @property
    def is_private(self) -> bool: ...
    @property
    def is_unspecified(self) -> bool: ...

    # =======================================================================
    # METHODS
    # =======================================================================
    def to_canonical(self) -> IpAddr: ...


@t.final
class SocketAddrV4(
    _Ipv4AddrProperties,
    _IpVersion4,
    # protocols
    FromStr,
    ToPyIpAddress[ipaddress.IPv4Address],
    ToString,
    _Parse,
):
    def __new__(
        cls,
        ip: IpAddr | Ipv4Addr | ipaddress.IPv4Address | ipaddress.IPv6Address,
        port: int,
    ) -> t.Self: ...
    def __eq__(self, other: object, /) -> bool: ...
    def __ne__(self, other: object, /) -> bool: ...
    def __lt__(self, other: t.Self, /) -> bool: ...
    def __le__(self, other: t.Self, /) -> bool: ...
    def __gt__(self, other: t.Self, /) -> bool: ...
    def __ge__(self, other: t.Self, /) -> bool: ...
    def __hash__(self) -> int: ...
    def to_ipv4(self) -> Ipv4Addr: ...
    def to_ipaddr(self) -> IpAddr: ...
    def to_socketaddr(self) -> SocketAddr: ...
    def to_string(self) -> str: ...
    @classmethod
    def from_str(cls, s: str, /) -> t.Self: ...
    @classmethod
    def parse(cls, value: str | bytes, /) -> t.Self: ...
    @property
    def port(self) -> int: ...
    @property
    def ip(self) -> Ipv4Addr: ...
    @property
    def is_ipv4(self) -> t.Literal[True]: ...
    @property
    def is_ipv6(self) -> t.Literal[False]: ...


@t.final
class SocketAddrV6(
    _Ipv6AddrProperties,
    _IpVersion6,
    # protocols
    FromStr,
    ToPyIpAddress[ipaddress.IPv6Address],
    ToString,
    _Parse,
):
    def __new__(
        cls,
        ip: IpAddr | Ipv6Addr | ipaddress.IPv4Address | ipaddress.IPv6Address,
        port: int,
        *,
        flowinfo: int = 0,
        scope_id: int = 0,
    ) -> t.Self: ...
    def __eq__(self, other: object, /) -> bool: ...
    def __ne__(self, other: object, /) -> bool: ...
    def __lt__(self, other: t.Self, /) -> bool: ...
    def __le__(self, other: t.Self, /) -> bool: ...
    def __gt__(self, other: t.Self, /) -> bool: ...
    def __ge__(self, other: t.Self, /) -> bool: ...
    def __hash__(self) -> int: ...
    def to_string(self) -> str: ...
    def to_ipv6(self) -> Ipv6Addr: ...
    def to_ipaddr(self) -> IpAddr: ...
    def to_socketaddr(self) -> SocketAddr: ...
    @classmethod
    def from_str(cls, s: str, /) -> t.Self: ...
    @classmethod
    def parse(cls, value: str | bytes, /) -> t.Self: ...
    @property
    def port(self) -> int: ...
    @property
    def ip(self) -> Ipv6Addr: ...
    @property
    def is_documentation(self) -> t.NoReturn: ...
    @property
    def is_ipv4(self) -> t.Literal[False]: ...
    @property
    def is_ipv6(self) -> t.Literal[True]: ...


@t.final
class SocketAddr(
    _IpAddrProperties,
    _IpVersion,
    # protocols
    FromStr,
    _Parse,
    ToString,
    ToPyIpAddress[ipaddress.IPv4Address | ipaddress.IPv6Address],
):
    @t.overload
    def __new__(
        cls,
        ip: IpAddr | Ipv4Addr | ipaddress.IPv4Address,
        port: int,
    ) -> t.Self: ...
    @t.overload
    def __new__(
        cls,
        ip: IpAddr | Ipv6Addr | ipaddress.IPv6Address,
        port: int,
        flowinfo: int | None = None,
        scope_id: int | None = None,
    ) -> t.Self: ...
    def __eq__(self, other: object, /) -> bool: ...
    def __ne__(self, other: object, /) -> bool: ...
    def __lt__(self, other: t.Self, /) -> bool: ...
    def __le__(self, other: t.Self, /) -> bool: ...
    def __gt__(self, other: t.Self, /) -> bool: ...
    def __ge__(self, other: t.Self, /) -> bool: ...
    def __hash__(self) -> int: ...
    @classmethod
    def from_str(cls, s: str, /) -> SocketAddr: ...
    @classmethod
    def parse(cls, value: str | bytes, /) -> SocketAddr: ...
    def to_ipaddr(self) -> IpAddr: ...
    def to_string(self) -> str: ...
    def to_socketaddrv4(self) -> SocketAddrV4:
        """Return SocketAddrV4 representation

        Raises
        ------
        ValueError
            if the internal `SocketAddr` is v6
        """

    def to_socketaddrv6(self) -> SocketAddrV6:
        """Return SocketAddrV6 representation

        Raises
        ------
        ValueError
            if the internal `SocketAddr` is v4
        """

    @property
    def is_ipv4(self) -> bool: ...
    @property
    def is_ipv6(self) -> bool: ...
    @property
    def ip(self) -> IpAddr: ...
    @property
    def port(self) -> int: ...
```

<h2 id="ry.ryo3._tokio"><code>ry.ryo3._tokio</code></h2>

```python
"""ryo3-tokio ~ types"""

import pathlib
import typing as t
from collections.abc import Generator
from types import TracebackType

from ry import Bytes
from ry._types import Buffer, FsPathLike, OpenBinaryMode
from ry.protocols import RyAsyncIterator
from ry.ryo3._std import FileType, Metadata


# =============================================================================
# FS
# =============================================================================
async def canonicalize_async(path: FsPathLike) -> FsPathLike: ...
async def copy_async(src: FsPathLike, dst: FsPathLike) -> int: ...
async def create_dir_async(path: FsPathLike) -> None: ...
async def create_dir_all_async(path: FsPathLike) -> None: ...
async def hard_link_async(src: FsPathLike, dst: FsPathLike) -> None: ...
async def metadata_async(path: FsPathLike) -> Metadata: ...
async def read_async(path: FsPathLike) -> Bytes: ...
async def remove_dir_async(path: FsPathLike) -> None: ...
async def remove_dir_all_async(path: FsPathLike) -> None: ...
async def remove_file_async(path: FsPathLike) -> None: ...
async def read_link_async(path: FsPathLike) -> FsPathLike: ...
async def read_to_string_async(path: FsPathLike) -> str: ...
async def rename_async(src: FsPathLike, dst: FsPathLike) -> None: ...
async def write_async(path: FsPathLike, buf: Buffer) -> int: ...
async def write_string_async(path: FsPathLike, s: str) -> int: ...
async def exists_async(path: FsPathLike) -> bool: ...


@t.final
class AsyncDirEntry:
    def __fspath__(self) -> str: ...
    @property
    def path(self) -> pathlib.Path: ...
    @property
    def filename(self) -> str: ...
    async def metadata(self) -> Metadata: ...
    async def file_type(self) -> FileType: ...


@t.final
class AsyncReadDir(RyAsyncIterator[AsyncDirEntry]):
    """Async iterator for read_dir_async"""

    async def collect(self) -> list[AsyncDirEntry]: ...
    async def take(self, n: int = 1) -> list[AsyncDirEntry]: ...
    def __aiter__(self) -> AsyncReadDir: ...
    async def __anext__(self) -> AsyncDirEntry: ...


async def read_dir_async(path: FsPathLike) -> AsyncReadDir: ...


# =============================================================================
# SLEEP
# =============================================================================
async def sleep_async(secs: float) -> float: ...
async def asleep(secs: float) -> float:
    """Alias for sleep_async"""


# =============================================================================
# ASYNC-FILE
# =============================================================================
@t.final
class AsyncFile:
    def __new__(cls, path: FsPathLike, mode: OpenBinaryMode = "rb") -> t.Self: ...
    async def close(self) -> None: ...
    async def flush(self) -> None: ...
    async def isatty(self) -> t.NoReturn: ...
    async def open(self) -> None: ...
    async def peek(self, size: int = ..., /) -> Bytes: ...
    async def read(self, size: int | None = None, /) -> Bytes: ...
    def readable(self) -> bool: ...
    async def readall(self) -> Bytes: ...
    async def readline(self, size: int | None = None, /) -> Bytes: ...
    async def readlines(self, hint: int | None = None, /) -> list[Bytes]: ...
    async def seek(self, offset: int, whence: int = ..., /) -> int: ...
    def seekable(self) -> bool: ...
    async def tell(self) -> int: ...
    async def truncate(self, pos: int | None = None, /) -> int: ...
    def writable(self) -> bool: ...
    async def write(self, b: Buffer, /) -> int: ...
    @property
    def closed(self) -> bool: ...
    def __await__(self) -> Generator[t.Any, t.Any, t.Self]: ...
    def __aiter__(self) -> t.Self: ...
    async def __anext__(self) -> Bytes: ...
    async def __aenter__(self) -> t.Self: ...
    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None: ...


def aopen(
    path: FsPathLike, mode: OpenBinaryMode | str = "rb", buffering: int = -1
) -> AsyncFile: ...


@t.final
class AsyncFileReadStream(RyAsyncIterator[Bytes]):
    def __new__(
        cls,
        path: FsPathLike,
        *,
        read_size: int = 65536,
        offset: int = 0,
        buffered: bool = True,
        strict: bool = True,
    ) -> t.Self:
        """asynchronous file read stream

        Parameters
        ----------
        path : FsPathLike
            path-like object
        read_size : int, optional
            number of bytes to read at a time (default=65536)
        offset : int, optional
            offset to start reading from (default=0)
        buffered : bool, optional
            whether the stream is buffered (default=True)
        strict : bool, optional
            whether to raise a ValueError on offset beyond EOF (default=True)

        Raises
        ------
        FileNotFoundError
            If file does not exist.
        IsADirectoryError
            If path is a directory.
        ValueError
            If offset is beyond EOF and strict is True.

        """

    def __await__(self) -> Generator[t.Any, t.Any, t.Self]: ...
    async def __aenter__(self) -> t.Self: ...
    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None: ...
    def __aiter__(self) -> t.Self: ...
    async def __anext__(self) -> Bytes: ...
    async def close(self) -> None: ...
    async def collect(self) -> list[Bytes]: ...
    async def take(self, n: int = 1) -> list[Bytes]: ...


def read_stream_async(
    path: FsPathLike,
    read_size: int = 65536,
    *,
    offset: int = 0,
    buffered: bool = True,
    strict: bool = True,
) -> AsyncFileReadStream:
    """Return an `AsyncFileReadStream` for the given path-like object

    Parameters
    ----------
    path : FsPathLike
        path-like object
    read_size : int, optional
        number of bytes to read at a time (default=65536)
    offset : int, optional
        offset to start reading from (default=0)
    buffered : bool, optional
        whether the stream is buffered (default=True)
    strict : bool, optional
        whether to raise a ValueError on offset beyond EOF (default=True)

    Raises
    ------
    FileNotFoundError
        If file does not exist.
    IsADirectoryError
        If path is a directory.
    ValueError
        If offset is beyond EOF and strict is True.

    """
```

<h2 id="ry.ryo3._tokio_websockets"><code>ry.ryo3._tokio_websockets</code></h2>

```python
"""ryo3-tokio-websockets ~ types"""

import datetime as pydt
import sys
import typing as t
from collections.abc import Generator
from types import TracebackType

from ry import Bytes
from ry._types import Buffer
from ry.ryo3._http import Headers, HttpStatus
from ry.ryo3._std import Duration
from ry.ryo3._url import URL

if sys.version_info >= (3, 12):
    from collections.abc import Buffer as Buffer
else:
    from typing_extensions import Buffer as Buffer

_TimeoutLike: t.TypeAlias = Duration | pydt.timedelta | float


class WebSocketConfig(t.TypedDict):
    headers: Headers
    max_payload_len: int
    frame_size: int
    flush_threshold: int
    close_timeout: Duration | None
    recv_timeout: Duration | None


_ReadyState: t.TypeAlias = t.Literal[
    0,  # CONNECTING
    1,  # OPEN
    2,  # CLOSING
    3,  # CLOSED
]


@t.final
class WsMessage(Buffer):
    @t.overload
    def __new__(cls, kind: t.Literal["text"], data: str) -> t.Self: ...
    @t.overload
    def __new__(cls, kind: t.Literal["binary"], data: Buffer) -> t.Self: ...
    @t.overload
    def __new__(
        cls, kind: t.Literal["ping", "pong"], data: Buffer | None = None
    ) -> t.Self: ...
    @t.overload
    def __new__(
        cls,
        kind: t.Literal["close"],
        data: None = None,
        *,
        code: int | None = None,  # default: 1000
        reason: str | Buffer | None = None,  # default: ""
    ) -> t.Self: ...
    # -------------------------------------------------------------------------
    # "CLASSMETHODS" (STATIC FACTORY FNS)
    # -------------------------------------------------------------------------
    @staticmethod
    def text(text: str) -> WsMessage:
        """Construct a new text message with the given text data."""

    @staticmethod
    def binary(data: Buffer) -> WsMessage:
        """Construct a new binary message with the given data."""

    @staticmethod
    def ping(payload: Buffer | None = None) -> WsMessage:
        """Construct a new ping message with the given optional payload

        Parameters
        ----------
        payload : Buffer | None, optional
            optional payload data for the ping message, by default None

        Raises
        ------
        ValueError
            if the payload is larger than 125 bytes

        Examples
        --------
        >>> from ry import WsMessage
        >>> ping_msg = WsMessage.ping(b"ping-payload")
        >>> ping_msg.kind
        'ping'
        >>> ping_msg.payload
        Bytes(b"ping-payload")
        >>> too_large_payload = b"x" * 126
        >>> WsMessage.ping(too_large_payload)  # doctest: +IGNORE_EXCEPTION_DETAIL
        Traceback (most recent call last):
            ...
        ValueError: ping-payload exceeds the websocket limit of 125 bytes

        """

    @staticmethod
    def pong(payload: Buffer | None = None) -> WsMessage:
        """Construct a new pong message with the given optional payload

        Parameters
        ----------
        payload : Buffer | None, optional
            optional payload data for the pong message, by default None

        Raises
        ------
        ValueError
            if the payload is larger than 125 bytes

        Examples
        --------
        >>> from ry import WsMessage
        >>> pong_msg = WsMessage.pong(b"pong-payload")
        >>> pong_msg.kind
        'pong'
        >>> pong_msg.payload
        Bytes(b"pong-payload")
        >>> too_large_payload = b"x" * 126
        >>> WsMessage.pong(too_large_payload)  # doctest: +IGNORE_EXCEPTION_DETAIL
        Traceback (most recent call last):
            ...
        ValueError: pong-payload exceeds the websocket limit of 125 bytes

        """

    @staticmethod
    def close(code: int = 1_000, reason: str | Buffer | None = None) -> WsMessage:
        """Construct a new close message with the given close-code and reason"""

    # -------------------------------------------------------------------------
    # PROPERTIES
    # -------------------------------------------------------------------------

    @property
    def kind(self) -> t.Literal["text", "binary", "close", "ping", "pong"]:
        """Return the message kind as a string literal."""

    @property
    def is_text(self) -> bool:
        """Return `True` if this is a text message, `False` otherwise"""

    @property
    def is_binary(self) -> bool:
        """Return `True` if this is a binary message, `False` otherwise"""

    @property
    def is_close(self) -> bool:
        """Return `True` if this is a close message, `False` otherwise"""

    @property
    def is_ping(self) -> bool:
        """Return `True` if this is a ping message, `False` otherwise"""

    @property
    def is_pong(self) -> bool:
        """Return `True` if this is a pong message, `False` otherwise"""

    @property
    def data(self) -> str | Bytes:
        """Return the message data as a `str` for text messages or `Bytes` for binary messages"""

    @property
    def payload(self) -> Bytes:
        """Return the message payload as a `Bytes` object for any message kind"""

    @property
    def code(self) -> int | None:
        """Returns the close code as an integer if the close message"""

    @property
    def reason(self) -> str | None:
        """Returns the close reason as a string if the close message"""

    # -------------------------------------------------------------------------
    # INSTANCE METHODS
    # -------------------------------------------------------------------------
    def json(
        self,
        *,
        allow_inf_nan: bool = False,
        cache_mode: t.Literal[True, False, "all", "keys", "none"] = "all",
        partial_mode: t.Literal[True, False, "off", "on", "trailing-strings"] = False,
        catch_duplicate_keys: bool = False,
    ) -> t.Any:
        """Parse the message payload as JSON"""

    def __bytes__(self) -> bytes:
        """Return message payload as `builtins.bytes`"""

    def __len__(self) -> int:
        """Return the length of the message payload in bytes"""


@t.final
class WebSocket:
    def __new__(
        cls,
        uri: URL | str,
        *,
        headers: Headers | dict[str, str] | None = None,
        max_payload_len: int = 67_108_864,
        frame_size: int = 4_194_304,
        flush_threshold: int = 8_192,
        close_timeout: _TimeoutLike | None = 10,
        recv_timeout: _TimeoutLike | None = None,
    ) -> t.Self: ...
    def config(self) -> WebSocketConfig:
        """Return the `WebSocketConfig` as a dict"""

    @property
    def uri(self) -> str: ...
    @property
    def status(self) -> HttpStatus | None:
        """Return the HTTP status of the websocket handshake if connected"""

    @property
    def headers(self) -> Headers | None:
        """Return the HTTP headers of the websocket handshake if connected"""

    @property
    def closed(self) -> bool:
        """Return `True` if the WebSocket is closed, `False` otherwise"""

    @property
    def open(self) -> bool:
        """Return `True` if the WebSocket is open, `False` otherwise"""

    @property
    def ready_state(self) -> _ReadyState:
        """Return `WebSocket` ready-state (`0`=CONNECTING, `1`=OPEN, `2`=CLOSING, `3`=CLOSED)

        Based on the `WebSocket.readyState` property from the Web API:
        <https://developer.mozilla.org/en-US/docs/Web/API/WebSocket/readyState>

        - `0` CONNECTING: created, not connected yet (`await ws` connects)
        - `1` OPEN
        - `2` CLOSING: a started close always finishes (see `close_timeout`)
        - `3` CLOSED: closed or failed to connect; `await ws` reconnects
        """

    def __bool__(self) -> bool:
        """Return `True` if the WebSocket is open, `False` otherwise"""

    async def recv(self, timeout: _TimeoutLike | None = None) -> WsMessage:
        """Receive the next message from the WebSocket connection"""

    async def receive(self, timeout: _TimeoutLike | None = None) -> WsMessage:
        """Receive the next message from the WebSocket connection"""

    async def send(self, message: WsMessage | str | Buffer) -> None:
        """Send a message over the WebSocket connection"""

    async def send_json(
        self,
        data: t.Any,
        *,
        kind: t.Literal["text", "binary", "ping", "pong"] = "text",
        default: t.Callable[[t.Any], t.Any] | None = None,
        fmt: bool = False,
        sort_keys: bool = False,
        append_newline: bool = False,
    ) -> None:
        """Serialize `data` to JSON and send it over the WebSocket connection

        Parameters
        ----------
        data : Any
            JSON-serializable object
        kind : Literal["text", "binary", "ping", "pong"], optional
            websocket message kind to send the JSON as, by default "text";
            ping/pong payloads are limited to 125 bytes
        default : Callable[[Any], Any] | None, optional
            fallback serializer for otherwise unsupported types, by default None
        fmt : bool, optional
            pretty-print (2-space indent), by default False
        sort_keys : bool, optional
            sort object keys, by default False
        append_newline : bool, optional
            append a trailing newline, by default False

        Serialization options are the same as `ry.stringify` (minus `dtype`)

        Raises
        ------
        ValueError
            if `kind` is "close" (use `WebSocket.close`) or a ping/pong
            payload exceeds 125 bytes
        TypeError
            if `data` is not JSON-serializable
        """

    async def close(
        self, code: int = 1_000, reason: str | Buffer | None = None
    ) -> None:
        """Close the WebSocket connection.

        Sends the close frame and waits for the peer's. A started close always
        finishes, even if this call is cancelled; it gives up after
        `close_timeout` (`None` waits forever, so a peer that never answers
        keeps the connection open).

        Parameters
        ----------
        code : int, optional
            close code (default: `1000`=NORMAL_CLOSURE)
        reason : str | Buffer | None, optional
            close reason (max length: 123 bytes), by default None
        """

    async def ping(self, payload: Buffer | None = None) -> None:
        """Send a ping frame over the WebSocket connection"""

    async def pong(self, payload: Buffer | None = None) -> None:
        """Send a pong frame over the WebSocket connection"""

    def __await__(self) -> Generator[t.Any, t.Any, t.Self]: ...
    def __aiter__(self) -> t.Self: ...
    async def __anext__(self) -> WsMessage: ...
    async def __aenter__(self) -> t.Self: ...
    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None: ...


def websocket(
    uri: URL | str,
    *,
    headers: Headers | dict[str, str] | None = None,
    close_timeout: _TimeoutLike | None = 10,
    recv_timeout: _TimeoutLike | None = None,
    flush_threshold: int = 8_192,
    frame_size: int = 4_194_304,
    max_payload_len: int = 67_108_864,
) -> WebSocket: ...
```

<h2 id="ry.ryo3._twox_hash"><code>ry.ryo3._twox_hash</code></h2>

```python
"""ryo3-twox-hash ~ types"""

import typing as t

from ry._types import Buffer


@t.final
class xxh32:  # noqa: N801
    name: t.Literal["xxh32"]
    digest_size: t.Literal[4]
    block_size: t.Literal[16]

    def __new__(cls, data: Buffer | None = None, *, seed: int = 0) -> t.Self: ...
    def update(self, data: Buffer) -> None: ...
    def digest(self) -> bytes: ...
    def hexdigest(self) -> str: ...
    def intdigest(self) -> int: ...
    def copy(self) -> t.Self: ...
    def reset(self, *, seed: int | None = None) -> None: ...
    @property
    def seed(self) -> int: ...
    @property
    def length(self) -> int:
        """number of bytes hashed"""

    @staticmethod
    def oneshot(data: Buffer, *, seed: int = 0) -> bytes: ...
    @staticmethod
    def oneshot_int(data: Buffer, *, seed: int = 0) -> int: ...
    @staticmethod
    def oneshot_hex(data: Buffer, *, seed: int = 0) -> str: ...


@t.final
class xxh64:  # noqa: N801
    name: t.Literal["xxh64"]
    digest_size: t.Literal[8]
    block_size: t.Literal[32]

    def __new__(cls, data: Buffer | None = None, *, seed: int = 0) -> t.Self: ...
    def update(self, data: Buffer) -> None: ...
    def digest(self) -> bytes: ...
    def hexdigest(self) -> str: ...
    def intdigest(self) -> int: ...
    def copy(self) -> t.Self: ...
    def reset(self, *, seed: int | None = None) -> None: ...
    @property
    def seed(self) -> int: ...
    @property
    def length(self) -> int:
        """number of bytes hashed"""

    @staticmethod
    def oneshot(data: Buffer, *, seed: int = 0) -> bytes: ...
    @staticmethod
    def oneshot_int(data: Buffer, *, seed: int = 0) -> int: ...
    @staticmethod
    def oneshot_hex(data: Buffer, *, seed: int = 0) -> str: ...


@t.final
class xxh3_64:  # noqa: N801
    name: t.Literal["xxh3_64"]
    digest_size: t.Literal[8]
    block_size: t.Literal[32]

    def __new__(
        cls,
        data: Buffer | None = None,
        *,
        seed: int = 0,
        secret: Buffer | None = ...,
    ) -> t.Self: ...
    def update(self, data: Buffer) -> None: ...
    def digest(self) -> bytes: ...
    def hexdigest(self) -> str: ...
    def intdigest(self) -> int: ...
    @property
    def seed(self) -> int: ...
    def copy(self) -> t.Self: ...
    def reset(self, *, seed: int | None = None) -> None: ...
    @staticmethod
    def oneshot(
        data: Buffer, *, seed: int = 0, secret: Buffer | None = None
    ) -> bytes: ...
    @staticmethod
    def oneshot_int(
        data: Buffer, *, seed: int = 0, secret: Buffer | None = None
    ) -> int: ...
    @staticmethod
    def oneshot_hex(
        data: Buffer, *, seed: int = 0, secret: Buffer | None = None
    ) -> str: ...


@t.final
class xxh3_128:  # noqa: N801
    name: t.Literal["xxh3_128"]
    digest_size: t.Literal[16]
    block_size: t.Literal[64]

    def __new__(
        cls,
        data: Buffer | None = None,
        *,
        seed: int = 0,
        secret: Buffer | None = ...,
    ) -> t.Self: ...
    def update(self, data: Buffer) -> None: ...
    def digest(self) -> bytes: ...
    def hexdigest(self) -> str: ...
    def intdigest(self) -> int: ...
    @property
    def seed(self) -> int: ...
    def copy(self) -> t.Self: ...
    def reset(self, *, seed: int | None = None) -> None: ...
    @staticmethod
    def oneshot(
        data: Buffer, *, seed: int = 0, secret: Buffer | None = None
    ) -> bytes: ...
    @staticmethod
    def oneshot_int(
        data: Buffer, *, seed: int = 0, secret: Buffer | None = None
    ) -> int: ...
    @staticmethod
    def oneshot_hex(
        data: Buffer, *, seed: int = 0, secret: Buffer | None = None
    ) -> str: ...
```

<h2 id="ry.ryo3._ulid"><code>ry.ryo3._ulid</code></h2>

```python
"""ryo3-ulid ~ types"""

import builtins
import datetime as pydt
import typing as t
import uuid
from collections.abc import Callable as Callable

from pydantic import GetCoreSchemaHandler as GetCoreSchemaHandler
from pydantic import ValidatorFunctionWrapHandler as ValidatorFunctionWrapHandler
from pydantic_core import CoreSchema as CoreSchema

from ry.protocols import FromStr


@t.final
class ULID(FromStr):
    TIME_BITS: t.Literal[48]
    RAND_BITS: t.Literal[80]
    MAX: t.Final[ULID]
    NIL: t.Final[ULID]

    def __new__(cls, value: builtins.bytes | str | None = None) -> t.Self: ...

    # ----------------
    # INSTANCE METHODS
    # ----------------
    def equiv(self, other: object, /) -> bool: ...
    def to_bytes(self) -> builtins.bytes: ...
    def to_uuid(self) -> uuid.UUID: ...
    def to_uuid4(self) -> uuid.UUID: ...

    # ----------
    # PROPERTIES
    # ----------
    @property
    def bytes(self) -> builtins.bytes: ...
    @property
    def milliseconds(self) -> int: ...
    @property
    def timestamp(self) -> float: ...
    @property
    def datetime(self) -> pydt.datetime: ...
    @property
    def hex(self) -> str: ...

    # -------------
    # CLASS METHODS
    # -------------
    @classmethod
    def from_datetime(cls, value: pydt.datetime) -> ULID: ...
    @classmethod
    def from_timestamp(cls, value: float) -> ULID: ...
    @classmethod
    def from_timestamp_seconds(cls, value: float) -> ULID: ...
    @classmethod
    def from_timestamp_milliseconds(cls, value: int) -> ULID: ...
    @classmethod
    def from_uuid(cls, uu: uuid.UUID) -> ULID: ...
    @classmethod
    def from_bytes(cls, b: builtins.bytes) -> ULID: ...
    @classmethod
    def from_hex(cls, hexstr: str) -> ULID: ...
    @classmethod
    def from_str(cls, s: str, /) -> ULID: ...
    @classmethod
    def from_string(cls, s: str, /) -> ULID:
        """Alias for `from_str` to match python-ulid lib"""

    @classmethod
    def from_int(cls, i: int) -> ULID: ...
    @classmethod
    def parse(cls, value: t.Any) -> ULID: ...
    @staticmethod
    def _reset_generator() -> None: ...

    # -------
    # DUNDERS
    # -------
    def __int__(self) -> int: ...
    def __bytes__(self) -> builtins.bytes: ...
    def __lt__(self, other: t.Self, /) -> bool: ...
    def __le__(self, other: t.Self, /) -> bool: ...
    def __eq__(self, other: object, /) -> bool: ...
    def __ne__(self, other: object, /) -> bool: ...
    def __gt__(self, other: t.Self, /) -> bool: ...
    def __ge__(self, other: t.Self, /) -> bool: ...
    def __hash__(self) -> int: ...

    # --------
    # PYDANTIC
    # --------
    @classmethod
    def __get_pydantic_core_schema__(
        cls, source: t.Any, handler: GetCoreSchemaHandler
    ) -> CoreSchema: ...
```

<h2 id="ry.ryo3._unindent"><code>ry.ryo3._unindent</code></h2>

```python
"""ryo3-unindent ~ types"""


def unindent(s: str, /) -> str:
    """Unindent a string.

    Examples
    --------
    >>> import ry
    >>> indented_str = '''
    ...     indented'''
    >>> ry.unindent(indented_str)
    'indented'

    """


def unindent_bytes(b: bytes, /) -> bytes:
    """Unindent a python bytes.

    Examples
    --------
    >>> import ry
    >>> indented_bytes = b'''
    ...     indented'''
    >>> ry.unindent_bytes(indented_bytes)
    b'indented'

    """
```

<h2 id="ry.ryo3._url"><code>ry.ryo3._url</code></h2>

```python
"""ryo3-url ~ types"""

import typing as t
from ipaddress import IPv4Address, IPv6Address

from ry._types import FsPathLike
from ry.protocols import FromStr, ToString, _Parse
from ry.ryo3._std import IpAddr, Ipv4Addr, Ipv6Addr, SocketAddr


@t.final
class URL(FromStr, ToString, _Parse):
    def __new__(
        cls, url: str | bytes | URL, *, params: dict[str, str] | None = None
    ) -> t.Self: ...
    # =========================================================================
    # CLASSMETHODS
    # =========================================================================
    @classmethod
    def parse(cls, value: str | bytes, /) -> t.Self: ...
    @classmethod
    def from_str(cls, s: str, /) -> t.Self: ...
    @classmethod
    def parse_with_params(cls, url: str | bytes, params: dict[str, str]) -> t.Self: ...
    @classmethod
    def from_directory_path(cls, path: FsPathLike) -> t.Self: ...
    @classmethod
    def from_filepath(cls, path: FsPathLike) -> t.Self: ...
    # =========================================================================
    # STRING
    # =========================================================================
    def to_string(self) -> str: ...
    def __fspath__(self) -> str: ...

    # =========================================================================
    # PROPERTIES
    # =========================================================================
    @property
    def authority(self) -> str: ...
    @property
    def domain(self) -> str | None: ...
    @property
    def fragment(self) -> str | None: ...
    @property
    def host(self) -> str | Ipv4Addr | Ipv6Addr | None: ...
    @property
    def host_str(self) -> str | None: ...
    @property
    def netloc(self) -> str: ...
    @property
    def password(self) -> str | None: ...
    @property
    def path(self) -> str: ...
    @property
    def path_segments(self) -> tuple[str, ...]: ...
    @property
    def port(self) -> int | None:
        """The port number for this URL, if any.

        Note
        ----
        the default port numbers are never reflected by the serialization,
        use the `port_or_known_default` if you want a default port number returned.

        Default port numbers:
            - `http`  | `ws`  => `80`
            - `https` | `wss` => `443`
            - `ftp`           => `21`

        Examples
        --------
        >>> from ry import URL
        >>> assert URL("https://rotatingsandwiches.com:3000").port == 3000
        >>> assert URL("https://rotatingsandwiches.com").port is None
        >>> assert URL("https://rotatingsandwiches.com:443/").port is None
        >>> assert URL("ssh://rotatingsandwiches.com:22").port == 22

        """

    @property
    def port_or_known_default(self) -> int | None:
        """The port number, or the default port number if known.

        Default port numbers:
            - `http`  | `ws`  => `80`
            - `https` | `wss` => `443`
            - `ftp`           => `21`

        Examples
        --------
        >>> from ry import URL
        >>> URL("https://rotatingsandwiches.com:3000").port_or_known_default
        3000
        >>> URL("https://rotatingsandwiches.com").port_or_known_default
        443
        >>> URL("https://rotatingsandwiches.com:443/").port_or_known_default
        443
        >>> URL("ssh://rotatingsandwiches.com:22").port_or_known_default
        22

        """

    @property
    def query(self) -> str | None: ...
    @property
    def query_string(self) -> str: ...
    @property
    def query_pairs(self) -> tuple[tuple[str, str], ...]: ...
    @property
    def scheme(self) -> str: ...
    @property
    def user(self) -> str:
        """alias for yarl compatibility"""

    @property
    def username(self) -> str: ...
    @property
    def origin(self) -> str: ...

    # =========================================================================
    # INSTANCE METHODS
    # =========================================================================
    def has_authority(self) -> bool: ...
    def has_host(self) -> bool: ...
    def equiv(self, other: URL | str) -> bool: ...
    def is_special(self) -> bool: ...
    def join(self, *parts: str) -> URL: ...
    def make_relative(self, other: URL) -> t.Self: ...
    def socket_addrs(
        self, default_port_number: int | None = None
    ) -> list[SocketAddr]: ...
    def to_filepath(self) -> str: ...
    def replace(
        self,
        *,
        scheme: str = ...,
        username: str = ...,
        password: str | None = ...,
        host: str
        | IPv4Address
        | IPv6Address
        | Ipv4Addr
        | Ipv6Addr
        | IpAddr
        | None = ...,
        port: int | None = ...,
        path: str = ...,
        query: str | None = ...,
        fragment: str | None = ...,
    ) -> t.Self:
        """Return a new URL with the given parts replaced (like `dataclasses.replace`)

        Omitted kwargs are kept and `None` clears a part. Parts are applied in
        url order (scheme, username, password, host, port, path, query,
        fragment), so combined replacements don't depend on kwarg order.

        Parameters
        ----------
        scheme : str, optional
            url scheme (`http`, `https`, `ws`, `wss`, `ftp`, `file`)
        username : str, optional
            username; `""` removes it (the password is kept).
        password : str | None, optional
            New password; `None` removes it.
        host : str | IPv4Address | IPv6Address | Ipv4Addr | Ipv6Addr | IpAddr | None, optional
            host to set; a str is parsed based on the URL's scheme.
        port : int | None, optional
            port (0-65535); `None` removes it.
        path : str, optional
            path; a leading `/` is added for urls with a host.
        query : str | None, optional
            query string (without the `?`); `None` removes it, `""` leaves
            an empty `?`.
        fragment : str | None, optional
            fragment (without the `#`); `None` removes it, `""` leaves an empty `#`.

        Raises
        ------
        TypeError
            If `None` is given for `scheme`, `username` or `path`, or wrong kw type
        ValueError
            If the url can't take the new value (e.g. a port on a `file:` url,
            removing the host of an `http` url, an invalid host).
        OverflowError
            If `port` is outside 0-65535.

        Examples
        --------
        >>> import ry
        >>> u = ry.URL("http://user:pass@example.com:8080/foo?a=1#frag")
        >>> u.replace(path="/bar", query=None, fragment=None)
        URL('http://user:pass@example.com:8080/bar')
        >>> u.replace(port=None, password=None)
        URL('http://user@example.com/foo?a=1#frag')
        >>> u.replace(host=ry.Ipv4Addr(127, 0, 0, 1))
        URL('http://user:pass@127.0.0.1:8080/foo?a=1#frag')

        """

    def with_fragment(self, fragment: str | None = None) -> t.Self:
        """Return a new URL with the fragment replaced

        Parameters
        ----------
        fragment : str | None, optional
            fragment (without the `#`); `None` (the default) removes it, `""`
            leaves an empty `#`.

        Examples
        --------
        >>> import ry
        >>> ry.URL("http://example.com/a#x").with_fragment("y")
        URL('http://example.com/a#y')
        >>> ry.URL("http://example.com/a#x").with_fragment(None)
        URL('http://example.com/a')

        """

    def with_host(
        self,
        host: str
        | IPv4Address
        | IPv6Address
        | Ipv4Addr
        | Ipv6Addr
        | IpAddr
        | None = None,
    ) -> t.Self:
        """Return a new URL with the host replaced

        Parameters
        ----------
        host : str | IPv4Address | IPv6Address | Ipv4Addr | Ipv6Addr | IpAddr | None, optional
            host to set; a str is parsed based on the URL's scheme. `None`
            (the default) removes it.

        Raises
        ------
        ValueError
            If the host is invalid or can't be removed.

        Examples
        --------
        >>> import ry
        >>> ry.URL("http://example.com/a").with_host("example.org")
        URL('http://example.org/a')
        >>> ry.URL("http://example.com/a").with_host(ry.Ipv6Addr.parse("::1"))
        URL('http://[::1]/a')
        >>> ry.URL("foo://example.com/a").with_host(None)
        URL('foo:/a')

        """

    def with_ip_host(
        self, address: IPv4Address | IPv6Address | Ipv4Addr | Ipv6Addr | IpAddr
    ) -> t.Self:
        """Return a new URL with an ip address as the host

        Parameters
        ----------
        address : IPv4Address | IPv6Address | Ipv4Addr | Ipv6Addr | IpAddr
            ip address to set as the host (`with_host` & `replace(host=...)`
            accept ip addresses too).

        Raises
        ------
        ValueError
            If the url can't have a host (e.g. `mailto:`).

        Examples
        --------
        >>> import ry
        >>> ry.URL("http://example.com/a").with_ip_host(ry.Ipv4Addr(10, 0, 0, 1))
        URL('http://10.0.0.1/a')

        """

    def with_password(self, password: str | None = None) -> t.Self:
        """Return a new URL with the password replaced

        Parameters
        ----------
        password : str | None, optional
            password; `None` (the default) removes it.

        Raises
        ------
        ValueError
            If the url can't have a password (no host, or `file:`).

        Examples
        --------
        >>> import ry
        >>> ry.URL("http://user@example.com/").with_password("pw")
        URL('http://user:pw@example.com/')

        """

    def with_path(self, path: str) -> t.Self:
        """Return a new URL with the path replaced

        Parameters
        ----------
        path : str
            path; a leading `/` is added for urls with a host.

        Examples
        --------
        >>> import ry
        >>> ry.URL("http://example.com/a?q=1").with_path("b/c")
        URL('http://example.com/b/c?q=1')

        """

    def with_port(self, port: int | None = None) -> t.Self:
        """Return a new URL with the port replaced

        Parameters
        ----------
        port : int | None, optional
            port (0-65535); `None` (the default) removes it.

        Raises
        ------
        ValueError
            If the url can't have a port (no host, or `file:`).
        OverflowError
            If `port` is outside 0-65535.

        Examples
        --------
        >>> import ry
        >>> ry.URL("http://example.com/").with_port(8080)
        URL('http://example.com:8080/')
        >>> ry.URL("http://example.com:8080/").with_port(None)
        URL('http://example.com/')

        """

    def with_query(self, query: str | None = None) -> t.Self:
        """Return a new URL with the query string replaced

        Parameters
        ----------
        query : str | None, optional
            query string (without the `?`); `None` (the default) removes it,
            `""` leaves an empty `?`.

        Examples
        --------
        >>> import ry
        >>> ry.URL("http://example.com/a?x=1").with_query("y=2")
        URL('http://example.com/a?y=2')
        >>> ry.URL("http://example.com/a?x=1").with_query(None)
        URL('http://example.com/a')

        """

    def with_scheme(self, scheme: str) -> t.Self:
        """Return a new URL with the scheme replaced

        Parameters
        ----------
        scheme : str
            url scheme (`http`, `https`, `ws`, `wss`, `ftp`, `file`)

        Raises
        ------
        ValueError
            If the scheme is invalid or the switch isn't allowed.

        Examples
        --------
        >>> import ry
        >>> ry.URL("http://example.com/").with_scheme("https")
        URL('https://example.com/')

        """

    def with_username(self, username: str) -> t.Self:
        """Return a new URL with the username replaced

        Parameters
        ----------
        username : str
            username; `""` removes it (the password is kept).

        Raises
        ------
        ValueError
            If the url can't have a username (no host, or `file:`).

        Examples
        --------
        >>> import ry
        >>> ry.URL("http://example.com/").with_username("me")
        URL('http://me@example.com/')

        """

    # =========================================================================
    # OPERATORS/DUNDER
    # =========================================================================
    def __len__(self) -> int: ...
    def __truediv__(self, relative: str, /) -> t.Self: ...
    def __rtruediv__(self, relative: str, /) -> t.Self: ...
    def __lt__(self, other: t.Self, /) -> bool: ...
    def __le__(self, other: t.Self, /) -> bool: ...
    def __eq__(self, other: object, /) -> bool: ...
    def __ne__(self, other: object, /) -> bool: ...
    def __gt__(self, other: t.Self, /) -> bool: ...
    def __ge__(self, other: t.Self, /) -> bool: ...
    def __hash__(self) -> int: ...
```

<h2 id="ry.ryo3._uuid"><code>ry.ryo3._uuid</code></h2>

```python
"""ryo3-uuid ~ types

based on typeshed types for python's builtin uuid module

REF: https://github.com/python/typeshed/blob/main/stdlib/uuid.pyi
"""

import builtins
import typing as t
import uuid as pyuuid

from ry._types import Buffer
from ry.protocols import FromStr

# aliases ~ `UUID.int` / `UUID.bytes` shadow the builtins inside the class
_Bytes: t.TypeAlias = builtins.bytes
_Int: t.TypeAlias = builtins.int
_UuidVersion: t.TypeAlias = t.Literal[1, 2, 3, 4, 5, 6, 7, 8]
_UuidFields: t.TypeAlias = tuple[int, int, int, int, int, int]


@t.final
class UUID(FromStr):
    """UUID class & namespace (hybrid)"""

    NAMESPACE_DNS: t.Final[UUID]
    NAMESPACE_URL: t.Final[UUID]
    NAMESPACE_OID: t.Final[UUID]
    NAMESPACE_X500: t.Final[UUID]
    NIL: t.Final[UUID]
    MAX: t.Final[UUID]
    RESERVED_NCS: t.Final = "reserved for NCS compatibility"
    RFC_4122: t.Final = "specified in RFC 4122"
    RESERVED_MICROSOFT: t.Final = "reserved for Microsoft compatibility"
    RESERVED_FUTURE: t.Final = "reserved for future definition"

    @t.overload
    def __new__(cls, hex: str, *, version: _UuidVersion | None = None) -> t.Self: ...
    @t.overload
    def __new__(
        cls, *, bytes: _Bytes, version: _UuidVersion | None = None
    ) -> t.Self: ...
    @t.overload
    def __new__(
        cls, *, bytes_le: _Bytes, version: _UuidVersion | None = None
    ) -> t.Self: ...
    @t.overload
    def __new__(
        cls, *, fields: _UuidFields, version: _UuidVersion | None = None
    ) -> t.Self: ...
    @t.overload
    def __new__(cls, *, int: _Int, version: _UuidVersion | None = None) -> t.Self: ...
    @t.overload
    def __new__(
        cls,
        hex: None = None,
        bytes: None = None,
        bytes_le: None = None,
        fields: None = None,
        int: None = None,
        version: _UuidVersion | None = None,
    ) -> t.NoReturn: ...
    @staticmethod
    def getnode() -> _Int: ...
    @staticmethod
    def uuid1(node: _Int | None = None, clock_seq: _Int | None = None) -> UUID: ...
    @staticmethod
    def uuid3(namespace: UUID, name: str | _Bytes) -> UUID: ...
    @staticmethod
    def uuid4() -> UUID: ...
    @staticmethod
    def uuid5(namespace: UUID, name: str | _Bytes) -> UUID: ...
    @staticmethod
    def uuid6(node: _Int | None = None, clock_seq: _Int | None = None) -> UUID: ...
    @staticmethod
    def uuid7(timestamp: _Int | None = None) -> UUID: ...
    @t.overload
    @staticmethod
    def uuid8(*, buf: Buffer) -> UUID: ...  # 16 bytes buffer
    @t.overload
    @staticmethod
    def uuid8(
        a: _Int | None = None,
        b: _Int | None = None,
        c: _Int | None = None,
        *,
        buf: None = None,
    ) -> UUID: ...
    @staticmethod
    def _reseed_rng() -> None: ...
    @property
    def is_nil(self) -> bool: ...
    @property
    def bytes(self) -> _Bytes: ...
    @property
    def bytes_le(self) -> _Bytes: ...
    @property
    def clock_seq(self) -> _Int: ...
    @property
    def clock_seq_hi_variant(self) -> _Int: ...
    @property
    def clock_seq_low(self) -> _Int: ...
    @property
    def fields(self) -> _UuidFields: ...
    @property
    def hex(self) -> str: ...
    @property
    def int(self) -> _Int: ...
    @property
    def node(self) -> _Int: ...
    @property
    def time(self) -> _Int: ...
    @property
    def time_hi_version(self) -> _Int: ...
    @property
    def time_low(self) -> _Int: ...
    @property
    def time_mid(self) -> _Int: ...
    @property
    def urn(self) -> str: ...
    @property
    def variant(self) -> str: ...
    @property
    def version(self) -> _UuidVersion | None: ...
    def equiv(self, other: object, /) -> bool: ...
    def to_py(self) -> pyuuid.UUID: ...
    def to_string(self) -> str: ...
    def format(
        self, kind: t.Literal["hyphenated", "simple", "urn", "braced"] = "hyphenated"
    ) -> str: ...
    def __format__(self, format_spec: str, /) -> str: ...
    # --- CLASSMETHODS --
    @classmethod
    def from_bytes(cls, b: _Bytes) -> t.Self: ...
    @classmethod
    def from_bytes_le(cls, b: _Bytes) -> t.Self: ...
    @classmethod
    def from_fields(cls, fields: _UuidFields) -> t.Self: ...
    @classmethod
    def from_hex(cls, hexstr: str) -> t.Self: ...
    @classmethod
    def from_int(cls, i: _Int) -> t.Self: ...
    @classmethod
    def from_pyuuid(cls, ob: pyuuid.UUID) -> t.Self: ...
    @classmethod
    def from_str(cls, s: str, /) -> t.Self: ...
    # --- DUNDERS ---
    def __bytes__(self) -> _Bytes: ...
    def __lt__(self, other: UUID | pyuuid.UUID, /) -> bool: ...
    def __le__(self, other: UUID | pyuuid.UUID, /) -> bool: ...
    def __eq__(self, other: object, /) -> bool: ...
    def __ne__(self, other: object, /) -> bool: ...
    def __gt__(self, other: UUID | pyuuid.UUID, /) -> bool: ...
    def __ge__(self, other: UUID | pyuuid.UUID, /) -> bool: ...
    def __hash__(self) -> _Int: ...
    def __int__(self) -> _Int: ...


def getnode() -> _Int: ...
def uuid1(node: _Int | None = None, clock_seq: _Int | None = None) -> UUID: ...
def uuid3(namespace: UUID, name: str | _Bytes) -> UUID: ...
def uuid4() -> UUID: ...
def uuid5(namespace: UUID, name: str | _Bytes) -> UUID: ...
def uuid6(node: _Int | None = None, clock_seq: _Int | None = None) -> UUID: ...
def uuid7(timestamp: _Int | None = None) -> UUID: ...
@t.overload
def uuid8(*, buf: Buffer) -> UUID: ...  # 16 bytes buffer
@t.overload
def uuid8(
    a: _Int | None = None,
    b: _Int | None = None,
    c: _Int | None = None,
    *,
    buf: None = None,
) -> UUID: ...
```

<h2 id="ry.ryo3._walkdir"><code>ry.ryo3._walkdir</code></h2>

```python
"""ryo3-walkdir ~ types"""

import typing as t
from os import PathLike

from ry.protocols import RyIterator
from ry.ryo3._globset import Glob, GlobSet, Globster
from ry.ryo3._std import FileType, Metadata


@t.final
class WalkDirEntry:
    def to_string(self) -> str: ...
    def __fspath__(self) -> str: ...
    @property
    def path(self) -> str: ...
    @property
    def file_name(self) -> str: ...
    @property
    def name(self) -> str: ...
    @property
    def depth(self) -> int: ...
    @property
    def path_is_symlink(self) -> bool: ...
    @property
    def file_type(self) -> FileType: ...
    @property
    def is_dir(self) -> bool: ...
    @property
    def is_file(self) -> bool: ...
    @property
    def is_symlink(self) -> bool: ...
    @property
    def len(self) -> int: ...
    def __hash__(self) -> int: ...
    def __eq__(self, other: object, /) -> bool: ...
    def __ne__(self, other: object, /) -> bool: ...
    def __lt__(self, other: t.Self, /) -> bool: ...
    def __le__(self, other: t.Self, /) -> bool: ...
    def __gt__(self, other: t.Self, /) -> bool: ...
    def __ge__(self, other: t.Self, /) -> bool: ...
    def metadata(self) -> Metadata: ...


@t.final
class WalkDirIter(RyIterator[WalkDirEntry]):
    """walkdir::Walkdir iterable wrapper"""

    def __new__(cls) -> t.NoReturn: ...
    def __iter__(self) -> t.Self: ...
    def __next__(self) -> WalkDirEntry: ...
    def collect(self) -> list[WalkDirEntry]: ...
    def take(self, n: int = 1) -> list[WalkDirEntry]: ...
    def next(self) -> WalkDirEntry: ...


def walkdir(
    path: str | PathLike[str] | None = None,
    /,
    *,
    files: bool = True,
    dirs: bool = True,
    contents_first: bool = False,
    min_depth: int = 0,
    max_depth: int | None = None,
    follow_links: bool = False,
    follow_root_links: bool = True,
    same_file_system: bool = False,
    sort_by_file_name: bool = False,
    glob: Glob | GlobSet | Globster | t.Sequence[str] | str | None = None,
) -> WalkDirIter: ...
```

<h2 id="ry.ryo3._which"><code>ry.ryo3._which</code></h2>

```python
"""ryo3-which ~ types"""

from pathlib import Path

from ry.ryo3._regex import Regex


def which(cmd: str, path: str | None = None) -> Path | None: ...
def which_all(cmd: str, path: str | None = None) -> list[Path]: ...
def which_re(regex: str | Regex, path: str | None = None) -> list[Path]: ...
```

<h2 id="ry.ryo3._zstd"><code>ry.ryo3._zstd</code></h2>

```python
"""ryo3-zstd ~ types"""

import typing as t

from ry import Bytes
from ry._types import Buffer

_ZstdLevel: t.TypeAlias = t.Literal[
    1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22
]

ZSTD_VERSION: str  # "1.5.7" (c. 2026-10-29)
ZSTD_VERSION_INFO: tuple[int, int, int]  # (1, 5, 7) (c. 2026-10-29)


def zstd_compress(data: Buffer, /, level: _ZstdLevel = 3) -> Bytes: ...
def zstd_decompress(data: Buffer, /) -> Bytes: ...
def is_zstd(data: Buffer, /) -> bool: ...
```

<h2 id="ry._types"><code>ry._types</code></h2>

```python
"""ry-types"""

from __future__ import annotations

import sys
from os import PathLike
from typing import Literal, TypeAlias

if sys.version_info >= (3, 12):  # pragma: no cover
    from collections.abc import Buffer
    from typing import TypedDict, Unpack
else:  # pragma: no cover
    from typing_extensions import Buffer, TypedDict, Unpack

__all__ = (
    "Buffer",
    "FsPathLike",
    "TypedDict",
    "Unpack",
)
FsPathLike: TypeAlias = str | PathLike[str]
# =============================================================================
# OPEN MODES (CANONICAL)
# =============================================================================
# ry accepts the non-canonical modes, but they are mapped to the canonical ones]
# fmt: off
OpenTextModeUpdating: TypeAlias = Literal[
    "a+", "at+",
    "r+", "rt+",
    "w+", "wt+",
    "x+", "xt+"
]
OpenTextModeWriting: TypeAlias = Literal["a", "at", "w", "wt", "x", "xt"]
OpenTextModeReading: TypeAlias = Literal["r", "rt"]
OpenTextMode: TypeAlias = Literal[
    "a", "a+", "at", "at+",
    "r", "r+", "rt", "rt+",
    "w", "w+", "wt", "wt+",
    "x", "x+", "xt", "xt+"
]
OpenBinaryModeUpdating: TypeAlias = Literal["ab+", "rb+", "wb+", "xb+"]
OpenBinaryModeWriting: TypeAlias = Literal["ab", "wb", "xb"]
OpenBinaryModeReading: TypeAlias = Literal["rb"]
OpenBinaryMode: TypeAlias = Literal[
    "ab", "ab+",
    "rb", "rb+",
    "wb", "wb+",
    "xb", "xb+"
]
OpenMode: TypeAlias = Literal[
    "a", "a+", "ab", "ab+", "at", "at+",
    "r", "r+", "rb", "rb+", "rt", "rt+",
    "w", "w+", "wb", "wb+", "wt", "wt+",
    "x", "x+", "xb", "xb+", "xt", "xt+",
]
# fmt: on
```

<h2 id="ry.protocols"><code>ry.protocols</code></h2>

```python
import datetime as pydt
import typing as t

__all__ = (
    "FromStr",
    "NoInit",
    "RyIterator",
    "Strftime",
    "ToPy",
    "ToPyDate",
    "ToPyDateTime",
    "ToPyTime",
    "ToPyTimeDelta",
    "ToPyTzInfo",
    "ToString",
    "_Parse",
)

_T = t.TypeVar("_T")
_T_co = t.TypeVar("_T_co", covariant=True)


class ToPy(t.Protocol[_T_co]):
    """Objects that can be converted to a python stdlib type (`_T_co`) via `obj.to_py()`."""

    def to_py(self) -> _T_co: ...


class NoInit(t.Protocol):
    """Protocol for types that cannot be instantiated directly."""

    def __init__(self) -> t.NoReturn: ...


# =============================================================================
# TO/FROM STRING
# =============================================================================
class FromStr(t.Protocol):
    """Protocol for types that have a `.from_str()` class method."""

    @classmethod
    def from_str(cls, s: str, /) -> t.Self: ...


class _Parse(t.Protocol):
    """Protocol for types that have a `.parse()` class method."""

    @classmethod
    def parse(cls, value: str | bytes, /) -> t.Self: ...


class ToString(t.Protocol):
    """Protocol for types that have a `.to_string()` method."""

    def to_string(self) -> str: ...


# =============================================================================
# ITERABLE
# =============================================================================
class RyIterator(t.Protocol[_T]):
    def __iter__(self) -> t.Self: ...
    def __next__(self) -> _T: ...
    def collect(self) -> list[_T]: ...
    def take(self, n: int = 1) -> list[_T]: ...


class RyAsyncIterator(t.Protocol[_T]):
    def __aiter__(self) -> t.Self: ...
    async def __anext__(self) -> _T: ...
    async def collect(self) -> list[_T]: ...
    async def take(self, n: int = 1) -> list[_T]: ...


# =============================================================================
# DATETIME
# =============================================================================


class Strftime(t.Protocol):
    """Protocol for types that have a `.strftime()` method."""

    def strftime(self, fmt: str) -> str: ...


class ToPyDate(t.Protocol):
    """Objects that can be converted to a Python `datetime.date`."""

    def to_pydate(self) -> pydt.date: ...


class ToPyTime(t.Protocol):
    """Objects that can be converted to a Python `datetime.time`."""

    def to_pytime(self) -> pydt.time: ...


class ToPyDateTime(t.Protocol):
    """Objects that can be converted to a Python `datetime.datetime`."""

    def to_pydatetime(self) -> pydt.datetime: ...


class ToPyTimeDelta(t.Protocol):
    """Objects that can be converted to a Python `datetime.timedelta`."""

    def to_pytimedelta(self) -> pydt.timedelta: ...


class ToPyTzInfo(t.Protocol):
    """Objects that can be converted to a Python `datetime.tzinfo`."""

    def to_pytzinfo(self) -> pydt.tzinfo: ...
```
