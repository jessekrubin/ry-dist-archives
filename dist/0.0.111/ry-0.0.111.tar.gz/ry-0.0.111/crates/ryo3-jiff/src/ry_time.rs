use std::fmt::Display;
use std::hash::{DefaultHasher, Hash, Hasher};
use std::ops::Sub;

use jiff::ZonedDateTime;
use jiff::civil::{Time, TimeArithmetic, TimeRound};
use pyo3::BoundObject;
use pyo3::prelude::*;
use pyo3::types::{PyDict, PyTuple};
use ryo3_core::{
    PyAsciiString, PyNotImplementedOr, PyOperandArg, map_py_overflow_err, map_py_value_err,
};
use ryo3_jiff_core::{JiffRoundMode, JiffTime, JiffUnit};
use ryo3_macro_rules::{any_repr, py_type_err};

use crate::difference::{RyTimeDifference, TimeDifferenceArg};
use crate::py_temporal_like::{TemporalSubInput, TemporalSubOutput};
use crate::series::RyTimeSeries;
use crate::spanish::{DurationLike, Spanish};
use crate::util::SpanKwargs;
use crate::{
    RyDate, RyDateTime, RySignedDuration, RySpan, RyTimeRound, RyTimestamp, RyZonedDateTime,
};

#[cfg_attr(feature = "serde", derive(serde::Serialize), serde(transparent))]
#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq, PartialOrd, Ord)]
#[pyclass(name = "Time", frozen, immutable_type, eq, ord)]
#[cfg_attr(feature = "ry", pyo3(module = "ry.ryo3"))]
pub struct RyTime(pub(crate) Time);

impl RyTime {
    fn checked_sub<T: Into<TimeArithmetic>>(self, other: T) -> Result<Self, jiff::Error> {
        self.0.checked_sub(other).map(Self)
    }
}

#[expect(clippy::trivially_copy_pass_by_ref)]
impl RyTime {
    fn try_add(&self, other: Spanish<'_, '_>) -> PyResult<Self> {
        self.0
            .checked_add(other)
            .map(Self::from)
            .map_err(map_py_overflow_err)
    }

    fn try_sub_temporal(&self, other: TemporalSubInput<'_, '_, Self>) -> TemporalSubOutput<Self> {
        match other {
            TemporalSubInput::Temporal(ob) => self.0.sub(ob.get().0).into(),
            TemporalSubInput::Spanish(spanish) => self.checked_sub(spanish).into(),
        }
    }
}

#[pymethods]
#[expect(clippy::trivially_copy_pass_by_ref)]
impl RyTime {
    #[new]
    #[pyo3(signature = (hour = 0, minute = 0, second = 0, nanosecond = 0))]
    pub(crate) fn py_new(hour: i8, minute: i8, second: i8, nanosecond: i32) -> PyResult<Self> {
        Time::new(hour, minute, second, nanosecond)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    fn __getnewargs__<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyTuple>> {
        PyTuple::new(
            py,
            vec![
                self.hour().into_pyobject(py)?,
                self.minute().into_pyobject(py)?,
                self.second().into_pyobject(py)?,
                self.subsec_nanosecond().into_pyobject(py)?,
            ],
        )
    }
    // ========================================================================
    // CLASS ATTRS
    // ========================================================================
    #[classattr]
    fn __match_args__() -> (&'static str, &'static str, &'static str, &'static str) {
        ("hour", "minute", "second", "subsec_nanosecond")
    }

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn MIN() -> Self {
        Self(Time::MIN)
    }

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn MAX() -> Self {
        Self(Time::MAX)
    }

    // ========================================================================
    // CLASS METHODS
    // ========================================================================
    #[staticmethod]
    fn now() -> Self {
        jiff::civil::Time::from(ZonedDateTime::now()).into()
    }

    #[staticmethod]
    fn utcnow() -> Self {
        jiff::civil::Time::from(ZonedDateTime::now().with_time_zone(jiff::tz::TimeZone::UTC)).into()
    }

    #[staticmethod]
    fn midnight() -> Self {
        Self(Time::midnight())
    }

    // ========================================================================
    // STRPTIME/STRFTIME
    // ========================================================================
    fn __format__(&self, fmt: &str) -> PyResult<String> {
        if fmt.is_empty() {
            Ok(self.0.to_string())
        } else {
            self.strftime(fmt)
        }
    }

    #[pyo3(signature = (fmt))]
    fn strftime(&self, fmt: &str) -> PyResult<String> {
        let bdt: jiff::fmt::strtime::BrokenDownTime = self.0.into();
        bdt.to_string(fmt).map_err(map_py_value_err)
    }

    #[staticmethod]
    #[pyo3(signature = (s, /, fmt))]
    fn strptime(s: &str, fmt: &str) -> PyResult<Self> {
        Time::strptime(fmt, s)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    // ========================================================================
    // STRING
    // ========================================================================
    #[pyo3(name = "to_string")]
    fn py_to_string(&self) -> PyAsciiString {
        self.__str__()
    }

    fn __str__(&self) -> PyAsciiString {
        self.0.to_string().into()
    }

    fn __repr__(&self) -> PyAsciiString {
        format!("{self}").into()
    }

    // ========================================================================
    // OPERATORS/DUNDERS
    // ========================================================================
    fn __hash__(&self) -> u64 {
        let mut hasher = DefaultHasher::new();
        self.0.hash(&mut hasher);
        hasher.finish()
    }

    fn __add__(&self, other: PyOperandArg<Spanish<'_, '_>>) -> PyResult<PyNotImplementedOr<Self>> {
        other.try_map(|rhs| self.try_add(rhs))
    }

    fn __radd__(
        &self,
        other: PyOperandArg<DurationLike<'_, '_>>,
    ) -> PyResult<PyNotImplementedOr<Self>> {
        other.try_map(|lhs| self.try_add(lhs.into()))
    }

    #[expect(clippy::too_many_arguments, reason = "python kwargs")]
    #[pyo3(
        signature = (
            other = None,
            /, *,
            hours = 0,
            minutes = 0,
            seconds = 0,
            milliseconds = 0,
            microseconds = 0,
            nanoseconds = 0,
        )
    )]
    fn add(
        &self,
        other: Option<Spanish>,
        hours: i32,
        minutes: i64,
        seconds: i64,
        milliseconds: i64,
        microseconds: i64,
        nanoseconds: i64,
        // TODO: wrapping and saturating kwargs
        // saturating : bool,
        // wrapping: bool,
    ) -> PyResult<Self> {
        // if saturating && wrapping {
        // return py_type_err!("saturating and wrapping are mutually exclusive");
        // }
        let spkw = SpanKwargs::new()
            .hours(hours)
            .minutes(minutes)
            .seconds(seconds)
            .milliseconds(milliseconds)
            .microseconds(microseconds)
            .nanoseconds(nanoseconds);

        match (other, !spkw.is_zero()) {
            (Some(o), false) => self.try_add(o),
            (None, true) => {
                let span = spkw.build_span()?;
                self.0
                    .checked_add(span)
                    .map(Self::from)
                    .map_err(map_py_overflow_err)
            }
            (Some(_), true) => {
                py_type_err!("add accepts either a span-like object or keyword units, not both")
            }
            (None, false) => Ok(*self),
        }
    }

    fn __sub__(
        &self,
        other: PyOperandArg<TemporalSubInput<'_, '_, Self>>,
    ) -> PyNotImplementedOr<TemporalSubOutput<Self>> {
        other.map(|rhs| self.try_sub_temporal(rhs))
    }

    #[expect(clippy::too_many_arguments, reason = "python kwargs")]
    #[pyo3(
        signature = (
            other = None,
            /, *,
            hours = 0,
            minutes = 0,
            seconds = 0,
            milliseconds = 0,
            microseconds = 0,
            nanoseconds = 0
        )
    )]
    fn sub(
        &self,
        other: Option<TemporalSubInput<Self>>,
        hours: i32,
        minutes: i64,
        seconds: i64,
        milliseconds: i64,
        microseconds: i64,
        nanoseconds: i64,
    ) -> PyResult<TemporalSubOutput<Self>> {
        let spkw = SpanKwargs::new()
            .hours(hours)
            .minutes(minutes)
            .seconds(seconds)
            .milliseconds(milliseconds)
            .microseconds(microseconds)
            .nanoseconds(nanoseconds);

        match (other, !spkw.is_zero()) {
            (Some(o), false) => Ok(self.try_sub_temporal(o)),
            (None, true) => {
                let span = spkw.build_span()?;
                Ok(self.checked_sub(span).into())
            }
            (Some(_), true) => {
                py_type_err!("sub accepts either a span-like object or keyword units, not both")
            }
            (None, false) => Ok(TemporalSubOutput::Temporal(*self)),
        }
    }

    // ========================================================================
    // PROPERTIES
    // ========================================================================
    #[getter]
    fn hour(&self) -> i8 {
        self.0.hour()
    }

    #[getter]
    fn minute(&self) -> i8 {
        self.0.minute()
    }

    #[getter]
    fn second(&self) -> i8 {
        self.0.second()
    }

    #[getter]
    fn millisecond(&self) -> i16 {
        self.0.millisecond()
    }

    #[getter]
    fn microsecond(&self) -> i16 {
        self.0.microsecond()
    }

    #[getter]
    fn nanosecond(&self) -> i16 {
        self.0.nanosecond()
    }

    #[getter]
    fn subsec_nanosecond(&self) -> i32 {
        self.0.subsec_nanosecond()
    }

    // =====================================================================
    // PYTHON CONVERSIONS
    // =====================================================================
    #[expect(clippy::wrong_self_convention)]
    fn to_py(&self) -> JiffTime {
        self.to_pytime()
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_pytime(&self) -> JiffTime {
        self.0.into()
    }

    #[staticmethod]
    fn from_pytime(time: JiffTime) -> Self {
        Self::from(time)
    }

    // =====================================================================
    // INSTANCE METHODS
    // =====================================================================

    fn on(&self, year: i16, month: i8, day: i8) -> PyResult<RyDateTime> {
        // `Time::on` can panic on invalid date
        jiff::civil::Date::new(year, month, day)
            .map(|d| RyDateTime::from(self.0.to_datetime(d)))
            .map_err(map_py_value_err)
    }

    #[pyo3(
        signature = (
            *,
            hour = None,
            minute = None,
            second = None,
            millisecond = None,
            microsecond = None,
            nanosecond = None,
            subsec_nanosecond = None,
        )
    )]
    #[expect(clippy::too_many_arguments, reason = "python kwargs")]
    fn replace(
        &self,
        hour: Option<i8>,
        minute: Option<i8>,
        second: Option<i8>,
        millisecond: Option<i16>,
        microsecond: Option<i16>,
        nanosecond: Option<i16>,
        subsec_nanosecond: Option<i32>,
    ) -> PyResult<Self> {
        if hour.is_none()
            && minute.is_none()
            && second.is_none()
            && millisecond.is_none()
            && microsecond.is_none()
            && nanosecond.is_none()
            && subsec_nanosecond.is_none()
        {
            // nothing to replace, return self
            return Ok(*self);
        }
        if subsec_nanosecond.is_some()
            && (millisecond.is_some() || microsecond.is_some() || nanosecond.is_some())
        {
            return py_type_err!(
                "Cannot specify both subsec_nanosecond and millisecond/microsecond/nanosecond",
            );
        }

        // start the builder
        let mut builder = self.0.with();
        if let Some(h) = hour {
            builder = builder.hour(h);
        }
        if let Some(min) = minute {
            builder = builder.minute(min);
        }
        if let Some(sec) = second {
            builder = builder.second(sec);
        }
        if let Some(us) = microsecond {
            builder = builder.microsecond(us);
        }
        if let Some(ms) = millisecond {
            builder = builder.millisecond(ms);
        }
        if let Some(ns) = nanosecond {
            builder = builder.nanosecond(ns);
        }
        if let Some(subns) = subsec_nanosecond {
            builder = builder.subsec_nanosecond(subns);
        }
        // finally build, mapping any error back to Python
        builder.build().map(Self::from).map_err(map_py_value_err)
    }

    fn astuple<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyTuple>> {
        PyTuple::new(
            py,
            vec![
                i32::from(self.0.hour()),
                i32::from(self.0.minute()),
                i32::from(self.0.second()),
                self.0.subsec_nanosecond(),
            ],
        )
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_dict<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyDict>> {
        use crate::interns;
        let dict = PyDict::new(py);
        dict.set_item(interns::hour(py), self.0.hour())?;
        dict.set_item(interns::minute(py), self.0.minute())?;
        dict.set_item(interns::second(py), self.0.second())?;
        dict.set_item(interns::nanosecond(py), self.0.subsec_nanosecond())?;
        Ok(dict)
    }

    fn series(&self, period: &RySpan) -> PyResult<RyTimeSeries> {
        (self, period).try_into()
    }

    fn duration_since(&self, other: &Self) -> RySignedDuration {
        RySignedDuration::from(self.0.duration_since(other.0))
    }

    fn duration_until(&self, other: &Self) -> RySignedDuration {
        RySignedDuration::from(self.0.duration_until(other.0))
    }

    fn saturating_add(&self, other: Spanish) -> Self {
        Self::from(self.0.saturating_add(other))
    }

    fn saturating_sub(&self, other: Spanish) -> Self {
        Self::from(self.0.saturating_sub(other))
    }

    fn wrapping_add(&self, other: Spanish) -> Self {
        Self::from(self.0.wrapping_add(other))
    }

    fn wrapping_sub(&self, other: Spanish) -> Self {
        Self::from(self.0.wrapping_sub(other))
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_datetime(&self, date: &RyDate) -> RyDateTime {
        RyDateTime::from(self.0.to_datetime(date.0))
    }

    #[pyo3(
        signature = (
            smallest = JiffUnit::NANOSECOND,
            *,
            mode = JiffRoundMode::HALF_EXPAND,
            increment = 1
        ),
        text_signature = "(self, smallest=\"nanosecond\", *, mode=\"half-expand\", increment=1)"
    )]
    fn round(&self, smallest: JiffUnit, mode: JiffRoundMode, increment: i64) -> PyResult<Self> {
        let timeround = TimeRound::new()
            .smallest(smallest.into())
            .mode(mode.into())
            .increment(increment);
        self.0
            .round(timeround)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    #[expect(clippy::used_underscore_items, reason = "python-private-method")]
    fn _round(&self, options: &RyTimeRound) -> PyResult<Self> {
        options.round(self)
    }
    // ------------------------------------------------------------------------
    // SINCE/UNTIL
    // ------------------------------------------------------------------------
    #[pyo3(
        signature = (
            t,
            *,
            smallest = JiffUnit::NANOSECOND,
            largest = None,
            mode = JiffRoundMode::TRUNC,
            increment = 1
        ),
       text_signature = "(self, t, *, smallest=\"nanosecond\", largest=None, mode=\"trunc\", increment=1)"
    )]
    fn since(
        &self,
        t: TimeDifferenceArg,
        smallest: JiffUnit,
        largest: Option<JiffUnit>,
        mode: JiffRoundMode,
        increment: i64,
    ) -> PyResult<RySpan> {
        let t_diff = t.build(smallest, largest, mode, increment);
        self.0
            .since(t_diff)
            .map(RySpan::from)
            .map_err(map_py_value_err)
    }

    #[pyo3(
        signature = (
            t,
            *,
            smallest = JiffUnit::NANOSECOND,
            largest = None,
            mode = JiffRoundMode::TRUNC,
            increment = 1
        ),
       text_signature = "(self, t, *, smallest=\"nanosecond\", largest=None, mode=\"trunc\", increment=1)"
    )]
    fn until(
        &self,
        t: TimeDifferenceArg,
        smallest: JiffUnit,
        largest: Option<JiffUnit>,
        mode: JiffRoundMode,
        increment: i64,
    ) -> PyResult<RySpan> {
        let t_diff = t.build(smallest, largest, mode, increment);
        self.0
            .until(t_diff)
            .map(RySpan::from)
            .map_err(map_py_value_err)
    }

    #[expect(clippy::used_underscore_items, reason = "python-private-method")]
    fn _since(&self, other: &RyTimeDifference) -> PyResult<RySpan> {
        self.0
            .since(other.diff)
            .map(RySpan::from)
            .map_err(map_py_value_err)
    }

    #[expect(clippy::used_underscore_items, reason = "python-private-method")]
    fn _until(&self, other: &RyTimeDifference) -> PyResult<RySpan> {
        self.0
            .until(other.diff)
            .map(RySpan::from)
            .map_err(map_py_value_err)
    }

    #[staticmethod]
    fn from_any<'py>(value: &Bound<'py, PyAny>) -> PyResult<Bound<'py, Self>> {
        let py = value.py();
        if let Ok(val) = value.cast_exact::<Self>() {
            Ok(val.as_borrowed().into_bound())
        } else if let Ok(pystr) = value.cast::<pyo3::types::PyString>() {
            let s = pystr.extract::<&str>()?;
            Self::from_str(s).map(|dt| dt.into_pyobject(py))?
        } else if let Ok(pybytes) = value.cast::<pyo3::types::PyBytes>() {
            let s = String::from_utf8_lossy(pybytes.as_bytes());
            Self::from_str(&s).map(|dt| dt.into_pyobject(py))?
        } else if let Ok(d) = value.cast_exact::<RyDateTime>() {
            Self::from(d.get()).into_pyobject(py)
        } else if let Ok(zdt) = value.cast_exact::<RyZonedDateTime>() {
            Self::from(zdt.get()).into_pyobject(py)
        } else if let Ok(ts) = value.cast_exact::<RyTimestamp>() {
            Self::from(ts.get()).into_pyobject(py)
        } else if let Ok(d) = value.extract::<JiffTime>() {
            Self::from_pytime(d).into_pyobject(py)
        } else {
            let valtype = any_repr!(value);
            py_type_err!("Time conversion error: {valtype}")
        }
    }
    // ========================================================================
    // PYDANTIC
    // ========================================================================

    #[cfg(feature = "pydantic")]
    #[staticmethod]
    #[pyo3(name = "_pydantic_validate")]
    fn py_pydantic_validate<'py>(value: &Bound<'py, PyAny>) -> PyResult<Bound<'py, Self>> {
        Self::from_any(value).map_err(map_py_value_err)
    }

    #[cfg(feature = "pydantic")]
    #[classmethod]
    fn __get_pydantic_core_schema__<'py>(
        cls: &Bound<'py, ::pyo3::types::PyType>,
        source: &Bound<'py, PyAny>,
        handler: &Bound<'py, PyAny>,
    ) -> PyResult<Bound<'py, PyAny>> {
        use ryo3_pydantic::GetPydanticCoreSchemaCls;
        Self::get_pydantic_core_schema(cls, source, handler)
    }

    #[cfg(feature = "pydantic")]
    #[classmethod]
    fn __get_pydantic_json_schema__<'py>(
        cls: &Bound<'py, ::pyo3::types::PyType>,
        source: &Bound<'py, PyAny>,
        handler: &Bound<'py, PyAny>,
    ) -> PyResult<Bound<'py, PyAny>> {
        use ryo3_pydantic::GetPydanticJsonSchemaCls;
        Self::get_pydantic_json_schema(cls, source, handler)
    }

    // ========================================================================
    // STANDARD METHODS
    // ========================================================================
    // <STD-METHODS>
    #[staticmethod]
    #[pyo3(signature = (s, /))]
    fn from_str(s: &str) -> PyResult<Self> {
        use ryo3_core::PyFromStr;
        Self::py_from_str(s)
    }

    #[staticmethod]
    #[pyo3(signature = (value, /))]
    fn parse(value: ryo3_core::PyParseArg<Self>) -> Self {
        value.into_inner()
    }

    fn isoformat(&self) -> PyAsciiString {
        <Self as crate::isoformat::PyIsoFormat>::isoformat(self)
    }
    // </STD-METHODS>
}

impl Display for RyTime {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "Time(hour={}, minute={}, second={}, nanosecond={})",
            self.0.hour(),
            self.0.minute(),
            self.0.second(),
            self.0.subsec_nanosecond()
        )
    }
}
