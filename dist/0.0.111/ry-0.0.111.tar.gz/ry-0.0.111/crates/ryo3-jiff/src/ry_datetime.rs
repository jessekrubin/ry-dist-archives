use std::fmt::Display;
use std::hash::{DefaultHasher, Hash, Hasher};
use std::ops::Sub;

use jiff::ZonedDateTime;
use jiff::civil::{DateTime, DateTimeArithmetic, DateTimeRound, Weekday};
use pyo3::prelude::*;
use pyo3::types::{PyDict, PyTuple};
use pyo3::{BoundObject, IntoPyObjectExt};
use ryo3_core::{
    PyAsciiString, PyCastExactOpt, PyNotImplementedOr, PyOperandArg, map_py_overflow_err,
    map_py_value_err,
};
use ryo3_jiff_core::{
    JiffDate, JiffDateTime, JiffEra, JiffEraYear, JiffRoundMode, JiffTime, JiffUnit, JiffWeekday,
};
use ryo3_macro_rules::{any_repr, py_type_err, py_type_error};

use crate::difference::{DateTimeDifferenceArg, RyDateTimeDifference};
use crate::py_temporal_like::{TemporalSubInput, TemporalSubOutput};
use crate::ry_iso_week_date::RyISOWeekDate;
use crate::ry_signed_duration::RySignedDuration;
use crate::ry_span::RySpan;
use crate::ry_time::RyTime;
use crate::ry_timezone::RyTimeZone;
use crate::ry_zoned_datetime::RyZonedDateTime;
use crate::series::RyDateTimeSeries;
use crate::spanish::{DurationLike, Spanish};
use crate::util::SpanKwargs;
use crate::{RyDate, RyDateTimeRound, RyTimestamp};

#[cfg_attr(feature = "serde", derive(serde::Serialize), serde(transparent))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd)]
#[pyclass(name = "DateTime", frozen, immutable_type, eq, ord)]
#[cfg_attr(feature = "ry", pyo3(module = "ry.ryo3"))]
pub struct RyDateTime(pub(crate) DateTime);

impl RyDateTime {
    fn checked_sub<T: Into<DateTimeArithmetic>>(self, other: T) -> Result<Self, jiff::Error> {
        self.0.checked_sub(other).map(Self)
    }
}

impl RyDateTime {
    fn try_add(&self, other: Spanish<'_, '_>) -> PyResult<Self> {
        self.0
            .checked_add(other)
            .map(Self::from)
            .map_err(map_py_overflow_err)
    }

    fn try_sub_temporal(&self, other: TemporalSubInput<'_, '_, Self>) -> TemporalSubOutput<Self> {
        match other {
            TemporalSubInput::Temporal(ob) => self.0.sub(ob.get().0).into(),
            TemporalSubInput::Spanish(spanish) => self.checked_sub(spanish).into(),
        }
    }
}

#[expect(clippy::trivially_copy_pass_by_ref)]
#[pymethods]
impl RyDateTime {
    #[new]
    #[pyo3(signature = (year, month, day, hour = 0, minute = 0, second = 0, subsec_nanosecond = 0))]
    pub(crate) fn py_new(
        year: i16,
        month: i8,
        day: i8,
        hour: i8,
        minute: i8,
        second: i8,
        subsec_nanosecond: i32,
    ) -> PyResult<Self> {
        DateTime::new(year, month, day, hour, minute, second, subsec_nanosecond)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    fn __getnewargs__<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyTuple>> {
        PyTuple::new(
            py,
            vec![
                self.year().into_bound_py_any(py)?,
                self.month().into_bound_py_any(py)?,
                self.day().into_bound_py_any(py)?,
                self.hour().into_bound_py_any(py)?,
                self.minute().into_bound_py_any(py)?,
                self.second().into_bound_py_any(py)?,
                self.subsec_nanosecond().into_bound_py_any(py)?,
            ],
        )
    }

    #[classattr]
    fn __match_args__() -> (
        &'static str,
        &'static str,
        &'static str,
        &'static str,
        &'static str,
        &'static str,
        &'static str,
    ) {
        (
            "year",
            "month",
            "day",
            "hour",
            "minute",
            "second",
            "subsec_nanosecond",
        )
    }

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn MIN() -> Self {
        Self(DateTime::MIN)
    }

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn MAX() -> Self {
        Self(DateTime::MAX)
    }

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn ZERO() -> Self {
        Self(DateTime::ZERO)
    }

    #[staticmethod]
    fn now() -> Self {
        Self::from(DateTime::from(ZonedDateTime::now()))
    }

    #[staticmethod]
    fn today() -> Self {
        Self::from(DateTime::from(ZonedDateTime::now()))
    }

    #[getter]
    fn year(&self) -> i16 {
        self.0.year()
    }

    #[getter]
    fn month(&self) -> i8 {
        self.0.month()
    }

    #[getter]
    fn day(&self) -> i8 {
        self.0.day()
    }

    #[getter]
    fn hour(&self) -> i8 {
        self.0.hour()
    }

    #[getter]
    fn minute(&self) -> i8 {
        self.0.minute()
    }

    #[getter]
    fn second(&self) -> i8 {
        self.0.second()
    }

    #[getter]
    fn millisecond(&self) -> i16 {
        self.0.millisecond()
    }

    #[getter]
    fn microsecond(&self) -> i16 {
        self.0.microsecond()
    }

    #[getter]
    fn nanosecond(&self) -> i16 {
        self.0.nanosecond()
    }

    #[getter]
    fn subsec_nanosecond(&self) -> i32 {
        self.0.subsec_nanosecond()
    }

    fn __str__(&self) -> PyAsciiString {
        self.0.to_string().into()
    }

    #[pyo3(name = "to_string")]
    fn py_to_string(&self) -> PyAsciiString {
        self.__str__()
    }

    fn __repr__(&self) -> PyAsciiString {
        format!("{self}").into()
    }

    fn __hash__(&self) -> u64 {
        let mut hasher = DefaultHasher::new();
        self.0.hash(&mut hasher);
        hasher.finish()
    }

    fn __add__(&self, other: PyOperandArg<Spanish<'_, '_>>) -> PyResult<PyNotImplementedOr<Self>> {
        other.try_map(|rhs| self.try_add(rhs))
    }

    fn __radd__(
        &self,
        other: PyOperandArg<DurationLike<'_, '_>>,
    ) -> PyResult<PyNotImplementedOr<Self>> {
        other.try_map(|lhs| self.try_add(lhs.into()))
    }

    #[expect(clippy::too_many_arguments, reason = "python kwargs")]
    #[pyo3(
        signature = (
            other = None,
            /, *,
            years = 0,
            months = 0,
            weeks = 0,
            days = 0,
            hours = 0,
            minutes = 0,
            seconds = 0,
            milliseconds = 0,
            microseconds = 0,
            nanoseconds = 0
        )
    )]
    fn add(
        &self,
        other: Option<Spanish>,
        years: i16,
        months: i32,
        weeks: i32,
        days: i32,
        hours: i32,
        minutes: i64,
        seconds: i64,
        milliseconds: i64,
        microseconds: i64,
        nanoseconds: i64,
    ) -> PyResult<Self> {
        let spkw = SpanKwargs::new()
            .years(years)
            .months(months)
            .weeks(weeks)
            .days(days)
            .hours(hours)
            .minutes(minutes)
            .seconds(seconds)
            .milliseconds(milliseconds)
            .microseconds(microseconds)
            .nanoseconds(nanoseconds);

        match (other, !spkw.is_zero()) {
            (Some(o), false) => self.try_add(o),
            (None, true) => {
                let span = spkw.build_span()?;
                self.0
                    .checked_add(span)
                    .map(Self::from)
                    .map_err(map_py_overflow_err)
            }
            (Some(_), true) => {
                py_type_err!("add accepts either a span-like object or keyword units, not both")
            }
            (None, false) => Ok(*self),
        }
    }

    fn __sub__(
        &self,
        other: PyOperandArg<TemporalSubInput<'_, '_, Self>>,
    ) -> PyNotImplementedOr<TemporalSubOutput<Self>> {
        other.map(|rhs| self.try_sub_temporal(rhs))
    }

    #[expect(clippy::too_many_arguments, reason = "python kwargs")]
    #[pyo3(
        signature = (
            other = None,
            /, *,
            years = 0,
            months = 0,
            weeks = 0,
            days = 0,
            hours = 0,
            minutes = 0,
            seconds = 0,
            milliseconds = 0,
            microseconds = 0,
            nanoseconds = 0
        )
    )]
    fn sub(
        &self,
        other: Option<TemporalSubInput<Self>>,
        years: i16,
        months: i32,
        weeks: i32,
        days: i32,
        hours: i32,
        minutes: i64,
        seconds: i64,
        milliseconds: i64,
        microseconds: i64,
        nanoseconds: i64,
    ) -> PyResult<TemporalSubOutput<Self>> {
        let spkw = SpanKwargs::new()
            .years(years)
            .months(months)
            .weeks(weeks)
            .days(days)
            .hours(hours)
            .minutes(minutes)
            .seconds(seconds)
            .milliseconds(milliseconds)
            .microseconds(microseconds)
            .nanoseconds(nanoseconds);

        match (other, !spkw.is_zero()) {
            (Some(o), false) => Ok(self.try_sub_temporal(o)),
            (None, true) => {
                let span = spkw.build_span()?;
                Ok(self.checked_sub(span).into())
            }
            (Some(_), true) => {
                py_type_err!("sub accepts either a span-like object or keyword units, not both")
            }
            (None, false) => Ok(TemporalSubOutput::Temporal(*self)),
        }
    }

    fn saturating_add(&self, other: Spanish) -> Self {
        Self::from(self.0.saturating_add(other))
    }

    fn saturating_sub(&self, other: Spanish) -> Self {
        Self::from(self.0.saturating_sub(other))
    }

    fn time(&self) -> RyTime {
        self.into()
    }

    fn date(&self) -> RyDate {
        self.into()
    }

    pub(crate) fn in_tz(&self, tz: &str) -> PyResult<RyZonedDateTime> {
        let tz = ryo3_jiff_core::get_time_zone(tz).map_err(map_py_value_err)?;
        self.0
            .to_zoned_datetime(tz)
            .map(RyZonedDateTime::from)
            .map_err(map_py_value_err)
    }

    fn iso_week_date(&self) -> RyISOWeekDate {
        RyISOWeekDate::from(self)
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_zoned_datetime(&self, tz: &RyTimeZone) -> PyResult<RyZonedDateTime> {
        self.0
            .to_zoned_datetime(tz.to_inner())
            .map(RyZonedDateTime::from)
            .map_err(map_py_value_err)
    }

    // DEPRECATED ~ remove in v0.0.112 (jiff 1.0 renamed `to_zoned`)
    #[expect(clippy::wrong_self_convention)]
    #[pyo3(warn(
        message = "`DateTime.to_zoned` is deprecated; use `DateTime.to_zoned_datetime` instead [removal: v0.0.112]",
        category = pyo3::exceptions::PyDeprecationWarning
    ))]
    fn to_zoned(&self, tz: &RyTimeZone) -> PyResult<RyZonedDateTime> {
        self.to_zoned_datetime(tz)
    }

    fn first_of_month(&self) -> Self {
        Self::from(self.0.first_of_month())
    }

    fn last_of_month(&self) -> Self {
        Self::from(self.0.last_of_month())
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_py(&self) -> JiffDateTime {
        self.to_pydatetime()
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_pydatetime(&self) -> JiffDateTime {
        self.0.into()
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_pydate(&self) -> JiffDate {
        self.0.date().into()
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_pytime(&self) -> JiffTime {
        self.0.time().into()
    }

    #[staticmethod]
    fn from_pydatetime(datetime: JiffDateTime) -> Self {
        Self::from(datetime)
    }

    fn series(&self, period: &RySpan) -> PyResult<RyDateTimeSeries> {
        (self, period).try_into()
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_dict<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyDict>> {
        use crate::interns;
        let dict = PyDict::new(py);
        dict.set_item(interns::year(py), self.0.year())?;
        dict.set_item(interns::month(py), self.0.month())?;
        dict.set_item(interns::day(py), self.0.day())?;
        dict.set_item(interns::hour(py), self.0.hour())?;
        dict.set_item(interns::minute(py), self.0.minute())?;
        dict.set_item(interns::second(py), self.0.second())?;
        dict.set_item(interns::nanosecond(py), self.0.subsec_nanosecond())?;
        Ok(dict)
    }

    #[pyo3(
        signature = (
            obj = None,
            *,
            date = None,
            time = None,
            year = None,
            era_year = None,
            month = None,
            day = None,
            day_of_year = None,
            day_of_year_no_leap = None,
            hour = None,
            minute = None,
            second = None,
            millisecond = None,
            microsecond = None,
            nanosecond = None,
            subsec_nanosecond = None,
        )
    )]
    #[expect(clippy::too_many_arguments, reason = "python kwargs")]
    fn replace(
        &self,
        obj: Option<Bound<'_, PyAny>>,
        date: Option<&RyDate>,
        time: Option<&RyTime>,
        year: Option<i16>,
        era_year: Option<(i16, JiffEra)>,
        month: Option<i8>,
        day: Option<i8>,
        day_of_year: Option<i16>,
        day_of_year_no_leap: Option<i16>,
        hour: Option<i8>,
        minute: Option<i8>,
        second: Option<i8>,
        millisecond: Option<i16>,
        microsecond: Option<i16>,
        nanosecond: Option<i16>,
        subsec_nanosecond: Option<i32>,
    ) -> PyResult<Self> {
        // start the builder
        let mut builder = self.0.with();
        if let Some(obj) = obj {
            if let Ok(d) = obj.cast_exact::<RyDate>() {
                builder = builder.date(d.get().0);
            } else if let Ok(time) = obj.cast_exact::<RyTime>() {
                // if obj is a Time, use it as the base
                builder = builder.time(time.get().0);
            } else {
                return Err(py_type_error!("obj must be a Date or Time; given: {obj}"));
            }
        }
        // only override if the Option is Some
        if let Some(date) = date {
            builder = builder.date(date.0);
        }
        if let Some(time) = time {
            builder = builder.time(time.0);
        }
        if let Some(y) = year {
            builder = builder.year(y);
        }
        if let Some(ey) = era_year {
            builder = builder.era_year(ey.0, (ey.1).into());
        }
        if let Some(m) = month {
            builder = builder.month(m);
        }
        if let Some(d) = day {
            builder = builder.day(d);
        }
        if let Some(doy) = day_of_year {
            builder = builder.day_of_year(doy);
        }
        if let Some(doy) = day_of_year_no_leap {
            builder = builder.day_of_year_no_leap(doy);
        }
        if let Some(h) = hour {
            builder = builder.hour(h);
        }
        if let Some(min) = minute {
            builder = builder.minute(min);
        }
        if let Some(sec) = second {
            builder = builder.second(sec);
        }
        if let Some(us) = microsecond {
            builder = builder.microsecond(us);
        }
        if let Some(ms) = millisecond {
            builder = builder.millisecond(ms);
        }
        if let Some(ns) = nanosecond {
            builder = builder.nanosecond(ns);
        }
        if let Some(subns) = subsec_nanosecond {
            builder = builder.subsec_nanosecond(subns);
        }
        builder.build().map(Self::from).map_err(map_py_value_err)
    }

    #[pyo3(
        signature = (
            smallest = JiffUnit::NANOSECOND,
            *,
            mode = JiffRoundMode::HALF_EXPAND,
            increment = 1
        ),
        text_signature = "(self, smallest=\"nanosecond\", *, mode=\"half-expand\", increment=1)"
    )]
    fn round(&self, smallest: JiffUnit, mode: JiffRoundMode, increment: i64) -> PyResult<Self> {
        let dt_round = DateTimeRound::new()
            .smallest(smallest.into())
            .increment(increment)
            .mode(mode.into());
        self.0
            .round(dt_round)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    #[expect(clippy::used_underscore_items, reason = "python-private-method")]
    fn _round(&self, options: &RyDateTimeRound) -> PyResult<Self> {
        options.round(self)
    }

    fn day_of_year(&self) -> i16 {
        self.0.day_of_year()
    }

    fn day_of_year_no_leap(&self) -> Option<i16> {
        self.0.day_of_year_no_leap()
    }

    fn days_in_month(&self) -> i8 {
        self.0.days_in_month()
    }

    fn days_in_year(&self) -> i16 {
        self.0.days_in_year()
    }

    fn duration_since(&self, other: &Self) -> RySignedDuration {
        self.0.duration_since(other.0).into()
    }

    fn duration_until(&self, other: &Self) -> RySignedDuration {
        self.0.duration_until(other.0).into()
    }

    /// Returns the end of the day `DateTime`
    fn end_of_day(&self) -> Self {
        Self::from(self.0.end_of_day())
    }

    /// Return the era year as a tuple (era, year)
    fn era_year(&self) -> JiffEraYear {
        JiffEraYear::new(self.0.era_year())
    }

    fn first_of_year(&self) -> Self {
        Self::from(self.0.first_of_year())
    }

    #[staticmethod]
    fn from_parts(date: &RyDate, time: &RyTime) -> Self {
        Self::from(DateTime::from_parts(date.0, time.0))
    }

    fn in_leap_year(&self) -> bool {
        self.0.in_leap_year()
    }

    fn last_of_year(&self) -> Self {
        Self::from(self.0.last_of_year())
    }

    fn start_of_day(&self) -> Self {
        Self::from(self.0.start_of_day())
    }

    fn __format__(&self, fmt: &str) -> PyResult<String> {
        if fmt.is_empty() {
            Ok(self.0.to_string())
        } else {
            self.strftime(fmt)
        }
    }

    #[pyo3(signature = (fmt))]
    fn strftime(&self, fmt: &str) -> PyResult<String> {
        let bdt: jiff::fmt::strtime::BrokenDownTime = self.0.into();
        bdt.to_string(fmt).map_err(map_py_value_err)
    }

    #[staticmethod]
    #[pyo3(signature = (s, /, fmt))]
    fn strptime(s: &str, fmt: &str) -> PyResult<Self> {
        DateTime::strptime(fmt, s)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    #[pyo3(
        signature = (
            other,
            *,
            smallest = JiffUnit::NANOSECOND,
            largest = None,
            mode = JiffRoundMode::TRUNC,
            increment = 1
        ),
        text_signature = "(self, other, *, smallest=\"nanosecond\", largest=None, mode=\"trunc\", increment=1)"
    )]
    fn since(
        &self,
        other: DateTimeDifferenceArg,
        smallest: JiffUnit,
        largest: Option<JiffUnit>,
        mode: JiffRoundMode,
        increment: i64,
    ) -> PyResult<RySpan> {
        let dt_diff = other.build(smallest, largest, mode, increment);
        self.0
            .since(dt_diff)
            .map(RySpan::from)
            .map_err(map_py_value_err)
    }

    #[pyo3(
        signature = (
            other,
            *,
            smallest = JiffUnit::NANOSECOND,
            largest = None,
            mode = JiffRoundMode::TRUNC,
            increment = 1
        ),
        text_signature = "(self, other, *, smallest=\"nanosecond\", largest=None, mode=\"trunc\", increment=1)"
    )]
    fn until(
        &self,
        other: DateTimeDifferenceArg,
        smallest: JiffUnit,
        largest: Option<JiffUnit>,
        mode: JiffRoundMode,
        increment: i64,
    ) -> PyResult<RySpan> {
        let dt_diff = other.build(smallest, largest, mode, increment);
        self.0
            .until(dt_diff)
            .map(RySpan::from)
            .map_err(map_py_value_err)
    }

    #[expect(clippy::used_underscore_items, reason = "python-private-method")]
    fn _since(&self, other: &RyDateTimeDifference) -> PyResult<RySpan> {
        self.0
            .since(other.diff)
            .map(RySpan::from)
            .map_err(map_py_value_err)
    }

    #[expect(clippy::used_underscore_items, reason = "python-private-method")]
    fn _until(&self, other: &RyDateTimeDifference) -> PyResult<RySpan> {
        self.0
            .until(other.diff)
            .map(RySpan::from)
            .map_err(map_py_value_err)
    }

    fn tomorrow(&self) -> PyResult<Self> {
        self.0.tomorrow().map(Self::from).map_err(map_py_value_err)
    }

    fn yesterday(&self) -> PyResult<Self> {
        self.0.yesterday().map(Self::from).map_err(map_py_value_err)
    }

    // #[pyo3(signature = (nth, weekday, *, err = true))]
    // fn nth_weekday(&self, nth: i32, weekday: JiffWeekday, err: bool) -> PyResult<Option<Self>> {
    //     if err {
    //         self.0
    //             .nth_weekday(nth, weekday.0)
    //             .map(Self::from)
    //             .map(Some)
    //             .map_err(map_py_value_err)
    //     } else {
    //         match self.0.nth_weekday(nth, weekday.0) {
    //             Ok(dt) => Ok(Some(Self::from(dt))),
    //             Err(_) => Ok(None),
    //         }
    //     }
    // }

    #[pyo3(signature = (nth, weekday))]
    fn nth_weekday(&self, nth: i32, weekday: JiffWeekday) -> PyResult<Self> {
        self.0
            .nth_weekday(nth, weekday.into())
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    fn nth_weekday_of_month(&self, nth: i8, weekday: JiffWeekday) -> PyResult<Self> {
        self.0
            .nth_weekday_of_month(nth, weekday.into())
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    #[getter]
    fn weekday(&self) -> i8 {
        match self.0.weekday() {
            Weekday::Monday => 1,
            Weekday::Tuesday => 2,
            Weekday::Wednesday => 3,
            Weekday::Thursday => 4,
            Weekday::Friday => 5,
            Weekday::Saturday => 6,
            Weekday::Sunday => 7,
        }
    }

    #[staticmethod]
    fn from_any<'py>(value: &Bound<'py, PyAny>) -> PyResult<Bound<'py, Self>> {
        let py = value.py();
        if let Some(val) = value.cast_exact_opt::<Self>() {
            Ok(val.as_borrowed().into_bound())
        } else if let Ok(pystr) = value.cast::<pyo3::types::PyString>() {
            let s = pystr.extract::<&str>()?;
            Self::from_str(s).map(|dt| dt.into_pyobject(py))?
        } else if let Ok(pybytes) = value.cast::<pyo3::types::PyBytes>() {
            let s = String::from_utf8_lossy(pybytes.as_bytes());
            Self::from_str(&s).map(|dt| dt.into_pyobject(py))?
        } else if let Some(d) = value.cast_exact_opt::<RyZonedDateTime>() {
            Self::from(d.get()).into_pyobject(py)
        } else if let Some(ts) = value.cast_exact_opt::<RyTimestamp>() {
            Self::from(ts.get()).into_pyobject(py)
        } else if let Ok(d) = value.extract::<JiffDateTime>() {
            Self::from(d).into_pyobject(py)
        } else {
            let valtype = any_repr!(value);
            py_type_err!("DateTime conversion error: {valtype}",)
        }
    }

    // ========================================================================
    // PYDANTIC
    // ========================================================================
    #[cfg(feature = "pydantic")]
    #[staticmethod]
    #[pyo3(name = "_pydantic_validate")]
    fn py_pydantic_validate<'py>(value: &Bound<'py, PyAny>) -> PyResult<Bound<'py, Self>> {
        Self::from_any(value).map_err(map_py_value_err)
    }

    #[cfg(feature = "pydantic")]
    #[classmethod]
    fn __get_pydantic_core_schema__<'py>(
        cls: &Bound<'py, ::pyo3::types::PyType>,
        source: &Bound<'py, PyAny>,
        handler: &Bound<'py, PyAny>,
    ) -> PyResult<Bound<'py, PyAny>> {
        use ryo3_pydantic::GetPydanticCoreSchemaCls;
        Self::get_pydantic_core_schema(cls, source, handler)
    }

    #[cfg(feature = "pydantic")]
    #[classmethod]
    fn __get_pydantic_json_schema__<'py>(
        cls: &Bound<'py, ::pyo3::types::PyType>,
        source: &Bound<'py, PyAny>,
        handler: &Bound<'py, PyAny>,
    ) -> PyResult<Bound<'py, PyAny>> {
        use ryo3_pydantic::GetPydanticJsonSchemaCls;
        Self::get_pydantic_json_schema(cls, source, handler)
    }

    // ========================================================================
    // STANDARD METHODS
    // ========================================================================
    // <STD-METHODS>
    #[staticmethod]
    #[pyo3(signature = (s, /))]
    fn from_str(s: &str) -> PyResult<Self> {
        use ryo3_core::PyFromStr;
        Self::py_from_str(s)
    }

    #[staticmethod]
    #[pyo3(signature = (value, /))]
    fn parse(value: ryo3_core::PyParseArg<Self>) -> Self {
        value.into_inner()
    }

    fn isoformat(&self) -> PyAsciiString {
        <Self as crate::isoformat::PyIsoFormat>::isoformat(self)
    }
    // </STD-METHODS>
}

impl Display for RyDateTime {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "DateTime(year={}, month={}, day={}, hour={}, minute={}, second={}, subsec_nanosecond={})",
            self.year(),
            self.month(),
            self.day(),
            self.hour(),
            self.minute(),
            self.second(),
            self.subsec_nanosecond()
        )
    }
}
