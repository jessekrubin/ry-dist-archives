use std::hash::{Hash, Hasher};
use std::net::{IpAddr, Ipv4Addr, Ipv6Addr, SocketAddr, SocketAddrV4, SocketAddrV6};

use pyo3::BoundObject;
use pyo3::prelude::*;
use ryo3_core::{PyAsciiString, PyFromStr};
use ryo3_macro_rules::{any_repr, py_type_err, py_type_error, py_value_err};

use crate::net::RyIpv6Addr;
use crate::net::ipaddr::{IpAddrLike, RyIpAddr, RyIpv4Addr};
use crate::net::ipaddr_props::IpAddrProps;

#[cfg_attr(feature = "serde", derive(serde::Serialize), serde(transparent))]
#[pyclass(name = "SocketAddrV4", frozen, immutable_type, eq, ord)]
#[cfg_attr(feature = "ry", pyo3(module = "ry.ryo3"))]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash, PartialOrd, Ord)]
pub struct RySocketAddrV4(pub(crate) SocketAddrV4);

#[cfg_attr(feature = "serde", derive(serde::Serialize), serde(transparent))]
#[pyclass(name = "SocketAddrV6", frozen, immutable_type, eq, ord)]
#[cfg_attr(feature = "ry", pyo3(module = "ry.ryo3"))]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash, PartialOrd, Ord)]
pub struct RySocketAddrV6(pub(crate) SocketAddrV6);

#[cfg_attr(feature = "serde", derive(serde::Serialize), serde(transparent))]
#[pyclass(name = "SocketAddr", frozen, immutable_type, eq, ord)]
#[cfg_attr(feature = "ry", pyo3(module = "ry.ryo3"))]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash, PartialOrd, Ord)]
pub struct RySocketAddr(pub(crate) SocketAddr);

#[pymethods]
#[expect(clippy::trivially_copy_pass_by_ref)]
impl RySocketAddrV4 {
    #[new]
    #[expect(clippy::needless_pass_by_value)]
    pub(crate) fn py_new(ip: IpAddrLike, port: u16) -> PyResult<Self> {
        let ipv4 = ip.get_ipv4()?;
        let sa = SocketAddrV4::new(ipv4, port);
        Ok(Self(sa))
    }

    fn __str__(&self) -> PyAsciiString {
        self.0.to_string().into()
    }

    #[pyo3(name = "to_string")]
    fn py_to_string(&self) -> PyAsciiString {
        self.__str__()
    }

    fn __repr__(&self) -> PyAsciiString {
        format!("{self}").into()
    }

    fn __hash__(&self) -> u64 {
        let mut hasher = std::hash::DefaultHasher::new();
        self.0.hash(&mut hasher);
        hasher.finish()
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_ipv4(&self) -> RyIpv4Addr {
        RyIpv4Addr::from(self.0.ip())
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_ipaddr(&self) -> RyIpAddr {
        RyIpAddr::from(self.0)
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_pyipaddress(&self) -> Ipv4Addr {
        *self.0.ip()
    }

    #[getter]
    fn port(&self) -> u16 {
        self.0.port()
    }

    #[staticmethod]
    #[pyo3(signature = (s, /))]
    fn from_str(s: &str) -> PyResult<Self> {
        Self::py_from_str(s)
    }

    #[staticmethod]
    #[pyo3(signature = (value, /))]
    fn parse(value: ryo3_core::PyParseArg<Self>) -> Self {
        value.into_inner()
    }

    #[classattr]
    fn version() -> u8 {
        4
    }

    // ip getter
    #[getter]
    fn ip(&self) -> RyIpv4Addr {
        RyIpv4Addr::from(self.0.ip())
    }

    // ========================================================================
    // Ipv4 forwarded
    // ========================================================================
    #[getter]
    fn is_ipv4(&self) -> bool {
        <Self as IpAddrProps>::is_ipv4(self)
    }

    #[getter]
    fn is_ipv6(&self) -> bool {
        <Self as IpAddrProps>::is_ipv6(self)
    }

    #[getter]
    fn is_benchmarking(&self) -> bool {
        <Self as IpAddrProps>::is_benchmarking(self)
    }

    #[getter]
    fn is_broadcast(&self) -> bool {
        <Self as IpAddrProps>::is_broadcast(self)
    }

    #[getter]
    fn is_documentation(&self) -> bool {
        <Self as IpAddrProps>::is_documentation(self)
    }

    #[getter]
    fn is_global(&self) -> PyResult<bool> {
        <Self as IpAddrProps>::is_global(self)
    }

    #[getter]
    fn is_link_local(&self) -> bool {
        <Self as IpAddrProps>::is_link_local(self)
    }

    #[getter]
    fn is_loopback(&self) -> bool {
        <Self as IpAddrProps>::is_loopback(self)
    }

    #[getter]
    fn is_multicast(&self) -> bool {
        <Self as IpAddrProps>::is_multicast(self)
    }

    #[getter]
    fn is_private(&self) -> bool {
        <Self as IpAddrProps>::is_private(self)
    }

    #[getter]
    fn is_reserved(&self) -> bool {
        <Self as IpAddrProps>::is_reserved(self)
    }

    #[getter]
    fn is_shared(&self) -> bool {
        <Self as IpAddrProps>::is_shared(self)
    }

    #[getter]
    fn is_unspecified(&self) -> bool {
        <Self as IpAddrProps>::is_unspecified(self)
    }

    #[getter]
    fn is_unicast(&self) -> bool {
        <Self as IpAddrProps>::is_unicast(self)
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_socketaddr(&self) -> RySocketAddr {
        RySocketAddr(SocketAddr::V4(self.0))
    }

    #[staticmethod]
    fn from_any<'py>(value: &Bound<'py, PyAny>) -> PyResult<Bound<'py, Self>> {
        let py = value.py();
        if let Ok(val) = value.cast_exact::<Self>() {
            Ok(val.as_borrowed().into_bound())
        } else if let Ok(pystr) = value.cast::<pyo3::types::PyString>() {
            let s = pystr.extract::<&str>()?;
            Self::from_str(s).map(|dt| dt.into_pyobject(py))?
        } else if let Ok(pybytes) = value.cast::<pyo3::types::PyBytes>() {
            let s = String::from_utf8_lossy(pybytes.as_bytes());
            Self::from_str(&s).map(|dt| dt.into_pyobject(py))?
        } else if let Ok(sockaddr) = value.cast::<RySocketAddr>() {
            match sockaddr.get().0 {
                SocketAddr::V4(sa) => Self::from(sa).into_pyobject(py),
                SocketAddr::V6(_) => {
                    py_type_err!(
                        "SocketAddrV4 conversion error: expected SocketAddrV4, got SocketAddrV6"
                    )
                }
            }
        } else {
            let valtype = any_repr!(value);
            py_type_err!("SocketAddrV4 conversion error: {valtype}")
        }
    }

    // ========================================================================
    // PYDANTIC
    // ========================================================================

    #[cfg(feature = "pydantic")]
    #[staticmethod]
    #[pyo3(name = "_pydantic_validate")]
    fn py_pydantic_validate<'py>(value: &Bound<'py, PyAny>) -> PyResult<Bound<'py, Self>> {
        use ryo3_core::map_py_value_err;
        Self::from_any(value).map_err(map_py_value_err)
    }

    #[cfg(feature = "pydantic")]
    #[classmethod]
    fn __get_pydantic_core_schema__<'py>(
        cls: &Bound<'py, ::pyo3::types::PyType>,
        source: &Bound<'py, PyAny>,
        handler: &Bound<'py, PyAny>,
    ) -> PyResult<Bound<'py, PyAny>> {
        use ryo3_pydantic::GetPydanticCoreSchemaCls;
        Self::get_pydantic_core_schema(cls, source, handler)
    }
}

#[pymethods]
impl RySocketAddrV6 {
    #[new]
    #[pyo3(signature = (ip, port, *, flowinfo = 0, scope_id = 0))]
    #[expect(clippy::needless_pass_by_value)]
    fn py_new(ip: IpAddrLike, port: u16, flowinfo: u32, scope_id: u32) -> PyResult<Self> {
        let ipv6 = ip.get_ipv6()?;
        let sa = SocketAddrV6::new(ipv6, port, flowinfo, scope_id);
        Ok(Self(sa))
    }

    fn __str__(&self) -> PyAsciiString {
        self.0.to_string().into()
    }

    #[pyo3(name = "to_string")]
    fn py_to_string(&self) -> PyAsciiString {
        self.__str__()
    }

    fn __repr__(&self) -> String {
        format!("{self}")
    }

    fn __hash__(&self) -> u64 {
        let mut hasher = std::hash::DefaultHasher::new();
        self.0.hash(&mut hasher);
        hasher.finish()
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_pyipaddress(&self) -> Ipv6Addr {
        *self.0.ip()
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_ipv6(&self) -> RyIpv6Addr {
        RyIpv6Addr::from(self.0.ip())
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_ipaddr(&self) -> RyIpAddr {
        RyIpAddr::from(IpAddr::V6(*self.0.ip()))
    }

    #[getter]
    fn ip(&self) -> RyIpv6Addr {
        RyIpv6Addr::from(self.0.ip())
    }

    #[getter]
    fn port(&self) -> u16 {
        self.0.port()
    }

    #[staticmethod]
    #[pyo3(signature = (s, /))]
    fn from_str(s: &str) -> PyResult<Self> {
        Self::py_from_str(s)
    }

    #[staticmethod]
    #[pyo3(signature = (value, /))]
    fn parse(value: ryo3_core::PyParseArg<Self>) -> Self {
        value.into_inner()
    }

    #[classattr]
    fn version() -> u8 {
        6
    }

    // ========================================================================
    // IpAddr forwarded
    // ========================================================================
    #[getter]
    fn is_ipv4(&self) -> bool {
        <Self as IpAddrProps>::is_ipv4(self)
    }

    #[getter]
    fn is_ipv6(&self) -> bool {
        <Self as IpAddrProps>::is_ipv6(self)
    }

    #[getter]
    fn is_documentation(&self) -> bool {
        <Self as IpAddrProps>::is_documentation(self)
    }

    #[getter]
    fn is_loopback(&self) -> bool {
        <Self as IpAddrProps>::is_loopback(self)
    }

    #[getter]
    fn is_multicast(&self) -> bool {
        <Self as IpAddrProps>::is_multicast(self)
    }

    #[getter]
    pub(crate) fn is_ipv4_mapped(&self) -> bool {
        <Self as IpAddrProps>::is_ipv4_mapped(self)
    }

    #[getter]
    fn is_unicast(&self) -> bool {
        <Self as IpAddrProps>::is_unicast(self)
    }

    #[getter]
    fn is_unicast_global(&self) -> bool {
        <Self as IpAddrProps>::is_unicast_global(self)
    }

    #[getter]
    fn is_unicast_link_local(&self) -> bool {
        <Self as IpAddrProps>::is_unicast_link_local(self)
    }

    #[getter]
    fn is_unique_local(&self) -> bool {
        <Self as IpAddrProps>::is_unique_local(self)
    }

    #[getter]
    fn is_unspecified(&self) -> bool {
        <Self as IpAddrProps>::is_unspecified(self)
    }

    // ----------------------------------------------------------------------
    // unstable properties
    // ----------------------------------------------------------------------

    #[getter]
    fn is_benchmarking(&self) -> bool {
        <Self as IpAddrProps>::is_benchmarking(self)
    }

    #[getter]
    fn is_global(&self) -> PyResult<bool> {
        <Self as IpAddrProps>::is_global(self)
    }

    #[getter]
    fn is_reserved(&self) -> bool {
        <Self as IpAddrProps>::is_reserved(self)
    }

    #[getter]
    fn is_shared(&self) -> bool {
        <Self as IpAddrProps>::is_shared(self)
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_socketaddr(&self) -> RySocketAddr {
        RySocketAddr(SocketAddr::V6(self.0))
    }

    #[staticmethod]
    fn from_any<'py>(value: &Bound<'py, PyAny>) -> PyResult<Bound<'py, Self>> {
        let py = value.py();
        if let Ok(val) = value.cast_exact::<Self>() {
            Ok(val.as_borrowed().into_bound())
        } else if let Ok(pystr) = value.cast::<pyo3::types::PyString>() {
            let s = pystr.extract::<&str>()?;
            Self::from_str(s).map(|dt| dt.into_pyobject(py))?
        } else if let Ok(pybytes) = value.cast::<pyo3::types::PyBytes>() {
            let s = String::from_utf8_lossy(pybytes.as_bytes());
            Self::from_str(&s).map(|dt| dt.into_pyobject(py))?
        } else if let Ok(socketaddr) = value.cast::<RySocketAddr>() {
            match socketaddr.get().0 {
                SocketAddr::V6(sa6) => Self::from(sa6).into_pyobject(py),
                SocketAddr::V4(_) => {
                    py_type_err!(
                        "SocketAddrV6 conversion error: expected SocketAddrV6, got SocketAddrV4"
                    )
                }
            }
        } else {
            let valtype = any_repr!(value);
            py_type_err!("SocketAddrV6 conversion error: {valtype}")
        }
    }

    // ========================================================================
    // PYDANTIC
    // ========================================================================

    #[cfg(feature = "pydantic")]
    #[staticmethod]
    #[pyo3(name = "_pydantic_validate")]
    fn py_pydantic_validate<'py>(value: &Bound<'py, PyAny>) -> PyResult<Bound<'py, Self>> {
        use ryo3_core::map_py_value_err;
        Self::from_any(value).map_err(map_py_value_err)
    }

    #[cfg(feature = "pydantic")]
    #[classmethod]
    fn __get_pydantic_core_schema__<'py>(
        cls: &Bound<'py, ::pyo3::types::PyType>,
        source: &Bound<'py, PyAny>,
        handler: &Bound<'py, PyAny>,
    ) -> PyResult<Bound<'py, PyAny>> {
        use ryo3_pydantic::GetPydanticCoreSchemaCls;
        Self::get_pydantic_core_schema(cls, source, handler)
    }
}

#[pymethods]
impl RySocketAddr {
    #[new]
    #[pyo3(signature = (ip, port, flowinfo = None, scope_id = None))]
    pub(crate) fn py_new(
        ip: &Bound<'_, PyAny>,
        port: u16,
        flowinfo: Option<u32>,
        scope_id: Option<u32>,
    ) -> PyResult<Self> {
        let iplike = ip.extract::<IpAddrLike>()?;
        let ip = iplike.get_ip()?;
        match ip {
            IpAddr::V4(ipv4) => {
                let sa = SocketAddr::V4(SocketAddrV4::new(ipv4, port));
                Ok(Self(sa))
            }
            IpAddr::V6(ipv6) => {
                let flowinfo = flowinfo.unwrap_or(0);
                let scope_id = scope_id.unwrap_or(0);
                let sa = SocketAddr::V6(SocketAddrV6::new(ipv6, port, flowinfo, scope_id));
                Ok(Self(sa))
            }
        }
    }

    fn __str__(&self) -> PyAsciiString {
        self.0.to_string().into()
    }

    #[pyo3(name = "to_string")]
    fn py_to_string(&self) -> PyAsciiString {
        self.__str__()
    }

    fn __repr__(&self) -> String {
        format!("{self}")
    }

    fn __hash__(&self) -> u64 {
        let mut hasher = std::hash::DefaultHasher::new();
        self.0.hash(&mut hasher);
        hasher.finish()
    }

    #[staticmethod]
    #[pyo3(signature = (s, /))]
    fn from_str(s: &str) -> PyResult<Self> {
        Self::py_from_str(s)
    }

    #[staticmethod]
    #[pyo3(signature = (value, /))]
    fn parse(value: ryo3_core::PyParseArg<Self>) -> Self {
        value.into_inner()
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_ipaddr(&self) -> RyIpAddr {
        RyIpAddr::from(self.0.ip())
    }

    #[getter]
    fn ip(&self) -> RyIpAddr {
        RyIpAddr::from(self.0.ip())
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_pyipaddress(&self) -> IpAddr {
        match self.0.ip() {
            IpAddr::V4(addr) => IpAddr::V4(addr),
            IpAddr::V6(addr) => IpAddr::V6(addr),
        }
    }

    #[getter]
    fn port(&self) -> u16 {
        self.0.port()
    }

    #[getter]
    fn version(&self) -> u8 {
        match self.0.ip() {
            IpAddr::V4(_) => 4,
            IpAddr::V6(_) => 6,
        }
    }

    // ========================================================================
    // IpAddr forwarded
    // ========================================================================
    #[getter]
    fn is_ipv4(&self) -> bool {
        <Self as IpAddrProps>::is_ipv4(self)
    }

    #[getter]
    fn is_ipv6(&self) -> bool {
        <Self as IpAddrProps>::is_ipv6(self)
    }

    // #[expect(clippy::unused_self)]
    #[getter]
    fn is_benchmarking(&self) -> bool {
        <Self as IpAddrProps>::is_benchmarking(self)
    }

    #[getter]
    fn is_broadcast(&self) -> bool {
        <Self as IpAddrProps>::is_broadcast(self)
    }

    #[getter]
    fn is_documentation(&self) -> bool {
        <Self as IpAddrProps>::is_documentation(self)
    }

    #[getter]
    fn is_loopback(&self) -> bool {
        <Self as IpAddrProps>::is_loopback(self)
    }

    #[getter]
    fn is_multicast(&self) -> bool {
        <Self as IpAddrProps>::is_multicast(self)
    }

    #[getter]
    fn is_private(&self) -> bool {
        <Self as IpAddrProps>::is_private(self)
    }

    #[getter]
    fn is_unspecified(&self) -> bool {
        <Self as IpAddrProps>::is_unspecified(self)
    }

    #[getter]
    // #[expect(clippy::unused_self)]
    fn is_global(&self) -> PyResult<bool> {
        <Self as IpAddrProps>::is_global(self)
    }

    #[getter]
    fn is_ipv4_mapped(&self) -> bool {
        <Self as IpAddrProps>::is_ipv4_mapped(self)
    }

    #[getter]
    fn is_link_local(&self) -> bool {
        <Self as IpAddrProps>::is_link_local(self)
    }

    #[getter]
    fn is_reserved(&self) -> bool {
        <Self as IpAddrProps>::is_reserved(self)
    }

    #[getter]
    fn is_shared(&self) -> bool {
        <Self as IpAddrProps>::is_shared(self)
    }

    #[getter]
    fn is_unicast(&self) -> bool {
        <Self as IpAddrProps>::is_unicast(self)
    }

    #[getter]
    // #[expect(clippy::unused_self)]
    fn is_unicast_global(&self) -> bool {
        <Self as IpAddrProps>::is_unicast_global(self)
    }

    #[getter]
    fn is_unicast_link_local(&self) -> bool {
        <Self as IpAddrProps>::is_unicast_link_local(self)
    }

    #[getter]
    fn is_unique_local(&self) -> bool {
        <Self as IpAddrProps>::is_unique_local(self)
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_socketaddrv4(&self) -> PyResult<RySocketAddrV4> {
        match self.0 {
            SocketAddr::V4(sa4) => Ok(RySocketAddrV4(sa4)),
            SocketAddr::V6(_) => py_value_err!("Cannot convert SocketAddr (v6) to SocketAddrV4"),
        }
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_socketaddrv6(&self) -> PyResult<RySocketAddrV6> {
        match self.0 {
            SocketAddr::V6(sa6) => Ok(RySocketAddrV6(sa6)),
            SocketAddr::V4(_) => py_value_err!("Cannot convert SocketAddr (v4) to SocketAddrV6"),
        }
    }

    #[staticmethod]
    fn from_any<'py>(value: &Bound<'py, PyAny>) -> PyResult<Bound<'py, Self>> {
        let py = value.py();
        if let Ok(val) = value.cast_exact::<Self>() {
            Ok(val.as_borrowed().into_bound())
        } else if let Ok(pystr) = value.cast::<pyo3::types::PyString>() {
            let s = pystr.extract::<&str>()?;
            Self::from_str(s).map(|dt| dt.into_pyobject(py))?
        } else if let Ok(pybytes) = value.cast::<pyo3::types::PyBytes>() {
            let s = String::from_utf8_lossy(pybytes.as_bytes());
            Self::from_str(&s).map(|dt| dt.into_pyobject(py))?
        } else if let Ok(sockaddrv4) = value.cast::<RySocketAddrV4>() {
            let sockaddr = Self::from(SocketAddr::V4(sockaddrv4.get().0));
            sockaddr.into_pyobject(py)
        } else if let Ok(sockaddrv6) = value.cast::<RySocketAddrV6>() {
            let sockaddr = Self::from(SocketAddr::V6(sockaddrv6.get().0));
            sockaddr.into_pyobject(py)
        } else {
            let valtype = any_repr!(value);
            py_type_err!("SocketAddr conversion error: {valtype}")
        }
    }

    // ========================================================================
    // PYDANTIC
    // ========================================================================

    #[cfg(feature = "pydantic")]
    #[staticmethod]
    #[pyo3(name = "_pydantic_validate")]
    fn py_pydantic_validate<'py>(value: &Bound<'py, PyAny>) -> PyResult<Bound<'py, Self>> {
        use ryo3_core::map_py_value_err;
        Self::from_any(value).map_err(map_py_value_err)
    }

    #[cfg(feature = "pydantic")]
    #[classmethod]
    fn __get_pydantic_core_schema__<'py>(
        cls: &Bound<'py, ::pyo3::types::PyType>,
        source: &Bound<'py, PyAny>,
        handler: &Bound<'py, PyAny>,
    ) -> PyResult<Bound<'py, PyAny>> {
        use ryo3_pydantic::GetPydanticCoreSchemaCls;
        Self::get_pydantic_core_schema(cls, source, handler)
    }
}

impl std::fmt::Display for RySocketAddrV4 {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let py_ip = RyIpv4Addr::from(self.0.ip());
        write!(f, "SocketAddrV4({}, {})", py_ip, self.port())
    }
}

impl std::fmt::Display for RySocketAddrV6 {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let py_ip = RyIpv6Addr::from(self.0.ip());
        write!(
            f,
            "SocketAddrV6({}, {}, flowinfo={}, scope_id={})",
            py_ip,
            self.port(),
            self.0.flowinfo(),
            self.0.scope_id()
        )
    }
}

impl std::fmt::Display for RySocketAddr {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self.0.ip() {
            IpAddr::V4(ipv4) => {
                let py_ip = RyIpv4Addr::from(ipv4);
                write!(f, "SocketAddr({}, {})", py_ip, self.port())
            }
            IpAddr::V6(ipv6) => {
                let py_ip = RyIpv6Addr::from(ipv6);
                let flowinfo = match self.0 {
                    SocketAddr::V6(sa6) => sa6.flowinfo(),
                    SocketAddr::V4(_) => unreachable!(),
                };
                let scope_id = match self.0 {
                    SocketAddr::V6(sa6) => sa6.scope_id(),
                    SocketAddr::V4(_) => unreachable!(),
                };
                write!(
                    f,
                    "SocketAddr({}, {}, flowinfo={}, scope_id={})",
                    py_ip,
                    self.port(),
                    flowinfo,
                    scope_id
                )
            }
        }
    }
}

impl<'py> FromPyObject<'_, 'py> for RySocketAddrV4 {
    type Error = PyErr;

    fn extract(obj: Borrowed<'_, 'py, PyAny>) -> Result<Self, Self::Error> {
        obj.cast_exact::<Self>()
            .map(|val| *(val.get()))
            .map_err(|_| py_type_error!("Expected SocketAddrV4"))
    }
}

impl<'py> FromPyObject<'_, 'py> for RySocketAddrV6 {
    type Error = PyErr;

    fn extract(obj: Borrowed<'_, 'py, PyAny>) -> Result<Self, Self::Error> {
        obj.cast_exact::<Self>()
            .map(|val| *(val.get()))
            .map_err(|_| py_type_error!("Expected SocketAddrV6"))
    }
}

impl<'py> FromPyObject<'_, 'py> for RySocketAddr {
    type Error = PyErr;

    fn extract(obj: Borrowed<'_, 'py, PyAny>) -> Result<Self, Self::Error> {
        obj.cast_exact::<Self>()
            .map(|val| *(val.get()))
            .map_err(|_| py_type_error!("Expected SocketAddr"))
    }
}
