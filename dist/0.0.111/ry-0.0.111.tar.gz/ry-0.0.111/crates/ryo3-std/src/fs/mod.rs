mod buffered_file;
mod file_read_stream;
mod file_type;
use std::convert::Into;
use std::ffi::OsString;
use std::path::{Path, PathBuf};
use std::sync::Mutex;
use std::time::SystemTime;

pub use buffered_file::{BUF_SIZE, BufferedFile};
pub use file_read_stream::FileReadStreamOptions;
pub use file_type::RyFileType;
use pyo3::exceptions::PyRuntimeError;
use pyo3::prelude::*;
use pyo3::types::{PyBytes, PyDict};
use ryo3_bytes::RyBytes;
use ryo3_core::PyIoResultExt;
use ryo3_core::types::{PathLike, PyUtf8Bytes};
use ryo3_macro_rules::py_type_err;

use crate::fs::file_read_stream::RyFileReadStream;

#[pyclass(name = "Metadata", frozen, immutable_type)]
#[cfg_attr(feature = "ry", pyo3(module = "ry.ryo3"))]
#[derive(Clone)]
pub struct RyMetadata(std::fs::Metadata);

impl From<std::fs::Metadata> for RyMetadata {
    #[inline]
    fn from(m: std::fs::Metadata) -> Self {
        Self::new(m)
    }
}

impl RyMetadata {
    #[inline]
    #[must_use]
    pub fn new(m: std::fs::Metadata) -> Self {
        Self(m)
    }

    #[inline]
    #[must_use]
    pub fn inner(&self) -> &std::fs::Metadata {
        &self.0
    }

    #[inline]
    #[must_use]
    pub fn into_inner(self) -> std::fs::Metadata {
        self.0
    }
}

#[pymethods]
impl RyMetadata {
    fn __repr__(&self) -> String {
        format!(
            "Metadata<is_dir={}, is_file={}, is_symlink={}, len={}, readonly={}>",
            self.0.is_dir(),
            self.0.is_file(),
            self.0.file_type().is_symlink(),
            self.0.len(),
            self.0.permissions().readonly(),
        )
    }

    fn to_py<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyDict>> {
        let metadata_dict = PyDict::new(py);
        metadata_dict.set_item(pyo3::intern!(py, "is_dir"), self.is_dir())?;
        metadata_dict.set_item(pyo3::intern!(py, "is_file"), self.is_file())?;
        metadata_dict.set_item(pyo3::intern!(py, "is_symlink"), self.is_symlink())?;
        metadata_dict.set_item(pyo3::intern!(py, "len"), self.len())?;
        metadata_dict.set_item(pyo3::intern!(py, "readonly"), self.readonly())?;
        metadata_dict.set_item(pyo3::intern!(py, "file_type"), self.file_type().to_py(py))?;
        metadata_dict.set_item(pyo3::intern!(py, "accessed"), self.accessed()?)?;
        if let Ok(created) = self.created() {
            metadata_dict.set_item(pyo3::intern!(py, "created"), created)?;
        }
        metadata_dict.set_item(pyo3::intern!(py, "modified"), self.modified()?)?;
        Ok(metadata_dict)
    }

    #[getter]
    fn accessed(&self) -> PyResult<SystemTime> {
        let accessed = self.0.accessed()?;
        Ok(accessed)
    }

    #[getter]
    fn created(&self) -> PyResult<SystemTime> {
        let created = self.0.created()?;
        Ok(created)
    }

    #[getter]
    #[must_use]
    fn file_type(&self) -> RyFileType {
        RyFileType::from(self.0.file_type())
    }

    #[getter]
    #[must_use]
    fn is_dir(&self) -> bool {
        self.0.is_dir()
    }

    #[getter]
    #[must_use]
    fn is_file(&self) -> bool {
        self.0.is_file()
    }

    #[getter]
    #[must_use]
    fn is_symlink(&self) -> bool {
        self.0.file_type().is_symlink()
    }

    #[getter]
    #[must_use]
    fn len(&self) -> u64 {
        self.0.len()
    }

    #[getter]
    #[must_use]
    fn is_empty(&self) -> bool {
        self.0.len() == 0
    }

    #[getter]
    fn modified(&self) -> PyResult<SystemTime> {
        let modified = self.0.modified()?;
        Ok(modified)
    }

    #[getter]
    #[must_use]
    fn readonly(&self) -> bool {
        self.0.permissions().readonly()
    }

    #[getter]
    fn permissions(&self) -> RyPermissions {
        let permissions = self.0.permissions();
        RyPermissions::from(permissions)
    }
}

#[pyclass(name = "Permissions", frozen, immutable_type, eq)]
#[cfg_attr(feature = "ry", pyo3(module = "ry.ryo3"))]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct RyPermissions(std::fs::Permissions);

impl From<std::fs::Permissions> for RyPermissions {
    fn from(p: std::fs::Permissions) -> Self {
        Self(p)
    }
}

impl RyPermissions {
    #[must_use]
    pub fn new(p: std::fs::Permissions) -> Self {
        Self(p)
    }

    #[must_use]
    pub fn inner(&self) -> &std::fs::Permissions {
        &self.0
    }

    #[must_use]
    pub fn into_inner(self) -> std::fs::Permissions {
        self.0
    }
}

#[pymethods]
impl RyPermissions {
    #[getter]
    #[must_use]
    fn readonly(&self) -> bool {
        self.0.readonly()
    }

    fn __repr__(&self) -> &str {
        if self.readonly() {
            "Permissions<readonly=True>"
        } else {
            "Permissions<readonly=False>"
        }
    }
}

#[pyclass(name = "DirEntry", frozen, immutable_type)]
#[cfg_attr(feature = "ry", pyo3(module = "ry.ryo3"))]
pub struct RyDirEntry(std::fs::DirEntry);

impl From<std::fs::DirEntry> for RyDirEntry {
    fn from(de: std::fs::DirEntry) -> Self {
        Self(de)
    }
}

#[pymethods]
impl RyDirEntry {
    fn __repr__(&self) -> String {
        let path = self.0.path();
        let path_disp = path.display();
        format!("DirEntry('{path_disp}')")
    }

    #[must_use]
    fn __fspath__(&self) -> OsString {
        self.0.path().into_os_string()
    }

    #[getter]
    fn path(&self) -> PathBuf {
        self.0.path()
    }

    #[getter]
    fn filename(&self) -> OsString {
        self.0.file_name()
    }

    fn file_type(&self) -> PyResult<RyFileType> {
        let file_type = self.0.file_type().map_py_io_err_with_path(self.0.path())?;
        Ok(RyFileType::from(file_type))
    }

    fn metadata(&self) -> PyResult<RyMetadata> {
        let metadata = self.0.metadata().map_py_io_err_with_path(self.0.path())?;
        Ok(RyMetadata::from(metadata))
    }
}

// ============================================================================
// FUNCTIONS
// ============================================================================

#[pyfunction]
#[pyo3(
    signature = (
        path,
        read_size = 65_536,
        *,
        offset = 0,
        buffered = true,
        strict = true
    )
)]
pub fn read_stream(
    path: PathBuf,
    read_size: usize,
    offset: u64,
    buffered: bool,
    strict: bool,
) -> PyResult<RyFileReadStream> {
    RyFileReadStream::py_new(path, read_size, offset, buffered, strict)
}

#[pyfunction]
pub fn read(py: Python<'_>, path: PathLike) -> PyResult<RyBytes> {
    let fbytes = py
        .detach(|| std::fs::read(&path))
        .map(Into::into)
        .map_py_io_err_with_path(path)?;
    Ok(fbytes)
}

#[pyfunction]
pub fn read_bytes(py: Python<'_>, path: PathLike) -> PyResult<Py<PyAny>> {
    let fbytes = py
        .detach(|| std::fs::read(&path))
        .map_py_io_err_with_path(path)?;
    Ok(PyBytes::new(py, &fbytes).into())
}

#[pyfunction]
pub fn read_text(py: Python<'_>, path: PathLike) -> PyResult<PyUtf8Bytes> {
    let fbytes = py
        .detach(|| std::fs::read(&path))
        .map_py_io_err_with_path(path)?;
    Ok(fbytes.into())
}

fn write_impl<P: AsRef<Path>, C: AsRef<[u8]>>(fspath: P, b: C) -> PyResult<usize> {
    std::fs::write(fspath.as_ref(), b.as_ref()).map_py_io_err_with_path(fspath)?;
    Ok(b.as_ref().len())
}

#[pyfunction]
pub fn read_link(path: PathBuf) -> PyResult<PathBuf> {
    std::fs::read_link(&path).map_py_io_err_with_path(path)
}

#[pyfunction]
pub fn read_to_string(py: Python<'_>, path: PathBuf) -> PyResult<String> {
    py.detach(|| std::fs::read_to_string(&path))
        .map_py_io_err_with_path(path)
}

#[pyfunction]
pub fn read_str(py: Python<'_>, path: PathBuf) -> PyResult<String> {
    read_to_string(py, path)
}

#[pyfunction]
pub fn write(py: Python<'_>, path: PathBuf, data: &Bound<'_, PyAny>) -> PyResult<usize> {
    if let Ok(pystr) = data.cast_exact::<pyo3::types::PyString>() {
        let s = pystr.extract::<&str>()?;
        let bytes = s.as_bytes();
        py.detach(|| write_impl(path, bytes))
    } else if let Ok(b) = data.extract::<RyBytes>() {
        py.detach(|| write_impl(path, &b))
    } else {
        py_type_err!("write - expected str, bytes, bytes-like or buffer-protocol object")
    }
}

#[pyfunction]
pub fn write_bytes(py: Python<'_>, path: PathBuf, buf: &Bound<'_, PyAny>) -> PyResult<usize> {
    let bref = buf.extract::<RyBytes>()?;
    py.detach(|| write_impl(path, &bref))
}

#[pyfunction]
pub fn write_text(py: Python<'_>, path: PathBuf, s: &str) -> PyResult<usize> {
    let str_bytes = s.as_bytes();
    py.detach(|| std::fs::write(&path, str_bytes))
        .map_py_io_err_with_path(path)?;
    Ok(str_bytes.len())
}

#[pyfunction]
pub fn write_str(py: Python<'_>, path: PathBuf, string: &str) -> PyResult<usize> {
    write_text(py, path, string)
}

#[pyfunction]
pub fn rename(py: Python<'_>, from: PathBuf, to: PathBuf) -> PyResult<()> {
    py.detach(|| std::fs::rename(&from, &to))
        .map_py_io_err_with_src_dst(from, to)
}

#[pyfunction]
pub fn metadata(path: PathLike) -> PyResult<RyMetadata> {
    let metadata = std::fs::metadata(&path).map_py_io_err_with_path(path)?;
    Ok(RyMetadata::from(metadata))
}

#[pyfunction]
pub fn copy(py: Python<'_>, from: PathBuf, to: PathBuf) -> PyResult<u64> {
    py.detach(|| std::fs::copy(&from, &to))
        .map_py_io_err_with_src_dst(from, to)
}

#[pyfunction]
pub fn remove_file(py: Python<'_>, path: PathLike) -> PyResult<()> {
    py.detach(|| std::fs::remove_file(&path))
        .map_py_io_err_with_path(path)
}

#[pyfunction]
pub fn remove_dir(py: Python<'_>, path: PathLike) -> PyResult<()> {
    py.detach(|| std::fs::remove_dir(&path))
        .map_py_io_err_with_path(path)
}

#[pyfunction]
pub fn remove_dir_all(py: Python<'_>, path: PathLike) -> PyResult<()> {
    py.detach(|| std::fs::remove_dir_all(&path))
        .map_py_io_err_with_path(path)
}

#[pyfunction]
pub fn create_dir(py: Python<'_>, path: PathLike) -> PyResult<()> {
    py.detach(|| std::fs::create_dir(&path))
        .map_py_io_err_with_path(path)
}

#[pyfunction]
pub fn create_dir_all(py: Python<'_>, path: PathLike) -> PyResult<()> {
    py.detach(|| std::fs::create_dir_all(&path))
        .map_py_io_err_with_path(path)
}

#[pyfunction]
pub fn canonicalize(py: Python<'_>, path: PathLike) -> PyResult<PathLike> {
    match path {
        PathLike::PathBuf(p) => {
            let resolved = py
                .detach(|| std::fs::canonicalize(&p))
                .map_py_io_err_with_path(p)?;
            Ok(PathLike::PathBuf(resolved))
        }
        PathLike::PyStr(s) => {
            let resolved = py
                .detach(|| std::fs::canonicalize(&*s))
                .map_py_io_err_with_path(&*s)?;
            Ok(PathLike::Str(resolved.to_string_lossy().to_string()))
        }
        PathLike::Str(s) => {
            let resolved = py
                .detach(|| std::fs::canonicalize(&s))
                .map_py_io_err_with_path(s)?;
            Ok(PathLike::Str(resolved.to_string_lossy().to_string()))
        }
    }
}

#[pyfunction]
pub fn exists(path: PathBuf) -> PyResult<bool> {
    std::fs::exists(&path).map_py_io_err_with_path(path)
}

#[pyfunction]
pub fn hard_link(py: Python<'_>, original: PathBuf, link: PathBuf) -> PyResult<()> {
    py.detach(|| std::fs::hard_link(&original, &link))
        .map_py_io_err_with_src_dst(original, link)
}

#[pyfunction]
pub fn set_permissions(py: Python<'_>, path: PathBuf, perm: &RyPermissions) -> PyResult<()> {
    py.detach(|| std::fs::set_permissions(&path, perm.0.clone()))
        .map_py_io_err_with_path(path)
}

#[pyfunction]
pub fn soft_link(py: Python<'_>, original: PathBuf, link: PathBuf) -> PyResult<()> {
    #[cfg(unix)]
    {
        use std::os::unix::fs as unix_fs;
        py.detach(|| unix_fs::symlink(&original, &link))
            .map_py_io_err_with_src_dst(original, link)
    }
    #[cfg(windows)]
    {
        use std::os::windows::fs as windows_fs;
        let metadata = py
            .detach(|| std::fs::metadata(&original))
            .map_py_io_err_with_path(&original)?;
        if metadata.is_dir() {
            py.detach(|| windows_fs::symlink_dir(&original, &link))
                .map_py_io_err_with_src_dst(original, link)
        } else {
            py.detach(|| windows_fs::symlink_file(&original, &link))
                .map_py_io_err_with_src_dst(original, link)
        }
    }
    #[cfg(not(any(unix, windows)))]
    {
        pytodo!("soft_link is not implemented on this platform");
    }
}

#[pyfunction]
pub fn symlink_metadata(path: PathBuf) -> PyResult<RyMetadata> {
    std::fs::symlink_metadata(&path)
        .map(RyMetadata::from)
        .map_py_io_err_with_path(path)
}

#[pyfunction]
#[expect(clippy::needless_pass_by_value)]
pub fn read_dir(path: PathLike) -> PyResult<RyReadDir> {
    let path_ref = path.as_ref();
    let iter = std::fs::read_dir(path_ref).map_py_io_err_with_path(path_ref)?;
    Ok(RyReadDir {
        path: path_ref.to_path_buf(),
        iter: Mutex::new(iter),
    })
}

#[pyclass(name = "ReadDir", frozen, immutable_type)]
#[cfg_attr(feature = "ry", pyo3(module = "ry.ryo3"))]
pub struct RyReadDir {
    path: PathBuf,
    iter: Mutex<std::fs::ReadDir>,
}

#[pymethods]
impl RyReadDir {
    fn __repr__(&self) -> String {
        format!("{self}")
    }

    fn __iter__(slf: PyRef<'_, Self>) -> PyRef<'_, Self> {
        slf
    }

    fn __next__(&self) -> PyResult<Option<RyDirEntry>> {
        if let Ok(mut iter) = self.iter.lock() {
            match iter.next() {
                Some(Ok(entry)) => Ok(Some(RyDirEntry::from(entry))),
                _ => Ok(None),
            }
        } else {
            Err(PyRuntimeError::new_err("ReadDir lock poisoned"))
        }
    }

    fn collect(&self) -> PyResult<Vec<RyDirEntry>> {
        let mut paths = vec![];
        let mut iter = self
            .iter
            .lock()
            .map_err(|_| PyRuntimeError::new_err("ReadDir lock poisoned"))?;
        for entry in iter.by_ref() {
            match entry {
                Ok(entry) => paths.push(RyDirEntry::from(entry)),
                Err(_) => break,
            }
        }
        Ok(paths)
    }

    #[pyo3(signature = (n = 1))]
    fn take(&self, n: usize) -> PyResult<Vec<RyDirEntry>> {
        let mut paths = vec![];
        let mut iter = self
            .iter
            .lock()
            .map_err(|_| PyRuntimeError::new_err("ReadDir lock poisoned"))?;
        for entry in iter.by_ref().take(n) {
            match entry {
                Ok(entry) => paths.push(RyDirEntry::from(entry)),
                Err(_) => break,
            }
        }
        Ok(paths)
    }
}

impl std::fmt::Display for RyReadDir {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let path = self.path.to_string_lossy();
        write!(f, "ReadDir(\"{path}\")")
    }
}

pub fn pymod_add(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<RyFileReadStream>()?;
    m.add_class::<RyFileType>()?;
    m.add_class::<RyDirEntry>()?;
    m.add_class::<RyReadDir>()?;
    m.add_class::<RyMetadata>()?;
    m.add_function(wrap_pyfunction!(canonicalize, m)?)?;
    m.add_function(wrap_pyfunction!(copy, m)?)?;
    m.add_function(wrap_pyfunction!(create_dir, m)?)?;
    m.add_function(wrap_pyfunction!(create_dir_all, m)?)?;
    m.add_function(wrap_pyfunction!(exists, m)?)?;
    m.add_function(wrap_pyfunction!(hard_link, m)?)?;
    m.add_function(wrap_pyfunction!(metadata, m)?)?;
    m.add_function(wrap_pyfunction!(read, m)?)?;
    m.add_function(wrap_pyfunction!(read_bytes, m)?)?;
    m.add_function(wrap_pyfunction!(read_dir, m)?)?;
    m.add_function(wrap_pyfunction!(read_link, m)?)?;
    m.add_function(wrap_pyfunction!(read_str, m)?)?;
    m.add_function(wrap_pyfunction!(read_stream, m)?)?;
    m.add_function(wrap_pyfunction!(read_text, m)?)?;
    m.add_function(wrap_pyfunction!(read_to_string, m)?)?;
    m.add_function(wrap_pyfunction!(remove_dir, m)?)?;
    m.add_function(wrap_pyfunction!(remove_dir_all, m)?)?;
    m.add_function(wrap_pyfunction!(remove_file, m)?)?;
    m.add_function(wrap_pyfunction!(rename, m)?)?;
    m.add_function(wrap_pyfunction!(set_permissions, m)?)?;
    m.add_function(wrap_pyfunction!(soft_link, m)?)?;
    m.add_function(wrap_pyfunction!(symlink_metadata, m)?)?;
    m.add_function(wrap_pyfunction!(write, m)?)?;
    m.add_function(wrap_pyfunction!(write_bytes, m)?)?;
    m.add_function(wrap_pyfunction!(write_text, m)?)?;
    Ok(())
}
