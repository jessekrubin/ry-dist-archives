use pyo3::prelude::*;
use pyo3::types::PyDict;
use reqwest::header::HeaderValue;
use ryo3_core::py_dict::KwargsIter;
use ryo3_http::{PyHeadersLike, RyHeaders};
use ryo3_macro_rules::{py_type_err, py_value_error};
use ryo3_std::time::{PyTimeout, RyDuration};

use crate::constants::DEFAULT_USER_AGENT;
use crate::proxy::PyProxies;
use crate::tls::{RyCertificate, RyCertificateRevocationList, RyIdentity, py_load_native_certs};
use crate::tls_version::PyTlsVersion;
use crate::types::PyUserAgent;

#[derive(Debug, Clone, PartialEq)]
#[expect(clippy::struct_excessive_bools)]
pub struct ClientConfig {
    headers: Option<RyHeaders>,
    cookies: bool,
    user_agent: Option<ryo3_http::PyHttpHeaderValue>,
    hickory_dns: bool,
    redirect: Option<usize>,
    resolve: Option<PyResolveMap>,
    connection_verbose: bool,
    // misspelled of course :/
    referer: bool,
    // -- http preferences --
    http1_only: bool,
    https_only: bool,
    // -- http1 --
    http1_title_case_headers: bool,
    http1_max_headers: usize,
    http1_allow_obsolete_multiline_headers_in_responses: bool,
    http1_allow_spaces_after_header_name_in_responses: bool,
    http1_ignore_invalid_headers_in_responses: bool,
    // -- http2 --
    http2_prior_knowledge: bool,
    http2_initial_stream_window_size: Option<u32>,
    http2_initial_connection_window_size: Option<u32>,
    http2_adaptive_window: bool,
    http2_max_frame_size: Option<u32>,
    http2_max_header_list_size: Option<u32>,
    http2_keep_alive_interval: Option<RyDuration>,
    http2_keep_alive_timeout: Option<RyDuration>,
    http2_keep_alive_while_idle: bool,
    // -- timeout(s) --
    timeout: Option<RyDuration>,
    read_timeout: Option<RyDuration>,
    connect_timeout: Option<RyDuration>,
    // -- compression --
    gzip: bool,
    brotli: bool,
    deflate: bool,
    zstd: bool,
    // -- pool --
    pool_max_idle_per_host: usize,
    pool_idle_timeout: Option<RyDuration>,
    // -- tcp --
    tcp_keepalive: Option<RyDuration>, // default: 15 seconds
    tcp_keepalive_interval: Option<RyDuration>, // default: 15 seconds
    tcp_keepalive_retries: Option<u32>, // default: 3
    tcp_nodelay: bool,                 // default: true
    // -- tls --
    identity: Option<RyIdentity>,
    tls_certs_merge: Option<Vec<RyCertificate>>,
    tls_certs_only: Option<Vec<RyCertificate>>,
    tls_crls_only: Option<Vec<RyCertificateRevocationList>>,
    tls_info: bool, // default: false
    tls_sni: bool,  // default: true
    tls_version_max: Option<PyTlsVersion>,
    tls_version_min: Option<PyTlsVersion>,
    // -- tls danger zone --
    tls_danger_accept_invalid_certs: bool,
    tls_danger_accept_invalid_hostnames: bool,
    proxy: Option<PyProxies>,
    // == CLIENT BUILDER OPTIONS TODO ==
    // connector_layer
    // cookie_provider
    // cookie_store
    // dns_resolver
    // dns_resolver2
    // http09_responses
    // interface
    // local_address

    // -- UNSTABLE ~ RY ONLY) -
    /// (unstable) use cached native system certs
    _tls_cached_native_certs: bool,
}

impl Default for ClientConfig {
    fn default() -> Self {
        Self {
            headers: None,
            cookies: false,
            user_agent: Some(HeaderValue::from_static(DEFAULT_USER_AGENT).into()),
            hickory_dns: true,
            redirect: Some(10),
            resolve: None,
            connection_verbose: false,
            referer: true,
            // compression
            gzip: true,
            brotli: true,
            deflate: true,
            zstd: true,
            // http prefs
            http1_only: false,
            https_only: false,
            // http/1.x
            http1_title_case_headers: false,
            http1_max_headers: 100,
            http1_allow_obsolete_multiline_headers_in_responses: false,
            http1_allow_spaces_after_header_name_in_responses: false,
            http1_ignore_invalid_headers_in_responses: false,
            // http/2
            http2_prior_knowledge: false,
            http2_initial_stream_window_size: None,
            http2_initial_connection_window_size: None,
            http2_adaptive_window: false,
            // hyper default is 16kb ~ bigger frames == way less cpu on big bodies
            // (for us and the server)
            http2_max_frame_size: Some(64 * 1024),
            http2_max_header_list_size: None,
            http2_keep_alive_interval: None,
            http2_keep_alive_timeout: None,
            http2_keep_alive_while_idle: false,
            // timeouts
            timeout: None,
            read_timeout: None,
            connect_timeout: None,
            // pool
            pool_max_idle_per_host: usize::MAX,
            pool_idle_timeout: Some(RyDuration::from_secs(90)),
            // tcp
            tcp_keepalive: Some(RyDuration::from_secs(15)),
            tcp_keepalive_interval: Some(RyDuration::from_secs(15)),
            tcp_keepalive_retries: Some(3),
            tcp_nodelay: true,
            // tls
            identity: None,
            tls_certs_merge: None,
            tls_certs_only: None,
            tls_crls_only: None,
            tls_info: false,
            tls_sni: true,
            tls_version_max: None,
            tls_version_min: None,
            // tls-danger
            tls_danger_accept_invalid_certs: false,
            tls_danger_accept_invalid_hostnames: false,
            proxy: None,
            // (UNSTABLE)
            _tls_cached_native_certs: false,
        }
    }
}

impl<'py> FromPyObject<'_, 'py> for ClientConfig {
    type Error = PyErr;
    #[expect(clippy::too_many_lines)]
    fn extract(obj: Borrowed<'_, 'py, PyAny>) -> PyResult<Self> {
        let dict = obj.cast_exact::<PyDict>()?;
        let mut cfg = Self::default();

        for kwarg in KwargsIter::new(dict) {
            let (key_str, v) = kwarg?;
            match key_str {
                "headers" => {
                    cfg.headers = v.extract::<Option<PyHeadersLike>>()?.map(RyHeaders::from);
                }
                "cookies" => {
                    cfg.cookies = v.extract::<bool>()?;
                }
                "user_agent" => {
                    cfg.user_agent = v.extract::<PyUserAgent>()?.into();
                }
                "timeout" => {
                    cfg.timeout = v.extract::<Option<PyTimeout>>()?.map(RyDuration::from);
                }
                "read_timeout" => {
                    cfg.read_timeout = v.extract::<Option<PyTimeout>>()?.map(RyDuration::from);
                }
                "connect_timeout" => {
                    cfg.connect_timeout = v.extract::<Option<PyTimeout>>()?.map(RyDuration::from);
                }
                "redirect" => {
                    cfg.redirect = v.extract::<Option<usize>>()?;
                }
                "resolve" => {
                    cfg.resolve = v.extract::<Option<PyResolveMap>>()?;
                }
                "referer" => {
                    cfg.referer = v.extract::<bool>()?;
                }
                "gzip" => {
                    cfg.gzip = v.extract::<bool>()?;
                }
                "brotli" => {
                    cfg.brotli = v.extract::<bool>()?;
                }
                "deflate" => {
                    cfg.deflate = v.extract::<bool>()?;
                }
                "zstd" => {
                    cfg.zstd = v.extract::<bool>()?;
                }
                "connection_verbose" => {
                    cfg.connection_verbose = v.extract::<bool>()?;
                }
                "hickory_dns" => {
                    cfg.hickory_dns = v.extract::<bool>()?;
                }
                "http1_only" => {
                    cfg.http1_only = v.extract::<bool>()?;
                }
                "https_only" => {
                    cfg.https_only = v.extract::<bool>()?;
                }
                // -- http1 --
                "http1_title_case_headers" => {
                    cfg.http1_title_case_headers = v.extract::<bool>()?;
                }
                "http1_allow_obsolete_multiline_headers_in_responses" => {
                    cfg.http1_allow_obsolete_multiline_headers_in_responses =
                        v.extract::<bool>()?;
                }
                "http1_allow_spaces_after_header_name_in_responses" => {
                    cfg.http1_allow_spaces_after_header_name_in_responses = v.extract::<bool>()?;
                }
                "http1_max_headers" => {
                    cfg.http1_max_headers = v.extract::<usize>()?;
                }
                "http1_ignore_invalid_headers_in_responses" => {
                    cfg.http1_ignore_invalid_headers_in_responses = v.extract::<bool>()?;
                }
                // -- http2 --
                "http2_prior_knowledge" => {
                    cfg.http2_prior_knowledge = v.extract::<bool>()?;
                }
                "http2_initial_stream_window_size" => {
                    cfg.http2_initial_stream_window_size = v.extract::<Option<u32>>()?;
                }
                "http2_initial_connection_window_size" => {
                    cfg.http2_initial_connection_window_size = v.extract::<Option<u32>>()?;
                }
                "http2_adaptive_window" => {
                    cfg.http2_adaptive_window = v.extract::<bool>()?;
                }
                "http2_max_frame_size" => {
                    cfg.http2_max_frame_size = v.extract::<Option<u32>>()?;
                }
                "http2_max_header_list_size" => {
                    cfg.http2_max_header_list_size = v.extract::<Option<u32>>()?;
                }
                "http2_keep_alive_interval" => {
                    cfg.http2_keep_alive_interval =
                        v.extract::<Option<PyTimeout>>()?.map(RyDuration::from);
                }
                "http2_keep_alive_timeout" => {
                    cfg.http2_keep_alive_timeout =
                        v.extract::<Option<PyTimeout>>()?.map(RyDuration::from);
                }
                "http2_keep_alive_while_idle" => {
                    cfg.http2_keep_alive_while_idle = v.extract::<bool>()?;
                }
                // --- pool ---
                "pool_idle_timeout" => {
                    cfg.pool_idle_timeout = v.extract::<Option<PyTimeout>>()?.map(RyDuration::from);
                }
                "pool_max_idle_per_host" => {
                    cfg.pool_max_idle_per_host = v.extract::<usize>()?;
                }
                // --- tcp ---
                "tcp_keepalive" => {
                    cfg.tcp_keepalive = v.extract::<Option<PyTimeout>>()?.map(RyDuration::from);
                }
                "tcp_keepalive_interval" => {
                    cfg.tcp_keepalive_interval =
                        v.extract::<Option<PyTimeout>>()?.map(RyDuration::from);
                }
                "tcp_keepalive_retries" => {
                    cfg.tcp_keepalive_retries = v.extract::<Option<u32>>()?;
                }
                "tcp_nodelay" => {
                    cfg.tcp_nodelay = v.extract::<bool>()?;
                }
                // --- TLS ---
                "identity" => {
                    cfg.identity = v.extract::<Option<RyIdentity>>()?;
                }
                "tls_certs_merge" => {
                    cfg.tls_certs_merge = v.extract::<Option<Vec<RyCertificate>>>()?;
                }
                "tls_certs_only" => {
                    cfg.tls_certs_only = v.extract::<_>()?;
                }
                "tls_crls_only" => {
                    cfg.tls_crls_only = v.extract::<_>()?;
                }
                "tls_info" => {
                    cfg.tls_info = v.extract::<_>()?;
                }
                "tls_sni" => {
                    cfg.tls_sni = v.extract::<_>()?;
                }
                "tls_version_max" => {
                    cfg.tls_version_max = v.extract::<_>()?;
                }
                "tls_version_min" => {
                    cfg.tls_version_min = v.extract::<_>()?;
                }
                "tls_danger_accept_invalid_certs" => {
                    cfg.tls_danger_accept_invalid_certs = v.extract::<_>()?;
                }
                "tls_danger_accept_invalid_hostnames" => {
                    cfg.tls_danger_accept_invalid_hostnames = v.extract::<_>()?;
                }
                "proxy" => {
                    cfg.proxy = v.extract::<_>()?;
                }
                "_tls_cached_native_certs" => {
                    #[expect(clippy::used_underscore_binding)]
                    {
                        cfg._tls_cached_native_certs = v.extract::<_>()?;
                    }
                }
                _ => {
                    return py_type_err!("unknown ClientConfig option: {}", key_str);
                }
            }
        }

        Ok(cfg)
    }
}

impl ClientConfig {
    #[inline]
    fn apply_http2_opts(
        &self,
        mut client_builder: reqwest::ClientBuilder,
    ) -> reqwest::ClientBuilder {
        if self.http2_prior_knowledge {
            client_builder = client_builder.http2_prior_knowledge();
        }
        if let Some(http2_initial_stream_window_size) = self.http2_initial_stream_window_size {
            client_builder =
                client_builder.http2_initial_stream_window_size(http2_initial_stream_window_size);
        }
        if let Some(http2_initial_connection_window_size) =
            self.http2_initial_connection_window_size
        {
            client_builder = client_builder
                .http2_initial_connection_window_size(http2_initial_connection_window_size);
        }
        if self.http2_adaptive_window {
            client_builder = client_builder.http2_adaptive_window(true);
        }
        if let Some(http2_max_frame_size) = self.http2_max_frame_size {
            client_builder = client_builder.http2_max_frame_size(http2_max_frame_size);
        }
        if let Some(http2_max_header_list_size) = self.http2_max_header_list_size {
            client_builder = client_builder.http2_max_header_list_size(http2_max_header_list_size);
        }
        if let Some(http2_keep_alive_interval) = &self.http2_keep_alive_interval {
            client_builder =
                client_builder.http2_keep_alive_interval(*http2_keep_alive_interval.inner());
        }
        if let Some(http2_keep_alive_timeout) = &self.http2_keep_alive_timeout {
            client_builder =
                client_builder.http2_keep_alive_timeout(*http2_keep_alive_timeout.inner());
        }
        if self.http2_keep_alive_while_idle {
            client_builder = client_builder.http2_keep_alive_while_idle(true);
        }
        client_builder
    }

    #[inline]
    #[expect(clippy::used_underscore_binding)]
    fn apply_tls_opts(&self, mut client_builder: reqwest::ClientBuilder) -> reqwest::ClientBuilder {
        // based on the reqwest logic for system cert loading, but adapted to allow for
        // caching the system certs once per process instead of loading them every time
        // a client is built
        if let Some(tls_certs_only) = &self.tls_certs_only {
            client_builder = client_builder
                .tls_certs_only(tls_certs_only.iter().map(|py_cert| py_cert.cert.clone()));
        } else if self._tls_cached_native_certs && self.tls_certs_merge.is_none() {
            let cached = py_load_native_certs();
            if !cached.is_empty() {
                client_builder = client_builder.tls_certs_only(cached.iter().cloned());
            }
        }

        if let Some(tls_certs_merge) = &self.tls_certs_merge {
            client_builder = client_builder
                .tls_certs_merge(tls_certs_merge.iter().map(|py_cert| py_cert.cert.clone()));
        }

        // CRL
        if let Some(tls_crls_only) = &self.tls_crls_only {
            client_builder = client_builder
                .tls_crls_only(tls_crls_only.clone().into_iter().map(|py_crl| py_crl.crl));
        }

        if let Some(tls_version_min) = &self.tls_version_min {
            client_builder = client_builder.tls_version_min(tls_version_min.into());
        }
        if let Some(tls_version_max) = &self.tls_version_max {
            client_builder = client_builder.tls_version_max(tls_version_max.into());
        }
        client_builder
    }

    #[inline]
    pub(crate) fn apply(&self, client_builder: reqwest::ClientBuilder) -> reqwest::ClientBuilder {
        let mut client_builder = client_builder
            .connection_verbose(self.connection_verbose)
            .gzip(self.gzip)
            .brotli(self.brotli)
            .deflate(self.deflate)
            .zstd(self.zstd)
            .cookie_store(self.cookies)
            .hickory_dns(self.hickory_dns)
            .referer(self.referer)
            .redirect(
                self.redirect
                    .map_or_else(reqwest::redirect::Policy::none, |max| {
                        reqwest::redirect::Policy::limited(max)
                    }),
            )
            .https_only(self.https_only)
            .http1_allow_obsolete_multiline_headers_in_responses(
                self.http1_allow_obsolete_multiline_headers_in_responses,
            )
            .http1_max_headers(self.http1_max_headers)
            .http1_allow_spaces_after_header_name_in_responses(
                self.http1_allow_spaces_after_header_name_in_responses,
            )
            .http1_ignore_invalid_headers_in_responses(
                self.http1_ignore_invalid_headers_in_responses,
            )
            .pool_idle_timeout(self.pool_idle_timeout.map(|d| *d.inner()))
            .pool_max_idle_per_host(self.pool_max_idle_per_host)
            .tcp_keepalive(self.tcp_keepalive.map(|d| *d.inner()))
            .tcp_keepalive_interval(self.tcp_keepalive_interval.map(|d| *d.inner()))
            .tcp_keepalive_retries(self.tcp_keepalive_retries)
            .tcp_nodelay(self.tcp_nodelay)
            .tls_sni(self.tls_sni)
            .tls_info(self.tls_info)
            .tls_danger_accept_invalid_certs(self.tls_danger_accept_invalid_certs)
            .tls_danger_accept_invalid_hostnames(self.tls_danger_accept_invalid_hostnames);

        if let Some(user_agent) = &self.user_agent {
            client_builder = client_builder.user_agent(user_agent.clone());
        }
        if let Some(headers) = &self.headers {
            client_builder = client_builder.default_headers(headers.0.py_read().clone());
        }
        if let Some(timeout) = &self.timeout {
            client_builder = client_builder.timeout(timeout.into());
        }
        if let Some(read_timeout) = &self.read_timeout {
            client_builder = client_builder.read_timeout(read_timeout.into());
        }
        if let Some(connect_timeout) = &self.connect_timeout {
            client_builder = client_builder.connect_timeout(connect_timeout.into());
        }

        if let Some(resolve) = &self.resolve {
            for (domain, addrs) in &resolve.0 {
                client_builder = client_builder.resolve_to_addrs(domain, addrs);
            }
        }

        if let Some(proxy) = &self.proxy {
            client_builder = proxy.apply2client(client_builder);
        }

        // http1
        if self.http1_only {
            client_builder = client_builder.http1_only();
        }
        if self.http1_title_case_headers {
            client_builder = client_builder.http1_title_case_headers();
        }

        // http2
        client_builder = self.apply_http2_opts(client_builder);
        // apply_tls
        client_builder = self.apply_tls_opts(client_builder);
        client_builder
    }

    pub(crate) fn as_pydict<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyDict>> {
        let dict = PyDict::new(py);
        macro_rules! set_item {
            ($key:expr, $value:expr) => {
                dict.set_item(pyo3::intern!(py, $key), $value)?
            };
        }
        macro_rules! set_items {
            ($( $key:expr => $value:expr),* ) => {
                $(
                    set_item!($key, $value);
                )*
            };
        }
        let resolve = self.resolve.into_pyobject(py)?;

        set_items! {
            "headers" => self.headers.clone(),
            "cookies" => self.cookies,
            "user_agent" => self.user_agent.clone(),
            "timeout" => self.timeout,
            "read_timeout" => self.read_timeout,
            "connect_timeout" => self.connect_timeout,
            "connection_verbose" => self.connection_verbose,
            "redirect" => self.redirect,
            "resolve" => resolve,
            "referer" => self.referer,
            "gzip" => self.gzip,
            "brotli" => self.brotli,
            "deflate" => self.deflate,
            "zstd" => self.zstd,
            "hickory_dns" => self.hickory_dns,
            "http1_only" => self.http1_only,
            "https_only" => self.https_only,
            // -- http1 --
            "http1_title_case_headers" => self.http1_title_case_headers,
            "http1_max_headers" => self.http1_max_headers,
            "http1_allow_obsolete_multiline_headers_in_responses" => self.http1_allow_obsolete_multiline_headers_in_responses,
            "http1_allow_spaces_after_header_name_in_responses" => self.http1_allow_spaces_after_header_name_in_responses,
            "http1_ignore_invalid_headers_in_responses" => self.http1_ignore_invalid_headers_in_responses,
            // -- http2 --
            "http2_prior_knowledge" => self.http2_prior_knowledge,
            "http2_initial_stream_window_size" => self.http2_initial_stream_window_size,
            "http2_initial_connection_window_size" => self.http2_initial_connection_window_size,
            "http2_adaptive_window" => self.http2_adaptive_window,
            "http2_max_frame_size" => self.http2_max_frame_size,
            "http2_max_header_list_size" => self.http2_max_header_list_size,
            "http2_keep_alive_interval" => self.http2_keep_alive_interval,
            "http2_keep_alive_timeout" => self.http2_keep_alive_timeout,
            "http2_keep_alive_while_idle" => self.http2_keep_alive_while_idle,
            // -- pool --
            "pool_idle_timeout" => self.pool_idle_timeout,
            "pool_max_idle_per_host" => self.pool_max_idle_per_host,
            // -- tcp --
            "tcp_keepalive" => self.tcp_keepalive,
            "tcp_keepalive_interval" => self.tcp_keepalive_interval,
            "tcp_keepalive_retries" => self.tcp_keepalive_retries,
            "tcp_nodelay" => self.tcp_nodelay,
            // -- tls --
            "identity" => self.identity.clone(),
            "tls_crls_only" => self.tls_crls_only.clone(),
            "tls_certs_merge" => self.tls_certs_merge.clone(),
            "tls_certs_only" => self.tls_certs_only.clone(),
            "tls_info" => self.tls_info,
            "tls_sni" => self.tls_sni,
            "tls_version_max" => self.tls_version_max,
            "tls_version_min" => self.tls_version_min,
            "tls_danger_accept_invalid_certs" => self.tls_danger_accept_invalid_certs,
            "tls_danger_accept_invalid_hostnames" => self.tls_danger_accept_invalid_hostnames,
            "proxy" => &self.proxy
        }
        // unstable
        #[expect(clippy::used_underscore_binding)]
        {
            set_item!("_tls_cached_native_certs", self._tls_cached_native_certs);
        }

        Ok(dict)
    }

    #[inline]
    pub(crate) fn client_builder(&self) -> reqwest::ClientBuilder {
        let client_builder = reqwest::Client::builder();
        self.apply(client_builder)
    }
}

impl<'py> IntoPyObject<'py> for &ClientConfig {
    type Target = PyDict;
    type Output = Bound<'py, Self::Target>;
    type Error = PyErr;

    fn into_pyobject(self, py: Python<'py>) -> Result<Self::Output, Self::Error> {
        self.as_pydict(py)
    }
}
// ============================================================================
// RESOLVE EXTRACT
// ============================================================================
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
struct PySocketAddrLike(std::net::SocketAddr);

impl<'py> FromPyObject<'_, 'py> for PySocketAddrLike {
    type Error = PyErr;
    fn extract(obj: Borrowed<'_, 'py, PyAny>) -> PyResult<Self> {
        if let Ok(addr) = obj.cast_exact::<ryo3_std::net::RySocketAddr>() {
            Ok(Self(addr.get().into()))
        } else if let Ok(addr_str) = obj.cast_exact::<ryo3_std::net::RySocketAddrV4>() {
            Ok(Self(addr_str.get().into()))
        } else if let Ok(addr_str) = obj.cast_exact::<ryo3_std::net::RySocketAddrV6>() {
            Ok(Self(addr_str.get().into()))
        } else if let Ok(s) = obj.extract::<pyo3::pybacked::PyBackedStr>() {
            let addr: std::net::SocketAddr = s
                .parse()
                .map_err(|err| py_value_error!("failed to parse socket addr '{s}': {err}"))?;
            Ok(Self(addr))
        } else {
            py_type_err!("expected SocketAddr, SocketAddrV4, SocketAddrV6, or str")
        }
    }
}

pub(crate) enum PyResolveMapValue {
    Single(std::net::SocketAddr),
    Multiple(Vec<std::net::SocketAddr>),
}

impl<'py> FromPyObject<'_, 'py> for PyResolveMapValue {
    type Error = PyErr;
    fn extract(obj: Borrowed<'_, 'py, PyAny>) -> PyResult<Self> {
        if let Ok(addr) = obj.extract::<PySocketAddrLike>() {
            Ok(Self::Single(addr.0))
        } else if let Ok(addr_list) = obj.extract::<Vec<PySocketAddrLike>>() {
            let mut addrs = addr_list.into_iter().map(|a| a.0).collect::<Vec<_>>();
            addrs.sort_unstable();
            addrs.dedup();

            Ok(Self::Multiple(addrs))
        } else if let Ok(addr_list) = obj.extract::<std::collections::HashSet<PySocketAddrLike>>() {
            let addrs = addr_list.into_iter().map(|a| a.0).collect();
            Ok(Self::Multiple(addrs))
        } else {
            py_type_err!("expected SocketAddr, SocketAddrV4, SocketAddrV6, str, or list of these")
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct PyResolveMap(Vec<(String, Vec<std::net::SocketAddr>)>);

impl<'py> FromPyObject<'_, 'py> for PyResolveMap {
    type Error = PyErr;
    fn extract(obj: Borrowed<'_, 'py, PyAny>) -> PyResult<Self> {
        let dict = obj.cast_exact::<PyDict>()?;
        let mut map: std::collections::HashMap<String, Vec<std::net::SocketAddr>> =
            std::collections::HashMap::new();
        for (key, value) in dict.iter() {
            let key_str = key.extract::<pyo3::pybacked::PyBackedStr>()?.to_string();
            let resolve_value = value.extract::<PyResolveMapValue>()?;
            match resolve_value {
                PyResolveMapValue::Single(addr) => {
                    map.entry(key_str).or_default().push(addr);
                }
                PyResolveMapValue::Multiple(addrs) => {
                    map.entry(key_str).or_default().extend(addrs);
                }
            }
        }
        let vecify = map
            .into_iter()
            .filter(
                |(_domain, addrs)| !addrs.is_empty(), // filter out empty addr lists
            )
            .collect::<Vec<(String, Vec<std::net::SocketAddr>)>>();
        Ok(Self(vecify))
    }
}

impl<'py> IntoPyObject<'py> for &PyResolveMap {
    type Target = PyDict;
    type Output = Bound<'py, PyDict>;
    type Error = PyErr;

    fn into_pyobject(self, py: Python<'py>) -> Result<Self::Output, Self::Error> {
        let dict = PyDict::new(py);
        for (key, addrs) in &self.0 {
            // map 2 RySocketAddr,
            let py_sock_addrs = addrs
                .iter()
                .map(ryo3_std::net::RySocketAddr::from)
                .collect::<Vec<_>>();
            dict.set_item(key, py_sock_addrs)?;
        }
        Ok(dict)
    }
}
