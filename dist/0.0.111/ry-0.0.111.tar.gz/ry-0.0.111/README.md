# ry

[![PyPI](https://img.shields.io/pypi/v/ry?style=flat-square&cacheSeconds=600)](https://pypi.org/project/ry/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/ry?style=flat-square&cacheSeconds=600)](https://pypi.org/project/ry/)
[![PyPI - Wheel](https://img.shields.io/pypi/wheel/ry?style=flat-square&cacheSeconds=600)](https://pypi.org/project/ry/)
[![PyPI - Downloads](https://img.shields.io/pypi/dm/ry?style=flat-square&cacheSeconds=600)](https://pypistats.org/packages/ry)
[![PyPI - Status](https://img.shields.io/pypi/status/ry?style=flat-square&cacheSeconds=600)](https://pypi.org/project/ry/)
[![PyPI - License](https://img.shields.io/pypi/l/ry?style=flat-square&cacheSeconds=600)](https://pypi.org/project/ry/)

python bindings for rust crates ~ `ry == rust | python`

**DOCS:** [ryo3.dev](https://ryo3.dev) (WIP)

**API:** [ryo3.dev/api](https://ryo3.dev/api)

**This is a work in progress ~ feedback and PRs are welcome.**

## What it do!?

- **Async/Blocking http-clients:** Built on `reqwest`, with a `fetch`-like API.
  Supports streaming, zero-copy IO (via the buffer protocol), timeouts,
  redirect-following, and native JSON (de)serialization.
- **`WebSocket` client:** Built on `tokio-websockets` and styled after
  jawascript's `WebSocket` API.
- **`jiff` based datetime library:** comprehensive datetime library based on
  `jiff` (pydantic-compatible).
- **Async file I/O:** `AsyncFile` API similar to `aiofiles` and `anyio`'s
  async-file api.
- **(de)compression:** (de)compression support for `zstd`, `brotli`, and `gzip`.
- **hashing:** `aws-lc-rs`, `fnv`, and `twox-hash` (aka `xxhash`)
- **Ergonomic:** APIs designed to be ergonomic and pythonic and familiar to both
  python and rust users.
- **Type Annotated:** All public APIs are (painstakingly) type annotated and
  checked.
- **Performant:** Speed without the words "blazingly fast." [^1]
- **Pydantic Integration:** ry data types (mostly) work good w/ pydantic.
- **Not slop:** Artisanal, hand-crafted, grassfed, fair-trade, small-batch
  software.
- **No emojis**
- **MANY crate bindings** see below.

## Install

```bash
pip install ry
uv add ry
uv pip install ry

# check install
python -m ry
# run & check install w/ uv
uv run --with ry python -m ry
```

## Quickstart

Bop around the
[./examples](https://github.com/jessekrubin/ry/tree/main/examples) to see some
of what `ry` can do.

Or to play with ry in a repl, run the following:

```bash
# repl w/ ipython
uv run --with ry,ipython python -m ry.dev
# repl w/o ipython
uv run --with ry python -m ry.dev
```

---

## What?

- `ry` -- the python package
- `ryo3-*` -- the rust crates that are used by `ry` and possibly your own
  `pyo3`-based python package

## Who?

- jessekrubin <jessekrubin@gmail.com>
- possibly you!?

## FAQ

_(aka: questions that I have been asking myself)_

- **Q:** Why?
  - **A:** I (jesse) needed several hashing functions for python and then kept
    adding things as I needed them.
- **Q:** Does this have anything to do with the (excellent) package manager
  `rye`?
  - **A:** short answer: no. long answer: no, it does not.
- **Q:** Why is the repo split into `ry` and `ryo3`?
  - **A:** `ry` is the python package. `ry.ryo3` is the compiled extension that
    registers all the apis from the `ryo3-*` crates. the `ryo3-*` crates are
    designed to be usable outside of `ry` (that is how i use them).

## Crate bindings

| **crate**          | **ryo3-crate**                                                                                      |
| ------------------ | --------------------------------------------------------------------------------------------------- |
| `std`              | [`ryo3-std`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-std)                           |
| `bytes`            | [`ryo3-bytes`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-bytes)                       |
| `dirs`             | [`ryo3-dirs`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-dirs)                         |
| `fspath`           | [`ryo3-fspath`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-fspath)                     |
| `glob`             | [`ryo3-glob`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-glob)                         |
| `heck`             | [`ryo3-heck`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-heck)                         |
| `http`             | [`ryo3-http`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-http)                         |
| `jiter`            | [`ryo3-jiter`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-jiter)                       |
| `json`             | [`ryo3-json`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-json)                         |
| `pydantic`         | [`ryo3-pydantic`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-pydantic)                 |
| `reqwest`          | [`ryo3-reqwest`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-reqwest)                   |
| `serde`            | [`ryo3-serde`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-serde)                       |
| `shlex`            | [`ryo3-shlex`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-shlex)                       |
| `size`             | [`ryo3-size`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-size)                         |
| `sqlformat`        | [`ryo3-sqlformat`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-sqlformat)               |
| `tokio`            | [`ryo3-tokio`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-tokio)                       |
| `tokio-websockets` | [`ryo3-tokio-websockets`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-tokio-websockets) |
| `ulid`             | [`ryo3-ulid`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-ulid)                         |
| `unindent`         | [`ryo3-unindent`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-unindent)                 |
| `url`              | [`ryo3-url`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-url)                           |
| `uuid`             | [`ryo3-uuid`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-uuid)                         |
| `which`            | [`ryo3-which`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-which)                       |
| **Compression**    | **~**                                                                                               |
| `brotli`           | [`ryo3-brotli`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-brotli)                     |
| `burli-encode`     | [`ryo3-burli`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-burli)                       |
| `flate2`           | [`ryo3-flate2`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-flate2)                     |
| `lz4rip`           | [`ryo3-lz4rip`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-lz4rip)                     |
| `zstd`             | [`ryo3-zstd`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-zstd)                         |
| **Hashing**        | **~**                                                                                               |
| `aws-lc-rs`        | [`ryo3-aws-lc`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-aws-lc)                     |
| `crc32fast`        | [`ryo3-crc32fast`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-crc32fast)               |
| `fnv`              | [`ryo3-fnv`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-fnv)                           |
| `twox-hash`        | [`ryo3-twox-hash`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-twox-hash)               |
| **@BurntSushi**    | **~**                                                                                               |
| `globset`          | [`ryo3-globset`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-globset)                   |
| `jiff`             | [`ryo3-jiff`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-jiff)                         |
| `memchr`           | [`ryo3-memchr`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-memchr)                     |
| `regex`            | [`ryo3-regex`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-regex)                       |
| `same-file`        | [`ryo3-same-file`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-same-file)               |
| `walkdir`          | [`ryo3-walkdir`](https://github.com/jessekrubin/ry/tree/main/crates/ryo3-walkdir)                   |

---

## DEV

- `just` is used to run tasks
- Do not use the phrase `blazing fast` or any emojis in any PRs or issues or
  docs
- type annotations are required
- `ruff` used for formatting and linting

---

## SEE ALSO

- [utiles](https://github.com/jessekrubin/utiles): web-map tile utils

[^1]:
    Release-version benchmarks of `ry` (via `pytest-benchmark`) showed no real
    performance variance, regardless of whether "blazingly fast" appeared in the
    README or docs.
