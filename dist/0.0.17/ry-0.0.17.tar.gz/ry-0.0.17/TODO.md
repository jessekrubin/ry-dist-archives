# TODO

- [ ] jiff until methods
- [ ] jiff offset object testing

___

## DONE

- [x] python `datetime.timedelta` conversions for `ryo3-jiff`
- [x] cleanup naming in pydatetime conversions for ryo3-jiff
