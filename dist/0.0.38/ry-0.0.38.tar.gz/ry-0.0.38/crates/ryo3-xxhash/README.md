# `ryo3-xxhash`

ryo3-wrapper for `xxhash` crate

[//]: # (<GENERATED>)

## Ref:

- docs.rs: [https://docs.rs/xxhash](https://docs.rs/xxhash)
- crates: [https://crates.io/crates/xxhash](https://crates.io/crates/xxhash)

[//]: # (</GENERATED>)
