"""ry + pydantic"""
