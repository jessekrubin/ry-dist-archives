# `ryo3-http`

**NOT IMPLEMENTED (YET)**

Wrapper around the `http` crate for Python.

REF:
- [crates.io](https://crates.io/crates/http)
- [docs.rs](https://docs.rs/http)
