# `ryo3-types`

Shared types and extractors for `ryo3-*` crates.
