# `ryo3-macros`

internal macros


