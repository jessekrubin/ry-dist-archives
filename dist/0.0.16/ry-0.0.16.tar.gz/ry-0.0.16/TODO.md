# TODO

- [ ] jiff until methods

___

## DONE

- [x] python `datetime.timedelta` conversions for `ryo3-jiff`
- [x] cleanup naming in pydatetime conversions for ryo3-jiff
