use std::time::{Duration, Instant};

use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;

use super::{PyDuration, PyInstant};

#[pyfunction]
pub fn sleep(py: Python<'_>, secs: f64) -> PyResult<f64> {
    if secs < 0.0 {
        Err(PyValueError::new_err("sleep ~ secs must be >= 0."))
    } else {
        let returned = secs;
        let py_duration = PyDuration::try_from_secs_f64(secs)?;
        py_duration.sleep(py, 10)?;
        Ok(returned)
    }
}

#[must_use]
#[pyfunction]
#[pyo3(name = "instant")]
pub fn py_instant() -> PyInstant {
    PyInstant::from(Instant::now())
}

#[must_use]
#[pyfunction]
#[pyo3(name = "duration", signature = (secs = 0, nanos = 0))]
pub fn py_duration(secs: u64, nanos: u32) -> PyDuration {
    PyDuration::from(Duration::new(secs, nanos))
}
