# `ryo3-regex`

**NOT YET IMPLEMENTED**

Wrapper around the `regex` crate for Python.
