use std::io;

use pyo3::prelude::*;
use pyo3::types::PyString;
use ryo3_bytes::{PyBytes as RyBytes, ReadableBuffer};
use ryo3_core::{py_type_err, py_value_error};
use serde_json::{Deserializer, Serializer};

fn minify_json<R: io::Read, W: io::Write>(input: R, output: W) -> Result<(), serde_json::Error> {
    let mut de = Deserializer::from_reader(input);
    let mut ser = Serializer::new(output);
    serde_transcode::transcode(&mut de, &mut ser)
}

fn py_minify_json<R: io::Read, W: io::Write>(input: R, output: W) -> PyResult<()> {
    minify_json(input, output).map_err(|e| py_value_error!("Failed to minify JSON: {e}"))
}

#[pyfunction(signature = (buf, /))]
pub(crate) fn minify<'py>(buf: &'py Bound<'py, PyAny>) -> PyResult<RyBytes> {
    if let Ok(s) = buf.cast::<PyString>() {
        // py-string
        let json_str = s.to_string();
        let json_bytes = json_str.as_bytes();
        let mut output = Vec::with_capacity(json_bytes.len() / 8);
        py_minify_json(json_bytes, &mut output)?;
        Ok(RyBytes::from(output))
    } else if let Ok(pybytes) = buf.extract::<ReadableBuffer>() {
        let json_bytes = pybytes.as_ref();
        let mut output = Vec::with_capacity(json_bytes.len() / 8);
        py_minify_json(json_bytes, &mut output)?;
        Ok(RyBytes::from(output))
    } else {
        py_type_err!("Expected bytes-like object, str or buffer-protocol object")
    }
}

fn indent2_json<R: io::Read, W: io::Write>(input: R, output: W) -> Result<(), serde_json::Error> {
    let mut de = Deserializer::from_reader(input);
    let mut ser = Serializer::pretty(output);
    serde_transcode::transcode(&mut de, &mut ser)
}

fn py_indent2_json<R: io::Read, W: io::Write>(input: R, output: W) -> PyResult<()> {
    indent2_json(input, output).map_err(|e| py_value_error!("Failed to format JSON: {e}"))
}

#[pyfunction(signature = (buf, /))]
pub(crate) fn fmt<'py>(buf: &'py Bound<'py, PyAny>) -> PyResult<RyBytes> {
    if let Ok(s) = buf.cast::<PyString>() {
        // py-string
        let json_str = s.to_string();
        let json_bytes = json_str.as_bytes();
        let mut output = Vec::with_capacity(json_bytes.len());
        py_indent2_json(json_bytes, &mut output)?;
        Ok(RyBytes::from(output))
    } else if let Ok(pybytes) = buf.extract::<ReadableBuffer>() {
        let json_bytes = pybytes.as_ref();
        let mut output = Vec::with_capacity(json_bytes.len());
        py_indent2_json(json_bytes, &mut output)?;
        Ok(RyBytes::from(output))
    } else {
        py_type_err!("Expected bytes-like object, str or buffer-protocol object")
    }
}
