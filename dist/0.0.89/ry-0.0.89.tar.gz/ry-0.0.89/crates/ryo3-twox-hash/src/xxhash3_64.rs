use std::hash::Hasher;

use pyo3::intern;
use pyo3::prelude::*;
use pyo3::types::PyString;
use ryo3_bytes::ReadableBuffer;
use ryo3_core::types::{PyDigest, PyHexDigest};
use ryo3_core::{PyAsciiString, RyMutex};
use twox_hash::XxHash3_64;

use crate::xxhash3_secret::{PyXxHash3Secret, XXH3_SECRET_EXPECT_MSG};

const HASHLIB_GIL_MINSIZE: usize = 2048;

#[pyclass(name = "xxh3_64", frozen, immutable_type, skip_from_py_object)]
#[cfg_attr(feature = "ry", pyo3(module = "ry.ryo3.xxhash"))]
pub struct PyXxHash3_64 {
    seed: u64,
    hasher: RyMutex<XxHash3_64, true>,
}

#[inline]
fn oneshot_impl(data: &[u8], seed: u64, secret: Option<PyXxHash3Secret>) -> u64 {
    if let Some(secret) = secret {
        twox_hash::XxHash3_64::oneshot_with_seed_and_secret(seed, secret.as_ref(), data)
            .expect(XXH3_SECRET_EXPECT_MSG)
    } else {
        twox_hash::XxHash3_64::oneshot_with_seed(seed, data)
    }
}

#[pymethods]
impl PyXxHash3_64 {
    #[new]
    #[pyo3(signature = (data = None, *, seed = 0, secret = None))]
    fn py_new(data: Option<ReadableBuffer>, seed: u64, secret: Option<PyXxHash3Secret>) -> Self {
        let hasher = if let Some(s) = secret {
            XxHash3_64::with_seed_and_secret(seed, s).expect(XXH3_SECRET_EXPECT_MSG)
        } else {
            XxHash3_64::with_seed(seed)
        };
        match data {
            Some(s) => {
                let mut hasher = hasher;
                hasher.write(s.as_ref());
                Self {
                    seed,
                    hasher: hasher.into(),
                }
            }
            None => Self {
                seed,
                hasher: hasher.into(),
            },
        }
    }

    fn __repr__(&self) -> PyResult<PyAsciiString> {
        self.hasher
            .py_lock()
            .map(|hasher| format!("xxh3_64<{:x}>", hasher.finish()).into())
    }

    #[classattr]
    fn name(py: Python<'_>) -> &Bound<'_, PyString> {
        intern!(py, "xxh3_64")
    }

    #[classattr]
    fn digest_size() -> usize {
        8
    }

    #[classattr]
    fn block_size() -> usize {
        32
    }

    #[getter]
    fn seed(&self) -> u64 {
        self.seed
    }

    fn digest(&self) -> PyResult<PyDigest<u64>> {
        let digest = self.hasher.py_lock().map(|h| h.finish())?;
        Ok(PyDigest(digest))
    }

    fn intdigest(&self) -> PyResult<u64> {
        self.hasher.py_lock().map(|h| h.finish())
    }

    fn hexdigest(&self) -> PyResult<String> {
        let digest = self.intdigest()?;
        Ok(format!("{digest:016x}"))
    }

    #[expect(clippy::needless_pass_by_value)]
    fn update(&self, py: Python<'_>, data: ReadableBuffer) -> PyResult<()> {
        let slice = data.as_slice();
        if slice.len() > HASHLIB_GIL_MINSIZE {
            py.detach(|| {
                let mut hasher = self.hasher.py_lock()?;
                hasher.write(slice);
                Ok(())
            })
        } else {
            let mut hasher = self.hasher.py_lock()?;
            hasher.write(slice);
            Ok(())
        }
    }

    fn copy(&self) -> PyResult<Self> {
        let hasher = self.hasher.py_lock()?;
        Ok(Self {
            hasher: hasher.clone().into(),
            seed: self.seed,
        })
    }

    #[pyo3(signature = (*, seed = None))]
    fn reset(&self, seed: Option<u64>) -> PyResult<()> {
        let mut h = self.hasher.py_lock()?;
        *h = XxHash3_64::with_seed(seed.unwrap_or(self.seed));
        Ok(())
    }

    #[expect(clippy::needless_pass_by_value)]
    #[staticmethod]
    #[pyo3(signature = (data, *, seed = 0, secret = None))]
    fn oneshot(
        py: Python<'_>,
        data: ReadableBuffer,
        seed: u64,
        secret: Option<PyXxHash3Secret>,
    ) -> PyDigest<u64> {
        let data = data.as_slice();
        if data.len() > HASHLIB_GIL_MINSIZE {
            py.detach(|| oneshot_impl(data, seed, secret).into())
        } else {
            oneshot_impl(data, seed, secret).into()
        }
    }
}

// ====================================================================================
// ONCE SHOT FUNCTIONS
// ====================================================================================

#[pyfunction]
#[pyo3(signature = (data, *, seed = 0, secret = None))]
pub fn xxh3_64_digest(
    py: Python<'_>,
    data: ReadableBuffer,
    seed: u64,
    secret: Option<PyXxHash3Secret>,
) -> PyDigest<u64> {
    PyXxHash3_64::oneshot(py, data, seed, secret)
}

#[pyfunction]
#[pyo3(signature = (data, *, seed = 0, secret = None))]
pub fn xxh3_64_intdigest(
    py: Python<'_>,
    data: ReadableBuffer,
    seed: u64,
    secret: Option<PyXxHash3Secret>,
) -> u64 {
    PyXxHash3_64::oneshot(py, data, seed, secret).0
}

#[pyfunction]
#[pyo3(signature = (data, *, seed = 0, secret = None))]
pub fn xxh3_64_hexdigest(
    py: Python<'_>,
    data: ReadableBuffer,
    seed: u64,
    secret: Option<PyXxHash3Secret>,
) -> PyHexDigest<u64> {
    PyXxHash3_64::oneshot(py, data, seed, secret).0.into()
}

pub fn pymod_add(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PyXxHash3_64>()?;
    m.add_function(wrap_pyfunction!(xxh3_64_digest, m)?)?;
    m.add_function(wrap_pyfunction!(xxh3_64_hexdigest, m)?)?;
    m.add_function(wrap_pyfunction!(xxh3_64_intdigest, m)?)?;
    Ok(())
}
