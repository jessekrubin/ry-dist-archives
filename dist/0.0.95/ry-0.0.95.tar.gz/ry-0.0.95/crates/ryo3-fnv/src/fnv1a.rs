//! python fnv1a implementation
//!
//! Formerly used the `fnv` crate but it is such a simple crate re-implementing
//! the core logic outweighs pulling in another dep.
use std::hash::Hasher;

use pyo3::prelude::*;
use pyo3::types::{PyString, PyTuple};
use pyo3::{IntoPyObjectExt, intern};
use ryo3_bytes::ReadableBuffer;
use ryo3_core::sync::RyMutex;
use ryo3_core::types::{PyDigest, PyHexDigest};
use ryo3_core::{PyAsciiString, py_type_err};

const FNV1A_64_OFFSET: u64 = 0xcbf2_9ce4_8422_2325;
const FNV1A_64_PRIME: u64 = 0x0100_0000_01b3;
const HASHLIB_GIL_MINSIZE: usize = 2048;

// ============================================================================
// adapted from the `fnv` crate
// ============================================================================
#[derive(Clone, Copy, PartialEq, Eq)]
pub struct Fnv1aHasher(u64);

impl Default for Fnv1aHasher {
    #[inline]
    fn default() -> Self {
        Self(FNV1A_64_OFFSET)
    }
}

impl Fnv1aHasher {
    /// Create an FNV hasher starting with a state corresponding
    /// to the hash `seed`.
    #[inline]
    pub fn with_seed(seed: u64) -> Self {
        Self(seed)
    }
}

impl Hasher for Fnv1aHasher {
    #[inline]
    fn finish(&self) -> u64 {
        self.0
    }

    #[inline]
    fn write(&mut self, bytes: &[u8]) {
        let hash = bytes.iter().fold(self.0, |hash, &byte| {
            let hash = hash ^ u64::from(byte);
            hash.wrapping_mul(FNV1A_64_PRIME)
        });
        *self = Self(hash);
    }
}

// ============================================================================
// ~ PY ~ PY ~ PY ~ PY ~ PY ~ PY ~ PY ~ PY ~ PY ~ PY ~ PY ~ PY ~ PY ~ PY ~ PY ~
// ============================================================================

#[pyclass(name = "fnv1a", frozen, immutable_type, skip_from_py_object)]
#[cfg_attr(feature = "ry", pyo3(module = "ry.ryo3"))]
pub struct PyFnv1a(RyMutex<Fnv1aHasher>);

impl PyFnv1a {
    fn lock(&self) -> PyResult<std::sync::MutexGuard<'_, Fnv1aHasher>> {
        self.0.py_lock()
    }

    fn finish(&self) -> PyResult<u64> {
        self.0.py_lock().map(|h| h.finish())
    }
}

impl From<Fnv1aHasher> for PyFnv1a {
    fn from(hasher: Fnv1aHasher) -> Self {
        Self(RyMutex::new(hasher))
    }
}

impl From<u64> for PyFnv1a {
    fn from(seed: u64) -> Self {
        Self(RyMutex::new(Fnv1aHasher::with_seed(seed)))
    }
}

#[inline]
fn fnv1a_oneshot(bytes: &[u8], seed: u64) -> u64 {
    bytes.iter().fold(seed, |hash, &byte| {
        let hash = hash ^ u64::from(byte);
        hash.wrapping_mul(FNV1A_64_PRIME)
    })
}

#[pymethods]
impl PyFnv1a {
    #[new]
    #[pyo3(
        signature = (data = None, *, seed = Fnv1aSeed::default()),
        text_signature = "(data=None, *, seed=0xcbf29ce484222325)",
    )]
    fn py_new(py: Python<'_>, data: Option<ReadableBuffer>, seed: Fnv1aSeed) -> Self {
        if let Some(b) = data {
            let b = b.as_ref();
            if b.len() > HASHLIB_GIL_MINSIZE {
                py.detach(|| Self::from(fnv1a_oneshot(b, seed.into())))
            } else {
                Self::from(fnv1a_oneshot(b, seed.into()))
            }
        } else {
            Self::from(Fnv1aHasher::from(seed))
        }
    }

    #[classattr]
    fn digest_size() -> usize {
        8
    }

    #[classattr]
    fn block_size() -> usize {
        // well fnv ain't blocky and just does a byte at a time
        // so i guess it's just 1?
        1
    }

    #[classattr]
    fn name(py: Python<'_>) -> &Bound<'_, PyString> {
        intern!(py, "fnv1a")
    }

    #[classattr]
    fn default_seed() -> u64 {
        Fnv1aSeed::default().into()
    }

    fn __getnewargs_ex__<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyTuple>> {
        let args = PyTuple::new(py, [py.None().into_bound_py_any(py)?])?;
        let kw = pyo3::types::PyDict::new(py);
        let seed = self.finish()?;
        kw.set_item(pyo3::intern!(py, "seed"), seed)?;
        PyTuple::new(py, [args.into_bound_py_any(py)?, kw.into_bound_py_any(py)?])
    }

    fn __repr__(&self) -> PyAsciiString {
        format!("{self}").into()
    }

    fn intdigest(&self) -> PyResult<u64> {
        self.finish()
    }

    fn digest(&self) -> PyResult<PyDigest<u64>> {
        self.finish().map(PyDigest::from)
    }

    fn hexdigest(&self) -> PyResult<PyHexDigest<u64>> {
        self.finish().map(PyHexDigest::from)
    }

    #[expect(clippy::needless_pass_by_value)]
    fn update(&self, py: Python<'_>, data: ReadableBuffer) -> PyResult<()> {
        let slice = data.as_ref();
        if slice.len() > HASHLIB_GIL_MINSIZE {
            py.detach(|| {
                let mut h = self.lock()?;
                h.write(slice);
                Ok(())
            })
        } else {
            let mut h = self.lock()?;
            h.write(slice);
            Ok(())
        }
    }

    fn copy(&self) -> PyResult<Self> {
        self.finish().map(Self::from)
    }

    #[expect(clippy::needless_pass_by_value)]
    #[pyo3(
        signature = (data, *, seed = Fnv1aSeed::default()),
        text_signature = "(data, *, seed=0xcbf29ce484222325)",
    )]
    #[staticmethod]
    fn oneshot(data: ReadableBuffer, seed: Fnv1aSeed) -> PyDigest<u64> {
        fnv1a_oneshot(data.as_ref(), seed.into()).into()
    }

    #[expect(clippy::needless_pass_by_value)]
    #[pyo3(
        signature = (data, *, seed = Fnv1aSeed::default()),
        text_signature = "(data, *, seed=0xcbf29ce484222325)",
    )]
    #[staticmethod]
    fn oneshot_int(data: ReadableBuffer, seed: Fnv1aSeed) -> u64 {
        fnv1a_oneshot(data.as_ref(), seed.into())
    }

    #[expect(clippy::needless_pass_by_value)]
    #[pyo3(
        signature = (data, *, seed = Fnv1aSeed::default()),
        text_signature = "(data, *, seed=0xcbf29ce484222325)",
    )]
    #[staticmethod]
    fn oneshot_hex(data: ReadableBuffer, seed: Fnv1aSeed) -> PyHexDigest<u64> {
        fnv1a_oneshot(data.as_ref(), seed.into()).into()
    }
}

impl std::fmt::Display for PyFnv1a {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let seed = self.finish().expect("no-way-jose");
        write!(f, "fnv1a<{seed:x}>")
    }
}

#[derive(Debug, Clone, Copy)]
pub struct Fnv1aSeed(u64);

impl Default for Fnv1aSeed {
    fn default() -> Self {
        Self(FNV1A_64_OFFSET)
    }
}

impl<'a, 'py> FromPyObject<'a, 'py> for Fnv1aSeed {
    type Error = PyErr;

    fn extract(obj: Borrowed<'a, 'py, PyAny>) -> Result<Self, Self::Error> {
        if let Ok(n) = obj.extract::<u64>() {
            Ok(Self(n))
        } else if let Ok(b) = obj.extract::<[u8; 8]>() {
            let seed = u64::from_be_bytes(b);
            Ok(Self(seed))
        } else {
            py_type_err!("Seed must be an integer or 8-byte bytes-like object")
        }
    }
}

impl From<Fnv1aSeed> for u64 {
    fn from(seed: Fnv1aSeed) -> Self {
        seed.0
    }
}

impl From<Fnv1aSeed> for Fnv1aHasher {
    fn from(seed: Fnv1aSeed) -> Self {
        Self::with_seed(seed.into())
    }
}
