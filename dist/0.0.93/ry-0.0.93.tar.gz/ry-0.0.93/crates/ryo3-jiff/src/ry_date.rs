use std::fmt::Display;
use std::hash::{DefaultHasher, Hash, Hasher};
use std::ops::Sub;

use jiff::Zoned;
use jiff::civil::{Date, Weekday};
use pyo3::prelude::*;
use pyo3::pyclass::CompareOp;
use pyo3::types::{PyDict, PyTuple};
use pyo3::{BoundObject, IntoPyObject, IntoPyObjectExt};
use ryo3_core::{PyAsciiString, map_py_overflow_err, map_py_value_err};
use ryo3_macro_rules::{any_repr, py_type_err, py_value_error};

use crate::difference::{DateDifferenceArg, RyDateDifference};
use crate::ry_datetime::RyDateTime;
use crate::ry_iso_week_date::RyISOWeekDate;
use crate::ry_signed_duration::RySignedDuration;
use crate::ry_span::RySpan;
use crate::ry_time::RyTime;
use crate::ry_timezone::RyTimeZone;
use crate::ry_zoned::RyZoned;
use crate::series::RyDateSeries;
use crate::spanish::Spanish;
use crate::util::SpanKwargs;
use crate::{JiffEra, JiffEraYear, JiffRoundMode, JiffUnit, JiffWeekday, RyTimestamp};

#[cfg_attr(feature = "serde", derive(serde::Serialize))]
#[cfg_attr(feature = "serde", serde(transparent))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd)]
#[pyclass(name = "Date", frozen, immutable_type, skip_from_py_object)]
#[cfg_attr(feature = "ry", pyo3(module = "ry.ryo3"))]
pub struct RyDate(pub(crate) Date);

#[expect(clippy::trivially_copy_pass_by_ref)]
#[pymethods]
impl RyDate {
    #[new]
    pub(crate) fn py_new(year: i16, month: i8, day: i8) -> PyResult<Self> {
        Date::new(year, month, day)
            .map(Self::from)
            .map_err(|e| py_value_error!("{e} (year={year}, month={month}, day={day})",))
    }

    #[classattr]
    fn __match_args__() -> (&'static str, &'static str, &'static str) {
        ("year", "month", "day")
    }

    #[classattr]
    #[expect(non_snake_case)]
    fn MIN() -> Self {
        Self(Date::MIN)
    }

    #[classattr]
    #[expect(non_snake_case)]
    fn MAX() -> Self {
        Self(Date::MAX)
    }

    #[classattr]
    #[expect(non_snake_case)]
    fn ZERO() -> Self {
        Self(Date::ZERO)
    }

    #[staticmethod]
    fn today() -> Self {
        Self::now()
    }

    #[staticmethod]
    fn now() -> Self {
        Self::from(Zoned::now().date())
    }

    #[pyo3(signature = (hour, minute, second, nanosecond = 0))]
    pub(crate) fn at(&self, hour: i8, minute: i8, second: i8, nanosecond: i32) -> RyDateTime {
        RyDateTime::from(self.0.at(hour, minute, second, nanosecond))
    }

    #[getter]
    fn year(&self) -> i16 {
        self.0.year()
    }

    #[getter]
    fn month(&self) -> i8 {
        self.0.month()
    }

    #[getter]
    fn day(&self) -> i8 {
        self.0.day()
    }

    fn __hash__(&self) -> u64 {
        let mut hasher = DefaultHasher::new();
        self.0.hash(&mut hasher);
        hasher.finish()
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_datetime(&self, time: &RyTime) -> RyDateTime {
        RyDateTime::from(self.0.to_datetime(time.0))
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_zoned(&self, tz: &RyTimeZone) -> PyResult<RyZoned> {
        self.0
            .to_zoned(tz.into())
            .map(RyZoned::from)
            .map_err(map_py_value_err)
    }

    fn __richcmp__(&self, other: &Self, op: CompareOp) -> bool {
        match op {
            CompareOp::Eq => self.0 == other.0,
            CompareOp::Ne => self.0 != other.0,
            CompareOp::Lt => self.0 < other.0,
            CompareOp::Le => self.0 <= other.0,
            CompareOp::Gt => self.0 > other.0,
            CompareOp::Ge => self.0 >= other.0,
        }
    }

    #[pyo3(name = "to_string")]
    fn py_to_string(&self) -> PyAsciiString {
        self.__str__()
    }

    fn __str__(&self) -> PyAsciiString {
        self.0.to_string().into()
    }

    fn __repr__(&self) -> PyAsciiString {
        format!("{self}").into()
    }

    fn __getnewargs__<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyTuple>> {
        PyTuple::new(
            py,
            vec![
                self.year().into_pyobject(py)?,
                self.month().into_pyobject(py)?,
                self.day().into_pyobject(py)?,
            ],
        )
    }

    fn __sub__<'py>(
        &self,
        py: Python<'py>,
        other: &Bound<'py, PyAny>,
    ) -> PyResult<Bound<'py, PyAny>> {
        if let Ok(ob) = other.cast_exact::<Self>() {
            let span = self.0.sub(ob.get().0);
            let obj = RySpan::from(span).into_pyobject(py).map(Bound::into_any)?;
            Ok(obj)
        } else {
            let spanish = other.extract::<Spanish>()?;
            let z = self.0.checked_sub(spanish).map_err(map_py_overflow_err)?;
            Self::from(z).into_bound_py_any(py)
        }
    }

    fn __add__(&self, other: Spanish) -> PyResult<Self> {
        self.0
            .checked_add(other)
            .map(Self::from)
            .map_err(map_py_overflow_err)
    }

    #[expect(clippy::too_many_arguments)]
    #[pyo3(
        signature = (
            other = None,
            /, *,
            years = 0,
            months = 0,
            weeks = 0,
            days = 0,
            hours = 0,
            minutes = 0,
            seconds = 0,
            milliseconds = 0,
            microseconds = 0,
            nanoseconds = 0
        )
    )]
    fn add(
        &self,
        other: Option<Spanish>,
        years: i64,
        months: i64,
        weeks: i64,
        days: i64,
        hours: i64,
        minutes: i64,
        seconds: i64,
        milliseconds: i64,
        microseconds: i64,
        nanoseconds: i64,
    ) -> PyResult<Self> {
        let spkw = SpanKwargs::new()
            .years(years)
            .months(months)
            .weeks(weeks)
            .days(days)
            .hours(hours)
            .minutes(minutes)
            .seconds(seconds)
            .milliseconds(milliseconds)
            .microseconds(microseconds)
            .nanoseconds(nanoseconds);

        match (other, !spkw.is_zero()) {
            (Some(o), false) => self.__add__(o),
            (None, true) => {
                let span = spkw.build()?;
                self.0
                    .checked_add(span)
                    .map(Self::from)
                    .map_err(map_py_overflow_err)
            }
            (Some(_), true) => {
                py_type_err!("add accepts either a span-like object or keyword units, not both")
            }
            (None, false) => Ok(*self),
        }
    }

    #[expect(clippy::too_many_arguments)]
    #[pyo3(
        signature = (
            other = None,
            /, *,
            years = 0,
            months = 0,
            weeks = 0,
            days = 0,
            hours = 0,
            minutes = 0,
            seconds = 0,
            milliseconds = 0,
            microseconds = 0,
            nanoseconds = 0
        )
    )]
    fn sub<'py>(
        &self,
        py: Python<'py>,
        other: Option<&Bound<'py, PyAny>>,
        years: i64,
        months: i64,
        weeks: i64,
        days: i64,
        hours: i64,
        minutes: i64,
        seconds: i64,
        milliseconds: i64,
        microseconds: i64,
        nanoseconds: i64,
    ) -> PyResult<Bound<'py, PyAny>> {
        let spkw = SpanKwargs::new()
            .years(years)
            .months(months)
            .weeks(weeks)
            .days(days)
            .hours(hours)
            .minutes(minutes)
            .seconds(seconds)
            .milliseconds(milliseconds)
            .microseconds(microseconds)
            .nanoseconds(nanoseconds);

        match (other, !spkw.is_zero()) {
            (Some(o), false) => self.__sub__(py, o),
            (None, true) => {
                let span = spkw.build()?;
                self.0
                    .checked_sub(span)
                    .map(Self::from)
                    .map_err(map_py_overflow_err)
                    .and_then(|dt| dt.into_pyobject(py).map(Bound::into_any))
            }
            (Some(_), true) => {
                py_type_err!("sub accepts either a span-like object or keyword units, not both")
            }
            (None, false) => Ok((*self).into_pyobject(py).map(Bound::into_any)?),
        }
    }

    fn saturating_add(&self, other: Spanish) -> Self {
        Self::from(self.0.saturating_add(other))
    }

    fn saturating_sub(&self, other: Spanish) -> Self {
        Self::from(self.0.saturating_sub(other))
    }

    #[pyo3(
        signature = (
            *,
            year = None,
            era_year = None,
            month = None,
            day = None,
            day_of_year = None,
            day_of_year_no_leap = None,
        )
    )]
    fn replace(
        &self,
        year: Option<i16>,
        era_year: Option<(i16, JiffEra)>,
        month: Option<i8>,
        day: Option<i8>,
        day_of_year: Option<i16>,
        day_of_year_no_leap: Option<i16>,
    ) -> PyResult<Self> {
        let mut builder = self.0.with();
        if let Some(y) = year {
            builder = builder.year(y);
        }
        if let Some(ey) = era_year {
            builder = builder.era_year(ey.0, (ey.1).0);
        }
        if let Some(m) = month {
            builder = builder.month(m);
        }
        if let Some(d) = day {
            builder = builder.day(d);
        }
        if let Some(doy) = day_of_year {
            builder = builder.day_of_year(doy);
        }
        if let Some(doy) = day_of_year_no_leap {
            builder = builder.day_of_year_no_leap(doy);
        }
        // finally build, mapping any error back to Python
        builder.build().map(Self::from).map_err(map_py_value_err)
    }

    #[staticmethod]
    fn from_pydate(date: Date) -> Self {
        Self(date)
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_py(&self) -> Date {
        self.to_pydate()
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_pydate(&self) -> Date {
        self.0
    }

    fn astuple<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyTuple>> {
        let year_any = self.0.year().into_pyobject(py)?.into_any();
        let month_any = self.0.month().into_pyobject(py)?.into_any();
        let day_any = self.0.day().into_pyobject(py)?.into_any();
        let parts = vec![year_any, month_any, day_any];
        PyTuple::new(py, parts)
    }

    fn in_tz(&self, tz: &str) -> PyResult<RyZoned> {
        self.0
            .in_tz(tz)
            .map(RyZoned::from)
            .map_err(map_py_value_err)
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_dict<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyDict>> {
        use crate::interns;
        let dict = PyDict::new(py);
        dict.set_item(interns::year(py), self.0.year())?;
        dict.set_item(interns::month(py), self.0.month())?;
        dict.set_item(interns::day(py), self.0.day())?;
        Ok(dict)
    }

    fn series(&self, period: &RySpan) -> PyResult<RyDateSeries> {
        (self, period).try_into()
    }

    fn day_of_year(&self) -> i16 {
        self.0.day_of_year()
    }

    fn day_of_year_no_leap(&self) -> Option<i16> {
        self.0.day_of_year_no_leap()
    }

    fn days_in_month(&self) -> i8 {
        self.0.days_in_month()
    }

    fn days_in_year(&self) -> i16 {
        self.0.days_in_year()
    }

    fn duration_since(&self, other: &Self) -> RySignedDuration {
        RySignedDuration::from(self.0.duration_since(other.0))
    }

    fn duration_until(&self, other: &Self) -> RySignedDuration {
        RySignedDuration::from(self.0.duration_until(other.0))
    }

    fn era_year(&self) -> JiffEraYear {
        JiffEraYear(self.0.era_year())
    }

    fn first_of_month(&self) -> Self {
        Self::from(self.0.first_of_month())
    }

    fn first_of_year(&self) -> Self {
        Self::from(self.0.first_of_year())
    }

    fn in_leap_year(&self) -> bool {
        self.0.in_leap_year()
    }

    fn last_of_month(&self) -> Self {
        Self::from(self.0.last_of_month())
    }

    fn last_of_year(&self) -> Self {
        Self::from(self.0.last_of_year())
    }

    fn tomorrow(&self) -> PyResult<Self> {
        self.0.tomorrow().map(From::from).map_err(map_py_value_err)
    }

    fn yesterday(&self) -> PyResult<Self> {
        self.0.yesterday().map(From::from).map_err(map_py_value_err)
    }

    // ========================================================================
    // STRPTIME/STRFTIME
    // ========================================================================
    fn __format__(&self, fmt: &str) -> PyResult<String> {
        if fmt.is_empty() {
            Ok(self.0.to_string())
        } else {
            self.strftime(fmt)
        }
    }

    #[pyo3(signature = (fmt))]
    fn strftime(&self, fmt: &str) -> PyResult<String> {
        let bdt: jiff::fmt::strtime::BrokenDownTime = self.0.into();
        bdt.to_string(fmt).map_err(map_py_value_err)
    }

    #[staticmethod]
    #[pyo3(signature = (s, /, fmt))]
    fn strptime(s: &str, fmt: &str) -> PyResult<Self> {
        Date::strptime(fmt, s)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    #[getter]
    fn weekday(&self) -> i8 {
        match self.0.weekday() {
            Weekday::Monday => 1,
            Weekday::Tuesday => 2,
            Weekday::Wednesday => 3,
            Weekday::Thursday => 4,
            Weekday::Friday => 5,
            Weekday::Saturday => 6,
            Weekday::Sunday => 7,
        }
    }

    #[pyo3(
        signature = (
            other,
            *,
            smallest = JiffUnit::DAY,
            largest = None,
            mode = JiffRoundMode::TRUNC,
            increment = 1
        ),
        text_signature = "(self, other, *, smallest=\"day\", largest=None, mode=\"trunc\", increment=1)"
    )]
    fn since(
        &self,
        other: DateDifferenceArg,
        smallest: JiffUnit,
        largest: Option<JiffUnit>,
        mode: JiffRoundMode,
        increment: i64,
    ) -> PyResult<RySpan> {
        let dt_diff = other.build(smallest, largest, mode, increment);
        self.0
            .since(dt_diff)
            .map(RySpan::from)
            .map_err(map_py_value_err)
    }

    #[pyo3(
        signature = (
            other,
            *,
            smallest = JiffUnit::DAY,
            largest = None,
            mode = JiffRoundMode::TRUNC,
            increment = 1
        ),
        text_signature = "(self, other, *, smallest=\"day\", largest=None, mode=\"trunc\", increment=1)"
    )]
    fn until(
        &self,
        other: DateDifferenceArg,
        smallest: JiffUnit,
        largest: Option<JiffUnit>,
        mode: JiffRoundMode,
        increment: i64,
    ) -> PyResult<RySpan> {
        let dt_diff = other.build(smallest, largest, mode, increment);
        self.0
            .until(dt_diff)
            .map(RySpan::from)
            .map_err(map_py_value_err)
    }

    fn _since(&self, other: &RyDateDifference) -> PyResult<RySpan> {
        self.0
            .since(other.diff)
            .map(RySpan::from)
            .map_err(map_py_value_err)
    }

    fn _until(&self, other: &RyDateDifference) -> PyResult<RySpan> {
        self.0
            .until(other.diff)
            .map(RySpan::from)
            .map_err(map_py_value_err)
    }

    #[staticmethod]
    fn from_iso_week_date(iso_week_date: &RyISOWeekDate) -> Self {
        Self::from(iso_week_date.0.date())
    }

    fn nth_weekday(&self, nth: i32, weekday: JiffWeekday) -> PyResult<Self> {
        self.0
            .nth_weekday(nth, weekday.0)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    fn nth_weekday_of_month(&self, nth: i8, weekday: JiffWeekday) -> PyResult<Self> {
        self.0
            .nth_weekday_of_month(nth, weekday.0)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    fn iso_week_date(&self) -> RyISOWeekDate {
        self.into()
    }

    #[staticmethod]
    fn from_any<'py>(value: &Bound<'py, PyAny>) -> PyResult<Bound<'py, Self>> {
        let py = value.py();
        if let Ok(val) = value.cast_exact::<Self>() {
            Ok(val.as_borrowed().into_bound())
        } else if let Ok(pystr) = value.cast::<pyo3::types::PyString>() {
            let s = pystr.to_cow()?;
            Self::from_str(&s).map(|dt| dt.into_pyobject(py))?
        } else if let Ok(pybytes) = value.cast::<pyo3::types::PyBytes>() {
            let s = String::from_utf8_lossy(pybytes.as_bytes());
            Self::from_str(&s).map(|dt| dt.into_pyobject(py))?
        } else if let Ok(d) = value.cast_exact::<RyZoned>() {
            Self::from(d.get()).into_pyobject(py)
        } else if let Ok(ts) = value.cast_exact::<RyTimestamp>() {
            Self::from(ts.get()).into_pyobject(py)
        } else if let Ok(d) = value.cast_exact::<RyDateTime>() {
            Self::from(d.get()).into_pyobject(py)
        } else if let Ok(d) = value.extract::<Date>() {
            Self::from(d).into_pyobject(py)
        } else {
            let valtype = any_repr!(value);
            py_type_err!("Date conversion error: {valtype}")
        }
    }

    /// Try to create a Date from a variety of python objects
    #[cfg(feature = "pydantic")]
    #[staticmethod]
    fn _pydantic_validate<'py>(value: &Bound<'py, PyAny>) -> PyResult<Bound<'py, Self>> {
        Self::from_any(value).map_err(map_py_value_err)
    }

    #[cfg(feature = "pydantic")]
    #[classmethod]
    fn __get_pydantic_core_schema__<'py>(
        cls: &Bound<'py, ::pyo3::types::PyType>,
        source: &Bound<'py, PyAny>,
        handler: &Bound<'py, PyAny>,
    ) -> PyResult<Bound<'py, PyAny>> {
        use ryo3_pydantic::GetPydanticCoreSchemaCls;
        Self::get_pydantic_core_schema(cls, source, handler)
    }

    // ========================================================================
    // STANDARD METHODS
    // ========================================================================
    // <STD-METHODS>
    #[staticmethod]
    fn from_str(s: &str) -> PyResult<Self> {
        use ryo3_core::PyFromStr;
        Self::py_from_str(s)
    }

    #[staticmethod]
    fn parse(s: &Bound<'_, PyAny>) -> PyResult<Self> {
        use ryo3_core::PyParse;
        Self::py_parse(s)
    }

    fn isoformat(&self) -> PyAsciiString {
        <Self as crate::isoformat::PyIsoFormat>::isoformat(self)
    }
    // </STD-METHODS>
}

impl Display for RyDate {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "Date(year={}, month={}, day={})",
            self.year(),
            self.month(),
            self.day()
        )
    }
}
