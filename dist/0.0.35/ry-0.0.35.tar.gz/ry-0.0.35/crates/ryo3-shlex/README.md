# `ryo3-shlex`

ryo3-wrapper for `shlex` crate

[//]: # (<GENERATED>)

## Ref:

- docs.rs: [https://docs.rs/shlex](https://docs.rs/shlex)
- crates: [https://crates.io/crates/shlex](https://crates.io/crates/shlex)

[//]: # (</GENERATED>)
