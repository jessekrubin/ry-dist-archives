//! python shim for `TimeZoneDatabase`
use std::sync::LazyLock;

use jiff::tz::TimeZoneDatabase;
use pyo3::prelude::*;
use ryo3_core::map_py_value_err;
use ryo3_macro_rules::{py_key_error, py_value_err};

use crate::RyTimeZone;
#[pyclass(name = "TimeZoneDatabase", frozen, immutable_type, skip_from_py_object)]
#[cfg_attr(feature = "ry", pyo3(module = "ry.ryo3"))]
#[derive(Debug, Clone)]
pub struct RyTimeZoneDatabase {
    pub(crate) inner: Option<TimeZoneDatabase>,
}

pub(crate) static BUNDLED_TZDB: LazyLock<TimeZoneDatabase> =
    LazyLock::new(TimeZoneDatabase::bundled);

pub(crate) fn bundled_tzdb() -> &'static TimeZoneDatabase {
    &BUNDLED_TZDB
}

impl RyTimeZoneDatabase {
    fn db(&self) -> &TimeZoneDatabase {
        if let Some(db) = &self.inner {
            db
        } else {
            jiff::tz::db()
        }
    }
}

#[pymethods]
impl RyTimeZoneDatabase {
    #[new]
    fn py_new() -> Self {
        Self::from(TimeZoneDatabase::from_env())
    }

    fn __repr__(&self) -> String {
        format!("{:?}", self.db())
    }

    #[pyo3(signature = (name, err = false))]
    fn get(&self, name: &str, err: bool) -> PyResult<Option<RyTimeZone>> {
        let tz_res = self.db().get(name).map(RyTimeZone::from);
        match tz_res {
            Ok(tz) => Ok(Some(tz)),
            Err(e) => {
                if err {
                    py_value_err!("{e}")
                } else {
                    Ok(None)
                }
            }
        }
    }

    fn available(&self) -> Vec<String> {
        self.db()
            .available()
            .map(|tz_name| tz_name.to_string())
            .collect()
    }

    fn __getitem__(&self, name: &str) -> PyResult<RyTimeZone> {
        self.db()
            .get(name)
            .map(RyTimeZone::from)
            .map_err(|e| py_key_error!("{e}"))
    }

    fn __len__(&self) -> usize {
        self.db().available().count()
    }

    fn is_definitively_empty(&self) -> bool {
        self.db().is_definitively_empty()
    }

    #[staticmethod]
    fn bundled() -> Self {
        Self::from(TimeZoneDatabase::bundled())
    }

    #[staticmethod]
    fn from_env() -> Self {
        Self::from(TimeZoneDatabase::from_env())
    }

    #[staticmethod]
    fn from_dir(path: &str) -> PyResult<Self> {
        TimeZoneDatabase::from_dir(path)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    #[staticmethod]
    fn from_concatenated_path(path: &str) -> PyResult<Self> {
        TimeZoneDatabase::from_concatenated_path(path)
            .map(Self::from)
            .map_err(map_py_value_err)
    }
}
