use std::fmt::Display;
use std::hash::{DefaultHasher, Hash, Hasher};

use jiff::civil::{Date, Time, Weekday};
use jiff::tz::TimeZone;
use jiff::{Zoned, ZonedDifference, ZonedRound};
use pyo3::prelude::*;
use pyo3::pyclass::CompareOp;
use pyo3::types::{PyDict, PyTuple};
use pyo3::{BoundObject, IntoPyObjectExt};
use ryo3_core::{PyAsciiString, map_py_overflow_err, map_py_value_err};
use ryo3_macro_rules::{any_repr, py_type_err};

use crate::isoformat::PyIsoFormat;
use crate::round::RyZonedDateTimeRound;
use crate::ry_datetime::RyDateTime;
use crate::ry_iso_week_date::RyISOWeekDate;
use crate::ry_offset::RyOffset;
use crate::ry_signed_duration::RySignedDuration;
use crate::ry_span::RySpan;
use crate::ry_time::RyTime;
use crate::ry_timestamp::RyTimestamp;
use crate::ry_timezone::RyTimeZone;
use crate::series::RyZonedSeries;
use crate::spanish::Spanish;
use crate::util::SpanKwargs;
use crate::{
    JiffEra, JiffEraYear, JiffRoundMode, JiffTzDisambiguation, JiffTzOffsetConflict, JiffUnit,
    JiffWeekday, JiffZoned, RyDate,
};

#[cfg_attr(feature = "serde", derive(serde::Serialize))]
#[cfg_attr(feature = "serde", serde(transparent))]
#[derive(Debug, Clone, PartialEq, Eq)]
#[pyclass(name = "ZonedDateTime", frozen, immutable_type, skip_from_py_object)]
#[cfg_attr(feature = "ry", pyo3(module = "ry.ryo3"))]
pub struct RyZoned(pub(crate) Zoned);

#[pymethods]
impl RyZoned {
    #[new]
    #[pyo3(
        signature = (
            year,
            month,
            day,
            hour = 0,
            minute = 0,
            second = 0,
            nanosecond = 0,
            tz = None
        )
    )]
    #[expect(clippy::too_many_arguments)]
    fn py_new(
        year: i16,
        month: i8,
        day: i8,
        hour: i8,
        minute: i8,
        second: i8,
        nanosecond: i32,
        tz: Option<&str>,
    ) -> PyResult<Self> {
        if let Some(tz) = tz {
            Date::new(year, month, day)
                .map_err(map_py_value_err)?
                .at(hour, minute, second, nanosecond)
                .in_tz(tz)
                .map(Self::from)
                .map_err(map_py_value_err)
        } else {
            let tz_system = TimeZone::try_system().map_err(map_py_value_err)?;
            Date::new(year, month, day)
                .map_err(map_py_value_err)?
                .at(hour, minute, second, nanosecond)
                .to_zoned(tz_system)
                .map(Self::from)
                .map_err(map_py_value_err)
        }
    }

    fn __getnewargs__<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyTuple>> {
        PyTuple::new(
            py,
            vec![
                self.year().into_bound_py_any(py)?,
                self.month().into_bound_py_any(py)?,
                self.day().into_bound_py_any(py)?,
                self.hour().into_bound_py_any(py)?,
                self.minute().into_bound_py_any(py)?,
                self.second().into_bound_py_any(py)?,
                self.subsec_nanosecond().into_bound_py_any(py)?,
                self.0.time_zone().iana_name().into_bound_py_any(py)?,
            ],
        )
    }

    #[staticmethod]
    #[pyo3(signature = (tz = None))]
    fn now(tz: Option<&str>) -> PyResult<Self> {
        if let Some(tz) = tz {
            Zoned::now()
                .in_tz(tz)
                .map(Self::from)
                .map_err(map_py_value_err)
        } else {
            Ok(Self::from(Zoned::now()))
        }
    }

    #[staticmethod]
    pub(crate) fn utcnow() -> Self {
        Self::from(Zoned::now().with_time_zone(TimeZone::UTC))
    }

    #[staticmethod]
    #[pyo3(signature = (timestamp, time_zone))]
    fn from_parts(timestamp: &RyTimestamp, time_zone: &RyTimeZone) -> Self {
        let ts = timestamp.0;
        Self::from(Zoned::new(ts, time_zone.into()))
    }

    // ========================================================================
    // STRPTIME/STRFTIME
    // ========================================================================
    fn __format__(&self, fmt: &str) -> PyResult<String> {
        if fmt.is_empty() {
            Ok(self.0.to_string())
        } else {
            self.strftime(fmt)
        }
    }

    #[pyo3(signature = (fmt))]
    fn strftime(&self, fmt: &str) -> PyResult<String> {
        let bdt: jiff::fmt::strtime::BrokenDownTime = (&self.0).into();
        bdt.to_string(fmt).map_err(map_py_value_err)
    }

    #[staticmethod]
    #[pyo3(signature = (s, /, fmt))]
    fn strptime(s: &str, fmt: &str) -> PyResult<Self> {
        Zoned::strptime(fmt, s)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    #[staticmethod]
    fn parse_rfc2822(s: &str) -> PyResult<Self> {
        ::jiff::fmt::rfc2822::parse(s)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    #[staticmethod]
    fn from_rfc2822(s: &str) -> PyResult<Self> {
        jiff::fmt::rfc2822::parse(s)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    fn format_rfc2822(&self) -> PyResult<String> {
        jiff::fmt::rfc2822::to_string(&self.0).map_err(map_py_value_err)
    }

    fn to_rfc2822(&self) -> PyResult<String> {
        jiff::fmt::rfc2822::to_string(&self.0).map_err(map_py_value_err)
    }

    fn __richcmp__(&self, other: &Self, op: CompareOp) -> bool {
        match op {
            CompareOp::Eq => self.0 == other.0,
            CompareOp::Ne => self.0 != other.0,
            CompareOp::Lt => self.0 < other.0,
            CompareOp::Le => self.0 <= other.0,
            CompareOp::Gt => self.0 > other.0,
            CompareOp::Ge => self.0 >= other.0,
        }
    }

    #[pyo3(name = "to_string")]
    fn py_to_string(&self) -> PyAsciiString {
        self.__str__()
    }

    fn __str__(&self) -> PyAsciiString {
        self.0.to_string().into()
    }

    fn __repr__(&self) -> PyAsciiString {
        format!("{self}").into()
    }

    fn __hash__(&self) -> u64 {
        let mut hasher = DefaultHasher::new();
        self.0.hash(&mut hasher);
        self.0
            .time_zone()
            .to_offset_info(self.0.timestamp())
            .hash(&mut hasher);
        self.0.time_zone().iana_name().hash(&mut hasher);
        hasher.finish()
    }

    fn timestamp(&self) -> RyTimestamp {
        RyTimestamp::from(self)
    }

    fn date(&self) -> RyDate {
        RyDate::from(self)
    }

    fn time(&self) -> RyTime {
        RyTime::from(self)
    }

    fn datetime(&self) -> RyDateTime {
        RyDateTime::from(self)
    }

    fn to_dict<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyDict>> {
        use crate::interns;
        let dict = PyDict::new(py);
        dict.set_item(interns::year(py), self.0.year())?;
        dict.set_item(interns::month(py), self.0.month())?;
        dict.set_item(interns::day(py), self.0.day())?;
        dict.set_item(interns::hour(py), self.0.hour())?;
        dict.set_item(interns::minute(py), self.0.minute())?;
        dict.set_item(interns::second(py), self.0.second())?;
        dict.set_item(interns::nanosecond(py), self.0.subsec_nanosecond())?;
        dict.set_item(
            interns::tz(py),
            self.0.time_zone().iana_name().unwrap_or("unknown"),
        )?;
        Ok(dict)
    }

    fn to_py(&self) -> &Zoned {
        self.to_pydatetime()
    }

    fn to_pydatetime(&self) -> &Zoned {
        &self.0
    }

    fn to_pydate(&self) -> Date {
        self.0.date()
    }

    fn to_pytime(&self) -> Time {
        self.0.time()
    }

    fn to_pytzinfo(&self) -> &TimeZone {
        self.0.time_zone()
    }

    #[staticmethod]
    fn from_pydatetime(datetime: JiffZoned) -> Self {
        Self::from(datetime.0)
    }

    fn in_tz(&self, tz: &str) -> PyResult<Self> {
        self.0.in_tz(tz).map(Self::from).map_err(map_py_value_err)
    }

    #[pyo3(
        warn(
            message = "`intz` is deprecated, use `in_tz` instead",
            category = pyo3::exceptions::PyDeprecationWarning
        )
    )]
    fn intz(&self, tz: &str) -> PyResult<Self> {
        self.in_tz(tz)
    }

    fn astimezone(&self, tz: &str) -> PyResult<Self> {
        self.in_tz(tz)
    }

    fn inutc(&self) -> Self {
        Self::from(self.0.with_time_zone(TimeZone::UTC))
    }

    fn __sub__<'py>(
        &self,
        py: Python<'py>,
        other: &Bound<'py, PyAny>,
    ) -> PyResult<Bound<'py, PyAny>> {
        #[expect(clippy::arithmetic_side_effects)]
        if let Ok(zoned) = other.cast_exact::<Self>() {
            // if other is a Zoned, return a Span
            let span = &self.0 - &zoned.get().0;
            let obj = RySpan::from(span).into_pyobject(py).map(Bound::into_any)?;
            Ok(obj)
        } else {
            let spanish = other.extract::<Spanish>()?;
            // Spanish2::try_from(other)?;
            let z = self.0.checked_sub(spanish).map_err(map_py_overflow_err)?;
            Self::from(z).into_bound_py_any(py)
        }
    }

    fn __add__(&self, other: Spanish) -> PyResult<Self> {
        self.0
            .checked_add(other)
            .map(Self::from)
            .map_err(map_py_overflow_err)
    }

    #[expect(clippy::too_many_arguments)]
    #[pyo3(
        signature = (
            other = None,
            /, *,
            years = 0,
            months = 0,
            weeks = 0,
            days = 0,
            hours = 0,
            minutes = 0,
            seconds = 0,
            milliseconds = 0,
            microseconds = 0,
            nanoseconds = 0
        )
    )]
    fn add(
        &self,
        other: Option<Spanish>,
        years: i64,
        months: i64,
        weeks: i64,
        days: i64,
        hours: i64,
        minutes: i64,
        seconds: i64,
        milliseconds: i64,
        microseconds: i64,
        nanoseconds: i64,
    ) -> PyResult<Self> {
        let spkw = SpanKwargs::new()
            .years(years)
            .months(months)
            .weeks(weeks)
            .days(days)
            .hours(hours)
            .minutes(minutes)
            .seconds(seconds)
            .milliseconds(milliseconds)
            .microseconds(microseconds)
            .nanoseconds(nanoseconds);

        match (other, !spkw.is_zero()) {
            (Some(o), false) => self.__add__(o),
            (None, true) => {
                let span = spkw.build()?;
                self.0
                    .checked_add(span)
                    .map(Self::from)
                    .map_err(map_py_overflow_err)
            }
            (Some(_), true) => {
                py_type_err!("add accepts either a span-like object or keyword units, not both")
            }
            (None, false) => Ok(self.clone()),
        }
    }

    #[expect(clippy::too_many_arguments)]
    #[pyo3(
        signature = (
            other = None,
            /, *,
            years = 0,
            months = 0,
            weeks = 0,
            days = 0,
            hours = 0,
            minutes = 0,
            seconds = 0,
            milliseconds = 0,
            microseconds = 0,
            nanoseconds = 0
        )
    )]
    fn sub<'py>(
        &self,
        py: Python<'py>,
        other: Option<&Bound<'py, PyAny>>,
        years: i64,
        months: i64,
        weeks: i64,
        days: i64,
        hours: i64,
        minutes: i64,
        seconds: i64,
        milliseconds: i64,
        microseconds: i64,
        nanoseconds: i64,
    ) -> PyResult<Bound<'py, PyAny>> {
        let spkw = SpanKwargs::new()
            .years(years)
            .months(months)
            .weeks(weeks)
            .days(days)
            .hours(hours)
            .minutes(minutes)
            .seconds(seconds)
            .milliseconds(milliseconds)
            .microseconds(microseconds)
            .nanoseconds(nanoseconds);

        match (other, !spkw.is_zero()) {
            (Some(o), false) => self.__sub__(py, o),
            (None, true) => {
                let span = spkw.build()?;
                self.0
                    .checked_sub(span)
                    .map(Self::from)
                    .map_err(map_py_overflow_err)
                    .and_then(|dt| dt.into_pyobject(py).map(Bound::into_any))
            }
            (Some(_), true) => {
                py_type_err!("sub accepts either a span-like object or keyword units, not both")
            }
            (None, false) => Ok(self.clone().into_pyobject(py).map(Bound::into_any)?),
        }
    }

    fn saturating_add(&self, other: Spanish) -> Self {
        Self::from(self.0.saturating_add(other))
    }

    fn saturating_sub(&self, other: Spanish) -> Self {
        Self::from(self.0.saturating_sub(other))
    }

    #[pyo3(
        signature = (
            smallest = JiffUnit::NANOSECOND,
            *,
            mode = JiffRoundMode(jiff::RoundMode::HalfExpand),
            increment = 1
        ),
        text_signature = "(self, smallest=\"nanosecond\", *, mode=\"half-expand\", increment=1)"
    )]
    fn round(&self, smallest: JiffUnit, mode: JiffRoundMode, increment: i64) -> PyResult<Self> {
        let zdt_round = ZonedRound::new()
            .smallest(smallest.0)
            .increment(increment)
            .mode(mode.0);
        self.0
            .round(zdt_round)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    fn _round(&self, options: &RyZonedDateTimeRound) -> PyResult<Self> {
        options.round(self)
    }

    fn tomorrow(&self) -> PyResult<Self> {
        self.0.tomorrow().map(Self::from).map_err(map_py_value_err)
    }

    fn yesterday(&self) -> PyResult<Self> {
        self.0.yesterday().map(Self::from).map_err(map_py_value_err)
    }

    fn end_of_day(&self) -> PyResult<Self> {
        self.0
            .end_of_day()
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    fn in_leap_year(&self) -> bool {
        self.0.in_leap_year()
    }

    fn last_of_month(&self) -> PyResult<Self> {
        self.0
            .last_of_month()
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    fn last_of_year(&self) -> PyResult<Self> {
        self.0
            .last_of_year()
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    fn days_in_month(&self) -> i8 {
        self.0.days_in_month()
    }

    fn days_in_year(&self) -> i16 {
        self.0.days_in_year()
    }

    fn day_of_year(&self) -> i16 {
        self.0.day_of_year()
    }

    fn day_of_year_no_leap(&self) -> Option<i16> {
        self.0.day_of_year_no_leap()
    }

    fn duration_since(&self, other: &Self) -> RySignedDuration {
        RySignedDuration::from(self.0.duration_since(&other.0))
    }

    fn duration_until(&self, other: &Self) -> RySignedDuration {
        RySignedDuration::from(self.0.duration_until(&other.0))
    }

    fn era_year<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyAny>> {
        let era_year = JiffEraYear(self.0.era_year());
        let obj = era_year.into_pyobject(py)?;
        Ok(obj.into_any())
    }

    fn first_of_month(&self) -> PyResult<Self> {
        self.0
            .first_of_month()
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    fn first_of_year(&self) -> PyResult<Self> {
        self.0
            .first_of_year()
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    fn nth_weekday(&self, nth: i32, weekday: JiffWeekday) -> PyResult<Self> {
        self.0
            .nth_weekday(nth, weekday.0)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    fn nth_weekday_of_month(&self, nth: i8, weekday: JiffWeekday) -> PyResult<Self> {
        self.0
            .nth_weekday_of_month(nth, weekday.0)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    fn offset(&self) -> RyOffset {
        self.0.offset().into()
    }

    fn start_of_day(&self) -> PyResult<Self> {
        self.0
            .start_of_day()
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    #[pyo3(
        signature = (
            other,
            *,
            smallest = JiffUnit::NANOSECOND,
            largest = None,
            mode = JiffRoundMode::TRUNC,
            increment = 1
        ),
        text_signature = "(self, other, *, smallest=\"nanosecond\", largest=None, mode=\"trunc\", increment=1)"
    )]
    fn since(
        &self,
        other: &Self,
        smallest: JiffUnit,
        largest: Option<JiffUnit>,
        mode: JiffRoundMode,
        increment: i64,
    ) -> PyResult<RySpan> {
        let mut zdt_diff = ZonedDifference::from(&other.0)
            .increment(increment)
            .mode(mode.0)
            .smallest(smallest.0);
        if let Some(largest) = largest {
            zdt_diff = zdt_diff.largest(largest.0);
        }
        self.0
            .since(zdt_diff)
            .map(RySpan::from)
            .map_err(map_py_value_err)
    }

    #[pyo3(
        signature = (
            other,
            *,
            smallest = JiffUnit::NANOSECOND,
            largest = None,
            mode = JiffRoundMode::TRUNC,
            increment = 1
        ),
        text_signature = "(self, other, *, smallest=\"nanosecond\", largest=None, mode=\"trunc\", increment=1)"
    )]
    fn until(
        &self,
        other: &Self,
        smallest: JiffUnit,
        largest: Option<JiffUnit>,
        mode: JiffRoundMode,
        increment: i64,
    ) -> PyResult<RySpan> {
        let mut zdt_diff = ZonedDifference::from(&other.0)
            .increment(increment)
            .mode(mode.0)
            .smallest(smallest.0);
        if let Some(largest) = largest {
            zdt_diff = zdt_diff.largest(largest.0);
        }
        self.0
            .until(zdt_diff)
            .map(RySpan::from)
            .map_err(map_py_value_err)
    }

    fn with_time_zone(&self, tz: &RyTimeZone) -> Self {
        self.0.with_time_zone(tz.into()).into()
    }

    pub(crate) fn iso_week_date(&self) -> RyISOWeekDate {
        let d = self.0.date();
        d.iso_week_date().into()
    }

    #[pyo3(
        signature = (
            obj = None,
            *,
            date = None,
            time = None,
            year = None,
            era_year = None,
            month = None,
            day = None,
            day_of_year = None,
            day_of_year_no_leap = None,
            hour = None,
            minute = None,
            second = None,
            millisecond = None,
            microsecond = None,
            nanosecond = None,
            subsec_nanosecond = None,
            offset = None,
            offset_conflict = None,
            disambiguation = None,
        )
    )]
    #[expect(clippy::too_many_arguments)]
    fn replace(
        &self,
        obj: Option<Bound<'_, PyAny>>,
        date: Option<&RyDate>,
        time: Option<&RyTime>,
        year: Option<i16>,
        era_year: Option<(i16, JiffEra)>,
        month: Option<i8>,
        day: Option<i8>,
        day_of_year: Option<i16>,
        day_of_year_no_leap: Option<i16>,
        hour: Option<i8>,
        minute: Option<i8>,
        second: Option<i8>,
        millisecond: Option<i16>,
        microsecond: Option<i16>,
        nanosecond: Option<i16>,
        subsec_nanosecond: Option<i32>,
        offset: Option<&RyOffset>,
        offset_conflict: Option<JiffTzOffsetConflict>,
        disambiguation: Option<JiffTzDisambiguation>,
    ) -> PyResult<Self> {
        // start the builder
        let mut builder = self.0.with();
        if let Some(obj) = obj {
            // if obj is a Zoned, use it as the base
            if let Ok(zoned) = obj.cast_exact::<RyDate>() {
                // if obj is a Zoned, use it as the base
                builder = builder.date(zoned.get().0);
            } else if let Ok(time) = obj.cast_exact::<RyTime>() {
                // if obj is a Time, use it as the base
                builder = builder.time(time.get().0);
            } else if let Ok(dt) = obj.cast_exact::<RyDateTime>() {
                // if obj is a Time, use it as the base
                builder = builder.time(dt.get().0.time()).date(dt.get().0.date());
            } else if let Ok(offset) = obj.cast_exact::<RyOffset>() {
                builder = builder.offset(offset.get().0);
            } else {
                return py_type_err!("obj must be a Date, Time or Offset; given: {obj}",);
            }
        }

        // only override if the Option is Some
        if let Some(date) = date {
            builder = builder.date(date.0);
        }
        if let Some(time) = time {
            builder = builder.time(time.0);
        }
        if let Some(y) = year {
            builder = builder.year(y);
        }
        if let Some(ey) = era_year {
            builder = builder.era_year(ey.0, (ey.1).0);
        }
        if let Some(m) = month {
            builder = builder.month(m);
        }
        if let Some(d) = day {
            builder = builder.day(d);
        }
        if let Some(doy) = day_of_year {
            builder = builder.day_of_year(doy);
        }
        if let Some(doy) = day_of_year_no_leap {
            builder = builder.day_of_year_no_leap(doy);
        }
        if let Some(h) = hour {
            builder = builder.hour(h);
        }
        if let Some(min) = minute {
            builder = builder.minute(min);
        }
        if let Some(sec) = second {
            builder = builder.second(sec);
        }
        if let Some(us) = microsecond {
            builder = builder.microsecond(us);
        }
        if let Some(ms) = millisecond {
            builder = builder.millisecond(ms);
        }
        if let Some(ns) = nanosecond {
            builder = builder.nanosecond(ns);
        }
        if let Some(subns) = subsec_nanosecond {
            builder = builder.subsec_nanosecond(subns);
        }
        if let Some(offset) = offset {
            builder = builder.offset(offset.0);
        }
        if let Some(offset_conflict) = offset_conflict {
            builder = builder.offset_conflict(offset_conflict.0);
        }
        if let Some(disambiguation) = disambiguation {
            builder = builder.disambiguation(disambiguation.0);
        }
        // finally build, mapping any error back to Python
        builder.build().map(Self::from).map_err(map_py_value_err)
    }

    fn series(&self, period: &RySpan) -> PyResult<RyZonedSeries> {
        (self, period).try_into()
    }

    // -----------------------------------------------------------------------
    // getters
    // -----------------------------------------------------------------------
    #[getter]
    fn timezone(&self) -> RyTimeZone {
        RyTimeZone::from(self.0.time_zone())
    }

    #[getter]
    fn tz(&self) -> RyTimeZone {
        RyTimeZone::from(self.0.time_zone())
    }

    #[getter]
    fn year(&self) -> i16 {
        self.0.year()
    }

    #[getter]
    fn month(&self) -> i8 {
        self.0.month()
    }

    #[getter]
    fn day(&self) -> i8 {
        self.0.day()
    }

    #[getter]
    fn weekday(&self) -> i8 {
        match self.0.weekday() {
            Weekday::Monday => 1,
            Weekday::Tuesday => 2,
            Weekday::Wednesday => 3,
            Weekday::Thursday => 4,
            Weekday::Friday => 5,
            Weekday::Saturday => 6,
            Weekday::Sunday => 7,
        }
    }

    #[getter]
    fn hour(&self) -> i8 {
        self.0.hour()
    }

    #[getter]
    fn minute(&self) -> i8 {
        self.0.minute()
    }

    #[getter]
    fn second(&self) -> i8 {
        self.0.second()
    }

    #[getter]
    fn microsecond(&self) -> i16 {
        self.0.microsecond()
    }

    #[getter]
    fn millisecond(&self) -> i16 {
        self.0.millisecond()
    }

    #[getter]
    fn nanosecond(&self) -> i16 {
        self.0.nanosecond()
    }

    #[getter]
    fn subsec_nanosecond(&self) -> i32 {
        self.0.subsec_nanosecond()
    }

    #[staticmethod]
    fn from_any<'py>(value: &Bound<'py, PyAny>) -> PyResult<Bound<'py, Self>> {
        let py = value.py();
        if let Ok(val) = value.cast_exact::<Self>() {
            Ok(val.as_borrowed().into_bound())
        } else if let Ok(pystr) = value.cast::<pyo3::types::PyString>() {
            let s = pystr.extract::<&str>()?;
            Self::from_str(s).map(|dt| dt.into_pyobject(py))?
        } else if let Ok(pybytes) = value.cast::<pyo3::types::PyBytes>() {
            let s = String::from_utf8_lossy(pybytes.as_bytes());
            Self::from_str(&s).map(|dt| dt.into_pyobject(py))?
        } else if let Ok(ts) = value.cast_exact::<RyTimestamp>() {
            Self::from(ts.get()).into_pyobject(py)
        } else if let Ok(d) = value.extract::<JiffZoned>() {
            Self::from(d.0).into_pyobject(py)
        } else {
            let valtype = any_repr!(value);
            py_type_err!("ZonedDateTime conversion error: {valtype}",)
        }
    }

    // ========================================================================
    // PYDANTIC
    // ========================================================================
    #[cfg(feature = "pydantic")]
    #[staticmethod]
    fn _pydantic_validate<'py>(
        value: &Bound<'py, PyAny>,
        _handler: &Bound<'py, PyAny>,
    ) -> PyResult<Bound<'py, Self>> {
        Self::from_any(value).map_err(map_py_value_err)
    }

    #[cfg(feature = "pydantic")]
    #[classmethod]
    fn __get_pydantic_core_schema__<'py>(
        cls: &Bound<'py, ::pyo3::types::PyType>,
        source: &Bound<'py, PyAny>,
        handler: &Bound<'py, PyAny>,
    ) -> PyResult<Bound<'py, PyAny>> {
        use ryo3_pydantic::GetPydanticCoreSchemaCls;
        Self::get_pydantic_core_schema(cls, source, handler)
    }

    // ========================================================================
    // STANDARD METHODS
    // ========================================================================
    // <STD-METHODS>
    #[staticmethod]
    fn from_str(s: &str) -> PyResult<Self> {
        use ryo3_core::PyFromStr;
        Self::py_from_str(s)
    }

    #[staticmethod]
    fn parse(s: &Bound<'_, PyAny>) -> PyResult<Self> {
        use ryo3_core::PyParse;
        Self::py_parse(s)
    }

    fn isoformat(&self) -> PyAsciiString {
        <Self as PyIsoFormat>::isoformat(self)
    }
    // </STD-METHODS>
}

impl Display for RyZoned {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        if let Some(tz_name) = self.0.time_zone().iana_name() {
            write!(
                f,
                "ZonedDateTime(year={}, month={}, day={}, hour={}, minute={}, second={}, nanosecond={}, tz=\"{}\")",
                self.0.year(),
                self.0.month(),
                self.0.day(),
                self.0.hour(),
                self.0.minute(),
                self.0.second(),
                self.0.subsec_nanosecond(),
                tz_name
            )
        } else {
            write!(f, "ZonedDateTime.parse(\"{}\")", self.0)
        }
    }
}
