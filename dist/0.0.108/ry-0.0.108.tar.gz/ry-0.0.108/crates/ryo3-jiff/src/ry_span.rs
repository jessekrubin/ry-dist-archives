use std::fmt::Display;
use std::hash::{DefaultHasher, Hash, Hasher};

use jiff::{SignedDuration, Span, SpanArithmetic, SpanRelativeTo, SpanRound};
use pyo3::prelude::*;
use pyo3::types::{PyDelta, PyDict, PyFloat, PyInt, PyIterator, PyTuple};
use pyo3::{BoundObject, IntoPyObjectExt};
use ryo3_core::macros::{
    any_repr, py_key_err, py_overflow_error, py_type_err, py_type_error, py_value_err,
    py_value_error,
};
use ryo3_core::{
    FromPyOperand, PyAsciiString, PyCastExactOpt, PyNotImplementedOr, PyOperandArg,
    map_py_overflow_err, map_py_value_err,
};
use ryo3_jiff_core::{JiffFriendlyDesignator, JiffRoundMode, JiffSpan, JiffUnit};

use crate::py_temporal_like::PyTemporalArg;
use crate::ry_signed_duration::RySignedDuration;
use crate::span_units::{SpanUnit, SpanUnitsMask};
use crate::spanish::{DurationLike, Spanish};
use crate::util::SpanKwargs;
use crate::{RyDate, RyDateTime, RyTime, RyTimestamp, RyZoned, constants, timespan};

#[cfg_attr(feature = "serde", derive(serde::Serialize), serde(transparent))]
#[derive(Debug, Clone, Copy)]
#[pyclass(name = "TimeSpan", frozen, immutable_type, mapping, eq)]
#[cfg_attr(feature = "ry", pyo3(module = "ry.ryo3"))]
pub struct RySpan(pub(crate) Span);

impl RySpan {
    pub(crate) fn inner(&self) -> &Span {
        &self.0
    }

    fn max_jiff_span() -> Span {
        Span::new()
            .years(constants::SPAN_YEARS_MAX)
            .months(constants::SPAN_MONTHS_MAX)
            .weeks(constants::SPAN_WEEKS_MAX)
            .days(constants::SPAN_DAYS_MAX)
            .hours(constants::SPAN_HOURS_MAX)
            .minutes(constants::SPAN_MINUTES_MAX)
            .seconds(constants::SPAN_SECONDS_MAX)
            .milliseconds(constants::SPAN_MILLISECONDS_MAX)
            .microseconds(constants::SPAN_MICROSECONDS_MAX)
            .nanoseconds(constants::SPAN_NANOSECONDS_MAX)
    }

    fn min_jiff_span() -> Span {
        Span::new()
            .years(constants::SPAN_YEARS_MIN)
            .months(constants::SPAN_MONTHS_MIN)
            .weeks(constants::SPAN_WEEKS_MIN)
            .days(constants::SPAN_DAYS_MIN)
            .hours(constants::SPAN_HOURS_MIN)
            .minutes(constants::SPAN_MINUTES_MIN)
            .seconds(constants::SPAN_SECONDS_MIN)
            .milliseconds(constants::SPAN_MILLISECONDS_MIN)
            .microseconds(constants::SPAN_MICROSECONDS_MIN)
            .nanoseconds(constants::SPAN_NANOSECONDS_MIN)
    }
}

impl PartialEq for RySpan {
    fn eq(&self, other: &Self) -> bool {
        let self_fieldwise = self.0.fieldwise();
        let other_fieldwise = other.0.fieldwise();
        self_fieldwise == other_fieldwise
    }
}

impl RySpan {
    fn try_mul(&self, other: i64) -> PyResult<Self> {
        self.0
            .checked_mul(other)
            .map(Self::from)
            .map_err(map_py_overflow_err)
    }

    fn try_sub(&self, other: &RySpanArithmetic<'_, '_>) -> PyResult<Self> {
        let span_arithmetic: SpanArithmetic = other.into();
        self.0
            .checked_sub(span_arithmetic)
            .map(Self::from)
            .map_err(map_py_overflow_err)
    }
}

#[pymethods]
impl RySpan {
    #[expect(clippy::too_many_arguments, reason = "python kwargs")]
    #[new]
    #[pyo3(
        signature = (
            *,
            years = 0,
            months = 0,
            weeks = 0,
            days = 0,
            hours = 0,
            minutes = 0,
            seconds = 0,
            milliseconds = 0,
            microseconds = 0,
            nanoseconds = 0
        )
    )]
    fn py_new(
        years: i16,
        months: i32,
        weeks: i32,
        days: i32,
        hours: i32,
        minutes: i64,
        seconds: i64,
        milliseconds: i64,
        microseconds: i64,
        nanoseconds: i64,
    ) -> PyResult<Self> {
        timespan(
            years,
            months,
            weeks,
            days,
            hours,
            minutes,
            seconds,
            milliseconds,
            microseconds,
            nanoseconds,
        )
    }

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn MIN() -> Self {
        Self::min_jiff_span().into()
    }

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn MAX() -> Self {
        Self::max_jiff_span().into()
    }

    #[staticmethod]
    fn fromisoformat(s: &str) -> PyResult<Self> {
        ryo3_jiff_core::fmt::TEMPORAL_SPAN_PARSER
            .parse_span(s)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    fn __str__(&self) -> PyAsciiString {
        self.0.to_string().into()
    }

    fn __getnewargs_ex__<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyTuple>> {
        let args = PyTuple::empty(py).into_bound_py_any(py)?;
        let kwargs = self.py_to_dict(py)?.into_bound_py_any(py)?;
        PyTuple::new(py, vec![args, kwargs])
    }

    fn __iter__<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyIterator>> {
        self.keys(py)?.try_iter()
    }

    fn keys<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyTuple>> {
        if self.0.is_zero() {
            return Ok(PyTuple::empty(py));
        }
        PyTuple::new(py, SpanUnitsMask::from(&self.0))
    }

    fn __len__(&self) -> usize {
        usize::from(SpanUnitsMask::from(&self.0).count())
    }

    fn __contains__(&self, key: &str) -> bool {
        match key {
            "years" => self.0.get_years() != 0,
            "months" => self.0.get_months() != 0,
            "weeks" => self.0.get_weeks() != 0,
            "days" => self.0.get_days() != 0,
            "hours" => self.0.get_hours() != 0,
            "minutes" => self.0.get_minutes() != 0,
            "seconds" => self.0.get_seconds() != 0,
            "milliseconds" => self.0.get_milliseconds() != 0,
            "microseconds" => self.0.get_microseconds() != 0,
            "nanoseconds" => self.0.get_nanoseconds() != 0,
            _ => false,
        }
    }

    fn __getitem__(&self, key: &str) -> PyResult<i64> {
        macro_rules! get_da_unit_or_error {
            (@into, $field:ident) => {
                if self.0.$field() != 0 {
                    Ok(self.0.$field().into())
                } else {
                    py_key_err!("Unit '{key}' is not present in the TimeSpan")
                }
            };
            ($field:ident) => {
                if self.0.$field() != 0 {
                    Ok(self.0.$field())
                } else {
                    py_key_err!("Unit '{key}' is not present in the TimeSpan")
                }
            };
        }
        match key {
            "years" => get_da_unit_or_error!(@into, get_years),
            "months" => get_da_unit_or_error!(@into, get_months),
            "weeks" => get_da_unit_or_error!(@into, get_weeks),
            "days" => get_da_unit_or_error!(@into, get_days),
            "hours" => get_da_unit_or_error!(@into, get_hours),
            "minutes" => get_da_unit_or_error!(@into, get_minutes),
            "seconds" => get_da_unit_or_error!(get_seconds),
            "milliseconds" => get_da_unit_or_error!(get_milliseconds),
            "microseconds" => get_da_unit_or_error!(get_microseconds),
            "nanoseconds" => get_da_unit_or_error!(get_nanoseconds),
            _ => py_key_err!(
                "Invalid key: {key} (options: 'years', 'months', 'weeks', 'days', 'hours', 'minutes', 'seconds', 'milliseconds', 'microseconds', 'nanoseconds')"
            ),
        }
    }

    fn __format__(&self, fmt: &str) -> PyResult<String> {
        if fmt == "#" {
            Ok(format!("{:#}", self.0))
        } else if fmt.is_empty() {
            Ok(self.0.to_string())
        } else {
            py_type_err!("Invalid format specifier '{fmt}' for TimeSpan")
        }
    }

    #[pyo3(signature = (*, friendly = false), name = "to_string")]
    fn py_to_string(&self, friendly: bool) -> String {
        if friendly {
            format!("{:#}", self.0)
        } else {
            self.0.to_string()
        }
    }

    #[pyo3(
        signature = (designator = JiffFriendlyDesignator::COMPACT),
        text_signature = "(self, designator=\"compact\")"
    )]
    fn friendly(&self, designator: JiffFriendlyDesignator) -> String {
        ryo3_jiff_core::fmt::FRIENDLY_SPAN_PRINTER
            .designator(designator.into())
            .span_to_string(&self.0)
    }

    fn negate(&self) -> Self {
        Self(self.0.negate())
    }

    fn __neg__(&self) -> Self {
        Self(self.0.negate())
    }

    #[inline]
    fn __abs__(slf: PyRef<'_, Self>) -> PyResult<Bound<'_, Self>> {
        Self::abs(slf)
    }

    #[inline]
    fn abs(slf: PyRef<'_, Self>) -> PyResult<Bound<'_, Self>> {
        let py = slf.py();
        if slf.0.signum() >= 0 {
            slf.into_pyobject_or_pyerr(py)
        } else {
            Self(slf.0.abs()).into_pyobject(py)
        }
    }

    fn __invert__(&self) -> Self {
        Self(self.0.negate())
    }

    #[staticmethod]
    fn from_pytimedelta(delta: JiffSpan) -> Self {
        Self::from(delta.into_inner())
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_py<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyDelta>> {
        self.to_pytimedelta(py)
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_pytimedelta<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyDelta>> {
        JiffSpan::new(self.0).into_pyobject(py)
    }

    // <UNIFORM>
    #[staticmethod]
    #[pyo3(signature = (s, /))]
    fn from_str(s: &str) -> PyResult<Self> {
        use ryo3_core::PyFromStr;
        Self::py_from_str(s)
    }

    #[staticmethod]
    #[pyo3(signature = (value, /))]
    fn parse(value: ryo3_core::PyParseArg<Self>) -> Self {
        value.into_inner()
    }

    fn isoformat(&self) -> PyAsciiString {
        <Self as crate::isoformat::PyIsoFormat>::isoformat(self)
    }
    // </UNIFORM>

    #[expect(clippy::too_many_arguments, reason = "python kwargs")]
    #[pyo3(
        signature = (
            *,
            years = None,
            months = None,
            weeks = None,
            days = None,
            hours = None,
            minutes = None,
            seconds = None,
            milliseconds = None,
            microseconds = None,
            nanoseconds = None
        )
    )]
    fn replace(
        &self,
        years: Option<i16>,
        months: Option<i32>,
        weeks: Option<i32>,
        days: Option<i32>,
        hours: Option<i32>,
        minutes: Option<i64>,
        seconds: Option<i64>,
        milliseconds: Option<i64>,
        microseconds: Option<i64>,
        nanoseconds: Option<i64>,
    ) -> PyResult<Self> {
        Self::py_new(
            years.unwrap_or_else(|| self.0.get_years()),
            months.unwrap_or_else(|| self.0.get_months()),
            weeks.unwrap_or_else(|| self.0.get_weeks()),
            days.unwrap_or_else(|| self.0.get_days()),
            hours.unwrap_or_else(|| self.0.get_hours()),
            minutes.unwrap_or_else(|| self.0.get_minutes()),
            seconds.unwrap_or_else(|| self.0.get_seconds()),
            milliseconds.unwrap_or_else(|| self.0.get_milliseconds()),
            microseconds.unwrap_or_else(|| self.0.get_microseconds()),
            nanoseconds.unwrap_or_else(|| self.0.get_nanoseconds()),
        )
    }

    #[pyo3(signature = (years, /))]
    fn _years(&self, years: i64) -> PyResult<Self> {
        self.0
            .try_years(years)
            .map(Self::from)
            .map_err(|e| py_overflow_error!("Failed at try_years: {e}"))
    }

    #[pyo3(signature = (months, /))]
    fn _months(&self, months: i64) -> PyResult<Self> {
        self.0
            .try_months(months)
            .map(Self::from)
            .map_err(|e| py_overflow_error!("Failed at try_months: {e}"))
    }

    #[pyo3(signature = (weeks, /))]
    fn _weeks(&self, weeks: i64) -> PyResult<Self> {
        self.0
            .try_weeks(weeks)
            .map(Self::from)
            .map_err(|e| py_overflow_error!("Failed at try_weeks: {e}"))
    }

    #[pyo3(signature = (days, /))]
    fn _days(&self, days: i64) -> PyResult<Self> {
        self.0
            .try_days(days)
            .map(Self::from)
            .map_err(|e| py_overflow_error!("Failed at try_days: {e}"))
    }

    #[pyo3(signature = (hours, /))]
    fn _hours(&self, hours: i64) -> PyResult<Self> {
        self.0
            .try_hours(hours)
            .map(Self::from)
            .map_err(|e| py_overflow_error!("Failed at try_hours: {e}"))
    }

    #[pyo3(signature = (minutes, /))]
    fn _minutes(&self, minutes: i64) -> PyResult<Self> {
        self.0
            .try_minutes(minutes)
            .map(Self::from)
            .map_err(|e| py_overflow_error!("Failed at try_minutes: {e}"))
    }

    #[pyo3(signature = (seconds, /))]
    fn _seconds(&self, seconds: i64) -> PyResult<Self> {
        self.0
            .try_seconds(seconds)
            .map(Self::from)
            .map_err(|e| py_overflow_error!("Failed at try_seconds: {e}"))
    }

    #[pyo3(signature = (milliseconds, /))]
    fn _milliseconds(&self, milliseconds: i64) -> PyResult<Self> {
        self.0
            .try_milliseconds(milliseconds)
            .map(Self::from)
            .map_err(|e| py_overflow_error!("Failed at try_milliseconds: {e}"))
    }

    #[pyo3(signature = (microseconds, /))]
    fn _microseconds(&self, microseconds: i64) -> PyResult<Self> {
        self.0
            .try_microseconds(microseconds)
            .map(Self::from)
            .map_err(|e| py_overflow_error!("Failed at try_microseconds: {e}"))
    }

    #[pyo3(signature = (nanoseconds, /))]
    fn _nanoseconds(&self, nanoseconds: i64) -> PyResult<Self> {
        self.0
            .try_nanoseconds(nanoseconds)
            .map(Self::from)
            .map_err(|e| py_overflow_error!("Failed at try_nanoseconds: {e}"))
    }

    fn __repr__(&self) -> PyAsciiString {
        format!("{self}").into()
    }

    fn repr_full(&self) -> PyAsciiString {
        format!(
            "TimeSpan(years={}, months={}, weeks={}, days={}, hours={}, minutes={}, seconds={}, milliseconds={}, microseconds={}, nanoseconds={})",
            self.0.get_years(),
            self.0.get_months(),
            self.0.get_weeks(),
            self.0.get_days(),
            self.0.get_hours(),
            self.0.get_minutes(),
            self.0.get_seconds(),
            self.0.get_milliseconds(),
            self.0.get_microseconds(),
            self.0.get_nanoseconds()
        ) .into()
    }

    fn __hash__(&self) -> u64 {
        let mut hasher = DefaultHasher::new();
        self.0.fieldwise().hash(&mut hasher);
        hasher.finish()
    }

    #[pyo3(name = "to_dict")]
    fn py_to_dict<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyDict>> {
        let dict = PyDict::new(py);
        macro_rules! set_da_unit_in_da_dict {
            ($field:ident, $unit:expr) => {
                if self.0.$field() != 0 {
                    dict.set_item($unit, self.0.$field())?;
                }
            };
        }
        set_da_unit_in_da_dict!(get_years, SpanUnit::Years);
        set_da_unit_in_da_dict!(get_months, SpanUnit::Months);
        set_da_unit_in_da_dict!(get_weeks, SpanUnit::Weeks);
        set_da_unit_in_da_dict!(get_days, SpanUnit::Days);
        set_da_unit_in_da_dict!(get_hours, SpanUnit::Hours);
        set_da_unit_in_da_dict!(get_minutes, SpanUnit::Minutes);
        set_da_unit_in_da_dict!(get_seconds, SpanUnit::Seconds);
        set_da_unit_in_da_dict!(get_milliseconds, SpanUnit::Milliseconds);
        set_da_unit_in_da_dict!(get_microseconds, SpanUnit::Microseconds);
        set_da_unit_in_da_dict!(get_nanoseconds, SpanUnit::Nanoseconds);
        Ok(dict)
    }

    fn fieldwise<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyDict>> {
        self.py_to_dict(py)
    }

    #[pyo3(signature = (relative = None))]
    #[expect(clippy::wrong_self_convention)]
    fn to_signed_duration(&self, relative: Option<RySpanRelativeTo>) -> PyResult<RySignedDuration> {
        if let Some(r) = relative {
            self.0
                .to_duration(&r)
                .map(RySignedDuration)
                .map_err(map_py_value_err)
        } else {
            let now = jiff::Zoned::now();
            self.0
                .to_duration(&now)
                .map(RySignedDuration)
                .map_err(map_py_value_err)
        }
    }

    fn __add__<'py>(
        &self,
        py: Python<'py>,
        other: PyOperandArg<SpanAddTarget<'_, 'py>>,
    ) -> PyResult<PyNotImplementedOr<Bound<'py, PyAny>>> {
        other.try_map(|rhs| rhs.add_span(py, self))
    }

    #[expect(clippy::too_many_arguments, reason = "python kwargs")]
    #[pyo3(
        signature = (
            other = None,
            /, *,
            years = None,
            months = None,
            weeks = None,
            days = None,
            hours = None,
            minutes = None,
            seconds = None,
            milliseconds = None,
            microseconds = None,
            nanoseconds = None
        )
    )]
    fn add<'py>(
        &self,
        py: Python<'py>,
        other: Option<SpanAddTarget<'_, 'py>>,
        // **KWARG ONLY
        years: Option<i16>,
        months: Option<i32>,
        weeks: Option<i32>,
        days: Option<i32>,
        hours: Option<i32>,
        minutes: Option<i64>,
        seconds: Option<i64>,
        milliseconds: Option<i64>,
        microseconds: Option<i64>,
        nanoseconds: Option<i64>,
    ) -> PyResult<Bound<'py, PyAny>> {
        let kwargs = SpanKwargs::new()
            .years_opt(years)
            .months_opt(months)
            .weeks_opt(weeks)
            .days_opt(days)
            .hours_opt(hours)
            .minutes_opt(minutes)
            .seconds_opt(seconds)
            .milliseconds_opt(milliseconds)
            .microseconds_opt(microseconds)
            .nanoseconds_opt(nanoseconds);
        match (other, kwargs.is_empty()) {
            (Some(other), true) => other.add_span(py, self),
            (None, false) => {
                let span = kwargs.build_span()?;
                let span_arithmetic = SpanArithmetic::from(span).days_are_24_hours();
                self.0
                    .checked_add(span_arithmetic)
                    .map(Self::from)
                    .map_err(map_py_overflow_err)?
                    .into_bound_py_any(py)
            }
            (None, true) => {
                py_type_err!("add() missing required argument: 'other' or keyword units")
            }
            (Some(_), false) => {
                py_type_err!("add() accepts either a span-like object or keyword units, not both")
            }
        }
    }

    fn __sub__(
        &self,
        other: PyOperandArg<RySpanArithmetic<'_, '_>>,
    ) -> PyResult<PyNotImplementedOr<Self>> {
        other.try_map(|rhs| self.try_sub(&rhs))
    }

    #[expect(clippy::too_many_arguments, reason = "python kwargs")]
    #[pyo3(
        signature = (
            other = None,
            /, *,
            years = None,
            months = None,
            weeks = None,
            days = None,
            hours = None,
            minutes = None,
            seconds = None,
            milliseconds = None,
            microseconds = None,
            nanoseconds = None
        )
    )]
    fn sub(
        &self,
        other: Option<RySpanArithmetic>,
        // **KWARG ONLY
        years: Option<i16>,
        months: Option<i32>,
        weeks: Option<i32>,
        days: Option<i32>,
        hours: Option<i32>,
        minutes: Option<i64>,
        seconds: Option<i64>,
        milliseconds: Option<i64>,
        microseconds: Option<i64>,
        nanoseconds: Option<i64>,
    ) -> PyResult<Self> {
        let kwargs = SpanKwargs::new()
            .years_opt(years)
            .months_opt(months)
            .weeks_opt(weeks)
            .days_opt(days)
            .hours_opt(hours)
            .minutes_opt(minutes)
            .seconds_opt(seconds)
            .milliseconds_opt(milliseconds)
            .microseconds_opt(microseconds)
            .nanoseconds_opt(nanoseconds);
        match (other, kwargs.is_empty()) {
            (Some(other), true) => self.try_sub(&other),
            (None, false) => {
                let span = kwargs.build_span()?;
                let span_arithmetic = SpanArithmetic::from(span).days_are_24_hours();
                self.0
                    .checked_sub(span_arithmetic)
                    .map(Self::from)
                    .map_err(map_py_overflow_err)
            }
            (None, true) => {
                py_type_err!("sub() missing required argument: 'other' or keyword units")
            }
            (Some(_), false) => {
                py_type_err!("sub() accepts either a span-like object or keyword units, not both")
            }
        }
    }

    fn __mul__(&self, other: PyOperandArg<i64>) -> PyResult<PyNotImplementedOr<Self>> {
        other.try_map(|rhs| self.try_mul(rhs))
    }

    fn mul(&self, other: i64) -> PyResult<Self> {
        self.try_mul(other)
    }

    #[pyo3(signature = (other, relative = None, *, days_are_24_hours = false))]
    fn compare(
        &self,
        other: &Self,
        relative: Option<RySpanRelativeTo>,
        days_are_24_hours: bool,
    ) -> PyResult<i8> {
        if days_are_24_hours && relative.is_some() {
            return py_value_err!("Cannot provide relative with days_are_24_hours=True",);
        }
        if let Some(r) = relative {
            let relative_to: jiff::SpanRelativeTo = (&r).into();
            let r = self
                .0
                .compare((&other.0, relative_to))
                .map_err(map_py_value_err)?;
            match r {
                std::cmp::Ordering::Less => Ok(-1),
                std::cmp::Ordering::Equal => Ok(0),
                std::cmp::Ordering::Greater => Ok(1),
            }
        } else if days_are_24_hours {
            let span_total = SpanRelativeTo::days_are_24_hours();
            let r = self
                .0
                .compare((&other.0, span_total))
                .map_err(map_py_value_err)?;
            match r {
                std::cmp::Ordering::Less => Ok(-1),
                std::cmp::Ordering::Equal => Ok(0),
                std::cmp::Ordering::Greater => Ok(1),
            }
        } else {
            let r = self.0.compare(other.0).map_err(map_py_value_err)?;
            match r {
                std::cmp::Ordering::Less => Ok(-1),
                std::cmp::Ordering::Equal => Ok(0),
                std::cmp::Ordering::Greater => Ok(1),
            }
        }
    }

    // ========================================================================
    // PROPERTIES
    // ========================================================================
    #[getter]
    fn is_absolute(&self) -> bool {
        self.0.signum() >= 0
    }

    #[getter]
    fn is_calendar(&self) -> bool {
        self.0.get_years() != 0
            || self.0.get_months() != 0
            || self.0.get_weeks() != 0
            || self.0.get_days() != 0
    }

    #[getter]
    fn is_exact(&self) -> bool {
        self.0.get_years() == 0
            && self.0.get_months() == 0
            && self.0.get_weeks() == 0
            && self.0.get_days() == 0
    }

    #[getter]
    fn is_negative(&self) -> bool {
        self.0.is_negative()
    }

    #[getter]
    fn is_positive(&self) -> bool {
        self.0.is_positive()
    }

    #[getter]
    fn is_zero(&self) -> bool {
        self.0.is_zero()
    }

    #[getter]
    fn years(&self) -> i16 {
        self.0.get_years()
    }

    #[getter]
    fn months(&self) -> i32 {
        self.0.get_months()
    }

    #[getter]
    fn weeks(&self) -> i32 {
        self.0.get_weeks()
    }

    #[getter]
    fn days(&self) -> i32 {
        self.0.get_days()
    }

    #[getter]
    fn hours(&self) -> i32 {
        self.0.get_hours()
    }

    #[getter]
    fn minutes(&self) -> i64 {
        self.0.get_minutes()
    }

    #[getter]
    fn seconds(&self) -> i64 {
        self.0.get_seconds()
    }

    #[getter]
    fn milliseconds(&self) -> i64 {
        self.0.get_milliseconds()
    }

    #[getter]
    fn microseconds(&self) -> i64 {
        self.0.get_microseconds()
    }

    #[getter]
    fn nanoseconds(&self) -> i64 {
        self.0.get_nanoseconds()
    }

    // ========================================================================
    // INSTANCE METHODS
    // ========================================================================
    #[pyo3(
        signature = (
            smallest = JiffUnit::NANOSECOND,
            increment = 1,
            *,
            relative = None,
            largest = None,
            mode = JiffRoundMode::HALF_EXPAND,
            days_are_24_hours = false
        ),
        text_signature = "(self, smallest=\"nanosecond\", increment=1, *, relative=None, largest=None, mode=\"half-expand\", days_are_24_hours=False)"
    )]
    fn round(
        &self,
        smallest: JiffUnit,
        increment: i64,
        // kwarg only
        relative: Option<RySpanRelativeTo>,
        largest: Option<JiffUnit>,
        mode: JiffRoundMode,
        days_are_24_hours: bool,
    ) -> PyResult<Self> {
        // err on both relative and days_are_24_hours provided
        if relative.is_some() && days_are_24_hours {
            return Err(py_value_error!(
                "`relative` and `days_are_24_hours=True` are mutually exclusive",
            ));
        }
        if let Some(relative) = relative {
            let mut span_round: SpanRound = SpanRound::new()
                .increment(increment)
                .smallest(smallest.into())
                .mode(mode.into());
            if let Some(largest) = largest {
                span_round = span_round.largest(largest.into());
            }
            let rel = jiff::SpanRelativeTo::from(&relative);
            span_round = span_round.relative(rel);
            self.0
                .round(span_round)
                .map(Self::from)
                .map_err(map_py_value_err)
        } else if days_are_24_hours {
            let mut span_round: SpanRound = SpanRound::new()
                .increment(increment)
                .smallest(smallest.into())
                .mode(mode.into())
                .relative(SpanRelativeTo::days_are_24_hours());
            if let Some(largest) = largest {
                span_round = span_round.largest(largest.into());
            }
            self.0
                .round(span_round)
                .map(Self::from)
                .map_err(map_py_value_err)
        } else {
            let mut span_round: SpanRound = SpanRound::new()
                .increment(increment)
                .smallest(smallest.into())
                .mode(mode.into());
            if let Some(largest) = largest {
                span_round = span_round.largest(largest.into());
            }
            self.0
                .round(span_round)
                .map(Self::from)
                .map_err(map_py_value_err)
        }
    }

    fn signum(&self) -> i8 {
        self.0.signum()
    }

    #[pyo3(signature = (relative = None, *, days_are_24_hours = false))]
    fn total_seconds(
        &self,
        relative: Option<RySpanRelativeTo>,
        days_are_24_hours: bool,
    ) -> PyResult<f64> {
        self.total(JiffUnit::SECOND, relative, days_are_24_hours)
    }

    #[pyo3(signature = (unit, relative = None, *, days_are_24_hours = false))]
    fn total(
        &self,
        unit: JiffUnit,
        relative: Option<RySpanRelativeTo>,
        days_are_24_hours: bool,
    ) -> PyResult<f64> {
        // err on both relative and days_are_24_hours provided
        if relative.is_some() && days_are_24_hours {
            return Err(py_value_error!(
                "Cannot provide relative with days_are_24_hours=True",
            ));
        }

        if let Some(r) = relative {
            let relative_to: jiff::SpanRelativeTo = (&r).into();
            let r = self
                .0
                .total((unit.into_inner(), relative_to))
                .map_err(map_py_value_err)?;
            Ok(r)
        } else if days_are_24_hours {
            let span_total = SpanRelativeTo::days_are_24_hours();
            let a = self
                .0
                .total((unit.into_inner(), span_total))
                .map_err(map_py_value_err)?;
            Ok(a)
        } else {
            Ok(self.0.total(unit.into_inner()).map_err(map_py_value_err)?)
        }
    }

    #[staticmethod]
    fn from_any<'py>(value: &Bound<'py, PyAny>) -> PyResult<Bound<'py, Self>> {
        let py = value.py();
        if let Some(val) = value.cast_exact_opt::<Self>() {
            Ok(val.as_borrowed().into_bound())
        } else if let Ok(pystr) = value.cast::<pyo3::types::PyString>() {
            let s = pystr.extract::<&str>()?;
            Self::from_str(s).map(|dt| dt.into_pyobject(py))?
        } else if let Ok(pybytes) = value.cast::<pyo3::types::PyBytes>() {
            let s = String::from_utf8_lossy(pybytes.as_bytes());
            Self::from_str(&s).map(|dt| dt.into_pyobject(py))?
        } else if let Some(v) = value.cast_exact_opt::<PyFloat>() {
            let f = v.extract::<f64>()?;
            let sd = RySignedDuration::py_try_from_secs_f64(f)?;
            let span = jiff::Span::try_from(sd.0).map_err(map_py_overflow_err)?;
            Self::from(span).into_pyobject(py)
        } else if let Some(v) = value.cast_exact_opt::<PyInt>() {
            let i = v.extract::<i64>()?;
            let sd = SignedDuration::from_secs(i);
            Span::try_from(sd)
                .map(Self::from)
                .map_err(map_py_overflow_err)
                .and_then(|dt| dt.into_pyobject(py))
        } else if let Ok(d) = value.extract::<JiffSpan>() {
            Self::from(d).into_pyobject(py)
        } else {
            let valtype = any_repr!(value);
            py_type_err!("TimeSpan conversion error: {valtype}")
        }
    }
    // ========================================================================
    // PYDANTIC
    // ========================================================================

    #[cfg(feature = "pydantic")]
    #[staticmethod]
    fn _pydantic_validate<'py>(value: &Bound<'py, PyAny>) -> PyResult<Bound<'py, Self>> {
        Self::from_any(value).map_err(map_py_value_err)
    }

    #[cfg(feature = "pydantic")]
    #[classmethod]
    fn __get_pydantic_core_schema__<'py>(
        cls: &Bound<'py, ::pyo3::types::PyType>,
        source: &Bound<'py, PyAny>,
        handler: &Bound<'py, PyAny>,
    ) -> PyResult<Bound<'py, PyAny>> {
        use ryo3_pydantic::GetPydanticCoreSchemaCls;
        Self::get_pydantic_core_schema(cls, source, handler)
    }
}

impl Display for RySpan {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        // parts that we want are the years, months, weeks, days, hours,
        // minutes, seconds, milliseconds, microseconds, nanoseconds if not
        // zero in the form of kwargs i guess??? tbd
        f.write_str("TimeSpan(")?;
        let mut write_sep = false;

        let years = self.0.get_years();
        if years != 0 {
            write!(f, "years={years}")?;
            write_sep = true;
        }

        let months = self.0.get_months();
        if months != 0 {
            if write_sep {
                f.write_str(", ")?;
            }
            write!(f, "months={months}")?;
            write_sep = true;
        }

        let weeks = self.0.get_weeks();
        if weeks != 0 {
            if write_sep {
                f.write_str(", ")?;
            }
            write!(f, "weeks={weeks}")?;
            write_sep = true;
        }

        let days = self.0.get_days();
        if days != 0 {
            if write_sep {
                f.write_str(", ")?;
            }
            write!(f, "days={days}")?;
            write_sep = true;
        }

        let hours = self.0.get_hours();
        if hours != 0 {
            if write_sep {
                f.write_str(", ")?;
            }
            write!(f, "hours={hours}")?;
            write_sep = true;
        }

        let minutes = self.0.get_minutes();
        if minutes != 0 {
            if write_sep {
                f.write_str(", ")?;
            }
            write!(f, "minutes={minutes}")?;
            write_sep = true;
        }

        let seconds = self.0.get_seconds();
        if seconds != 0 {
            if write_sep {
                f.write_str(", ")?;
            }
            write!(f, "seconds={seconds}")?;
            write_sep = true;
        }

        let milliseconds = self.0.get_milliseconds();
        if milliseconds != 0 {
            if write_sep {
                f.write_str(", ")?;
            }
            write!(f, "milliseconds={milliseconds}")?;
            write_sep = true;
        }

        let microseconds = self.0.get_microseconds();
        if microseconds != 0 {
            if write_sep {
                f.write_str(", ")?;
            }
            write!(f, "microseconds={microseconds}")?;
            write_sep = true;
        }

        let nanoseconds = self.0.get_nanoseconds();
        if nanoseconds != 0 {
            if write_sep {
                f.write_str(", ")?;
            }
            write!(f, "nanoseconds={nanoseconds}")?;
        }

        f.write_str(")")
    }
}

#[derive(Debug, Clone)]
pub(crate) enum RySpanRelativeTo<'a, 'py> {
    Zoned(Borrowed<'a, 'py, RyZoned>),
    Date(Borrowed<'a, 'py, RyDate>),
    DateTime(Borrowed<'a, 'py, RyDateTime>),
}

impl<'a, 'py> FromPyObject<'a, 'py> for RySpanRelativeTo<'a, 'py> {
    type Error = PyErr;

    fn extract(obj: Borrowed<'a, 'py, PyAny>) -> Result<Self, Self::Error> {
        if let Some(z) = obj.cast_exact_opt::<RyZoned>() {
            Ok(Self::Zoned(z))
        } else if let Some(d) = obj.cast_exact_opt::<RyDate>() {
            Ok(Self::Date(d))
        } else if let Some(dt) = obj.cast_exact_opt::<RyDateTime>() {
            Ok(Self::DateTime(dt))
        } else {
            Err(PyErr::new::<pyo3::exceptions::PyTypeError, _>(
                "Expected ZonedDateTime, DateTime, or Date",
            ))
        }
    }
}

impl<'a, 'py> From<&'a RySpanRelativeTo<'a, 'py>> for jiff::SpanRelativeTo<'a> {
    fn from(val: &'a RySpanRelativeTo<'a, 'py>) -> Self {
        match val {
            RySpanRelativeTo::Zoned(z) => jiff::SpanRelativeTo::from(&z.get().0),
            RySpanRelativeTo::Date(d) => jiff::SpanRelativeTo::from(d.get().0),
            RySpanRelativeTo::DateTime(dt) => jiff::SpanRelativeTo::from(dt.get().0),
        }
    }
}

#[derive(Debug, Clone)]
pub(crate) struct RySpanArithmetic<'a, 'py> {
    spanish: Spanish<'a, 'py>,
    relative_to: Option<RySpanRelativeTo<'a, 'py>>,
}

impl<'a, 'py> FromPyObject<'a, 'py> for RySpanArithmetic<'a, 'py> {
    type Error = PyErr;

    fn extract(obj: Borrowed<'a, 'py, PyAny>) -> Result<Self, Self::Error> {
        if let Ok(tup) = obj.cast_exact::<PyTuple>() {
            if tup.len() == 2 {
                let both = tup.extract::<(Spanish<'a, 'py>, RySpanRelativeTo<'a, 'py>)>()?;
                Ok(RySpanArithmetic {
                    spanish: both.0,
                    relative_to: Some(both.1),
                })
            } else {
                py_type_err!("Expected a tuple of length 2 for Span arithmetic with relative")
            }
        } else if let Ok(spanish) = obj.extract::<Spanish<'a, 'py>>() {
            Ok(RySpanArithmetic {
                spanish,
                relative_to: None,
            })
        } else {
            py_type_err!(
                "Expected `<TimeSpan, SignedDuration, Duration, datetime.timedelta>`, or a tuple of length 2 for Span arithmetic with relative",
            )
        }
    }
}

impl<'a, 'py> FromPyOperand<'a, 'py> for RySpanArithmetic<'a, 'py> {
    fn from_py_operand(obj: Borrowed<'a, 'py, PyAny>) -> Option<Self> {
        if let Some(tup) = obj.cast_exact_opt::<PyTuple>() {
            if tup.len() != 2 {
                return None;
            }
            let (spanish, relative_to) = tup
                .extract::<(Spanish<'a, 'py>, RySpanRelativeTo<'a, 'py>)>()
                .ok()?;
            Some(RySpanArithmetic {
                spanish,
                relative_to: Some(relative_to),
            })
        } else {
            Spanish::from_py_operand(obj).map(|spanish| RySpanArithmetic {
                spanish,
                relative_to: None,
            })
        }
    }
}

// OLD WORKAROUND FOR https://github.com/BurntSushi/jiff/issues/683
// impl RySpanArithmetic<'_, '_> {
//     /// jiff 0.2.39 `Span::checked_add` panics (unchecked `+`) on huge durations;
//     /// reject them first (spans max out < 1e13s so jiff would err anyway)
//     /// TODO: revisit and check if fixed
//     fn check_duration_range(&self) -> PyResult<()> {
//         const MAX_SECS: u64 = 1_000_000_000_000_000;
//         let secs = match &self.spanish {
//             Spanish::Span(_) => return Ok(()),
//             Spanish::SignedDuration(sd) => sd.get().0.as_secs().unsigned_abs(),
//             Spanish::DurationLike(DurationLike::Duration(d)) => d.get().inner().as_secs(),
//             Spanish::DurationLike(DurationLike::PyTimeDelta(sd)) => sd.as_secs().unsigned_abs(),
//         };
//         if secs > MAX_SECS {
//             py_overflow_err!("duration out of range for span arithmetic")
//         } else {
//             Ok(())
//         }
//     }
// }

impl<'a, 'py> From<&'a RySpanArithmetic<'a, 'py>> for SpanArithmetic<'a> {
    fn from(value: &'a RySpanArithmetic<'a, 'py>) -> Self {
        if let Some(ref relative_to) = value.relative_to {
            macro_rules! from_relative_to {
                ($x:expr) => {
                    match relative_to {
                        RySpanRelativeTo::Zoned(z) => SpanArithmetic::from(($x, &z.get().0)),
                        RySpanRelativeTo::Date(d) => SpanArithmetic::from(($x, d.get().0)),
                        RySpanRelativeTo::DateTime(dt) => SpanArithmetic::from(($x, dt.get().0)),
                    }
                };
            }
            match &value.spanish {
                Spanish::Span(sp) => from_relative_to!(sp.get().0),
                Spanish::SignedDuration(sd) => from_relative_to!(sd.get().0),
                Spanish::DurationLike(DurationLike::Duration(d)) => {
                    from_relative_to!(*d.get().inner())
                }
                Spanish::DurationLike(DurationLike::PyTimeDelta(sd)) => from_relative_to!(*sd),
            }
        } else {
            SpanArithmetic::from(&value.spanish).days_are_24_hours()
        }
    }
}

#[derive(Debug, Clone)]
pub(crate) enum SpanAddTarget<'a, 'py> {
    Span(RySpanArithmetic<'a, 'py>),
    TemporalType(PyTemporalArg<'a, 'py>),
}

impl<'a, 'py> FromPyObject<'a, 'py> for SpanAddTarget<'a, 'py> {
    type Error = PyErr;

    fn extract(obj: Borrowed<'a, 'py, PyAny>) -> Result<Self, Self::Error> {
        const EXPECTED: &str = "Expected TimeSpan, SignedDuration, datetime.timedelta, a tuple of \
            length 2 for Span arithmetic with relative, or a temporal type";
        Self::from_py_operand(obj).ok_or_else(|| py_type_error!(EXPECTED))
    }
}

impl<'a, 'py> FromPyOperand<'a, 'py> for SpanAddTarget<'a, 'py> {
    fn from_py_operand(obj: Borrowed<'a, 'py, PyAny>) -> Option<Self> {
        use ryo3_core::PyOperandExt;
        obj.operand_match()
            .or(Self::Span)
            .or(Self::TemporalType)
            .ok()
    }
}

trait SpanAdd<'a, 'py> {
    type Target;
    type Output;
    fn add_span(self, py: Python<'py>, span: &RySpan) -> PyResult<Self::Output>;
}

macro_rules! impl_span_add_for_borrowed {
    ($ty:ty) => {
        impl<'a, 'py> SpanAdd<'a, 'py> for Borrowed<'a, 'py, $ty> {
            type Target = $ty;
            type Output = Bound<'py, Self::Target>;
            fn add_span(self, py: Python<'py>, span: &RySpan) -> PyResult<Self::Output> {
                self.get()
                    .0
                    .checked_add(span.0)
                    .map(Self::Target::from)
                    .map_err(map_py_overflow_err)
                    .map(|r| r.into_pyobject(py))?
            }
        }
    };
}

impl_span_add_for_borrowed!(RyDate);
impl_span_add_for_borrowed!(RyDateTime);
impl_span_add_for_borrowed!(RyTime);
impl_span_add_for_borrowed!(RyZoned);
impl_span_add_for_borrowed!(RyTimestamp);

impl<'a, 'py> SpanAdd<'a, 'py> for PyTemporalArg<'a, 'py> {
    type Target = PyAny;
    type Output = Bound<'py, Self::Target>;
    fn add_span(self, py: Python<'py>, span: &RySpan) -> PyResult<Self::Output> {
        match self {
            Self::Date(date) => date.add_span(py, span).map(Bound::into_any),
            Self::DateTime(datetime) => datetime.add_span(py, span).map(Bound::into_any),
            Self::Time(time) => time.add_span(py, span).map(Bound::into_any),
            Self::Zoned(zoned) => zoned.add_span(py, span).map(Bound::into_any),
            Self::Timestamp(timestamp) => timestamp.add_span(py, span).map(Bound::into_any),
        }
    }
}

impl<'a, 'py> SpanAdd<'a, 'py> for RySpanArithmetic<'a, 'py> {
    type Target = RySpan;
    type Output = Bound<'py, Self::Target>;
    fn add_span(self, py: Python<'py>, span: &RySpan) -> PyResult<Self::Output> {
        let span_arithmetic: SpanArithmetic = (&self).into();
        span.0
            .checked_add(span_arithmetic)
            .map(RySpan::from)
            .map_err(map_py_overflow_err)?
            .into_pyobject(py)
    }
}

impl<'a, 'py> SpanAdd<'a, 'py> for SpanAddTarget<'a, 'py> {
    type Target = PyAny;
    type Output = Bound<'py, Self::Target>;

    fn add_span(self, py: Python<'py>, span: &RySpan) -> PyResult<Self::Output> {
        match self {
            Self::Span(span_arithmetic) => {
                let span_arithmetic: SpanArithmetic = (&span_arithmetic).into();
                span.0
                    .checked_add(span_arithmetic)
                    .map(RySpan::from)
                    .map_err(map_py_overflow_err)?
                    .into_pyobject(py)
                    .map(Bound::into_any)
            }
            Self::TemporalType(temporal_type) => temporal_type.add_span(py, span),
        }
    }
}
