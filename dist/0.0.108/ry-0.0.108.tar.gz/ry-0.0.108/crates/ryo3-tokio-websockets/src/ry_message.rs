use std::ops::Deref;
use std::os::raw::c_int;

use bytes::Bytes;
use pyo3::IntoPyObjectExt;
use pyo3::prelude::*;
use pyo3::pybacked::PyBackedStr;
use pyo3::types::{PyDict, PyString, PyTuple};
use ryo3_bytes::{ReadableBuffer, RyBytes};
use ryo3_core::PyTryFrom;
use ryo3_core::macros::{py_type_err, py_value_err, py_value_error};
use tokio_websockets::Message;

use crate::PyWebSocketMessageKind;
use crate::constants::WS_MSG_PINGPONG_PAYLOAD_MAX_LEN;
use crate::types::{PyWsCloseCode, PyWsCloseReason};

#[derive(Debug, Clone)]
#[pyclass(name = "WsMessage", frozen, eq)]
#[cfg_attr(any(not(Py_LIMITED_API), Py_3_14), pyo3(immutable_type))]
#[cfg_attr(feature = "ry", pyo3(module = "ry.ryo3"))]
pub struct RyWsMessage(pub(crate) Message);

impl RyWsMessage {
    fn payload_bytes(&self) -> Bytes {
        self.0.clone().into_payload().into()
    }
}

impl PartialEq for RyWsMessage {
    fn eq(&self, other: &Self) -> bool {
        self.kind() == other.kind() && self.0.as_payload().deref() == other.0.as_payload().deref()
    }
}

#[pymethods]
impl RyWsMessage {
    #[new]
    #[pyo3(signature = (kind, data = None, *, code = None, reason = None))]
    fn py_new(
        kind: PyWebSocketMessageKind,
        data: Option<Bound<'_, PyAny>>,
        code: Option<u16>,
        reason: Option<&str>,
    ) -> PyResult<Self> {
        if matches!(kind, PyWebSocketMessageKind::Close) && data.is_some() {
            return py_value_err!("data not valid for close message")?;
        }
        if !matches!(kind, PyWebSocketMessageKind::Close) && (code.is_some() || reason.is_some()) {
            return py_value_err!("code/reason not valid for non-close message")?;
        }
        match kind {
            PyWebSocketMessageKind::Text => {
                let data = data
                    .ok_or_else(|| py_value_error!("data required for message w/ kind='text'"))?;
                let s = data.extract::<PyBackedStr>()?;
                Ok(Self::from(Message::text(Bytes::from_owner(s))))
            }
            PyWebSocketMessageKind::Binary => {
                let data = data
                    .ok_or_else(|| py_value_error!("data required for message w/ kind='binary'"))?;
                let bytes = data.extract::<RyBytes>()?;
                Ok(Self::from(Message::binary(bytes.into_inner())))
            }
            PyWebSocketMessageKind::Ping => {
                let pl = data
                    .map(|d| d.extract::<PyPingPayload>())
                    .transpose()?
                    .unwrap_or_default();
                Ok(Self::from(pl.into_inner()))
            }
            PyWebSocketMessageKind::Pong => {
                let pl = data
                    .map(|d| d.extract::<PyPongPayload>())
                    .transpose()?
                    .unwrap_or_default();
                Ok(Self::from(pl.into_inner()))
            }
            PyWebSocketMessageKind::Close => {
                let code = code
                    .map(|c| {
                        tokio_websockets::CloseCode::try_from(c)
                            .map(PyWsCloseCode::from)
                            .map_err(|_| py_value_error!("invalid close code: {c}"))
                    })
                    .transpose()?
                    .unwrap_or(PyWsCloseCode::NORMAL_CLOSURE);
                let reason = reason.map(|r| PyWsCloseReason(r.to_owned()));
                Self::close(code, reason)
            }
        }
    }

    #[staticmethod]
    fn text(text: PyBackedStr) -> Self {
        Self::from(Message::text(Bytes::from_owner(text)))
    }

    #[staticmethod]
    fn binary(data: RyBytes) -> Self {
        Self::from(Message::binary(data.into_inner()))
    }

    #[staticmethod]
    #[pyo3(signature = (payload = None))]
    fn ping(payload: Option<PyPingPayload>) -> Self {
        let payload = payload.unwrap_or_else(|| PyPingPayload(Message::ping(Bytes::new())));
        payload.into()
    }

    #[staticmethod]
    #[pyo3(signature = (payload = None))]
    fn pong(payload: Option<PyPongPayload>) -> Self {
        let payload = payload.unwrap_or_else(|| PyPongPayload(Message::pong(Bytes::new())));
        payload.into()
    }
    /// # Panics
    /// - If the `code` is reserved so it cannot be sent.
    /// - If `code` is present and the `reason` exceeds 123 bytes, the
    ///   protocol-imposed limit.
    #[expect(clippy::needless_pass_by_value)]
    #[staticmethod]
    #[pyo3(
        signature = (code = PyWsCloseCode::NORMAL_CLOSURE, reason = None),
        text_signature = "(code=1_000, reason=None)"
    )]
    pub(crate) fn close(code: PyWsCloseCode, reason: Option<PyWsCloseReason>) -> PyResult<Self> {
        // check for reserved codes
        if code.is_reserved() {
            return py_value_err!(
                "close code {} is reserved and cannot be sent",
                u16::from(code.0)
            )?;
        }
        // check that if reason is present/non-empty, code is also present
        let reason = reason.map(|r| r.0).unwrap_or_default();
        Ok(Self::from(Message::close(Some(code.0), reason.as_ref())))
    }

    fn __repr__(&self) -> String {
        format!("{self}")
    }

    fn __len__(&self) -> usize {
        self.0.as_payload().len()
    }

    fn __getnewargs_ex__<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyTuple>> {
        let kwargs = PyDict::new(py);
        let args = if let Some(text) = self.0.as_text() {
            PyTuple::new(
                py,
                [
                    PyWebSocketMessageKind::Text.into_bound_py_any(py)?,
                    text.into_bound_py_any(py)?,
                ],
            )?
        } else if let Some((code, reason)) = self.0.as_close() {
            kwargs.set_item(pyo3::intern!(py, "code"), u16::from(code))?;
            kwargs.set_item(pyo3::intern!(py, "reason"), reason)?;
            PyTuple::new(py, [PyWebSocketMessageKind::Close.into_bound_py_any(py)?])?
        } else {
            let kind = self.kind();
            PyTuple::new(
                py,
                [
                    kind.into_bound_py_any(py)?,
                    self.payload_bytes().as_ref().into_bound_py_any(py)?,
                ],
            )?
        };
        PyTuple::new(
            py,
            [args.into_bound_py_any(py)?, kwargs.into_bound_py_any(py)?],
        )
    }

    #[expect(unsafe_code, clippy::needless_pass_by_value, clippy::ptr_as_ptr)]
    unsafe fn __getbuffer__(
        slf: PyRef<Self>,
        view: *mut pyo3::ffi::Py_buffer,
        flags: c_int,
    ) -> PyResult<()> {
        unsafe {
            let bytes = slf.0.as_payload().deref();
            let ret = pyo3::ffi::PyBuffer_FillInfo(
                view,
                slf.as_ptr() as *mut _,
                bytes.as_ptr() as *mut _,
                bytes.len().try_into()?,
                1, // read only
                flags,
            );
            if ret == -1 {
                return Err(PyErr::fetch(slf.py()));
            }
            Ok(())
        }
    }

    #[expect(unsafe_code, clippy::unused_self)]
    unsafe fn __releasebuffer__(&self, _view: *mut pyo3::ffi::Py_buffer) {}

    #[getter]
    fn kind(&self) -> PyWebSocketMessageKind {
        self.into()
    }

    #[getter]
    fn is_text(&self) -> bool {
        self.0.is_text()
    }

    #[getter]
    fn is_binary(&self) -> bool {
        self.0.is_binary()
    }

    #[getter]
    fn is_close(&self) -> bool {
        self.0.is_close()
    }

    #[getter]
    fn is_ping(&self) -> bool {
        self.0.is_ping()
    }

    #[getter]
    fn is_pong(&self) -> bool {
        self.0.is_pong()
    }

    /// Parse the message payload as JSON
    #[cfg(feature = "json")]
    #[pyo3(
        signature = (
            *,
            allow_inf_nan = false,
            cache_mode = ryo3_jiter::StringCacheMode::All,
            partial_mode = ryo3_jiter::PartialMode::Off,
            catch_duplicate_keys = false,
        ),
        text_signature = "(self, *, allow_inf_nan=False, cache_mode=\"all\", partial_mode=False, catch_duplicate_keys=False)"
    )]
    fn json<'py>(
        &self,
        py: Python<'py>,
        allow_inf_nan: bool,
        cache_mode: ryo3_jiter::StringCacheMode,
        partial_mode: ryo3_jiter::PartialMode,
        catch_duplicate_keys: bool,
    ) -> Result<Bound<'py, PyAny>, ryo3_jiter::RyJSONDecodeError> {
        let options = ryo3_jiter::JiterParseOptions::new()
            .with_allow_inf_nan(allow_inf_nan)
            .with_cache_mode(cache_mode)
            .with_partial_mode(partial_mode)
            .with_catch_duplicate_keys(catch_duplicate_keys);
        options.parse(py, self.0.as_payload())
    }

    fn __bytes__<'py>(&'py self, py: Python<'py>) -> Bound<'py, pyo3::types::PyBytes> {
        pyo3::types::PyBytes::new(py, self.0.as_payload())
    }

    #[getter]
    fn data(&self) -> PyPayLoadData<'_> {
        self.into()
    }

    #[getter]
    fn payload(&self) -> RyBytes {
        RyBytes::from(self.payload_bytes())
    }

    #[getter]
    fn code(&self) -> Option<u16> {
        self.0.as_close().map(|(code, _)| u16::from(code))
    }

    #[getter]
    fn reason(&self) -> Option<String> {
        self.0.as_close().map(|(_, reason)| reason.to_owned())
    }
}

impl std::fmt::Display for RyWsMessage {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        if let Some(text) = self.0.as_text() {
            write!(f, "WsMessage.text({text:?})")
        } else if let Some((code, reason)) = self.0.as_close() {
            write!(
                f,
                "WsMessage.close(code={}, reason={reason:?})",
                u16::from(code)
            )
        } else if self.0.is_binary() {
            write!(f, "WsMessage.binary({:?})", self.payload_bytes())
        } else if self.0.is_ping() {
            write!(f, "WsMessage.ping({:?})", self.payload_bytes())
        } else if self.0.is_pong() {
            write!(f, "WsMessage.pong({:?})", self.payload_bytes())
        } else {
            write!(f, "WsMessage(unknown)")
        }
    }
}

enum PyPayLoadData<'a> {
    Text(&'a str),
    Binary(Bytes),
}

impl<'a> From<&'a RyWsMessage> for PyPayLoadData<'a> {
    fn from(msg: &'a RyWsMessage) -> Self {
        if let Some(text) = msg.0.as_text() {
            Self::Text(text)
        } else {
            Self::Binary(msg.payload_bytes())
        }
    }
}

impl<'py> IntoPyObject<'py> for PyPayLoadData<'py> {
    type Target = PyAny;

    type Output = Bound<'py, PyAny>;

    type Error = PyErr;

    fn into_pyobject(self, py: Python<'py>) -> Result<Self::Output, Self::Error> {
        match self {
            PyPayLoadData::Text(s) => s.into_bound_py_any(py),
            PyPayLoadData::Binary(b) => RyBytes::from(b).into_bound_py_any(py),
        }
    }
}

pub(crate) enum PyMessageLike {
    Message(RyWsMessage),
    Text(PyBackedStr),
    Bytes(Bytes),
}

impl<'py> FromPyObject<'_, 'py> for PyMessageLike {
    type Error = PyErr;

    fn extract(obj: Borrowed<'_, 'py, PyAny>) -> PyResult<Self> {
        use ryo3_core::PyCastExactOpt;
        if let Some(msg) = obj.cast_exact_opt::<RyWsMessage>() {
            Ok(Self::Message(msg.get().clone()))
        } else if obj.is_instance_of::<PyString>() {
            // propagate (e.g. lone surrogates can't be utf-8 encoded)
            Ok(Self::Text(obj.extract::<PyBackedStr>()?))
        } else if let Ok(bytes) = obj.extract::<ReadableBuffer>() {
            Ok(Self::Bytes(bytes.into_bytes()))
        } else {
            py_type_err!("expected Message, str, or bytes-like object")
        }
    }
}

#[derive(Debug)]
pub(crate) struct PyPingPayload(pub(crate) Message);

impl PyPingPayload {
    pub(crate) fn into_inner(self) -> Message {
        self.0
    }
}

impl PyPingPayload {
    #[inline]
    fn check_len(len: usize) -> PyResult<()> {
        if len > WS_MSG_PINGPONG_PAYLOAD_MAX_LEN {
            py_value_err!("ping-payload exceeds the websocket limit of 125 bytes")
        } else {
            Ok(())
        }
    }
}

impl TryFrom<Bytes> for PyPingPayload {
    type Error = PyErr;

    fn try_from(value: Bytes) -> PyResult<Self> {
        Self::check_len(value.len())?;
        Ok(Self(Message::ping(value)))
    }
}

impl PyTryFrom<ReadableBuffer<'_, '_>> for PyPingPayload {
    fn py_try_from(value: ReadableBuffer<'_, '_>) -> PyResult<Self> {
        // check before `into_bytes` to avoid copying an oversized buffer
        Self::check_len(value.as_slice().len())?;
        Ok(Self(Message::ping(value.into_bytes())))
    }
}

impl std::default::Default for PyPingPayload {
    fn default() -> Self {
        Self(Message::ping(Bytes::new()))
    }
}

impl<'py> FromPyObject<'_, 'py> for PyPingPayload {
    type Error = PyErr;

    fn extract(obj: Borrowed<'_, 'py, PyAny>) -> PyResult<Self> {
        obj.extract::<ReadableBuffer>().map(Self::py_try_from)?
    }
}

#[derive(Debug)]
pub(crate) struct PyPongPayload(pub(crate) Message);

impl PyPongPayload {
    pub(crate) fn into_inner(self) -> Message {
        self.0
    }
}

impl std::default::Default for PyPongPayload {
    fn default() -> Self {
        Self(Message::pong(Bytes::new()))
    }
}

impl PyPongPayload {
    #[inline]
    fn check_len(len: usize) -> PyResult<()> {
        if len > WS_MSG_PINGPONG_PAYLOAD_MAX_LEN {
            py_value_err!("pong-payload exceeds the websocket limit of 125 bytes")
        } else {
            Ok(())
        }
    }
}

impl TryFrom<Bytes> for PyPongPayload {
    type Error = PyErr;

    fn try_from(value: Bytes) -> PyResult<Self> {
        Self::check_len(value.len())?;
        Ok(Self(Message::pong(value)))
    }
}

impl PyTryFrom<ReadableBuffer<'_, '_>> for PyPongPayload {
    fn py_try_from(value: ReadableBuffer<'_, '_>) -> PyResult<Self> {
        // check before `into_bytes` to avoid copying an oversized buffer
        Self::check_len(value.as_slice().len())?;
        Ok(Self(Message::pong(value.into_bytes())))
    }
}

impl<'py> FromPyObject<'_, 'py> for PyPongPayload {
    type Error = PyErr;

    fn extract(obj: Borrowed<'_, 'py, PyAny>) -> PyResult<Self> {
        obj.extract::<ReadableBuffer<'_, '_>>()
            .map(Self::py_try_from)?
    }
}
