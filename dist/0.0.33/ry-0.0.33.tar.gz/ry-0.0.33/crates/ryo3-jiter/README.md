# `ryo3-jiter`

ryo3-wrapper for `jiter` crate

Provides jitter wrapper that uses `PyBackedStr` and `PyBackedBytes` and
allows for parsing json from bytes or str (which jiter-python does not as
of [2024-05-29])

[//]: # (<GENERATED>)

## Ref:

- docs.rs: [https://docs.rs/jiter](https://docs.rs/jiter)
- crates: [https://crates.io/crates/jiter](https://crates.io/crates/jiter)

[//]: # (</GENERATED>)
