"""ryo3-reqwest types"""

import typing as t

import ry
from ry._types import Buffer, Unpack
from ry.ryo3._cookie import Cookie
from ry.ryo3._encoding_rs import Encoding
from ry.ryo3._http import Headers, HttpStatus, HttpVersionLike
from ry.ryo3._std import Duration, SocketAddr
from ry.ryo3._url import URL

_Body: t.TypeAlias = (
    Buffer
    | t.Generator[Buffer]
    | t.AsyncGenerator[Buffer]
    | t.Iterable[Buffer]
    | t.AsyncIterable[Buffer]
)
# proxy
_ProxyKw: t.TypeAlias = t.Sequence[Proxy | URL | str] | Proxy | URL | str
# resolve
_ResolveMapLike: t.TypeAlias = dict[str, t.Sequence[SocketAddr]]

class RequestKwargs(t.TypedDict, total=False):
    body: _Body | None
    headers: Headers | dict[str, str] | None
    query: dict[str, t.Any] | t.Sequence[tuple[str, t.Any]] | None
    json: t.Any
    form: t.Any
    multipart: t.Any
    timeout: Duration | None
    basic_auth: tuple[str, str | None] | None
    bearer_auth: str | None
    version: HttpVersionLike | None

class ClientConfig(t.TypedDict):
    headers: Headers | None  # default: None
    cookies: bool
    user_agent: (
        str | bool | None
    )  # None/True => default ("ry/{ry.__version__}"), False => disabled
    redirect: int | None
    resolve: _ResolveMapLike | None  # default: None
    referer: bool
    proxy: list[Proxy] | Proxy | None  # default: None
    hickory_dns: bool
    connection_verbose: bool  # default: False
    # ____ TIMEOUT ____
    timeout: Duration | None  # default: None
    connect_timeout: Duration | None  # default: None
    read_timeout: Duration | None  # default: None
    # ____ COMPRESSION / CONTENT-ENCODING ____
    gzip: bool
    brotli: bool
    deflate: bool
    zstd: bool
    # ____ HTTP1 ____
    http1_only: bool
    https_only: bool
    http1_title_case_headers: bool
    http1_allow_obsolete_multiline_headers_in_responses: bool
    http1_allow_spaces_after_header_name_in_responses: bool
    http1_ignore_invalid_headers_in_responses: bool
    # ____ HTTP2 ____
    http2_prior_knowledge: bool
    http2_initial_stream_window_size: int | None
    http2_initial_connection_window_size: int | None
    http2_adaptive_window: bool
    http2_max_frame_size: int | None
    http2_max_header_list_size: int | None
    http2_keep_alive_interval: Duration | None
    http2_keep_alive_timeout: Duration | None
    http2_keep_alive_while_idle: bool
    # ____ POOL ____
    pool_idle_timeout: Duration | None
    pool_max_idle_per_host: int | None
    # ____ TCP ____
    tcp_keepalive: Duration | None
    tcp_keepalive_interval: Duration | None
    tcp_keepalive_retries: int | None
    tcp_nodelay: bool
    # ____ TLS ____
    identity: Identity | None
    tls_certs_merge: list[Certificate] | None
    tls_certs_only: list[Certificate] | None
    tls_crls_only: list[CertificateRevocationList] | None
    tls_info: bool
    tls_sni: bool
    tls_version_max: t.Literal["1.0", "1.1", "1.2", "1.3"] | None  # default: None
    tls_version_min: t.Literal["1.0", "1.1", "1.2", "1.3"] | None  # default: None
    tls_danger_accept_invalid_certs: bool  # default: False
    tls_danger_accept_invalid_hostnames: bool  # default: False
    # __ UNSTABLE __
    _tls_cached_native_certs: bool  # default: False

@t.final
class Client:
    """experimental client using the `pyo3/experimental-async` feature"""
    def __new__(
        cls,
        *,
        headers: dict[str, str] | Headers | None = None,
        cookies: bool = False,
        user_agent: str | bool | None = None,
        timeout: Duration | None = None,
        connect_timeout: Duration | None = None,
        read_timeout: Duration | None = None,
        redirect: int | None = 10,
        resolve: _ResolveMapLike | None = None,
        referer: bool = True,
        connection_verbose: bool = False,
        gzip: bool = True,
        brotli: bool = True,
        deflate: bool = True,
        zstd: bool = True,
        hickory_dns: bool = True,
        http1_only: bool = False,
        https_only: bool = False,
        http1_title_case_headers: bool = False,
        http1_allow_obsolete_multiline_headers_in_responses: bool = False,
        http1_allow_spaces_after_header_name_in_responses: bool = False,
        http1_ignore_invalid_headers_in_responses: bool = False,
        http2_prior_knowledge: bool = False,
        http2_initial_stream_window_size: int | None = None,
        http2_initial_connection_window_size: int | None = None,
        http2_adaptive_window: bool = False,
        http2_max_frame_size: int | None = None,
        http2_max_header_list_size: int | None = None,
        http2_keep_alive_interval: Duration | None = None,
        http2_keep_alive_timeout: Duration | None = None,
        http2_keep_alive_while_idle: bool = False,
        pool_idle_timeout: Duration | None = ...,  # 90 seconds
        pool_max_idle_per_host: int | None = ...,  # usize::MAX
        tcp_keepalive: Duration | None = ...,  # 15 seconds
        tcp_keepalive_interval: Duration | None = ...,  # 15 seconds
        tcp_keepalive_retries: int | None = 3,
        tcp_nodelay: bool = True,
        identity: Identity | None = None,
        tls_certs_only: list[Certificate] | None = None,
        tls_certs_merge: list[Certificate] | None = None,
        tls_crls_only: list[CertificateRevocationList] | None = None,
        tls_version_min: t.Literal["1.0", "1.1", "1.2", "1.3"] | None = None,
        tls_version_max: t.Literal["1.0", "1.1", "1.2", "1.3"] | None = None,
        tls_info: bool = False,
        tls_sni: bool = True,
        tls_danger_accept_invalid_certs: bool = False,
        tls_danger_accept_invalid_hostnames: bool = False,
        proxy: _ProxyKw | None = None,
        _tls_cached_native_certs: bool = False,
    ) -> t.Self: ...
    def config(self) -> ClientConfig: ...
    async def get(
        self,
        url: URL | str,
        **kwargs: Unpack[RequestKwargs],
    ) -> Response: ...
    async def post(
        self,
        url: URL | str,
        **kwargs: Unpack[RequestKwargs],
    ) -> Response: ...
    async def put(
        self,
        url: URL | str,
        **kwargs: Unpack[RequestKwargs],
    ) -> Response: ...
    async def delete(
        self, url: URL | str, **kwargs: Unpack[RequestKwargs]
    ) -> Response: ...
    async def patch(
        self,
        url: URL | str,
        **kwargs: Unpack[RequestKwargs],
    ) -> Response: ...
    async def options(
        self,
        url: URL | str,
        **kwargs: Unpack[RequestKwargs],
    ) -> Response: ...
    async def head(
        self,
        url: URL | str,
        **kwargs: Unpack[RequestKwargs],
    ) -> Response: ...
    async def fetch(
        self,
        url: URL | str,
        *,
        method: str = "GET",
        **kwargs: Unpack[RequestKwargs],
    ) -> Response: ...
    def fetch_sync(
        self,
        url: URL | str,
        *,
        method: str = "GET",
        **kwargs: Unpack[RequestKwargs],
    ) -> BlockingResponse: ...
    async def __call__(
        self,
        url: URL | str,
        *,
        method: str = "GET",
        **kwargs: Unpack[RequestKwargs],
    ) -> Response: ...

@t.final
class BlockingClient:
    def __new__(
        cls,
        *,
        headers: dict[str, str] | Headers | None = None,
        cookies: bool = False,
        user_agent: str | bool | None = None,
        timeout: Duration | None = None,
        connect_timeout: Duration | None = None,
        read_timeout: Duration | None = None,
        redirect: int | None = 10,
        resolve: _ResolveMapLike | None = None,
        referer: bool = True,
        connection_verbose: bool = False,
        gzip: bool = True,
        brotli: bool = True,
        deflate: bool = True,
        zstd: bool = True,
        hickory_dns: bool = True,
        http1_only: bool = False,
        https_only: bool = False,
        http1_title_case_headers: bool = False,
        http1_allow_obsolete_multiline_headers_in_responses: bool = False,
        http1_allow_spaces_after_header_name_in_responses: bool = False,
        http1_ignore_invalid_headers_in_responses: bool = False,
        http2_prior_knowledge: bool = False,
        http2_initial_stream_window_size: int | None = None,
        http2_initial_connection_window_size: int | None = None,
        http2_adaptive_window: bool = False,
        http2_max_frame_size: int | None = None,
        http2_max_header_list_size: int | None = None,
        http2_keep_alive_interval: Duration | None = None,
        http2_keep_alive_timeout: Duration | None = None,
        http2_keep_alive_while_idle: bool = False,
        pool_idle_timeout: Duration | None = ...,  # 90 seconds
        pool_max_idle_per_host: int | None = ...,  # usize::MAX
        tcp_keepalive: Duration | None = ...,  # 15 seconds
        tcp_keepalive_interval: Duration | None = ...,  # 15 seconds
        tcp_keepalive_retries: int | None = 3,
        tcp_nodelay: bool = True,
        identity: Identity | None = None,
        tls_certs_only: list[Certificate] | None = None,
        tls_certs_merge: list[Certificate] | None = None,
        tls_crls_only: list[CertificateRevocationList] | None = None,
        tls_version_min: t.Literal["1.0", "1.1", "1.2", "1.3"] | None = None,
        tls_version_max: t.Literal["1.0", "1.1", "1.2", "1.3"] | None = None,
        tls_info: bool = False,
        tls_sni: bool = True,
        tls_danger_accept_invalid_certs: bool = False,
        tls_danger_accept_invalid_hostnames: bool = False,
        proxy: _ProxyKw | None = None,
        _tls_cached_native_certs: bool = False,
    ) -> t.Self: ...
    def config(self) -> ClientConfig: ...
    def get(
        self,
        url: URL | str,
        **kwargs: Unpack[RequestKwargs],
    ) -> BlockingResponse: ...
    def post(
        self,
        url: URL | str,
        **kwargs: Unpack[RequestKwargs],
    ) -> BlockingResponse: ...
    def put(
        self,
        url: URL | str,
        **kwargs: Unpack[RequestKwargs],
    ) -> BlockingResponse: ...
    def delete(
        self,
        url: URL | str,
        **kwargs: Unpack[RequestKwargs],
    ) -> BlockingResponse: ...
    def patch(
        self,
        url: URL | str,
        **kwargs: Unpack[RequestKwargs],
    ) -> BlockingResponse: ...
    def options(
        self, url: URL | str, **kwargs: Unpack[RequestKwargs]
    ) -> BlockingResponse: ...
    def head(
        self,
        url: URL | str,
        **kwargs: Unpack[RequestKwargs],
    ) -> BlockingResponse: ...
    def fetch(
        self,
        url: URL | str,
        *,
        method: str = "GET",
        **kwargs: Unpack[RequestKwargs],
    ) -> BlockingResponse: ...
    def __call__(
        self,
        url: URL | str,
        *,
        method: str = "GET",
        **kwargs: Unpack[RequestKwargs],
    ) -> BlockingResponse: ...

@t.final
class ReqwestError(Exception):
    def __new__(cls, *args: t.Any, **kwargs: t.Any) -> t.Self: ...
    def __dbg__(self) -> str: ...
    def is_body(self) -> bool: ...
    def is_builder(self) -> bool: ...
    def is_connect(self) -> bool: ...
    def is_decode(self) -> bool: ...
    def is_redirect(self) -> bool: ...
    def is_request(self) -> bool: ...
    def is_status(self) -> bool: ...
    def is_timeout(self) -> bool: ...
    @property
    def status(self) -> HttpStatus | None: ...
    def url(self) -> URL | None: ...
    def without_url(self) -> None: ...
    def with_url(self, url: URL) -> ReqwestError: ...

@t.final
class Response:
    def __new__(cls) -> t.NoReturn: ...
    @property
    def headers(self) -> Headers: ...
    async def text(self, *, encoding: Encoding = "utf-8") -> str: ...
    async def text_with_charset(self, encoding: Encoding) -> str: ...
    async def json(
        self,
        *,
        allow_inf_nan: bool = False,
        cache_mode: t.Literal[True, False, "all", "keys", "none"] = "all",
        partial_mode: t.Literal[True, False, "off", "on", "trailing-strings"] = False,
        catch_duplicate_keys: bool = False,
    ) -> t.Any: ...
    async def bytes(self) -> ry.Bytes: ...
    def bytes_stream(
        self, min_read_size: int = 0, /
    ) -> ResponseStream: ...  # min_read_size=0 -> None
    def stream(
        self, min_read_size: int = 0, /
    ) -> ResponseStream: ...  # min_read_size=0 -> None
    @property
    def url(self) -> URL: ...
    @property
    def version(
        self,
    ) -> t.Literal["HTTP/0.9", "HTTP/1.0", "HTTP/1.1", "HTTP/2.0", "HTTP/3.0"]: ...
    @property
    def http_version(
        self,
    ) -> t.Literal["HTTP/0.9", "HTTP/1.0", "HTTP/1.1", "HTTP/2.0", "HTTP/3.0"]: ...
    @property
    def redirected(self) -> bool: ...
    @property
    def content_length(self) -> int | None: ...
    @property
    def content_encoding(self) -> str | None: ...
    @property
    def cookies(self) -> list[Cookie] | None: ...
    @property
    def set_cookies(self) -> list[Cookie] | None: ...
    @property
    def body_used(self) -> bool:
        """True if the body has been consumed"""

    @property
    def ok(self) -> bool:
        """True if the status is a success (2xx)"""

    @property
    def remote_addr(self) -> SocketAddr | None: ...
    @property
    def status(self) -> int: ...
    @property
    def status_text(self) -> str: ...
    @property
    def status_code(self) -> HttpStatus: ...
    def __bool__(self) -> bool:
        """Return `True` if the status is a success (2xx)"""

@t.final
class BlockingResponse:
    def __new__(cls) -> t.NoReturn: ...
    @property
    def headers(self) -> Headers: ...
    def text(self, *, encoding: Encoding = "utf-8") -> str: ...
    def text_with_charset(self, encoding: Encoding) -> str: ...
    def json(
        self,
        *,
        allow_inf_nan: bool = False,
        cache_mode: t.Literal[True, False, "all", "keys", "none"] = "all",
        partial_mode: t.Literal[True, False, "off", "on", "trailing-strings"] = False,
        catch_duplicate_keys: bool = False,
    ) -> t.Any: ...
    def bytes(self) -> ry.Bytes: ...
    def bytes_stream(self, min_read_size: int = 0, /) -> BlockingResponseStream: ...
    def stream(self, min_read_size: int = 0, /) -> BlockingResponseStream: ...
    @property
    def url(self) -> URL: ...
    @property
    def version(
        self,
    ) -> t.Literal["HTTP/0.9", "HTTP/1.0", "HTTP/1.1", "HTTP/2.0", "HTTP/3.0"]: ...
    @property
    def http_version(
        self,
    ) -> t.Literal["HTTP/0.9", "HTTP/1.0", "HTTP/1.1", "HTTP/2.0", "HTTP/3.0"]: ...
    @property
    def redirected(self) -> bool: ...
    @property
    def content_length(self) -> int | None: ...
    @property
    def content_encoding(self) -> str | None: ...
    @property
    def cookies(self) -> list[Cookie] | None: ...
    @property
    def set_cookies(self) -> list[Cookie] | None: ...
    @property
    def body_used(self) -> bool:
        """True if the body has been consumed"""

    @property
    def ok(self) -> bool:
        """True if the status is a success (2xx)"""

    @property
    def remote_addr(self) -> SocketAddr | None: ...
    @property
    def status(self) -> int: ...
    @property
    def status_text(self) -> str: ...
    @property
    def status_code(self) -> HttpStatus: ...
    def __bool__(self) -> bool:
        """Return `True` if the status is a success (2xx)"""

@t.final
class ResponseStream:
    def __aiter__(self) -> ResponseStream: ...
    async def __anext__(self) -> ry.Bytes: ...
    async def readall(self) -> ry.Bytes: ...
    async def take(self, n: int = 1) -> list[ry.Bytes]: ...
    @t.overload
    async def collect(self, join: t.Literal[True]) -> ry.Bytes: ...
    @t.overload
    async def collect(self, join: t.Literal[False] = False) -> list[ry.Bytes]: ...

@t.final
class BlockingResponseStream:
    def __iter__(self) -> BlockingResponseStream: ...
    def __next__(self) -> ry.Bytes: ...
    def readall(self) -> ry.Bytes: ...
    def take(self, n: int = 1) -> list[ry.Bytes]: ...
    def collect(self) -> list[ry.Bytes]: ...

async def fetch(
    url: URL | str,
    *,
    method: str = "GET",
    body: _Body | None = None,
    headers: Headers | dict[str, str] | None = None,
    query: dict[str, t.Any] | t.Sequence[tuple[str, t.Any]] | None = None,
    json: t.Any = None,
    form: t.Any = None,
    multipart: t.Any | None = None,
    timeout: Duration | None = None,
    basic_auth: tuple[str, str | None] | None = None,
    bearer_auth: str | None = None,
    version: HttpVersionLike | None = None,
) -> Response: ...
def fetch_sync(
    url: URL | str,
    *,
    method: str = "GET",
    body: _Body | None = None,
    headers: Headers | dict[str, str] | None = None,
    query: dict[str, t.Any] | t.Sequence[tuple[str, t.Any]] | None = None,
    json: t.Any = None,
    form: t.Any = None,
    multipart: t.Any | None = None,
    timeout: Duration | None = None,
    basic_auth: tuple[str, str | None] | None = None,
    bearer_auth: str | None = None,
    version: HttpVersionLike | None = None,
) -> BlockingResponse: ...

@t.final
class Certificate:
    def __bytes__(self) -> bytes: ...
    def __hash__(self) -> int: ...
    def __eq__(self, other: object) -> bool: ...
    def __ne__(self, other: object) -> bool: ...
    @classmethod
    def from_der(cls, der: Buffer) -> t.Self: ...
    @classmethod
    def from_pem(cls, pem: Buffer) -> t.Self: ...
    @classmethod
    def from_pem_bundle(cls, pem_bundle: Buffer) -> list[t.Self]: ...

@t.final
class CertificateRevocationList:
    def __new__(cls, pem: Buffer) -> t.Self: ...
    def __bytes__(self) -> bytes: ...
    def __hash__(self) -> int: ...
    def __eq__(self, other: object) -> bool: ...
    def __ne__(self, other: object) -> bool: ...
    @classmethod
    def from_pem(cls, pem: Buffer) -> t.Self: ...
    @classmethod
    def from_pem_bundle(cls, pem_bundle: Buffer) -> list[t.Self]: ...

@t.final
class Identity:
    def __new__(cls, pem: Buffer) -> t.Self: ...
    def __bytes__(self) -> bytes: ...
    def __hash__(self) -> int: ...
    def __eq__(self, other: object) -> bool: ...
    def __ne__(self, other: object) -> bool: ...
    @classmethod
    def from_pem(cls, pem: Buffer) -> t.Self: ...

class ProxyKwargs(t.TypedDict, total=False):
    basic_auth: tuple[str, str] | None
    no_proxy: str | None
    headers: Headers | dict[str, str] | None

@t.final
class Proxy:
    def __new__(
        cls,
        url: URL | str,
        ptype: t.Literal["http", "https", "all"] = "http",
        *,
        basic_auth: tuple[str, str] | None = None,
        headers: Headers | dict[str, str] | None = None,
        no_proxy: str | None = None,
    ) -> t.Self: ...
    @staticmethod
    def all(
        url: URL | str,
        *,
        basic_auth: tuple[str, str] | None = None,
        headers: Headers | dict[str, str] | None = None,
        no_proxy: str | None = None,
    ) -> Proxy: ...
    @staticmethod
    def http(
        url: URL | str,
        *,
        basic_auth: tuple[str, str] | None = None,
        headers: Headers | dict[str, str] | None = None,
        no_proxy: str | None = None,
    ) -> Proxy: ...
    @staticmethod
    def https(
        url: URL | str,
        *,
        basic_auth: tuple[str, str] | None = None,
        headers: Headers | dict[str, str] | None = None,
        no_proxy: str | None = None,
    ) -> Proxy: ...
    # -------------------------------------------------------------------------
    # BUILDERS
    # -------------------------------------------------------------------------
    def basic_auth(self, username: str, password: str) -> Proxy: ...
    def no_proxy(self, url: str) -> Proxy: ...
    def headers(self, headers: Headers | dict[str, str]) -> Proxy: ...
    # -------------------------------------------------------------------------
    # DUNDERS
    # -------------------------------------------------------------------------
    def __eq__(self, other: object) -> bool: ...
    def __hash__(self) -> int: ...
