"""ryo3-tokio-websockets types"""

import datetime as pydt
import sys
import typing as t
from collections.abc import Generator
from types import TracebackType

from ry import Bytes
from ry._types import Buffer
from ry.ryo3._http import Headers, HttpStatus
from ry.ryo3._std import Duration
from ry.ryo3._url import URL

if sys.version_info >= (3, 12):
    from collections.abc import Buffer as Buffer
else:
    from typing_extensions import Buffer as Buffer

_TimeoutLike: t.TypeAlias = Duration | pydt.timedelta | float

class WebSocketConfig(t.TypedDict):
    headers: Headers
    max_payload_len: int
    frame_size: int
    flush_threshold: int
    close_timeout: Duration | None
    recv_timeout: Duration | None

_ReadyState: t.TypeAlias = t.Literal[
    0,  # CONNECTING
    1,  # OPEN
    2,  # CLOSING
    3,  # CLOSED
]

@t.final
class WsMessage(Buffer):
    @t.overload
    def __new__(cls, kind: t.Literal["text"], data: str) -> t.Self: ...
    @t.overload
    def __new__(cls, kind: t.Literal["binary"], data: Buffer) -> t.Self: ...
    @t.overload
    def __new__(
        cls, kind: t.Literal["ping", "pong"], data: Buffer | None = None
    ) -> t.Self: ...
    @t.overload
    def __new__(
        cls,
        kind: t.Literal["close"],
        data: None = None,
        *,
        code: int | None = None,  # default: 1000
        reason: str | Buffer | None = None,  # default: ""
    ) -> t.Self: ...
    # -------------------------------------------------------------------------
    # "CLASSMETHODS" (STATIC FACTORY FNS)
    # -------------------------------------------------------------------------
    @staticmethod
    def text(text: str) -> WsMessage:
        """Construct a new text message with the given text data."""
    @staticmethod
    def binary(data: Buffer) -> WsMessage:
        """Construct a new binary message with the given data."""
    @staticmethod
    def ping(payload: Buffer | None = None) -> WsMessage:
        """Construct a new ping message with the given optional payload

        Parameters
        ----------
        payload : Buffer | None, optional
            optional payload data for the ping message, by default None

        Raises
        ------
        ValueError
            if the payload is larger than 125 bytes

        Examples
        --------
        >>> from ry import WsMessage
        >>> ping_msg = WsMessage.ping(b"ping-payload")
        >>> ping_msg.kind
        'ping'
        >>> ping_msg.payload
        Bytes(b"ping-payload")
        >>> too_large_payload = b"x" * 126
        >>> WsMessage.ping(too_large_payload)  # doctest: +IGNORE_EXCEPTION_DETAIL
        Traceback (most recent call last):
            ...
        ValueError: ping-payload exceeds the websocket limit of 125 bytes

        """
    @staticmethod
    def pong(payload: Buffer | None = None) -> WsMessage:
        """Construct a new pong message with the given optional payload

        Parameters
        ----------
        payload : Buffer | None, optional
            optional payload data for the pong message, by default None

        Raises
        ------
        ValueError
            if the payload is larger than 125 bytes

        Examples
        --------
        >>> from ry import WsMessage
        >>> pong_msg = WsMessage.pong(b"pong-payload")
        >>> pong_msg.kind
        'pong'
        >>> pong_msg.payload
        Bytes(b"pong-payload")
        >>> too_large_payload = b"x" * 126
        >>> WsMessage.pong(too_large_payload)  # doctest: +IGNORE_EXCEPTION_DETAIL
        Traceback (most recent call last):
            ...
        ValueError: pong-payload exceeds the websocket limit of 125 bytes

        """
    @staticmethod
    def close(code: int = 1_000, reason: str | Buffer | None = None) -> WsMessage:
        """Construct a new close message with the given close-code and reason"""

    # -------------------------------------------------------------------------
    # PROPERTIES
    # -------------------------------------------------------------------------

    @property
    def kind(self) -> t.Literal["text", "binary", "close", "ping", "pong"]:
        """Return the message kind as a string literal."""
    @property
    def is_text(self) -> bool:
        """Return `True` if this is a text message, `False` otherwise"""
    @property
    def is_binary(self) -> bool:
        """Return `True` if this is a binary message, `False` otherwise"""
    @property
    def is_close(self) -> bool:
        """Return `True` if this is a close message, `False` otherwise"""
    @property
    def is_ping(self) -> bool:
        """Return `True` if this is a ping message, `False` otherwise"""
    @property
    def is_pong(self) -> bool:
        """Return `True` if this is a pong message, `False` otherwise"""
    @property
    def data(self) -> str | Bytes:
        """Return the message data as a `str` for text messages or `Bytes` for binary messages"""
    @property
    def payload(self) -> Bytes:
        """Return the message payload as a `Bytes` object for any message kind"""
    @property
    def code(self) -> int | None:
        """Returns the close code as an integer if the close message"""
    @property
    def reason(self) -> str | None:
        """Returns the close reason as a string if the close message"""
    # -------------------------------------------------------------------------
    # INSTANCE METHODS
    # -------------------------------------------------------------------------
    def json(
        self,
        *,
        allow_inf_nan: bool = False,
        cache_mode: t.Literal[True, False, "all", "keys", "none"] = "all",
        partial_mode: t.Literal[True, False, "off", "on", "trailing-strings"] = False,
        catch_duplicate_keys: bool = False,
    ) -> t.Any:
        """Parse the message payload as JSON"""
    def __bytes__(self) -> bytes:
        """Return message payload as `builtins.bytes`"""
    def __len__(self) -> int:
        """Return the length of the message payload in bytes"""

@t.final
class WebSocket:
    def __new__(
        cls,
        uri: URL | str,
        *,
        headers: Headers | dict[str, str] | None = None,
        max_payload_len: int = 67_108_864,
        frame_size: int = 4_194_304,
        flush_threshold: int = 8_192,
        close_timeout: _TimeoutLike | None = 10,
        recv_timeout: _TimeoutLike | None = None,
    ) -> t.Self: ...
    def config(self) -> WebSocketConfig:
        """Return the `WebSocketConfig` as a dict"""
    @property
    def uri(self) -> str: ...
    @property
    def status(self) -> HttpStatus | None:
        """Return the HTTP status of the websocket handshake if connected"""

    @property
    def headers(self) -> Headers | None:
        """Return the HTTP headers of the websocket handshake if connected"""
    @property
    def closed(self) -> bool:
        """Return `True` if the WebSocket is closed, `False` otherwise"""
    @property
    def open(self) -> bool:
        """Return `True` if the WebSocket is open, `False` otherwise"""
    @property
    def ready_state(self) -> _ReadyState:
        """Return `WebSocket` ready-state (`0`=CONNECTING, `1`=OPEN, `2`=CLOSING, `3`=CLOSED)

        Based on the `WebSocket.readyState` property from the Web API:
        <https://developer.mozilla.org/en-US/docs/Web/API/WebSocket/readyState>
        """
    def __bool__(self) -> bool:
        """Return `True` if the WebSocket is open, `False` otherwise"""

    async def recv(self, timeout: _TimeoutLike | None = None) -> WsMessage:
        """Receive the next message from the WebSocket connection"""
    async def receive(self, timeout: _TimeoutLike | None = None) -> WsMessage:
        """Receive the next message from the WebSocket connection"""
    async def send(self, message: WsMessage | str | Buffer) -> None:
        """Send a message over the WebSocket connection"""
    async def close(
        self, code: int = 1_000, reason: str | Buffer | None = None
    ) -> None:
        """Close the WebSocket connection.

        Parameters
        ----------
        code : int, optional
            close code (default: `1000`=NORMAL_CLOSURE)
        reason : str | Buffer | None, optional
            close reason (max length: 123 bytes), by default None
        """
    async def ping(self, payload: Buffer | None = None) -> None:
        """Send a ping frame over the WebSocket connection"""
    async def pong(self, payload: Buffer | None = None) -> None:
        """Send a pong frame over the WebSocket connection"""
    def __await__(self) -> Generator[t.Any, t.Any, t.Self]: ...
    def __aiter__(self) -> t.Self: ...
    async def __anext__(self) -> WsMessage: ...
    async def __aenter__(self) -> t.Self: ...
    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None: ...

def websocket(
    uri: URL | str,
    *,
    headers: Headers | dict[str, str] | None = None,
    close_timeout: _TimeoutLike = 10,
    recv_timeout: _TimeoutLike | None = None,
    flush_threshold: int = 8_192,
    frame_size: int = 4_194_304,
    max_payload_len: int = 67_108_864,
) -> WebSocket: ...
