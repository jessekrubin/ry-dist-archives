# `ryo3-bytes`

**NOTE:** The current code is a copy-past of the code within the `pyo3-bytes`
crate from the `obstore` library. The goal is to bang out a python wrapper and
merge it back into the `obstore` repo and finally remove it from this crate.

python wrapper for the `bytes` crate

`bytes`:

- [crates.io](https://crates.io/crates/bytes)
- [docs.rs](https://docs.rs/bytes)
