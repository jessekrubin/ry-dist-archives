# Summary

- [README](./index.md)
- [DEVELOPMENT](./development.md)
- [ACKNOWLEDGEMENTS](./acknowledgements.md)

___

- [CHANGELOG](./CHANGELOG.md)

___

- [EXAMPLES](./examples.md)

___

- [API](./api.md)

___

- [food-4-thought](./food-4-thought.md)
