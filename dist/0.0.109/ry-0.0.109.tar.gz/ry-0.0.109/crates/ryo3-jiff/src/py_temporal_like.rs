use pyo3::prelude::*;
use pyo3::{IntoPyObjectExt, PyTypeInfo};
use ryo3_core::FromPyOperand;
use ryo3_macro_rules::{py_overflow_err, py_type_error, py_value_err};

use crate::spanish::Spanish;
use crate::{RyDate, RyDateTime, RySpan, RyTime, RyTimestamp, RyZoned};

#[derive(Debug, Clone)]
pub(crate) enum PyTemporalArg<'a, 'py> {
    Date(Borrowed<'a, 'py, RyDate>),
    DateTime(Borrowed<'a, 'py, RyDateTime>),
    Time(Borrowed<'a, 'py, RyTime>),
    Zoned(Borrowed<'a, 'py, RyZoned>),
    Timestamp(Borrowed<'a, 'py, RyTimestamp>),
}

impl<'a, 'py> FromPyOperand<'a, 'py> for PyTemporalArg<'a, 'py> {
    fn from_py_operand(obj: Borrowed<'a, 'py, PyAny>) -> Option<Self> {
        use ryo3_core::PyOperandExt;
        obj.operand_match()
            .or(Self::Zoned)
            .or(Self::Timestamp)
            .or(Self::DateTime)
            .or(Self::Date)
            .or(Self::Time)
            .ok()
    }
}

trait PyTemporalTypeName {
    const PY_NAME: &'static str;
}
macro_rules! impl_py_temporal_type_name {
    ($ty:ty, $name:expr) => {
        impl PyTemporalTypeName for $ty {
            const PY_NAME: &'static str = $name;
        }
    };
}
impl_py_temporal_type_name!(RyDate, "Date");
impl_py_temporal_type_name!(RyDateTime, "DateTime");
impl_py_temporal_type_name!(RyTime, "Time");
impl_py_temporal_type_name!(RyZoned, "ZonedDateTime");
impl_py_temporal_type_name!(RyTimestamp, "Timestamp");

impl<'a, 'py> FromPyObject<'a, 'py> for PyTemporalArg<'a, 'py> {
    type Error = PyErr;

    fn extract(obj: Borrowed<'a, 'py, PyAny>) -> Result<Self, Self::Error> {
        Self::from_py_operand(obj).ok_or_else(|| {
            py_type_error!("Expected a Date, DateTime, Time, Timestamp, or ZonedDateTime type")
        })
    }
}

/// Input to temporal types subtraction ops
pub(crate) enum TemporalSubInput<'a, 'py, T> {
    Temporal(Borrowed<'a, 'py, T>),
    Spanish(Spanish<'a, 'py>),
}

impl<'a, 'py, T> FromPyOperand<'a, 'py> for TemporalSubInput<'a, 'py, T>
where
    T: PyTypeInfo,
{
    fn from_py_operand(ob: Borrowed<'a, 'py, PyAny>) -> Option<Self> {
        use ryo3_core::PyOperandExt;
        ob.operand_match().or(Self::Temporal).or(Self::Spanish).ok()
    }
}

impl<'a, 'py, T> FromPyObject<'a, 'py> for TemporalSubInput<'a, 'py, T>
where
    T: PyTemporalTypeName + PyTypeInfo,
{
    type Error = PyErr;

    fn extract(ob: Borrowed<'a, 'py, PyAny>) -> Result<Self, Self::Error> {
        Self::from_py_operand(ob)
            .ok_or_else(|| py_type_error!("Expected a {} or span-like object", T::PY_NAME))
    }
}

pub(crate) enum TemporalSubOutput<T> {
    ValueError(jiff::Error),
    Overflow(jiff::Error),
    Temporal(T),
    Span(RySpan),
}

impl<T> From<jiff::Span> for TemporalSubOutput<T> {
    fn from(span: jiff::Span) -> Self {
        Self::Span(RySpan(span))
    }
}

impl<T> From<RySpan> for TemporalSubOutput<T> {
    fn from(span: RySpan) -> Self {
        Self::Span(span)
    }
}

impl<T> From<Result<T, jiff::Error>> for TemporalSubOutput<T> {
    fn from(result: Result<T, jiff::Error>) -> Self {
        match result {
            Ok(value) => Self::Temporal(value),
            Err(e) => {
                if e.is_range() {
                    Self::Overflow(e)
                } else {
                    Self::ValueError(e)
                }
            }
        }
    }
}

impl<'py, T> IntoPyObject<'py> for TemporalSubOutput<T>
where
    T: IntoPyObject<'py>,
{
    type Target = PyAny;
    type Output = Bound<'py, Self::Target>;
    type Error = PyErr;
    fn into_pyobject(self, py: Python<'py>) -> Result<Self::Output, Self::Error> {
        match self {
            Self::Temporal(ts) => ts.into_bound_py_any(py),
            Self::Span(span) => span.into_pyobject(py).map(Bound::into_any),
            Self::Overflow(err) => py_overflow_err!("{err}"),
            Self::ValueError(err) => py_value_err!("{err}"),
        }
    }
}
