use serde::Serialize;

use crate::{
    RyDate, RyDateTime, RyISOWeekDate, RySignedDuration, RySpan, RyTime, RyTimeZone, RyTimestamp,
    RyZoned,
};

impl Serialize for RyTimeZone {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        jiff::fmt::serde::tz::required::serialize(&self.0, serializer)
    }
}

// implement the deserialize macro for a ry-jiff-wrapper type to avoid the
// annoying clippy error messages
macro_rules! impl_deserialize {
    ($ry_type:ty, $jiff_type:ty) => {
        impl<'de> serde::Deserialize<'de> for $ry_type {
            fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                let inner: $jiff_type = serde::Deserialize::deserialize(deserializer)?;
                Ok(Self::from(inner))
            }
        }
    };
}

impl_deserialize!(RyDate, jiff::civil::Date);
impl_deserialize!(RyDateTime, jiff::civil::DateTime);
impl_deserialize!(RySignedDuration, jiff::SignedDuration);
impl_deserialize!(RySpan, jiff::Span);
impl_deserialize!(RyTime, jiff::civil::Time);
impl_deserialize!(RyTimestamp, jiff::Timestamp);
impl_deserialize!(RyZoned, jiff::Zoned);
impl_deserialize!(RyISOWeekDate, jiff::civil::ISOWeekDate);

// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use jiff::Span;
    use serde::{Deserialize, Serialize};

    use crate::{
        RyDate, RyDateTime, RyISOWeekDate, RySignedDuration, RySpan, RyTime, RyTimestamp, RyZoned,
    };

    #[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
    struct Stuff {
        date: RyDate,
        datetime: RyDateTime,
        signed_duration: RySignedDuration,
        span: RySpan,
        time: RyTime,
        timestamp: RyTimestamp,
        zoned: RyZoned,
        iso_week_date: RyISOWeekDate,
    }

    #[test]
    fn test_deserialize_and_serialize() {
        let ry_time = RyTime::py_new(4, 3, 2, 1).unwrap();
        let ry_date = RyDate::py_new(2025, 5, 21).unwrap();
        let ry_datetime = ry_date.at(4, 3, 2, 1).unwrap();
        let ry_zoned = ry_datetime.in_tz("America/New_York").unwrap();
        let ry_signed_duration = RySignedDuration::py_new(123, 123).unwrap();
        let ry_timestamp = RyTimestamp::py_new(1234, 5678).unwrap();
        let span = Span::new().days(1).hours(2).minutes(4);
        let ry_span = RySpan::from(span);

        let s = Stuff {
            date: ry_date,
            datetime: ry_datetime,
            signed_duration: ry_signed_duration,
            span: ry_span,
            time: ry_time,
            timestamp: ry_timestamp,
            zoned: ry_zoned,
            iso_week_date: ry_date.iso_week_date(),
        };

        let serialized = serde_json::to_string_pretty(&s).unwrap();

        println!("Serialized: {serialized}");
        let deserialized: Stuff = serde_json::from_str(&serialized).unwrap();
        assert_eq!(s, deserialized);
    }
}
