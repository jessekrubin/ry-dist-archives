use std::hash::{DefaultHasher, Hash, Hasher};
use std::ops::Sub;

use jiff::tz::TimeZone;
use jiff::{Timestamp, TimestampArithmetic, TimestampRound, Zoned};
use pyo3::BoundObject;
use pyo3::prelude::*;
use pyo3::types::{PyFloat, PyInt, PyTuple};
use ryo3_core::{
    PyAsciiString, PyCastExactOpt, PyCastOpt, PyNotImplementedOr, PyOperandArg,
    map_py_overflow_err, map_py_value_err,
};
use ryo3_jiff_core::{JiffDate, JiffRoundMode, JiffTime, JiffTimestamp, JiffUnit};
use ryo3_macro_rules::{any_repr, py_type_err};

use crate::difference::{RyTimestampDifference, TimestampDifferenceArg};
use crate::py_temporal_like::{TemporalSubInput, TemporalSubOutput};
use crate::round::RyTimestampRound;
use crate::series::RyTimestampSeries;
use crate::spanish::{DurationLike, Spanish};
use crate::util::SpanKwargs;
use crate::{
    RyDate, RyDateTime, RyISOWeekDate, RyOffset, RySignedDuration, RySpan, RyTime, RyTimeZone,
    RyZoned,
};

#[cfg_attr(feature = "serde", derive(serde::Serialize), serde(transparent))]
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd)]
#[pyclass(name = "Timestamp", frozen, immutable_type, eq, ord)]
#[cfg_attr(feature = "ry", pyo3(module = "ry.ryo3"))]
pub struct RyTimestamp(pub(crate) Timestamp);

impl RyTimestamp {
    pub fn new(second: i64, nanosecond: i32) -> Result<Self, jiff::Error> {
        Timestamp::new(second, nanosecond).map(Self)
    }

    fn checked_sub<T: Into<TimestampArithmetic>>(self, other: T) -> Result<Self, jiff::Error> {
        self.0.checked_sub(other).map(Self)
    }
}

impl RyTimestamp {
    fn try_add(&self, other: Spanish<'_, '_>) -> PyResult<Self> {
        self.0
            .checked_add(other)
            .map(Self::from)
            .map_err(map_py_overflow_err)
    }

    fn try_sub_temporal(&self, other: TemporalSubInput<'_, '_, Self>) -> TemporalSubOutput<Self> {
        match other {
            TemporalSubInput::Temporal(ob) => self.0.sub(ob.get().0).into(),
            TemporalSubInput::Spanish(spanish) => self.checked_sub(spanish).into(),
        }
    }
}

#[pymethods]
#[expect(clippy::trivially_copy_pass_by_ref)]
impl RyTimestamp {
    #[new]
    #[pyo3(signature = (second = 0, nanosecond = 0))]
    pub(crate) fn py_new(second: i64, nanosecond: i32) -> PyResult<Self> {
        Self::new(second, nanosecond).map_err(map_py_value_err)
    }

    #[classattr]
    fn __match_args__() -> (&'static str, &'static str) {
        ("second", "nanosecond")
    }

    fn __getnewargs__<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyTuple>> {
        PyTuple::new(
            py,
            vec![
                self.as_second().into_pyobject(py)?,
                self.subsec_nanosecond().into_pyobject(py)?,
            ],
        )
    }

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn MIN() -> Self {
        Self(Timestamp::MIN)
    }

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn MAX() -> Self {
        Self(Timestamp::MAX)
    }

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn UNIX_EPOCH() -> Self {
        Self(Timestamp::UNIX_EPOCH)
    }

    #[staticmethod]
    fn now() -> Self {
        Self::from(Timestamp::now())
    }

    #[staticmethod]
    fn from_millisecond(millisecond: i64) -> PyResult<Self> {
        Timestamp::from_millisecond(millisecond)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    fn date(&self) -> RyDate {
        RyDate::from(self)
    }

    fn time(&self) -> RyTime {
        RyTime::from(self)
    }

    fn datetime(&self) -> RyDateTime {
        RyDateTime::from(self)
    }

    fn iso_week_date(&self) -> RyISOWeekDate {
        RyISOWeekDate::from(self)
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_zoned(&self, time_zone: &RyTimeZone) -> RyZoned {
        Zoned::new(self.0, time_zone.to_inner()).into()
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_dict<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, ::pyo3::types::PyDict>> {
        use crate::interns;
        let dict = ::pyo3::types::PyDict::new(py);
        dict.set_item(interns::second(py), self.0.as_second())?;
        dict.set_item(interns::nanosecond(py), self.0.subsec_nanosecond())?;
        Ok(dict)
    }

    #[staticmethod]
    fn from_pydatetime(datetime: JiffTimestamp) -> Self {
        Self::from(datetime)
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_py(&self) -> JiffTimestamp {
        self.to_pydatetime()
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_pydatetime(&self) -> JiffTimestamp {
        JiffTimestamp::new(self.0)
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_pydate(&self) -> JiffDate {
        self.0.to_zoned(TimeZone::UTC).date().into()
    }

    #[expect(clippy::wrong_self_convention)]
    fn to_pytime(&self) -> JiffTime {
        self.0.to_zoned(TimeZone::UTC).time().into()
    }

    #[pyo3(name = "to_string")]
    fn py_to_string(&self) -> PyAsciiString {
        self.0.to_string().into()
    }

    fn __str__(&self) -> PyAsciiString {
        self.0.to_string().into()
    }

    fn __repr__(&self) -> PyAsciiString {
        format!("{self}").into()
    }

    fn __hash__(&self) -> u64 {
        let mut hasher = DefaultHasher::new();
        // use nanosecond as hash as it is lossless
        self.0.as_nanosecond().hash(&mut hasher);
        hasher.finish()
    }

    fn __add__(&self, other: PyOperandArg<Spanish<'_, '_>>) -> PyResult<PyNotImplementedOr<Self>> {
        other.try_map(|rhs| self.try_add(rhs))
    }

    fn __radd__(
        &self,
        other: PyOperandArg<DurationLike<'_, '_>>,
    ) -> PyResult<PyNotImplementedOr<Self>> {
        other.try_map(|lhs| self.try_add(lhs.into()))
    }

    #[expect(clippy::too_many_arguments, reason = "python kwargs")]
    #[pyo3(
        signature = (
            other = None,
            /, *,
            hours = 0,
            minutes = 0,
            seconds = 0,
            milliseconds = 0,
            microseconds = 0,
            nanoseconds = 0
        )
    )]
    fn add(
        &self,
        other: Option<Spanish>,
        hours: i32,
        minutes: i64,
        seconds: i64,
        milliseconds: i64,
        microseconds: i64,
        nanoseconds: i64,
    ) -> PyResult<Self> {
        let spkw = SpanKwargs::new()
            .hours(hours)
            .minutes(minutes)
            .seconds(seconds)
            .milliseconds(milliseconds)
            .microseconds(microseconds)
            .nanoseconds(nanoseconds);

        match (other, !spkw.is_zero()) {
            (Some(o), false) => self.try_add(o),
            (None, true) => {
                let span = spkw.build_span()?;
                self.0
                    .checked_add(span)
                    .map(Self::from)
                    .map_err(map_py_overflow_err)
            }
            (Some(_), true) => {
                py_type_err!("add accepts either a span-like object or keyword units, not both")
            }
            (None, false) => Ok(*self),
        }
    }

    fn __sub__(
        &self,
        other: PyOperandArg<TemporalSubInput<'_, '_, Self>>,
    ) -> PyNotImplementedOr<TemporalSubOutput<Self>> {
        other.map(|rhs| self.try_sub_temporal(rhs))
    }

    #[expect(clippy::too_many_arguments, reason = "python kwargs")]
    #[pyo3(
        signature = (
            other = None,
            /, *,
            hours = 0,
            minutes = 0,
            seconds = 0,
            milliseconds = 0,
            microseconds = 0,
            nanoseconds = 0
        )
    )]
    fn sub(
        &self,
        other: Option<TemporalSubInput<Self>>,
        hours: i32,
        minutes: i64,
        seconds: i64,
        milliseconds: i64,
        microseconds: i64,
        nanoseconds: i64,
    ) -> PyResult<TemporalSubOutput<Self>> {
        let spkw = SpanKwargs::new()
            .hours(hours)
            .minutes(minutes)
            .seconds(seconds)
            .milliseconds(milliseconds)
            .microseconds(microseconds)
            .nanoseconds(nanoseconds);

        match (other, !spkw.is_zero()) {
            (Some(o), false) => Ok(self.try_sub_temporal(o)),
            (None, true) => {
                let span = spkw.build_span()?;
                Ok(self.checked_sub(span).into())
            }
            (Some(_), true) => {
                py_type_err!("sub accepts either a span-like object or keyword units, not both")
            }
            (None, false) => Ok(TemporalSubOutput::Temporal(*self)),
        }
    }

    fn as_second(&self) -> i64 {
        self.0.as_second()
    }

    fn as_microsecond(&self) -> i64 {
        self.0.as_microsecond()
    }

    fn as_millisecond(&self) -> i64 {
        self.0.as_millisecond()
    }

    fn as_nanosecond(&self) -> i128 {
        self.0.as_nanosecond()
    }

    #[getter]
    fn second(&self) -> i64 {
        self.0.as_second()
    }

    #[getter]
    fn nanosecond(&self) -> i32 {
        self.0.subsec_nanosecond()
    }

    #[getter]
    fn subsec_nanosecond(&self) -> i32 {
        self.0.subsec_nanosecond()
    }

    #[getter]
    fn subsec_microsecond(&self) -> i32 {
        self.0.subsec_microsecond()
    }

    #[getter]
    fn subsec_millisecond(&self) -> i32 {
        self.0.subsec_millisecond()
    }

    fn series(&self, period: &RySpan) -> PyResult<RyTimestampSeries> {
        (self, period).try_into()
    }

    #[getter]
    fn is_zero(&self) -> bool {
        self.0.is_zero()
    }

    fn in_tz(&self, tz: &str) -> PyResult<RyZoned> {
        let tz = ryo3_jiff_core::get_time_zone(tz).map_err(map_py_value_err)?;
        Ok(RyZoned::from(self.0.to_zoned(tz)))
    }

    #[staticmethod]
    fn from_microsecond(microsecond: i64) -> PyResult<Self> {
        Timestamp::from_microsecond(microsecond)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    #[staticmethod]
    fn from_nanosecond(nanosecond: i128) -> PyResult<Self> {
        Timestamp::from_nanosecond(nanosecond)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    #[staticmethod]
    #[pyo3(name = "from_second")]
    fn py_from_second(second: &Bound<'_, PyAny>) -> PyResult<Self> {
        if let Some(second) = second.cast_exact_opt::<PyInt>() {
            // big ints should become `OverflowError` not type err
            let second = second.extract::<i64>()?;
            Timestamp::from_second(second)
                .map(Self::from)
                .map_err(map_py_value_err)
        } else if let Some(second) = second
            .cast_exact_opt::<PyFloat>()
            .and_then(|f| f.extract::<f64>().ok())
        {
            Self::from_second_f64(second)
        } else {
            py_type_err!("Invalid type for second; expected i64 or f64")
        }
    }

    /// float unix-seconds ~ explicit so numbers never get unit-guessed
    #[staticmethod]
    fn from_second_f64(second: f64) -> PyResult<Self> {
        let dur = jiff::SignedDuration::try_from_secs_f64(second).map_err(map_py_value_err)?;
        Timestamp::from_duration(dur)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    fn signum(&self) -> i8 {
        self.0.signum()
    }

    // ========================================================================
    // STRPTIME/STRFTIME
    // ========================================================================
    fn __format__(&self, fmt: &str) -> PyResult<String> {
        if fmt.is_empty() {
            Ok(self.0.to_string())
        } else {
            self.strftime(fmt)
        }
    }

    fn strftime(&self, fmt: &str) -> PyResult<String> {
        let bdt: jiff::fmt::strtime::BrokenDownTime = self.0.into();
        bdt.to_string(fmt).map_err(map_py_value_err)
    }

    #[staticmethod]
    #[pyo3(signature = (s, /, fmt))]
    fn strptime(s: &str, fmt: &str) -> PyResult<Self> {
        Timestamp::strptime(fmt, s)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    #[pyo3(
        signature = (
            ts,
            *,
            smallest = JiffUnit::NANOSECOND,
            largest = None,
            mode = JiffRoundMode::TRUNC,
            increment = 1
        ),
        text_signature = "(self, other, *, smallest=\"nanosecond\", largest=None, mode=\"trunc\", increment=1)"
    )]
    fn since(
        &self,
        ts: TimestampDifferenceArg,
        smallest: JiffUnit,
        largest: Option<JiffUnit>,
        mode: JiffRoundMode,
        increment: i64,
    ) -> PyResult<RySpan> {
        let dt_diff = ts.build(smallest, largest, mode, increment);
        self.0
            .since(dt_diff)
            .map(RySpan::from)
            .map_err(map_py_value_err)
    }

    #[pyo3(
        signature = (
            ts,
            *,
            smallest = JiffUnit::NANOSECOND,
            largest = None,
            mode = JiffRoundMode::TRUNC,
            increment = 1
        ),
        text_signature = "(self, other, *, smallest=\"nanosecond\", largest=None, mode=\"trunc\", increment=1)"
    )]
    fn until(
        &self,
        ts: TimestampDifferenceArg,
        smallest: JiffUnit,
        largest: Option<JiffUnit>,
        mode: JiffRoundMode,
        increment: i64,
    ) -> PyResult<RySpan> {
        let dt_diff = ts.build(smallest, largest, mode, increment);
        self.0
            .until(dt_diff)
            .map(RySpan::from)
            .map_err(map_py_value_err)
    }

    #[expect(clippy::used_underscore_items, reason = "python-private-method")]
    fn _since(&self, other: &RyTimestampDifference) -> PyResult<RySpan> {
        self.0
            .since(other.diff)
            .map(RySpan::from)
            .map_err(map_py_value_err)
    }

    #[expect(clippy::used_underscore_items, reason = "python-private-method")]
    fn _until(&self, other: &RyTimestampDifference) -> PyResult<RySpan> {
        self.0
            .until(other.diff)
            .map(RySpan::from)
            .map_err(map_py_value_err)
    }

    fn display_with_offset(&self, offset: &RyOffset) -> PyAsciiString {
        let dwo = self.0.display_with_offset(offset.0);
        dwo.to_string().into()
    }

    fn duration_since(&self, other: &Self) -> RySignedDuration {
        RySignedDuration::from(self.0.duration_since(other.0))
    }

    fn duration_until(&self, other: &Self) -> RySignedDuration {
        RySignedDuration::from(self.0.duration_until(other.0))
    }

    #[pyo3(
        signature = (
            smallest = JiffUnit::NANOSECOND,
            *,
            mode = JiffRoundMode::HALF_EXPAND,
            increment = 1
        ),
        text_signature = "(self, smallest=\"nanosecond\", *, mode=\"half-expand\", increment=1)"
    )]
    fn round(&self, smallest: JiffUnit, mode: JiffRoundMode, increment: i64) -> PyResult<Self> {
        let ts_round = TimestampRound::new()
            .smallest(smallest.into())
            .increment(increment)
            .mode(mode.into());
        self.0
            .round(ts_round)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    #[expect(clippy::used_underscore_items, reason = "python-private-method")]
    fn _round(&self, options: &RyTimestampRound) -> PyResult<Self> {
        options.round(self)
    }

    fn saturating_add(&self, other: Spanish) -> PyResult<Self> {
        self.0
            .saturating_add(other)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    fn saturating_sub(&self, other: Spanish) -> PyResult<Self> {
        self.0
            .saturating_sub(other)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    #[staticmethod]
    fn from_any<'py>(value: &Bound<'py, PyAny>) -> PyResult<Bound<'py, Self>> {
        let py = value.py();
        if let Some(val) = value.cast_exact_opt::<Self>() {
            Ok(val.as_borrowed().into_bound())
        } else if let Some(pystr) = value.cast_opt::<pyo3::types::PyString>() {
            let s = pystr.extract::<&str>()?;
            Self::from_str(s).map(|dt| dt.into_pyobject(py))?
        } else if let Some(pybytes) = value.cast_opt::<pyo3::types::PyBytes>() {
            let s = String::from_utf8_lossy(pybytes.as_bytes());
            Self::from_str(&s).map(|dt| dt.into_pyobject(py))?
        } else if let Some(d) = value.cast_exact_opt::<RyZoned>() {
            Self::from(d.get()).into_pyobject(py)
        } else if let Some(dt) = value.cast_exact_opt::<RyDateTime>() {
            jiff::tz::Offset::UTC
                .to_timestamp(dt.get().0)
                .map(Self::from)
                .map_err(map_py_value_err)?
                .into_pyobject(py)
        } else if let Ok(ts) = value.extract::<JiffTimestamp>() {
            Self::from(ts).into_pyobject(py)
        } else {
            let valtype = any_repr!(value);
            py_type_err!("Timestamp conversion error: {valtype}")
        }
    }
    // ========================================================================
    // PYDANTIC
    // ========================================================================
    #[cfg(feature = "pydantic")]
    #[staticmethod]
    #[pyo3(name = "_pydantic_validate")]
    fn py_pydantic_validate<'py>(value: &Bound<'py, PyAny>) -> PyResult<Bound<'py, Self>> {
        Self::from_any(value).map_err(map_py_value_err)
    }

    #[cfg(feature = "pydantic")]
    #[classmethod]
    fn __get_pydantic_core_schema__<'py>(
        cls: &Bound<'py, ::pyo3::types::PyType>,
        source: &Bound<'py, PyAny>,
        handler: &Bound<'py, PyAny>,
    ) -> PyResult<Bound<'py, PyAny>> {
        use ryo3_pydantic::GetPydanticCoreSchemaCls;
        Self::get_pydantic_core_schema(cls, source, handler)
    }

    // ========================================================================
    // STANDARD METHODS
    // ========================================================================
    // <STD-METHODS>
    #[staticmethod]
    #[pyo3(signature = (s, /))]
    fn from_str(s: &str) -> PyResult<Self> {
        use ryo3_core::PyFromStr;
        Self::py_from_str(s)
    }

    #[staticmethod]
    #[pyo3(signature = (value, /))]
    fn parse(value: ryo3_core::PyParseArg<Self>) -> Self {
        value.into_inner()
    }

    fn isoformat(&self) -> PyAsciiString {
        <Self as crate::isoformat::PyIsoFormat>::isoformat(self)
    }
    // </STD-METHODS>
}

impl std::fmt::Display for RyTimestamp {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "Timestamp(second={:?}, nanosecond={:?})",
            self.0.as_second(),
            self.0.subsec_nanosecond()
        )
    }
}
