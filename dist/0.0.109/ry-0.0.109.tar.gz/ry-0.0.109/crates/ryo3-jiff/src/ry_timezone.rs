use std::fmt::Debug;
use std::hash::{DefaultHasher, Hash, Hasher};

use jiff::Timestamp;
use jiff::tz::{Offset, TimeZone, TimeZoneTransition};
use pyo3::prelude::*;
use pyo3::types::{PyDict, PyList, PyString, PyTuple, PyTzInfo};
use pyo3::{BoundObject, IntoPyObjectExt};
use ryo3_core::map_py_value_err;
use ryo3_jiff_core::{JiffTimeZone, JiffTimeZoneRef, get_time_zone};
use ryo3_macro_rules::{py_type_err, pytodo};

use crate::ry_datetime::RyDateTime;
use crate::ry_offset::RyOffset;
use crate::ry_timestamp::RyTimestamp;
use crate::ry_zoned::RyZoned;

#[derive(Debug, Clone)]
#[pyclass(name = "TimeZone", frozen, immutable_type, eq)]
#[cfg_attr(feature = "ry", pyo3(module = "ry.ryo3"))]
pub struct RyTimeZone(pub(crate) TimeZone);

impl RyTimeZone {
    fn inner(&self) -> &TimeZone {
        &self.0
    }

    pub(crate) fn to_inner(&self) -> TimeZone {
        self.inner().clone()
    }
}

#[pymethods]
impl RyTimeZone {
    #[new]
    fn py_new(time_zone_name: &str) -> PyResult<Self> {
        if time_zone_name.is_empty() || time_zone_name.eq_ignore_ascii_case("unknown") {
            return Ok(Self::from(TimeZone::unknown()));
        }
        if time_zone_name.eq_ignore_ascii_case("utc") {
            return Ok(Self::from(TimeZone::fixed(Offset::UTC)));
        }
        get_time_zone(time_zone_name)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    #[classattr]
    #[expect(non_snake_case, reason = "python classattr")]
    fn UTC() -> Self {
        Self::from(TimeZone::UTC)
    }

    // =====================================================================
    // DUNDERS
    // =====================================================================

    fn __getnewargs__<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyTuple>> {
        PyTuple::new(
            py,
            vec![self.iana_name().unwrap_or("").into_bound_py_any(py)?],
        )
    }

    fn __call__(slf: PyRef<'_, Self>) -> PyRef<'_, Self> {
        slf
    }

    fn __repr__(&self) -> String {
        format!("{self}")
    }

    fn __str__(&self) -> String {
        if let Some(name) = self.iana_name() {
            name.to_string()
        } else {
            // REALLY NOT SURE IF THIS IS CORRECT
            let offset = self.0.to_offset(Timestamp::now());
            format!("{offset}")
        }
    }

    fn __hash__(&self) -> u64 {
        let mut hasher = DefaultHasher::new();
        match self.0.to_fixed_offset() {
            Ok(offset) => offset.hash(&mut hasher),
            Err(_) => {
                if let Some(name) = self.iana_name() {
                    name.hash(&mut hasher);
                }
            }
        }
        hasher.finish()
    }

    fn equiv<'py>(&self, other: &'py Bound<'py, PyAny>) -> PyResult<bool> {
        if let Ok(other) = other.cast_exact::<Self>() {
            Ok(self.0.eq(&other.get().0))
        } else if let Ok(other) = other.cast::<PyTzInfo>() {
            let tz: JiffTimeZone = other.extract()?;
            Ok(self.0.eq(tz.inner()))
        } else if let Ok(other) = other.cast::<PyString>() {
            let other_str = other.extract::<&str>()?;
            Ok(self.0.iana_name() == Some(other_str))
        } else {
            py_type_err!("Expected TimeZone, datetime.tzinfo or string")
        }
    }

    // =====================================================================
    // PY-CONVERSIONS
    // =====================================================================

    fn to_py(&self) -> JiffTimeZoneRef<'_> {
        JiffTimeZoneRef::new(&self.0)
    }

    fn to_pytzinfo(&self) -> JiffTimeZoneRef<'_> {
        JiffTimeZoneRef::new(&self.0)
    }

    #[staticmethod]
    fn from_pytzinfo(tz: JiffTimeZone) -> Self {
        Self::from(tz)
    }

    fn to_dict<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyDict>> {
        use crate::interns;
        let dict = PyDict::new(py);
        dict.set_item(interns::tz(py), self.iana_name().unwrap_or("unknown"))?;
        Ok(dict)
    }

    // =====================================================================
    // CLASS METHODS
    // =====================================================================
    #[expect(clippy::trivially_copy_pass_by_ref)]
    #[staticmethod]
    fn fixed(offset: &RyOffset) -> Self {
        Self::from(TimeZone::fixed(offset.0))
    }

    #[staticmethod]
    fn posix(tz_name: &str) -> PyResult<Self> {
        TimeZone::posix(tz_name)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    #[staticmethod]
    fn get(tz_name: &str) -> PyResult<Self> {
        get_time_zone(tz_name)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    #[staticmethod]
    fn tzif(name: &str, data: &[u8]) -> PyResult<Self> {
        TimeZone::tzif(name, data)
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    #[staticmethod]
    fn utc() -> Self {
        Self::UTC()
    }

    #[staticmethod]
    fn try_system() -> PyResult<Self> {
        TimeZone::try_system()
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    #[staticmethod]
    fn system() -> PyResult<Self> {
        TimeZone::try_system()
            .map(Self::from)
            .map_err(map_py_value_err)
    }

    // =====================================================================
    // INSTANCE METHODS
    // =====================================================================

    /// Return dictionary with `offset`, `dst` and `abbreviation` from `TimeZone`
    /// given a `Timestamp`
    fn to_offset_info<'py>(
        &self,
        py: Python<'py>,
        timestamp: &RyTimestamp,
    ) -> PyResult<Bound<'py, PyDict>> {
        let offset_info = self.0.to_offset_info(timestamp.0);
        let dict = PyDict::new(py);
        let ryoff = RyOffset::from(offset_info.offset());
        dict.set_item(crate::interns::offset(py), ryoff.to_dict(py)?)?;
        dict.set_item(crate::interns::dst(py), offset_info.dst().is_dst())?;
        dict.set_item(crate::interns::abbreviation(py), offset_info.abbreviation())?;
        Ok(dict)
    }

    fn to_datetime(&self, timestamp: &RyTimestamp) -> RyDateTime {
        RyDateTime::from(self.0.to_datetime(timestamp.0))
    }

    /// Return `Offset` from `TimeZone`
    fn to_offset(&self, timestamp: &RyTimestamp) -> RyOffset {
        RyOffset::from(self.0.to_offset(timestamp.0))
    }

    /// Return `Timestamp` from `TimeZone` given a `DateTime`
    fn to_timestamp(&self, datetime: &RyDateTime) -> Result<RyTimestamp, PyErr> {
        self.0
            .to_timestamp(datetime.0)
            .map(RyTimestamp::from)
            .map_err(map_py_value_err)
    }

    /// Return `Zoned` from `TimeZone` given a `DateTime`
    fn to_zoned(&self, datetime: &RyDateTime) -> PyResult<RyZoned> {
        self.0
            .to_zoned(datetime.0)
            .map(RyZoned::from)
            .map_err(map_py_value_err)
    }

    fn iana_name(&self) -> Option<&str> {
        self.0.iana_name()
    }

    fn to_fixed_offset(&self) -> PyResult<RyOffset> {
        self.0
            .to_fixed_offset()
            .map(RyOffset::from)
            .map_err(map_py_value_err)
    }

    // =====================================================================
    // PROPERTIES
    // =====================================================================

    #[getter]
    fn name(&self) -> Option<&str> {
        self.iana_name()
    }

    #[getter]
    fn is_unknown(&self) -> bool {
        self.0.is_unknown()
    }

    // ===============
    // NOT IMPLEMENTED
    // ===============
    #[expect(clippy::unused_self)]
    fn to_ambiguous_timestamp(&self) -> PyResult<()> {
        pytodo!();
    }

    #[expect(clippy::unused_self)]
    fn to_ambiguous_zoned(&self) -> PyResult<()> {
        pytodo!();
    }

    #[pyo3(signature = (timestamp, /, limit = None))]
    fn preceding(
        &self,
        timestamp: &RyTimestamp,
        limit: Option<usize>,
    ) -> PyTimeZoneTransitionsVec<'_> {
        let transitions = if let Some(lim) = limit {
            self.0.preceding(timestamp.0).take(lim).collect::<Vec<_>>()
        } else {
            self.0.preceding(timestamp.0).collect::<Vec<_>>()
        };
        PyTimeZoneTransitionsVec(transitions)
    }

    #[pyo3(signature = (timestamp, /, limit = None))]
    fn following(
        &self,
        timestamp: &RyTimestamp,
        limit: Option<usize>,
    ) -> PyTimeZoneTransitionsVec<'_> {
        let transitions = if let Some(lim) = limit {
            self.0.following(timestamp.0).take(lim).collect::<Vec<_>>()
        } else {
            self.0.following(timestamp.0).collect::<Vec<_>>()
        };
        PyTimeZoneTransitionsVec(transitions)
    }

    // ========================================================================
    // STANDARD METHODS
    // ========================================================================
    // <STD-METHODS>
    #[staticmethod]
    #[pyo3(signature = (s, /))]
    fn from_str(s: &str) -> PyResult<Self> {
        use ryo3_core::PyFromStr;
        Self::py_from_str(s)
    }

    #[staticmethod]
    #[pyo3(signature = (value, /))]
    fn parse(value: ryo3_core::PyParseArg<Self>) -> Self {
        value.into_inner()
    }
    // </STD-METHODS>

    #[staticmethod]
    fn from_any<'py>(value: &Bound<'py, PyAny>) -> PyResult<Bound<'py, Self>> {
        let py = value.py();
        if let Ok(val) = value.cast_exact::<Self>() {
            Ok(val.as_borrowed().into_bound())
        } else if let Ok(pystr) = value.cast::<pyo3::types::PyString>() {
            let s = pystr.extract::<&str>()?;
            Self::from_str(s).map(|dt| dt.into_pyobject(py))?
        } else if let Ok(pybytes) = value.cast::<pyo3::types::PyBytes>() {
            let s = String::from_utf8_lossy(pybytes.as_bytes());
            Self::from_str(&s).map(|dt| dt.into_pyobject(py))?
        } else if let Ok(other) = value.cast::<PyTzInfo>() {
            let tz: JiffTimeZone = other.extract()?;
            Self::from(tz).into_pyobject(py)
        } else {
            py_type_err!("expected TimeZone, tzinfo, str or bytes-like object")
        }
    }

    // ========================================================================
    // PYDANTIC
    // ========================================================================
    #[cfg(feature = "pydantic")]
    #[staticmethod]
    #[pyo3(name = "_pydantic_validate")]
    fn py_pydantic_validate<'py>(value: &Bound<'py, PyAny>) -> PyResult<Bound<'py, Self>> {
        Self::from_any(value).map_err(map_py_value_err)
    }

    #[cfg(feature = "pydantic")]
    #[classmethod]
    fn __get_pydantic_core_schema__<'py>(
        cls: &Bound<'py, ::pyo3::types::PyType>,
        source: &Bound<'py, PyAny>,
        handler: &Bound<'py, PyAny>,
    ) -> PyResult<Bound<'py, PyAny>> {
        use ryo3_pydantic::GetPydanticCoreSchemaCls;
        Self::get_pydantic_core_schema(cls, source, handler)
    }
}

impl std::fmt::Display for RyTimeZone {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "TimeZone(")?;

        if self.is_unknown() {
            write!(f, "\"unknown\"")?;
        } else if let Some(name) = self.iana_name() {
            write!(f, "\"{name}\"")?;
        } else {
            // REALLY NOT SURE IF THIS IS CORRECT
            let offset = self.0.to_offset(Timestamp::now());
            write!(f, "'{offset}'")?;
        }
        write!(f, ")")
    }
}

struct PyTimeZoneTransitionsVec<'t>(Vec<TimeZoneTransition<'t>>);

impl<'py> IntoPyObject<'py> for PyTimeZoneTransitionsVec<'_> {
    type Target = PyList;
    type Output = Bound<'py, Self::Target>;
    type Error = PyErr;

    fn into_pyobject(self, py: Python<'py>) -> Result<Self::Output, Self::Error> {
        use std::collections::HashMap;

        use crate::interns;
        // cache for same py-str abbreviations over and over
        let mut abbrevs: HashMap<&str, Bound<'py, PyString>> = HashMap::new();
        let mut objects = Vec::with_capacity(self.0.len());
        for t in &self.0 {
            let d = PyDict::new(py);
            d.set_item(interns::timestamp(py), RyTimestamp::from(t.timestamp()))?;
            d.set_item(interns::offset(py), RyOffset::from(t.offset()))?;
            d.set_item(interns::dst(py), t.dst().is_dst())?;
            let abbrev = abbrevs
                .entry(t.abbreviation())
                .or_insert_with_key(|abbrev| PyString::new(py, abbrev));
            d.set_item(interns::abbreviation(py), &*abbrev)?;
            objects.push(d);
        }
        PyList::new(py, objects)
    }
}

impl PartialEq for RyTimeZone {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}
