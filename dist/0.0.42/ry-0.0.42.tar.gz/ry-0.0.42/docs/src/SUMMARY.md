# Summary

- [README](./index.md)
- [DEVELOPMENT](./development.md)
- [ACKNOWLEDGEMENTS](./acknowledgements.md)

---

- [CHANGELOG](./CHANGELOG.md)

---

- [EXAMPLES](./examples.md)

---

- [API](./api.md)

---

- [food-4-thought](./food-4-thought.md)
  - [jiff](./jiff.md)
