use std::net::SocketAddr;
use std::sync::Arc;

use reqwest::StatusCode;
use reqwest::header::CONTENT_TYPE;
use ryo3_cookie::PyCookie;
use ryo3_core::sync::RyRwLock;
use ryo3_url::PyUrl;

use crate::charset::PyEncoding;

#[derive(Debug, Clone)]
pub(crate) struct RyResponseHead {
    /// das status code
    pub(crate) status: StatusCode,
    /// das headers
    pub(crate) headers: Arc<RyRwLock<http::HeaderMap, false>>,
    /// das url
    pub(crate) url: Box<reqwest::Url>,
    /// das content length -- if it exists (tho it might not and/or be
    /// different if the response is compressed)
    pub(crate) content_length: Option<u64>,
    /// version of http spec
    pub(crate) version: reqwest::Version,
    /// Remote address
    pub(crate) remote_addr: Option<SocketAddr>,
}

impl RyResponseHead {
    pub(crate) fn py_url(&self) -> PyUrl {
        PyUrl::from((*self.url).clone())
    }

    pub(crate) fn from_parts(
        status: StatusCode,
        headers: http::HeaderMap,
        url: reqwest::Url,
        content_length: Option<u64>,
        version: reqwest::Version,
        remote_addr: Option<SocketAddr>,
    ) -> Self {
        Self {
            status,
            headers: Arc::new(RyRwLock::new(headers)),
            url: Box::new(url),
            content_length,
            version,
            remote_addr,
        }
    }

    /// text encoding from the `content-type` charset, else `default`
    pub(crate) fn encoding(&self, default: PyEncoding) -> PyEncoding {
        let content_type = self
            .headers
            .py_read()
            .get(CONTENT_TYPE)
            .and_then(|value| value.to_str().ok())
            .and_then(|value| value.parse::<mime::Mime>().ok());
        let encoding_name = content_type
            .as_ref()
            .and_then(|mime| mime.get_param("charset").map(|charset| charset.as_str()))
            .unwrap_or(default.as_static_str());
        encoding_rs::Encoding::for_label(encoding_name.as_bytes())
            .map_or(default, PyEncoding::from_encoding)
    }

    /// `content-coding = token` (RFC 9110 §8.4.1) so valid values are ascii
    ///
    /// Non-ASCII values are decoded as latin-1 so it round-trips instead of
    /// failing (which matches the impl of python's stdlib and other http
    /// libraries)
    ///
    /// REF: <https://www.rfc-editor.org/rfc/rfc9110#section-8.4.1>
    pub(crate) fn content_encoding(&self) -> Option<String> {
        let headers = self.headers.py_read();
        let hv = headers.get(reqwest::header::CONTENT_ENCODING)?;
        let s = match hv.to_str() {
            Ok(s) => s.to_owned(),
            Err(_) => hv.as_bytes().iter().map(|&b| char::from(b)).collect(),
        };
        Some(s)
    }

    pub(crate) fn py_set_cookies(&self) -> Option<Vec<PyCookie>> {
        let headers = self.headers.py_read();
        if headers.is_empty() {
            return None;
        }
        let py_cookies: Vec<PyCookie> = headers // nom nom nom nom nom
            .get_all(reqwest::header::SET_COOKIE)
            .iter()
            .filter_map(|hv| hv.to_str().ok())
            .map(ToOwned::to_owned)
            .filter_map(|s| PyCookie::parse_cookie(s).ok())
            .collect();
        if py_cookies.is_empty() {
            None
        } else {
            Some(py_cookies)
        }
    }
}
