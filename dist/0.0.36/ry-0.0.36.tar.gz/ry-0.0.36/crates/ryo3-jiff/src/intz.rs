// use crate::JiffTimeZone;
// use pyo3::pyclass;
//
// #[pyclass]
// #[derive(Debug, Clone)]
// pub(crate) enum RyInTz {
//     Str(String),
//     JiffTimezone(JiffTimeZone),
// }
