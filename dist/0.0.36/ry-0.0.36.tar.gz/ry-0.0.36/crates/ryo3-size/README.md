# `ryo3-size`

python + `size` crate.

`size`:
- [crates.io](https://crates.io/crates/size)
- [docs.rs](https://docs.rs/size)
