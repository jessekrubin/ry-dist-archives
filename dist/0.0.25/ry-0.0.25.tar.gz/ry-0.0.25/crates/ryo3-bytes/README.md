# `ryo3-bytes`

python wrapper for the `bytes` crate

`bytes`:
- [crates.io](https://crates.io/crates/bytes)
- [docs.rs](https://docs.rs/bytes)
