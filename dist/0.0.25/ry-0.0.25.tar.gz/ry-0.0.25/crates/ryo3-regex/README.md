# `ryo3-regex`

Wrapper around the `regex` crate for Python.

**NOT FULLY IMPLEMENTED ~ currently crude**

- [crates.io](https://crates.io/crates/regex)
- [docs.rs](https://docs.rs/regex)

___

# TODO

- [ ] match the `regex` crate examples
- [ ] figure out how to support bytes/string maybe generics?
- [ ] `Regex` options/flags? kwargs or bitflags?
- [ ] `RegexSet` python wrapper
- [ ] Builders? - not sure if should be a part of the api at all...
  - [ ] `RegexBuilder`
  - [ ] `RegexSetBuilder`
