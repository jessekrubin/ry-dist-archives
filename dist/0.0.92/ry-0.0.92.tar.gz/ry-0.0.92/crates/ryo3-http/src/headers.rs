use std::fmt::Display;
use std::ops::Deref;
use std::sync::{Arc, RwLockReadGuard, RwLockWriteGuard};

use http::header::HeaderMap;
use pyo3::prelude::*;
use pyo3::types::{PyBytes, PyDict, PyList, PyString, PyTuple};
use ryo3_core::{RyRwLock, py_runtime_error};

use crate::http_types::{PyHttpHeaderName, PyHttpHeaderValue, PyHttpHeaderValueRef};
use crate::py_conversions::{header_name_to_pystring, header_value_to_pystring};
use crate::{PyHeadersLike, PyHttpHeaderMap};

#[pyclass(name = "Headers", frozen, immutable_type, mapping, skip_from_py_object)]
#[cfg_attr(feature = "ry", pyo3(module = "ry.ryo3"))]
#[derive(Clone, Debug)]
pub struct PyHeaders(pub Arc<RyRwLock<HeaderMap, false>>);

impl Deref for PyHeaders {
    type Target = Arc<RyRwLock<HeaderMap, false>>;

    fn deref(&self) -> &Self::Target {
        &self.0
    }
}

impl PyHeaders {
    #[inline]
    pub(crate) fn read(&self) -> RwLockReadGuard<'_, HeaderMap> {
        self.0.py_read()
    }

    #[inline]
    fn write(&self) -> RwLockWriteGuard<'_, HeaderMap> {
        self.0.py_write()
    }

    fn py_dict<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyDict>> {
        let inner = self.read();
        if inner.is_empty() {
            Ok(PyDict::new(py))
        } else if inner.len() == inner.keys_len() {
            // don't have to worry about duplicates bc of keys_len == len
            let d = PyDict::new(py);
            for (k, v) in inner.iter() {
                let key_pystr = header_name_to_pystring(py, k)?;
                let value_pystr = header_value_to_pystring(py, v)?;
                d.set_item(key_pystr, value_pystr)?;
            }
            Ok(d)
        } else {
            // need to handle duplicates
            let d = PyDict::new(py);
            for key in inner.keys() {
                let key_pystr = header_name_to_pystring(py, key)?;
                let values: Vec<_> = inner.get_all(key).iter().collect();
                if values.len() == 1 {
                    let v = values[0];
                    if let Ok(vstr) = v.to_str() {
                        d.set_item(key_pystr, vstr)?;
                    } else {
                        let pybytes = PyBytes::new(py, v.as_bytes());
                        d.set_item(key_pystr, pybytes)?;
                    }
                } else {
                    let py_list = PyList::empty(py);
                    for v in values {
                        if let Ok(vstr) = v.to_str() {
                            py_list.append(vstr)?;
                        } else {
                            let pybytes = PyBytes::new(py, v.as_bytes());
                            py_list.append(pybytes)?;
                        }
                    }
                    d.set_item(key_pystr, py_list)?;
                }
            }
            Ok(d)
        }
    }

    #[cfg(feature = "pydantic")]
    fn from_any<'py>(value: &Bound<'py, PyAny>) -> PyResult<Bound<'py, Self>> {
        use pyo3::BoundObject;
        let py = value.py();
        if let Ok(headers) = value.cast_exact::<Self>() {
            Ok(headers.as_borrowed().into_bound())
        } else {
            let headers_like = value.extract::<PyHeadersLike>()?;
            Py::new(py, Self::from(headers_like)).map(|headers| headers.into_bound(py))
        }
    }
}

impl Display for PyHeaders {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let inner = self.read();
        if f.alternate() {
            write!(f, "{inner:?}")
        } else {
            write!(f, "Headers({inner:?})")
        }
    }
}

impl PartialEq for PyHeaders {
    fn eq(&self, other: &Self) -> bool {
        *(self.read()) == *(other.read())
    }
}

impl Eq for PyHeaders {}

impl From<HeaderMap> for PyHeaders {
    fn from(hm: HeaderMap) -> Self {
        Self(Arc::new(RyRwLock::new(hm)))
    }
}

impl From<PyHttpHeaderMap> for PyHeaders {
    fn from(hm: PyHttpHeaderMap) -> Self {
        Self::from(HeaderMap::from(hm))
    }
}

impl From<Arc<RyRwLock<HeaderMap, false>>> for PyHeaders {
    fn from(hm: Arc<RyRwLock<HeaderMap, false>>) -> Self {
        Self(hm)
    }
}

#[pymethods]
impl PyHeaders {
    #[new]
    #[pyo3(signature = (headers = None, /, **kwargs))]
    fn py_new(headers: Option<PyHeadersLike>, kwargs: Option<PyHeadersLike>) -> Self {
        match (headers, kwargs) {
            (Some(headers), Some(kwargs)) => {
                let mut headers_map = HeaderMap::from(headers);
                headers_map.extend(HeaderMap::from(kwargs));
                Self::from(headers_map)
            }
            (Some(headers), None) => {
                let headers_map = HeaderMap::from(headers);
                Self::from(headers_map)
            }
            (None, Some(kwargs)) => {
                let kw_headers = HeaderMap::from(kwargs);
                Self::from(kw_headers)
            }
            (None, None) => Self::from(HeaderMap::new()),
        }
    }

    fn __getnewargs__<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyTuple>> {
        let dict = self.py_dict(py)?;
        PyTuple::new(py, vec![dict])
    }

    /// Return struct Debug-string
    #[must_use]
    fn __dbg__(&self) -> String {
        format!("{self:?}")
    }

    #[must_use]
    fn __repr__(&self) -> String {
        format!("{self}")
    }

    #[must_use]
    fn __len__(&self) -> usize {
        self.read().len()
    }

    #[must_use]
    fn __eq__(&self, other: &Self) -> bool {
        *(self.read()) == *(other.read())
    }

    #[must_use]
    fn __ne__(&self, other: &Self) -> bool {
        !self.__eq__(other)
    }

    #[must_use]
    fn __contains__(&self, key: &str) -> bool {
        self.contains_key(key)
    }

    fn __getitem__(&self, key: &str) -> Option<PyHttpHeaderValue> {
        self.read().get(key).map(PyHttpHeaderValue::from)
    }

    fn __setitem__(&self, key: PyHttpHeaderName, value: PyHttpHeaderValue) -> PyResult<()> {
        self.insert(key, value)?;
        Ok(())
    }

    fn __delitem__(&self, key: PyHttpHeaderName) {
        self.remove(key);
    }

    #[must_use]
    fn __iter__<'py>(&self, py: Python<'py>) -> Vec<Bound<'py, PyAny>> {
        self.keys(py)
    }

    // ========================================================================
    // Methods of `HeaderMap`:
    // ========================================================================
    // - `append`: impl via `try_append`
    // - `capacity`:
    // - `clear`:
    // - `contains_key`:
    // - `entry`:
    // - `get`:
    // - `get_all`:
    // - `insert`:
    // - `is_empty`:
    // - `iter`:
    // - `keys`:
    // - `keys_len`:
    // - `len`:
    // - `remove`:
    // - `try_append`: `append`
    // - `try_entry`: `entry`
    // - `try_insert`: `insert`
    // - `values`:
    // - TBD
    //     - `drain`
    //     - `get_mut`
    //     - `iter_mut`
    //     - `reserve`
    //     - `try_with_capacity`
    //     - `values_mut`
    //     - `with_capacity`

    fn append(&self, key: PyHttpHeaderName, value: PyHttpHeaderValue) -> PyResult<bool> {
        self.write()
            .try_append(key.0, value.0)
            .map_err(|e| py_runtime_error!("header-append-error: {e}"))
    }

    #[getter]
    fn is_flat(&self) -> bool {
        let inner = self.read();
        inner.len() == inner.keys_len()
    }

    fn clear(&self) {
        self.write().clear();
    }

    #[must_use]
    fn contains_key(&self, key: &str) -> bool {
        self.read().contains_key(key)
    }

    fn get(&self, key: &str) -> Option<PyHttpHeaderValue> {
        self.read().get(key).map(PyHttpHeaderValue::from)
    }

    fn get_all<'py>(&'py self, py: Python<'py>, key: &str) -> PyResult<Bound<'py, PyAny>> {
        // iterate and collect but filter out errors...
        self.read()
            .get_all(key)
            .iter()
            .map(PyHttpHeaderValueRef::from)
            .collect::<Vec<_>>()
            .into_pyobject(py)
    }

    fn insert(
        &self,
        key: PyHttpHeaderName,
        value: PyHttpHeaderValue,
    ) -> PyResult<Option<PyHttpHeaderValue>> {
        self.write()
            .try_insert(key.0, value.0)
            .map_err(|e| py_runtime_error!("header-insert-error: {e}"))
            .map(|v| v.map(PyHttpHeaderValue::from))
    }

    #[must_use]
    fn is_empty(&self) -> bool {
        self.read().is_empty()
    }

    #[must_use]
    fn __bool__(&self) -> bool {
        !self.read().is_empty()
    }

    #[must_use]
    fn keys<'py>(&self, py: Python<'py>) -> Vec<Bound<'py, PyAny>> {
        self.read()
            .keys()
            .flat_map(|h| header_name_to_pystring(py, h))
            .collect()
    }

    #[must_use]
    fn keys_len(&self) -> usize {
        self.read().keys_len()
    }

    #[must_use]
    fn len(&self) -> usize {
        self.read().len()
    }

    fn remove(&self, key: PyHttpHeaderName) -> Option<PyHttpHeaderValue> {
        self.write().remove(key.0).map(PyHttpHeaderValue::from)
    }

    fn pop(&self, key: PyHttpHeaderName) -> Option<PyHttpHeaderValue> {
        self.remove(key)
    }

    fn values<'py>(&self, py: Python<'py>) -> PyResult<Vec<Bound<'py, PyString>>> {
        let mut vals = vec![];
        for v in self.read().values() {
            let pystr = header_value_to_pystring(py, v)?;
            vals.push(pystr);
        }
        Ok(vals)
    }

    #[pyo3(signature = (headers, *, append = false))]
    fn update(&self, headers: PyHeadersLike, append: bool) {
        match headers {
            PyHeadersLike::Headers(other) => {
                let other_inner = other.read();
                let mut inner = self.write();
                if append {
                    for (k, v) in other_inner.iter() {
                        inner.append(k, v.into());
                    }
                } else {
                    for (k, v) in other_inner.iter() {
                        inner.insert(k, v.into());
                    }
                }
            }
            PyHeadersLike::Map(other) => {
                let hm = HeaderMap::from(other);
                if append {
                    let mut inner = self.write();
                    for (k, v) in hm {
                        if let Some(k) = k {
                            inner.append(k, v);
                        }
                    }
                } else {
                    let mut inner = self.write();
                    for (k, v) in hm {
                        if let Some(k) = k {
                            inner.insert(k, v);
                        }
                    }
                }
            }
        }
    }

    fn __or__(&self, other: PyHeadersLike) -> Self {
        let mut headers = self.read().clone();
        match other {
            PyHeadersLike::Headers(other) => {
                let other_inner = other.read();
                for (k, v) in other_inner.iter() {
                    headers.insert(k, v.clone());
                }
            }
            PyHeadersLike::Map(other) => {
                let h = HeaderMap::from(other);
                for (k, v) in h {
                    if let Some(k) = k {
                        headers.insert(k, v);
                    }
                }
            }
        }
        Self::from(headers)
    }

    fn to_py<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyDict>> {
        self.py_dict(py)
    }

    fn to_dict<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyDict>> {
        self.to_py(py)
    }

    #[cfg(feature = "json")]
    #[pyo3(signature = (*, fmt = false))]
    fn stringify(&self, fmt: bool) -> PyResult<String> {
        use ryo3_core::py_value_error;
        let inner = self.read();
        if fmt {
            serde_json::to_string_pretty(&crate::http_serde::HttpHeaderMapRef(&inner))
                .map_err(|e| py_value_error!("{e}"))
        } else {
            serde_json::to_string(&crate::http_serde::HttpHeaderMapRef(&inner))
                .map_err(|e| py_value_error!("{e}"))
        }
    }

    #[cfg(not(feature = "json"))]
    #[expect(clippy::unused_self)]
    #[expect(unused_variables)]
    #[pyo3(signature = (*args, **kwargs))]
    fn stringify(
        &self,
        args: &Bound<'_, PyTuple>,
        kwargs: Option<&Bound<'_, PyDict>>,
    ) -> PyResult<String> {
        Err(::ryo3_core::FeatureNotEnabledError::new_err(
            "ryo3-http: `json` feature not enabled",
        ))
    }

    #[cfg(feature = "json")]
    #[staticmethod]
    fn from_json(data: &str) -> PyResult<Self> {
        use ryo3_core::py_value_error;

        serde_json::from_str::<crate::PyHttpHeaderMap>(data)
            .map(|e| Self::from(e.0))
            .map_err(|e| py_value_error!("{e}"))
    }

    #[cfg(not(feature = "json"))]
    #[staticmethod]
    fn from_json(_json: &str) -> PyResult<Self> {
        Err(::ryo3_core::FeatureNotEnabledError::new_err(
            "ryo3-http: `json` feature not enabled",
        ))
    }

    // ========================================================================
    // PYDANTIC
    // ========================================================================

    #[cfg(feature = "pydantic")]
    #[staticmethod]
    fn _pydantic_validate<'py>(value: &Bound<'py, PyAny>) -> PyResult<Bound<'py, Self>> {
        use ryo3_core::py_value_error;
        Self::from_any(value).map_err(|e| py_value_error!("Headers validation error: {e}"))
    }

    #[cfg(feature = "pydantic")]
    fn _pydantic_serialize<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyDict>> {
        self.py_dict(py)
    }

    #[cfg(feature = "pydantic")]
    #[classmethod]
    fn __get_pydantic_core_schema__<'py>(
        cls: &Bound<'py, ::pyo3::types::PyType>,
        source: &Bound<'py, PyAny>,
        handler: &Bound<'py, PyAny>,
    ) -> PyResult<Bound<'py, PyAny>> {
        use ryo3_pydantic::GetPydanticCoreSchemaCls;
        Self::get_pydantic_core_schema(cls, source, handler)
    }
}

impl std::hash::Hash for PyHeaders {
    fn hash<H: std::hash::Hasher>(&self, state: &mut H) {
        let inner = self.read();
        HeaderMapRef(&inner).hash(state);
    }
}

struct HeaderMapRef<'a>(&'a HeaderMap);
impl std::hash::Hash for HeaderMapRef<'_> {
    fn hash<H: std::hash::Hasher>(&self, state: &mut H) {
        // sorted keys
        let mut keys: Vec<_> = self.0.keys().collect();
        keys.sort_unstable_by(|a, b| a.as_str().cmp(b.as_str()));
        for key in keys {
            key.hash(state);
            let values: Vec<_> = self.0.get_all(key).iter().collect();
            for value in values {
                value.as_bytes().hash(state);
            }
        }
    }
}

#[cfg(feature = "pydantic")]
impl ryo3_pydantic::GetPydanticCoreSchemaCls for PyHeaders {
    fn get_pydantic_core_schema<'py>(
        cls: &Bound<'py, pyo3::types::PyType>,
        source: &Bound<'py, PyAny>,
        _handler: &Bound<'py, PyAny>,
    ) -> PyResult<Bound<'py, PyAny>> {
        use ryo3_pydantic::interns;

        let py = source.py();
        let core_schema = ryo3_pydantic::core_schema(py)?;
        let str_schema = core_schema.call_method(interns::str_schema(py), (), None)?;
        let list_schema =
            core_schema.call_method(interns::list_schema(py), (&str_schema,), None)?;
        let value_schema = core_schema.call_method(
            interns::union_schema(py),
            (vec![&str_schema, &list_schema],),
            None,
        )?;
        // should be dict[str, str | list[str]] but fuck is this ugly
        let dict_schema = core_schema.call_method(
            interns::dict_schema(py),
            (&str_schema, &value_schema),
            None,
        )?;

        let validation_fn = cls.getattr(interns::_pydantic_validate(py))?;
        let serializer_fn = cls.getattr(interns::_pydantic_serialize(py))?;
        let serializer_kwargs = PyDict::new(py);
        serializer_kwargs.set_item(interns::return_schema(py), &dict_schema)?;
        let serializer_schema = core_schema.call_method(
            interns::plain_serializer_function_ser_schema(py),
            (&serializer_fn,),
            Some(&serializer_kwargs),
        )?;

        let plain_validator_kwargs = PyDict::new(py);
        plain_validator_kwargs.set_item("json_schema_input_schema", &dict_schema)?;
        plain_validator_kwargs.set_item(interns::serialization(py), &serializer_schema)?;
        core_schema.call_method(
            interns::no_info_plain_validator_function(py),
            (&validation_fn,),
            Some(&plain_validator_kwargs),
        )
    }
}
