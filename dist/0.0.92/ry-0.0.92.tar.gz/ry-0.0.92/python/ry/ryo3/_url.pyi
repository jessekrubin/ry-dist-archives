import sys
import typing as t
from ipaddress import IPv4Address, IPv6Address

from ry._types import FsPathLike
from ry.protocols import FromStr, ToString, _Parse
from ry.ryo3._std import IpAddr, Ipv4Addr, Ipv6Addr, SocketAddr

if sys.version_info >= (3, 13):
    from warnings import deprecated
else:
    from typing_extensions import deprecated

@t.final
class URL(FromStr, ToString, _Parse):
    def __new__(
        cls, url: str | bytes | URL, *, params: dict[str, str] | None = None
    ) -> t.Self: ...
    # =========================================================================
    # CLASSMETHODS
    # =========================================================================
    @classmethod
    def parse(cls, s: str | bytes) -> t.Self: ...
    @classmethod
    def from_str(cls, s: str) -> t.Self: ...
    @classmethod
    def parse_with_params(cls, url: str | bytes, params: dict[str, str]) -> t.Self: ...
    @classmethod
    def from_directory_path(cls, path: FsPathLike) -> t.Self: ...
    @classmethod
    def from_filepath(cls, path: FsPathLike) -> t.Self: ...
    # =========================================================================
    # STRING
    # =========================================================================
    def to_string(self) -> str: ...
    def __fspath__(self) -> str: ...

    # =========================================================================
    # PROPERTIES
    # =========================================================================
    @property
    def authority(self) -> str: ...
    @property
    def domain(self) -> str | None: ...
    @property
    def fragment(self) -> str | None: ...
    @property
    def host(self) -> str | Ipv4Addr | Ipv6Addr | None: ...
    @property
    def host_str(self) -> str | None: ...
    @property
    def netloc(self) -> str: ...
    @property
    def password(self) -> str | None: ...
    @property
    def path(self) -> str: ...
    @property
    def path_segments(self) -> tuple[str, ...]: ...
    @property
    def port(self) -> int | None:
        """
        Return the port number for this URL, if any.

        Note: the default port numbers are never reflected by the serialization,
        use the `port_or_known_default` if you want a default port number returned.

        Default port numbers:
            - `http`  | `ws`  => `80`
            - `https` | `wss` => `443`
            - `ftp`           => `21`

        Examples:

            >>> from ry import URL
            >>> assert URL("https://rotatingsandwiches.com:3000").port == 3000
            >>> assert URL("https://rotatingsandwiches.com").port is None
            >>> assert URL("https://rotatingsandwiches.com:443/").port is None
            >>> assert URL("ssh://rotatingsandwiches.com:22").port == 22

        """

    @property
    def port_or_known_default(self) -> int | None:
        """Return the port number, or the default port number if known.

        Default port numbers:
            - `http`  | `ws`  => `80`
            - `https` | `wss` => `443`
            - `ftp`           => `21`

        Examples:

            >>> from ry import URL
            >>> URL("https://rotatingsandwiches.com:3000").port_or_known_default
            3000
            >>> URL("https://rotatingsandwiches.com").port_or_known_default
            443
            >>> URL("https://rotatingsandwiches.com:443/").port_or_known_default
            443
            >>> URL("ssh://rotatingsandwiches.com:22").port_or_known_default
            22

        """
    @property
    def query(self) -> str | None: ...
    @property
    def query_string(self) -> str: ...
    @property
    def query_pairs(self) -> tuple[tuple[str, str], ...]: ...
    @property
    def scheme(self) -> str: ...
    @property
    def user(self) -> str:
        """alias for yarl compatibility"""
    @property
    def username(self) -> str: ...
    @property
    def origin(self) -> str: ...

    # =========================================================================
    # INSTANCE METHODS
    # =========================================================================
    def has_authority(self) -> bool: ...
    def has_host(self) -> bool: ...
    def equiv(self, other: URL | str) -> bool: ...
    def is_special(self) -> bool: ...
    def join(self, *parts: str) -> URL: ...
    def make_relative(self, other: URL) -> t.Self: ...
    def socket_addrs(
        self, default_port_number: int | None = None
    ) -> list[SocketAddr]: ...
    def to_filepath(self) -> str: ...
    def replace(
        self,
        *,
        fragment: str | None = None,
        host: str | None = None,
        ip_host: IPv4Address | IPv6Address | Ipv4Addr | Ipv6Addr | IpAddr | None = None,
        password: str | None = None,
        path: str | None = None,
        port: int | None = None,
        query: str | None = None,
        scheme: str | None = None,
        username: str | None = None,
    ) -> t.Self: ...
    def with_fragment(self, fragment: str | None = None) -> t.Self: ...
    def with_host(self, host: str | None = None) -> t.Self: ...
    def with_ip_host(
        self, address: IPv4Address | IPv6Address | Ipv4Addr | Ipv6Addr | IpAddr
    ) -> t.Self: ...
    def with_password(self, password: str | None = None) -> t.Self: ...
    def with_path(self, path: str) -> t.Self: ...
    def with_port(self, port: int | None = None) -> t.Self: ...
    def with_query(self, query: str | None = None) -> t.Self: ...
    def with_scheme(self, scheme: str) -> t.Self: ...
    def with_username(self, username: str) -> t.Self: ...

    # =========================================================================
    # OPERATORS/DUNDER
    # =========================================================================
    def __len__(self) -> int: ...
    def __truediv__(self, relative: str) -> t.Self: ...
    def __rtruediv__(self, relative: str) -> t.Self: ...
    def __lt__(self, other: t.Self) -> bool: ...
    def __le__(self, other: t.Self) -> bool: ...
    def __eq__(self, other: object) -> bool: ...
    def __ne__(self, other: object) -> bool: ...
    def __gt__(self, other: t.Self) -> bool: ...
    def __ge__(self, other: t.Self) -> bool: ...
    def __hash__(self) -> int: ...

    # =========================================================================
    # DEPRECATED
    # =========================================================================
    @deprecated(
        "`URL.replace_fragment` is deprecated; use `URL.with_fragment` instead [removal: v0.0.93]"
    )
    def replace_fragment(self, fragment: str | None = None) -> t.Self: ...
    @deprecated(
        "`URL.replace_host` is deprecated; use `URL.with_host` instead [removal: v0.0.93]"
    )
    def replace_host(self, host: str | None = None) -> t.Self: ...
    @deprecated(
        "`URL.replace_ip_host` is deprecated; use `URL.with_ip_host` instead [removal: v0.0.93]"
    )
    def replace_ip_host(
        self, address: IPv4Address | IPv6Address | Ipv4Addr | Ipv6Addr | IpAddr
    ) -> t.Self: ...
    @deprecated(
        "`URL.replace_password` is deprecated; use `URL.with_password` instead [removal: v0.0.93]"
    )
    def replace_password(self, password: str | None = None) -> t.Self: ...
    @deprecated(
        "`URL.replace_path` is deprecated; use `URL.with_path` instead [removal: v0.0.93]"
    )
    def replace_path(self, path: str) -> t.Self: ...
    @deprecated(
        "`URL.replace_port` is deprecated; use `URL.with_port` instead [removal: v0.0.93]"
    )
    def replace_port(self, port: int | None = None) -> t.Self: ...
    @deprecated(
        "`URL.replace_query` is deprecated; use `URL.with_query` instead [removal: v0.0.93]"
    )
    def replace_query(self, query: str | None = None) -> t.Self: ...
    @deprecated(
        "`URL.replace_scheme` is deprecated; use `URL.with_scheme` instead [removal: v0.0.93]"
    )
    def replace_scheme(self, scheme: str) -> t.Self: ...
    @deprecated(
        "`URL.replace_username` is deprecated; use `URL.with_username` instead [removal: v0.0.93]"
    )
    def replace_username(self, username: str) -> t.Self: ...
